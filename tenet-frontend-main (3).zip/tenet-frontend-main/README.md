# TENET Frontend

TENET - Training and Employment Network Enterprise Tracking System

## Getting started

1. Clone this repo `git clone git@github.com:GovAlta-EMU/tenet-frontend.git`
1. Ensure the use of the node version specified in `.nvmrc` file by running `nvm use 20` (if node v20 isn't installed run `nvm install 20`), [more info on nvm](https://github.com/nvm-sh/nvm)
1. Run `npm ci` to install dependencies

## Development

1. Run `npm run dev` and go to the listed port number of your localhost

## Design Token Usage

1. [Find token values here](https://design.alberta.ca/design-tokens)
1. Example: `color: var(--goa-color-text-default);`

## Lint

1. `npm run format:check` -- to get a list of errors

1. `npm run format` -- to format your code

1. `npm run lint` -- to lint your code

## Run tests

1. `npm test`

## Build

1. `npm run build`
