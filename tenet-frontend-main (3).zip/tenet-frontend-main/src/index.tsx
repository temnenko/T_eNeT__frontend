import * as ReactDOM from 'react-dom/client';
import '@abgov/web-components';
import { RouterProvider } from 'react-router-dom';
import './index.css';
import { StoreContext } from './contexts/store.context';
import { store } from './stores/root.store';
import { ModalProvider } from './contexts/modal.context';
import { loadConfig } from './config';
import { ConfigContext } from './contexts/config.context';
import { setApiClientInstance } from './services/api-client.service';
import router from './routes';

const root = ReactDOM.createRoot(document.getElementById('root')!);
loadConfig()
  .then((config) => {
    setApiClientInstance(config);
    root.render(
      <ConfigContext.Provider value={config}>
        <StoreContext.Provider value={store}>
          <ModalProvider>
            <RouterProvider router={router} />
          </ModalProvider>
        </StoreContext.Provider>
      </ConfigContext.Provider>,
    );
  })
  .catch(() => {
    root.render(<div>Error loading configuration</div>);
  });
