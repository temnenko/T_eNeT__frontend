import { createContext, useState, ReactNode, useMemo } from 'react';

export interface ModalContextType {
  showModal: (content: ReactNode) => void;
  hideModal: () => void;
  isVisible: boolean;
  modalContent: ReactNode;
}

const ModalContext = createContext<ModalContextType | undefined>(undefined);

interface ModalProviderProps {
  children: ReactNode;
}

export function ModalProvider({ children }: ModalProviderProps) {
  const [isVisible, setIsVisible] = useState<boolean>(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const showModal = (content: ReactNode) => {
    setModalContent(content);
    setIsVisible(true);
  };

  const hideModal = () => {
    setIsVisible(false);
    setModalContent(null);
  };

  const value = useMemo(
    () => ({
      showModal,
      hideModal,
      isVisible,
      modalContent,
    }),
    [isVisible, modalContent],
  );

  return (
    <ModalContext.Provider value={value}>
      {children}
      {isVisible && modalContent}
    </ModalContext.Provider>
  );
}

export { ModalContext };
