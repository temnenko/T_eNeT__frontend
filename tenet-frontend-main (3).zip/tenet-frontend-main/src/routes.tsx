import { createBrowserRouter, RouteObject } from 'react-router-dom';
import App from './App';
import DashboardView from './DashboardView';
import { AuthCallbackRoute } from './routes/auth/callback';
import { HealthRoute } from './routes/health';
import { LoginRoute } from './routes/login';
import UserForbidden from './routes/user-forbidden';
import AccessPending from './routes/access-pending';
import { Dashboard } from './common/components/dashboard/dashboard';
import { ProfileView } from './views/profile/profile.view';
import { ClientsListView } from './views/clients/clients-list-view';
import { UsersListView } from './views/users/users-list.view';
import { OrganizationView } from './common/components/organizations/organization-view';
import { AgreementContacts } from './common/components/agreements/agreement-contacts';
import { AssessmentSummary } from './common/components/clients/assessments/assessment-summary';
import { AssessmentView } from './common/components/clients/assessments/assessment-view';
import ClientContact from './common/components/clients/client-contact';
import ClientOverview from './common/components/clients/client-overview';
import { ClientDocuments } from './common/components/clients/documents/client-documents';
import { ClientHistoryView } from './common/components/clients/history/client-history';
import { LMDAVerificationView } from './common/components/clients/lmda-verification-summary';
import { ClientNoteView } from './common/components/clients/notes/client-note-view';
import { ServicePlanView } from './common/components/clients/service-plans/service-plan-view';
import { TransitionToEmployment } from './common/components/clients/service-plans/transition-to-employment';
import { AgreementContactGroups } from './common/components/forms/agreements/new/agreement-contact-groups.form';
import { AgreementDetailsForm } from './common/components/forms/agreements/new/agreement-details.form';
import { AgreementDocuments } from './common/components/forms/agreements/new/agreement-documents/agreement-documents.form';
import { AgreementProgramTypeForm } from './common/components/forms/agreements/new/agreement-program-type.form';
import AgreementReview from './common/components/forms/agreements/new/agreement-review-overview';
import AgreementDeliveryLocationsForm from './common/components/forms/agreements/new/delivery-locations/agreement-delivery-locations.form';
import { AssessmentFilesUploadForm } from './common/components/forms/clients/assessments/new/assessment-files-upload-form';
import AssessmentReview from './common/components/forms/clients/assessments/new/assessment-review';
import { AssessmentTypeForm } from './common/components/forms/clients/assessments/new/assessment-type-form';
import { EmploymentStatusForm } from './common/components/forms/clients/assessments/new/employment-status-form';
import { JobSearchStatusForm } from './common/components/forms/clients/assessments/new/job-search-status-form';
import { NeedsIdentificationForm } from './common/components/forms/clients/assessments/new/needs-identification-form';
import { ServiceRecommendationForm } from './common/components/forms/clients/assessments/new/service-recommendation-form';
import { AddConsentAcknowledgementForm } from './common/components/forms/clients/registration/add-consent-acknowledgement-form';
import ClientRegistrationReview from './common/components/forms/clients/registration/client-registration-review-overview';
import ContactDetailsForm from './common/components/forms/clients/registration/contact-details/contact-details-form';
import { DemographicForm } from './common/components/forms/clients/registration/demographic-form';
import FactorsForm from './common/components/forms/clients/registration/factors-form';
import PersonalDetailsForm from './common/components/forms/clients/registration/personal-details-form';
import { ComplianceForm } from './common/components/forms/organizations/enrollment/compliance.form';
import { FirstUserForm } from './common/components/forms/organizations/enrollment/first-user-form';
import OrganizationEnrollmentReview from './common/components/forms/organizations/enrollment/organization-enrollment-review';
import { OrganizationSubmitted } from './common/components/forms/organizations/enrollment/organization-submitted';
import { PrimaryDetails } from './common/components/forms/organizations/enrollment/primary-details';
import { UserAccessRequest } from './common/components/forms/users/access-request';
import UserAccessRequestTerms from './common/components/forms/users/access-request-terms';
import { ReviewAndUploadDocuments } from './common/components/forms/users/review-and-upload-documents';
import { AgreementDocumentsView } from './common/components/organizations/agreements/agreement-documents-view';
import { AgreementLocations } from './common/components/organizations/agreements/agreement-locations';
import OrganizationAgreementsTable from './common/components/organizations/organization-agreements-table';
import OrganizationCompliance from './common/components/organizations/organization-compliance';
import { OrganizationLocations } from './common/components/organizations/organization-locations';
import OrganizationOverview from './common/components/organizations/organization-overview';
import { OrganizationUserManagement } from './common/components/organizations/organization-user-management';
import { AgreementRoutes } from './routes/agreement-routes';
import AppGuard from './routes/app-guard';
import { ClientCreationRoutes } from './routes/client-creation-routes';
import { ClientRoutes } from './routes/client-routes';
import { DashboardRoutes } from './routes/dashboard-routes';
import { NewAgreementRoutes } from './routes/new-agreement-routes';
import { NewAssessmentRoutes } from './routes/new-assessment-routes';
import { OrganizationEnrollmentRoutes } from './routes/organization-enrollment-routes';
import { OrganizationRoutes } from './routes/organization-routes';
import { UserAccessRequestRoutes } from './routes/user-access-request-routes';
import { agreementFormsStepperPaths } from './types/agreement-forms';
import { assessmentFormStepperPaths } from './types/assessment-forms';
import { clientFormStepperPaths } from './types/client-forms';
import { organizationFormStepperPaths } from './types/organization-forms';
import { userFormsStepperPaths } from './types/user-forms';
import { ClientProfileView } from './views/clients/client-profile.view';
import { AgreementDetailsView } from './views/organizations/agreement-details-view';
import { OrganizationProfileView } from './views/organizations/organization-profile-view';
import { AccessRequestSubmittedView } from './views/users/access-request-submission.view';
import { GoaUserManagementView } from './views/users/goa-user-management.view';
import { AgreementDetailsOverview } from './common/components/agreements/agreement-details';
import { ClientFilesUploadForm } from './common/components/forms/clients/registration/client-files-upload-form';
import ProtectedRoute from './routes/auth/protected-route';
import ClientEmploymentHistorySummary from './common/components/clients/client-employment-history-summary';
import ClientEducationHistorySummary from './common/components/clients/client-education-history-summary';
import { Roles } from './types/role';
import { PerformanceTracking } from './common/components/agreements/performance-tracking';
import { AgreementReports } from './common/components/agreements/reports';

export const routes: RouteObject[] = [
  {
    path: '/',
    element: <App />,
    children: [
      { path: 'auth/callback', element: <AuthCallbackRoute /> },
      { path: 'health', element: <HealthRoute /> },
      { path: '/login', element: <LoginRoute /> },
      { path: '/', element: <LoginRoute /> },
    ],
  },
  {
    element: <AppGuard />,
    children: [
      {
        element: <DashboardView />,
        children: [
          {
            element: (
              <ProtectedRoute
                element={<DashboardRoutes />}
                allowedRoles={[Roles.SUPER_ADMIN, Roles.PROVIDER_SUPERVISOR, Roles.PROVIDER_USER, Roles.CSC]}
              />
            ),
            children: [
              { path: 'dashboard', element: <Dashboard /> },
              { path: 'profile', element: <ProfileView /> },
              {
                path: 'clients',
                element: <ClientsListView />,
              },
              {
                path: 'users',
                element: <ProtectedRoute element={<UsersListView />} allowedRoles={[Roles.SUPER_ADMIN]} />,
              },
              {
                path: 'users/:id',
                element: <ProtectedRoute element={<ProfileView />} allowedRoles={[Roles.SUPER_ADMIN]} />,
              },
              {
                path: 'organizations',
                element: (
                  <ProtectedRoute
                    element={<OrganizationView />}
                    allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC, Roles.PROVIDER_SUPERVISOR, Roles.PROVIDER_USER]}
                  />
                ),
              },
            ],
          },
        ],
      },
      {
        element: (
          <ProtectedRoute
            element={<ClientCreationRoutes />}
            allowedRoles={[Roles.SUPER_ADMIN, Roles.PROVIDER_USER, Roles.PROVIDER_SUPERVISOR]}
          />
        ),
        children: [
          { path: clientFormStepperPaths.personal, element: <PersonalDetailsForm /> },
          { path: clientFormStepperPaths.demographics, element: <DemographicForm /> },
          { path: clientFormStepperPaths.factors, element: <FactorsForm /> },
          { path: clientFormStepperPaths.consent, element: <AddConsentAcknowledgementForm /> },
          { path: clientFormStepperPaths.contact, element: <ContactDetailsForm /> },
          { path: clientFormStepperPaths.files, element: <ClientFilesUploadForm /> },
          { path: clientFormStepperPaths.review, element: <ClientRegistrationReview /> },
        ],
      },
      {
        element: (
          <ProtectedRoute
            element={<NewAssessmentRoutes />}
            allowedRoles={[Roles.SUPER_ADMIN, Roles.PROVIDER_USER, Roles.PROVIDER_SUPERVISOR, Roles.CSC]}
          />
        ),
        children: [
          { path: assessmentFormStepperPaths.type, element: <AssessmentTypeForm /> },
          { path: assessmentFormStepperPaths.need, element: <NeedsIdentificationForm /> },
          { path: assessmentFormStepperPaths.employment, element: <EmploymentStatusForm /> },
          { path: assessmentFormStepperPaths.jobSearch, element: <JobSearchStatusForm /> },
          { path: assessmentFormStepperPaths.service, element: <ServiceRecommendationForm /> },
          { path: assessmentFormStepperPaths.files, element: <AssessmentFilesUploadForm /> },
          { path: assessmentFormStepperPaths.review, element: <AssessmentReview /> },
        ],
      },
      {
        element: <ClientRoutes />,
        children: [
          {
            element: (
              <ProtectedRoute
                element={<ClientProfileView />}
                allowedRoles={[Roles.SUPER_ADMIN, Roles.PROVIDER_USER, Roles.PROVIDER_SUPERVISOR, Roles.CSC]}
              />
            ),
            children: [
              { path: 'clients/:id/overview', element: <ClientOverview /> },
              { path: 'clients/:id/all-assessments', element: <AssessmentView /> },
              { path: 'clients/:id/assessments/:assessmentId', element: <AssessmentSummary /> },
              { path: 'clients/:id/employments', element: <ClientEmploymentHistorySummary /> },
              { path: 'clients/:id/educations', element: <ClientEducationHistorySummary /> },
              { path: 'clients/:id/contact', element: <ClientContact /> },
              { path: 'clients/:id/lmda', element: <LMDAVerificationView /> },
              { path: 'clients/:id/documents', element: <ClientDocuments /> },
              { path: 'clients/:id/service-plans', element: <ServicePlanView /> },
              {
                path: 'clients/:id/service-plans/transition-to-employment/:serviceId?',
                element: <TransitionToEmployment />,
              },
              { path: 'clients/:id/notes', element: <ClientNoteView /> },
              { path: 'clients/:id/history', element: <ClientHistoryView /> },
            ],
          },
        ],
      },
      {
        element: (
          <ProtectedRoute element={<OrganizationEnrollmentRoutes />} allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC]} />
        ),
        children: [
          { path: organizationFormStepperPaths.primary, element: <PrimaryDetails /> },
          { path: organizationFormStepperPaths.firstUser, element: <FirstUserForm /> },
          { path: organizationFormStepperPaths.files, element: <ComplianceForm /> },
          { path: organizationFormStepperPaths.review, element: <OrganizationEnrollmentReview /> },
        ],
      },
      {
        path: organizationFormStepperPaths.submit,
        element: <ProtectedRoute element={<OrganizationSubmitted />} allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC]} />,
      },
      {
        element: <OrganizationRoutes />,
        children: [
          {
            element: <OrganizationProfileView />,
            children: [
              {
                path: 'organizations/:id',
                element: (
                  <ProtectedRoute
                    element={<OrganizationOverview />}
                    allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC, Roles.PROVIDER_SUPERVISOR, Roles.PROVIDER_USER]}
                  />
                ),
              },

              {
                path: 'organizations/:id/agreements',
                element: (
                  <ProtectedRoute
                    element={<OrganizationAgreementsTable />}
                    allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC, Roles.PROVIDER_SUPERVISOR, Roles.PROVIDER_USER]}
                  />
                ),
              },

              {
                path: 'organizations/:id/user-management',
                element: (
                  <ProtectedRoute
                    element={<OrganizationUserManagement />}
                    allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC]}
                  />
                ),
              },

              { path: 'organizations/:id/compliance', element: <OrganizationCompliance /> },
              {
                path: 'organizations/:id/compliance',
                element: (
                  <ProtectedRoute
                    element={<OrganizationCompliance />}
                    allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC, Roles.PROVIDER_SUPERVISOR]}
                  />
                ),
              },

              {
                path: 'organizations/:id/locations',
                element: (
                  <ProtectedRoute
                    element={<OrganizationLocations />}
                    allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC, Roles.PROVIDER_SUPERVISOR]}
                  />
                ),
              },
            ],
          },
        ],
      },
      {
        element: (
          <ProtectedRoute
            element={<AgreementRoutes />}
            allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC, Roles.PROVIDER_SUPERVISOR, Roles.PROVIDER_USER]}
          />
        ),
        children: [
          {
            element: <AgreementDetailsView />,
            children: [
              { path: 'agreements/:id', element: <AgreementDetailsOverview /> },
              { path: 'agreements/:id/contacts', element: <AgreementContacts /> },
              { path: 'agreements/:id/locations', element: <AgreementLocations /> },
              { path: 'agreements/:id/performance-tracking', element: <PerformanceTracking /> },
              { path: 'agreements/:id/reports', element: <AgreementReports /> },
              {
                path: 'agreements/:id/documents',
                element: (
                  <ProtectedRoute
                    element={<AgreementDocumentsView />}
                    allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC, Roles.PROVIDER_SUPERVISOR]}
                  />
                ),
              },
            ],
          },
        ],
      },
      {
        element: <ProtectedRoute element={<NewAgreementRoutes />} allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC]} />,
        children: [
          { path: agreementFormsStepperPaths.programType, element: <AgreementProgramTypeForm /> },
          { path: agreementFormsStepperPaths.agreementDetails, element: <AgreementDetailsForm /> },
          { path: agreementFormsStepperPaths.review, element: <AgreementReview /> },
          { path: agreementFormsStepperPaths.contactGroup, element: <AgreementContactGroups /> },
          { path: agreementFormsStepperPaths.deliveryLocations, element: <AgreementDeliveryLocationsForm /> },
          { path: agreementFormsStepperPaths.documents, element: <AgreementDocuments /> },
        ],
      },
      {
        element: (
          <ProtectedRoute
            element={<UserAccessRequestRoutes />}
            allowedRoles={[Roles.SUPER_ADMIN, Roles.CSC, Roles.STANDARD]}
          />
        ),

        children: [
          {
            path: userFormsStepperPaths.userDetails,
            element: <UserAccessRequest />,
          },
          {
            path: userFormsStepperPaths.requestDetails,
            element: <UserAccessRequestTerms />,
          },
          {
            path: userFormsStepperPaths.review,
            element: <ReviewAndUploadDocuments />,
          },
        ],
      },
      {
        path: 'goa',
        element: <ProtectedRoute element={<GoaUserManagementView />} allowedRoles={[Roles.SUPER_ADMIN]} />,
      },
      {
        path: 'user/access/request-submitted/:id',
        element: <ProtectedRoute element={<AccessRequestSubmittedView />} allowedRoles={[Roles.STANDARD]} />,
      },
    ],
  },
  { path: '/forbidden', element: <UserForbidden /> },
  { path: '/access-pending', element: <AccessPending /> },
];

const router = createBrowserRouter(routes);
export default router;
