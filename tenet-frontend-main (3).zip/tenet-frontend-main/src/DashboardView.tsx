import { GoAPageBlock, GoAOneColumnLayout } from '@abgov/react-components';
import { Outlet, useLocation } from 'react-router-dom';

import AppHeader from './common/components/app-header/app-header';
import AppFooter from './common/components/app-footer/app-footer';
import AppHeroBanner from './common/components/app-hero-banner/app-hero-banner';

export function DashboardView() {
  const location = useLocation();
  const showHeroBanner = location.pathname === '/';
  return (
    <GoAOneColumnLayout>
      <AppHeader />
      {showHeroBanner && <AppHeroBanner />}

      <GoAPageBlock width="1200px">
        <Outlet />
      </GoAPageBlock>

      <AppFooter />
    </GoAOneColumnLayout>
  );
}

export default DashboardView;
