import { observer } from 'mobx-react-lite';
import { GoATwoColumnLayout } from '@abgov/react-components';
import { Outlet, Navigate } from 'react-router-dom';

import { useStore } from '../hooks/use-store.hook';
import AppHeader from '../common/components/app-header/app-header';
import AppFooter from '../common/components/app-footer/app-footer';
import useOrganizationSideMenu from '../hooks/use-organization-sidemenu';

export const OrganizationRoutes = observer(() => {
  const {
    authStore: { isAuthenticated },
  } = useStore();

  const sideMenu = useOrganizationSideMenu();

  return isAuthenticated ? (
    <GoATwoColumnLayout navColumnWidth="35ch" nav={sideMenu} header={<AppHeader />} footer={<AppFooter />}>
      <Outlet />
    </GoATwoColumnLayout>
  ) : (
    <Navigate to="/" />
  );
});
