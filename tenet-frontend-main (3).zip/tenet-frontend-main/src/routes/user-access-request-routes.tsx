import { observer } from 'mobx-react-lite';
import { GoAPageBlock, GoAOneColumnLayout, GoAIcon, GoABlock, GoASpacer } from '@abgov/react-components';
import { Navigate, NavLink, Outlet } from 'react-router-dom';

import AppHeader from '../common/components/app-header/app-header';
import AppFooter from '../common/components/app-footer/app-footer';
import { useStore } from '../hooks/use-store.hook';
import { UserAccessRequestHeader } from '../common/components/users/user-access-request-header';
import { UserAccessRequestFormsStepper } from '../common/components/forms/users/user-access-request-forms-stepper';

export const UserAccessRequestRoutes = observer(() => {
  const {
    authStore: { isAuthenticated },
  } = useStore();

  return isAuthenticated ? (
    <GoAOneColumnLayout>
      <AppHeader />

      <GoAPageBlock width="1086px">
        <div className="stepper-form-container">
          <NavLink className="" to="/">
            <GoABlock gap="5" alignment="center">
              <GoAIcon type="arrow-back" />
              <span>Back to Home</span>
            </GoABlock>
          </NavLink>
          <GoASpacer vSpacing="s" />
          <UserAccessRequestHeader />
          <UserAccessRequestFormsStepper />
          <div className="stepper-form-main">
            <Outlet />
          </div>
        </div>
      </GoAPageBlock>

      <AppFooter />
    </GoAOneColumnLayout>
  ) : (
    <Navigate to="/" />
  );
});
