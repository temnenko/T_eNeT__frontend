import { observer } from 'mobx-react-lite';
import { GoAPageBlock, GoAOneColumnLayout } from '@abgov/react-components';
import { Navigate, Outlet } from 'react-router-dom';

import AppHeader from '../common/components/app-header/app-header';
import AppFooter from '../common/components/app-footer/app-footer';
import { useStore } from '../hooks/use-store.hook';
import { NewAssessmentHeader } from '../common/components/clients/assessments/new-assessment-header';
import { NewAssessmentFormsStepper } from '../common/components/forms/clients/assessments/new/new-assessment-forms-stepper';

export const NewAssessmentRoutes = observer(() => {
  const {
    authStore: { isAuthenticated },
  } = useStore();

  return isAuthenticated ? (
    <GoAOneColumnLayout>
      <AppHeader />

      <GoAPageBlock width="1086px">
        <div className="stepper-form-container">
          <NewAssessmentHeader />
          <NewAssessmentFormsStepper />
          <div className="assessment-form-main stepper-form-main">
            <Outlet />
          </div>
        </div>
      </GoAPageBlock>

      <AppFooter />
    </GoAOneColumnLayout>
  ) : (
    <Navigate to="/" />
  );
});
