import { observer } from 'mobx-react-lite';

import { Outlet, Navigate } from 'react-router-dom';
import { useStore } from '../hooks/use-store.hook';

export const DashboardRoutes = observer(() => {
  const {
    authStore: { isAuthenticated },
  } = useStore();

  return isAuthenticated ? <Outlet data-testid="dashboardRoute" /> : <Navigate to="/" />;
});
