/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable no-console */
import { useEffect, useState } from 'react';
import axios from 'axios';

export function HealthRoute() {
  const [applicationStatus, setApplicationStatus] = useState('Loading...');
  const [databaseStatus, setDatabaseStatus] = useState('Loading...');

  useEffect(() => {
    const fetchHealthData = () => {
      axios
        .get(`${import.meta.env?.VITE_TENET_API_URL}/health`)
        .then((response: any) => {
          const { data } = response;
          setApplicationStatus(data.applicationStatus || 'UP');
          setDatabaseStatus(data.databaseStatus);
        })
        .catch((error: any) => {
          console.error('Error fetching health data:', error);

          if (error.response) {
            if (error.response.status === 500) {
              setApplicationStatus('UP');
              setDatabaseStatus('Down');
            }
          } else {
            setApplicationStatus('Down');
            setDatabaseStatus('Unknown');
          }
        });
    };
    fetchHealthData();
  }, []);

  return (
    <main>
      <h1>TENET Health</h1>

      <h2>
        Application status:
        {applicationStatus}
      </h2>
      <h2>
        Database status:
        {databaseStatus}
      </h2>
    </main>
  );
}
