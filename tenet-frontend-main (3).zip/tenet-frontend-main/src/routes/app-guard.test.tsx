import { render } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { useStore } from '../hooks/use-store.hook';
import AuthGuard from './app-guard';

// Mock the useStore hook
jest.mock('../hooks/use-store.hook');

describe('AuthGuard', () => {
  it('should render the Outlet component if status is ACTIVE', () => {
    // Mock the store to return an active status
    (useStore as jest.Mock).mockReturnValue({
      userStore: { status: 'ACTIVE' },
    });

    const { container } = render(
      <MemoryRouter initialEntries={['/protected-route']}>
        <Routes>
          <Route path="/access-pending" element={<div>Access Pending</div>} />
          <Route element={<AuthGuard />}>
            <Route path="/protected-route" element={<div>Protected Route</div>} />
          </Route>
        </Routes>
      </MemoryRouter>,
    );

    expect(container.textContent).toBe('Protected Route');
  });
});
