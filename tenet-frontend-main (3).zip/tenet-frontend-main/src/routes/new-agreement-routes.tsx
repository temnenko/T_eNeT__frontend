import { observer } from 'mobx-react-lite';
import { GoAPageBlock, GoAOneColumnLayout, GoAIcon, GoABlock, GoASpacer } from '@abgov/react-components';
import { Navigate, NavLink, Outlet } from 'react-router-dom';

import AppHeader from '../common/components/app-header/app-header';
import AppFooter from '../common/components/app-footer/app-footer';
import { useStore } from '../hooks/use-store.hook';
import { NewAgreementHeader } from '../common/components/forms/agreements/new-agreement-header';
import { NewAgreementStepper } from '../common/components/forms/agreements/new/new-agreement-stepper';

export const NewAgreementRoutes = observer(() => {
  const {
    authStore: { isAuthenticated },
    organizationStore: { selectedOrganization },
  } = useStore();

  return isAuthenticated ? (
    <GoAOneColumnLayout>
      <AppHeader />

      <GoAPageBlock width="1086px">
        <div className="stepper-form-container">
          <NavLink className="" to={`/organizations/${selectedOrganization?.id}/agreements`}>
            <GoABlock gap="5" alignment="center">
              <GoAIcon type="arrow-back" />
              <span>Back</span>
            </GoABlock>
          </NavLink>
          <GoASpacer vSpacing="l" />
          <NewAgreementHeader />
          <NewAgreementStepper />
          <div className="stepper-form-main">
            <Outlet />
          </div>
        </div>
      </GoAPageBlock>

      <AppFooter />
    </GoAOneColumnLayout>
  ) : (
    <Navigate to="/" />
  );
});
