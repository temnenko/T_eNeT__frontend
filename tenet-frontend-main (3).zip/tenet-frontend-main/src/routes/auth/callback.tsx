import { useLocation, useNavigate } from 'react-router-dom';
import { GoABlock, GoACircularProgress } from '@abgov/react-components';

import { useEffect } from 'react';
import { useStore } from '../../hooks/use-store.hook';

export function AuthCallbackRoute() {
  const location = useLocation();
  const store = useStore();
  const { getAuthInfo } = store.userStore;
  const navigate = useNavigate();

  const getQueryParam = (param: string) => new URLSearchParams(location.search).get(param);

  const code = getQueryParam('code') as string;
  const state = getQueryParam('state') as string;

  useEffect(() => {
    getAuthInfo({ code, state })
      .then(() => {
        navigate('/dashboard');
      })
      .catch(() => {
        navigate('/forbidden');
      });
  }, [code, getAuthInfo, navigate, state]);

  return (
    <GoABlock alignment="center" direction="column">
      <GoACircularProgress message="Authenticating..." visible />
    </GoABlock>
  );
}
