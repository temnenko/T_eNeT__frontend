/* eslint-disable react/function-component-definition */
import { Navigate } from 'react-router-dom';
import { useStore } from '../../hooks/use-store.hook';

interface ProtectedRouteProps {
  element: JSX.Element;
  allowedRoles: string[];
}

const ProtectedRoute = ({ element, allowedRoles }: ProtectedRouteProps) => {
  const {
    userStore: { role },
  } = useStore();

  if (!role) {
    return <Navigate to="/login" replace />;
  }

  if (!allowedRoles.includes(role)) {
    return <Navigate to="/forbidden" replace />;
  }

  return element;
};

export default ProtectedRoute;
