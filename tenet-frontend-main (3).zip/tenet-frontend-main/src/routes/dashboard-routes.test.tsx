import '@testing-library/jest-dom';
import { getByTestId, render } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';

import * as hooks from '../hooks/use-store.hook';
import RootStore from '../stores/root.store';
import { DashboardRoutes } from './dashboard-routes';

describe('DashboardRoutes', () => {
  const mockStore = {
    userStore: { displayName: 'Doe', logout: () => null },
    authStore: {
      accessToken: 'token',
      get isAuthenticated() {
        return !!this.accessToken;
      },
    },
  } as unknown as RootStore;

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('should render DashboardRoutes', () => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: dashboardRoutes } = render(
      <BrowserRouter>
        <DashboardRoutes />
      </BrowserRouter>,
    );

    expect(dashboardRoutes).toBeInTheDocument();
  });

  test('should render side menu items when user is not logged-in', () => {
    mockStore.authStore.accessToken = '';

    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: dashboardRoutes } = render(
      <BrowserRouter>
        <DashboardRoutes />
      </BrowserRouter>,
    );

    expect(dashboardRoutes).toBeInTheDocument();
    expect(() => getByTestId(dashboardRoutes, 'dashboardRoute')).toThrow();
  });
});
