import { observer } from 'mobx-react-lite';
import { GoATwoColumnLayout } from '@abgov/react-components';
import { Outlet, Navigate } from 'react-router-dom';

import { useStore } from '../hooks/use-store.hook';
import AppHeader from '../common/components/app-header/app-header';
import AppFooter from '../common/components/app-footer/app-footer';
import useClientSideMenu from '../hooks/use-client-side-menu.hook';

export const ClientRoutes = observer(() => {
  const {
    authStore: { isAuthenticated },
  } = useStore();

  const sideMenu = useClientSideMenu();

  return isAuthenticated ? (
    <GoATwoColumnLayout
      maxContentWidth="1380px"
      navColumnWidth="35ch"
      nav={sideMenu}
      header={<AppHeader />}
      footer={<AppFooter />}
    >
      <Outlet />
    </GoATwoColumnLayout>
  ) : (
    <Navigate to="/" />
  );
});
