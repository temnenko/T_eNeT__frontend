import { observer } from 'mobx-react-lite';
import { GoAPageBlock, GoAOneColumnLayout, GoAIcon, GoABlock, GoASpacer } from '@abgov/react-components';
import { Navigate, NavLink, Outlet } from 'react-router-dom';

import AppHeader from '../common/components/app-header/app-header';
import AppFooter from '../common/components/app-footer/app-footer';
import { useStore } from '../hooks/use-store.hook';
import { OrganizationEnrollmentHeader } from '../common/components/organizations/organization-enrollment-header';
import { OrganizationEnrollmentFormsStepper } from '../common/components/forms/organizations/enrollment/organization-enrollment-forms-stepper';

export const OrganizationEnrollmentRoutes = observer(() => {
  const {
    authStore: { isAuthenticated },
  } = useStore();

  return isAuthenticated ? (
    <GoAOneColumnLayout>
      <AppHeader />

      <GoAPageBlock width="1086px">
        <div className="stepper-form-container">
          <NavLink className="" to="/organizations">
            <GoABlock gap="5" alignment="center">
              <GoAIcon type="arrow-back" />
              <span>Back to my applications</span>
            </GoABlock>
          </NavLink>
          <GoASpacer vSpacing="s" />
          <OrganizationEnrollmentHeader />
          <OrganizationEnrollmentFormsStepper />
          <div className="stepper-form-main">
            <Outlet />
          </div>
        </div>
      </GoAPageBlock>

      <AppFooter />
    </GoAOneColumnLayout>
  ) : (
    <Navigate to="/" />
  );
});
