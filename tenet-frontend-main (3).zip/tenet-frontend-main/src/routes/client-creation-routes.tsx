import { observer } from 'mobx-react-lite';
import { GoAPageBlock, GoAOneColumnLayout } from '@abgov/react-components';
import { Navigate, Outlet } from 'react-router-dom';

import AppHeader from '../common/components/app-header/app-header';
import AppFooter from '../common/components/app-footer/app-footer';
import { ClientCreationHeader } from '../common/components/clients/client-creation-header';
import { ClientRegistrationFormsStepper } from '../common/components/forms/clients/registration/client-registration-forms-stepper';
import { useStore } from '../hooks/use-store.hook';

export const ClientCreationRoutes = observer(() => {
  const {
    authStore: { isAuthenticated },
  } = useStore();

  return isAuthenticated ? (
    <GoAOneColumnLayout>
      <AppHeader />

      <GoAPageBlock width="1086px">
        <div className="stepper-form-container">
          <ClientCreationHeader />
          <ClientRegistrationFormsStepper />
          <div className="stepper-form-main">
            <Outlet />
          </div>
        </div>
      </GoAPageBlock>

      <AppFooter />
    </GoAOneColumnLayout>
  ) : (
    <Navigate to="/" />
  );
});
