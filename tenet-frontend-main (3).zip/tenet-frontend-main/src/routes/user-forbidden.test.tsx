import '@testing-library/jest-dom';
import { getByTestId, render } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';

import * as hooks from '../hooks/use-store.hook';
import RootStore from '../stores/root.store';
import UserForbidden from './user-forbidden';

describe('UserForbidden', () => {
  const mockStore = {
    permissionStore: { isSuperAdmin: false },
    userStore: { displayName: 'Doe', logout: () => null },
    authStore: {
      accessToken: 'token',
      get isAuthenticated() {
        return !!this.accessToken;
      },
    },
  } as unknown as RootStore;

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('should render UserForbidden', () => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: userForbidden } = render(
      <BrowserRouter>
        <UserForbidden />
      </BrowserRouter>,
    );
    const header = getByTestId(userForbidden, 'forbidden-header');
    const heading = getByTestId(userForbidden, 'forbidden-heading');
    const text = getByTestId(userForbidden, 'forbidden-text');
    const bg403 = getByTestId(userForbidden, 'forbidden-403');

    expect(userForbidden).toBeInTheDocument();
    expect(header).toHaveTextContent('TENET access not granted');
    expect(heading).toHaveTextContent(`Oops! It looks like you don't have permission to access this area.`);
    expect(text).toHaveTextContent(
      `For assistance, please reach out to your CSC if you are a service provider, or your supervisor if you are a GoA employee. We're here to help!`,
    );
    expect(bg403).toBeInTheDocument();
  });
});
