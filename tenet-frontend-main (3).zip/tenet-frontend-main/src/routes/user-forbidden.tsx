/* eslint-disable jsx-a11y/alt-text */
import { GoABlock, GoAButton, GoAPageBlock } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';

import AppHeroBanner from '../common/components/app-hero-banner/app-hero-banner';
import AppHeader from '../common/components/app-header/app-header';

export function UserForbidden() {
  const navigate = useNavigate();

  return (
    <>
      <AppHeader />
      <AppHeroBanner />
      <GoAPageBlock width="480px">
        <GoABlock gap="m" alignment="center" direction="column">
          <h2 data-testid="forbidden-header" className="forbidden-header">
            TENET access not granted
          </h2>
          <span
            data-testid="forbidden-heading"
            className="forbidden-text forbidden-heading"
          >{`Oops! It looks like you don't have permission to access this area.`}</span>
          <span
            data-testid="forbidden-text"
            className="forbidden-text"
          >{`For assistance, please reach out to your CSC if you are a service provider, or your supervisor if you are a GoA employee. We're here to help!`}</span>
          <GoAButton data-testid="forbidden-go-back" size="compact" type="primary" onClick={() => navigate('/')}>
            <ion-icon name="home-outline" />
            {` Go back`}
          </GoAButton>
          <br />
        </GoABlock>
      </GoAPageBlock>
      <section data-testid="forbidden-403" className="forbidden-403">
        <img src="../../403.svg" />
      </section>
    </>
  );
}

export default UserForbidden;
