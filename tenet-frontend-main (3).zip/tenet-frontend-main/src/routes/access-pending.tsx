import { GoABadge, GoABlock, GoAButton, GoAContainer, GoAPageBlock, GoAText } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';

import AppHeader from '../common/components/app-header/app-header';
import { useStore } from '../hooks/use-store.hook';
import { userFormsStepperPaths } from '../types/user-forms';

export function AccessPending() {
  const {
    userStore: { displayName, organizationName, status },
  } = useStore();

  const navigate = useNavigate();

  const getBadgeClass = () => {
    switch (status) {
      case 'INACTIVE':
        return 'information';
      case 'ACCESS_REQUEST_STARTED':
        return 'important';
      case 'ACCESS_REQUEST_COMPLETED':
        return 'success';
      default:
        return 'information';
    }
  };

  const getContent = () => {
    switch (status) {
      case 'INACTIVE':
        return 'Not started';
      case 'ACCESS_REQUEST_STARTED':
        return 'Not submitted';
      case 'ACCESS_REQUEST_COMPLETED':
        return 'Under review';
      default:
        return 'Inactive';
    }
  };

  const getButtonText = () => {
    switch (status) {
      case 'INACTIVE':
        return 'Start';
      case 'ACCESS_REQUEST_STARTED':
        return 'Continue';
      case 'ACCESS_REQUEST_COMPLETED':
        return 'Cancel';
      default:
        return 'Start';
    }
  };

  const getButtonType = () => {
    switch (status) {
      case 'INACTIVE':
        return 'primary';
      case 'ACCESS_REQUEST_STARTED':
        return 'secondary';
      case 'ACCESS_REQUEST_COMPLETED':
        return 'tertiary';
      default:
        return 'primary';
    }
  };

  return (
    <>
      <AppHeader />
      <GoAPageBlock width="736px">
        <GoABlock gap="m" alignment="center" direction="column">
          <GoAText size="heading-l" mt="m">
            Good afternoon, {displayName}
          </GoAText>
          <div>
            <GoAText size="body-l" mb="m">
              Welcome to TENET! Let’s start your application to obtain a new user role with {organizationName}.
            </GoAText>
            <GoAText size="body-m" mb="m">
              All users who are not current employees of the Government of Alberta are required to upload the results of
              a recent criminal record check (CRC) and proof of FOIP training completion.
            </GoAText>
            <GoAText size="body-m" mb="m">
              Please note, you can save your application part way through and return to finish it later.
            </GoAText>
            <GoAText size="body-m" mb="m">
              Two types of personal information will be collected by TENET.
            </GoAText>
            <GoAText size="body-m" mb="m">
              The first is your personal information. This collection is authorized by section 33(c) of the Freedom of
              Information and Protection of Privacy Act for the purpose of determining your authority to access and use
              Tenet, and for other program purposes.
            </GoAText>
            <GoAText size="body-m" mb="m">
              The second is personal information of clients. This personal information was collected by the organization
              you are associated with, as our contractor, for the purpose of registration and determining eligibility
              for government-funded training and employment programs in Alberta. This personal information is used for
              eligibility verification, the delivery of programs, benefits or services and to assess and evaluate the
              effectiveness of programs and services offered by the Government of Alberta. This information is to be
              kept confidential by you and your organization.
            </GoAText>
            <GoAText size="heading-xs" mb="xs">
              For questions about the collection of personal information, contact:
            </GoAText>
            <GoAText size="body-m" mb="none" mt="none">
              Training and Employment Program Specialist:
            </GoAText>
            <GoAText size="body-m" mb="none" mt="none">
              Email:
              <GoAButton
                type="tertiary"
                onClick={() => {
                  window.location.href = 'mailto:Jet.ProgramsSpecialist@gov.ab.ca';
                }}
              >
                Jet.ProgramsSpecialist@gov.ab.ca
              </GoAButton>
            </GoAText>
            <GoAText size="body-m" mb="m">
              Address: Training and Employment Services, 2nd Floor, 9925 109 St NW, Edmonton, AB T5J 3M9
            </GoAText>
          </div>
          <div className="w-100">
            <GoAContainer accent="filled" padding="relaxed">
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <GoABadge type={getBadgeClass()} content={getContent()} />
                </div>
                <div>Request access to TENET</div>
                <div>{organizationName}</div>
                <div>
                  <GoAButton
                    type={getButtonType()}
                    onClick={() => {
                      navigate(`${userFormsStepperPaths.userDetails}`);
                    }}
                  >
                    {getButtonText()}
                  </GoAButton>
                </div>
              </div>
            </GoAContainer>
          </div>
          <br />
        </GoABlock>
      </GoAPageBlock>
    </>
  );
}

export default AccessPending;
