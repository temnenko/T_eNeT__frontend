import { Navigate, Outlet } from 'react-router-dom';
import { useStore } from '../hooks/use-store.hook';
import { UserStatus } from '../types/user';
import { useAutoLogout } from '../hooks/use-auto-logout';

function AuthGuard() {
  useAutoLogout();

  const {
    userStore: { status },
  } = useStore();

  if (status === UserStatus.INACTIVE || status === UserStatus.DENIED) {
    return <Navigate to="/forbidden" replace />;
  }

  if (status === UserStatus.ACCESS_PENDING && window.location.pathname === '/dashboard') {
    return <Navigate to="/access-pending" replace />;
  }

  return <Outlet />;
}

export default AuthGuard;
