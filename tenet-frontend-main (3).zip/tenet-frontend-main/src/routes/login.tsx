import { useCallback } from 'react';
import { GoAButton, GoAContainer, GoAGrid, GoASpacer } from '@abgov/react-components';
import { Link } from 'react-router-dom';
// import { observer } from 'mobx-react-lite';

import { useStore } from '../hooks/use-store.hook';

export function LoginRoute() {
  const store = useStore();
  const { getLoginUrl } = store.authStore;

  const handleLogin = useCallback(
    async (idpHint: string) => {
      try {
        await getLoginUrl(idpHint);
      } catch (error) {
        // eslint-disable-next-line no-console
        console.error('Login failed:', error);
      }
    },
    [getLoginUrl],
  );

  return (
    <main>
      <GoASpacer vSpacing="l" />
      <span className="tenet-overview">Overview</span>
      <GoASpacer vSpacing="l" />
      <span>{`TENET's development is iterative, features and programs will be added in a phased approach.`}</span>
      <ul className="margin-left-10">
        <li>
          Contract Providers delivering Transition to Employment Services will use TENET for service management
          activities.
        </li>
        <li>Mobius continues to be used for all other training and employment contract types.</li>
      </ul>
      <div className="tenet-font-size-20">
        <span>Questions, support or to report a technical issue, contact us at </span>
        <a href="mailto:jet.tenet@gov.ab.ca">[jet.tenet@gov.ab.ca]</a>
      </div>
      <GoASpacer vSpacing="xl" />
      <span className="tenet-overview">Sign in</span>
      <GoASpacer vSpacing="l" />
      <GoAGrid gap="m" minChildWidth="400px">
        <GoAContainer accent="thin" type="interactive">
          <div>
            <h3>External Provider Access</h3>
            <div>Sign in with your Alberta.ca Account for Organizations</div>
            <div>
              <ul className="margin-left-10">
                <li>Permission to access TENET is authorized by your Contract Services Coordinator</li>
              </ul>
            </div>

            <GoAButton type="primary" onClick={() => handleLogin('business')}>
              <span className="sign-in-btn" id="business-sign-in-btn">
                Sign In
              </span>
            </GoAButton>
          </div>
        </GoAContainer>

        <GoAContainer accent="thin" type="interactive">
          <div>
            <h3>GoA Employee Access</h3>
            <div>Sign in with your Government of Alberta account</div>
            <div>
              <ul className="margin-left-10">
                <li>Permission to access TENET is authorized by your supervisor/manager</li>
              </ul>
            </div>
            <br />
            <GoAButton type="primary" onClick={() => handleLogin('government')}>
              <span className="sign-in-btn" id="goa-sign-in-btn">
                Sign In
              </span>
            </GoAButton>
          </div>
        </GoAContainer>
      </GoAGrid>
      <div>
        Need an account? <Link to="/">Create account</Link>
      </div>
      <div>
        Additional information about Alberta.ca Account for Organizations can be found{' '}
        <a href="https://www.alberta.ca/alberta-ca-account-for-organizations" target="_blank" rel="noreferrer">
          here
        </a>
      </div>
      <GoASpacer vSpacing="l" />
    </main>
  );
}
