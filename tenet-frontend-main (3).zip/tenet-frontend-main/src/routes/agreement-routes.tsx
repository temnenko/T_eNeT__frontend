import { useEffect } from 'react';
import { observer } from 'mobx-react-lite';
import { GoATwoColumnLayout } from '@abgov/react-components';
import { Outlet, Navigate, useParams } from 'react-router-dom';

import { useStore } from '../hooks/use-store.hook';
import AppHeader from '../common/components/app-header/app-header';
import AppFooter from '../common/components/app-footer/app-footer';
import useAgreementSideMenu from '../common/components/organizations/agreements/hooks/use-agreement-sidemenu';

export const AgreementRoutes = observer(() => {
  const {
    authStore: { isAuthenticated },
    agreementStore: { getAgreementById },
  } = useStore();
  const { id } = useParams();

  const sideMenu = useAgreementSideMenu();

  useEffect(() => {
    const fetchAgreement = async () => {
      if (id) {
        await getAgreementById(id);
      }
    };

    fetchAgreement();
  }, [getAgreementById, id]);

  return isAuthenticated ? (
    <GoATwoColumnLayout navColumnWidth="35ch" nav={sideMenu} header={<AppHeader />} footer={<AppFooter />}>
      <Outlet />
    </GoATwoColumnLayout>
  ) : (
    <Navigate to="/" />
  );
});
