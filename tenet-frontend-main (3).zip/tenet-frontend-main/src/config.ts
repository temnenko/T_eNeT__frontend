// src/config.js
export const loadConfig = async () => {
  const response = await fetch('/config.json');
  if (!response.ok) {
    throw new Error('Failed to load configuration');
  }
  return response.json();
};
