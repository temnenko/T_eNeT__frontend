import { GoAHeroBanner } from '@abgov/react-components';

export function AppHeroBanner() {
  return (
    <GoAHeroBanner heading="Welcome to TENET" minHeight="272px" textColor="#333333" backgroundColor="#F1F1F1">
      <p>
        TENET is Jobs, Economy and Trade’s service management system for <br /> training and employment contracts.
      </p>
    </GoAHeroBanner>
  );
}

export default AppHeroBanner;
