import { GoABlock } from '@abgov/react-components';

interface Props<T extends string> {
  headingText: string;
  currentlyActive: T;
  formStepperTitles: Record<T, string>;
  headingControl?: JSX.Element;
}

export function StepperFormHeader<T extends string>({
  headingText,
  currentlyActive,
  formStepperTitles,
  headingControl,
}: Props<T>) {
  const stepperKeys = Object.keys(formStepperTitles);
  const totalSection = stepperKeys.length;
  const currentSection = stepperKeys.indexOf(currentlyActive as string) + 1;

  return (
    <section className="stepper-form-heading">
      <div>
        <GoABlock direction="column">
          <h2 className="stepper-form-title">{headingText}</h2>
          <GoABlock>
            <span className="stepper-form-progress-indicator">
              Section {currentSection} of {totalSection}
            </span>
            <span>{formStepperTitles[currentlyActive]}</span>
          </GoABlock>
        </GoABlock>
        <GoABlock direction="column" alignment="end">
          {headingControl}
        </GoABlock>
      </div>
    </section>
  );
}

StepperFormHeader.defaultProps = {
  headingControl: undefined,
};
