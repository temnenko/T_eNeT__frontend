import { GoACallout } from '@abgov/react-components';

type Props = {
  message?: string;
};

export default function UserErrorCallout({ message }: Props) {
  return (
    <GoACallout type="emergency" heading="Missing information">
      <p className="client-font-with-margin">
        {`Uh-oh! It seems like there's missing information. Please review the following sections and ensure all required
        fields are filled out. Once completed, feel free to submit again.`}
      </p>
      <ul>
        <li>{message}</li>
      </ul>
    </GoACallout>
  );
}

UserErrorCallout.defaultProps = { message: undefined };
