/* eslint-disable @typescript-eslint/no-unused-vars */
import '@testing-library/jest-dom';
import { render } from '@testing-library/react';

import { ListPagination } from './list-pagination';

describe('ListPagination', () => {
  test('Renders ListPagination', () => {
    const { baseElement: listPagination } = render(
      <ListPagination
        {...{
          perPageSize: 15,
          actualPageSize: 15,
          perPageSizeOptions: [15, 50],
          changePerPageSize: (_a: string, _b: string | string[]) => {},
          pagePosition: 1,
          changePagePosition: (_val: number) => {},
          totalCount: 50,
        }}
      />,
    );

    expect(listPagination).toBeInTheDocument();
  });
});
