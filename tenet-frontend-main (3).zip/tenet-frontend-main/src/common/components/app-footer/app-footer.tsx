import { GoAAppFooter, GoAAppFooterMetaSection } from '@abgov/react-components';

export function AppFooter() {
  return (
    <section slot="footer">
      <GoAAppFooter maxContentWidth="100%">
        <GoAAppFooterMetaSection>
          <a href="https://goa-dio.slack.com/archives/C02PLLT9HQ9" target="_blank" rel="noreferrer">
            Get help
          </a>
          <a
            href="https://goa-dio.atlassian.net/wiki/spaces/DS/pages/2342813697/Design+System+Drop-in+hours"
            target="_blank"
            rel="noreferrer"
          >
            Drop-in Hours
          </a>
          <a href="https://github.com/GovAlta/ui-components/issues/new/choose" target="_blank" rel="noreferrer">
            Contribute
          </a>
        </GoAAppFooterMetaSection>
      </GoAAppFooter>
    </section>
  );
}

export default AppFooter;
