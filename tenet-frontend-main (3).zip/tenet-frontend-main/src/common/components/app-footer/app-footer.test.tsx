import '@testing-library/jest-dom';
import { render } from '@testing-library/react';
import AppFooter from './app-footer';

describe('AppFooter', () => {
  test('Renders AppFooter', () => {
    const { baseElement: appFooter } = render(<AppFooter />);

    expect(appFooter).toBeInTheDocument();
  });
});
