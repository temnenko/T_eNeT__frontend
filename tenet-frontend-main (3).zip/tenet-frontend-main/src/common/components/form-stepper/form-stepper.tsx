/* eslint-disable jsx-a11y/no-static-element-interactions */
import { observer } from 'mobx-react-lite';
import { GoAIcon } from '@abgov/react-components';

interface Props {
  steps: StepperValues[];
  currentStep: number;
  onChange: (page: number) => void;
  endProgressOnStep?: number;
}

export interface StepperValues {
  stepper: string[];
  done: boolean;
  position: number;
}

const Stepper = observer(({ steps, currentStep, onChange, endProgressOnStep }: Props) => {
  return (
    <div className="stepper-container">
      <div className="stepper">
        {steps.map((step) => (
          <div key={step.position} className={`step${step.position <= currentStep ? ' active' : ''}`}>
            <div
              className="step-circle"
              onClick={() => onChange(step.position)}
              onKeyDown={() => onChange(step.position)}
            >
              {step.position <= currentStep ? (
                <span className="checkmark">
                  <GoAIcon type={step.position === currentStep ? 'pencil' : 'checkmark'} />
                </span>
              ) : (
                <span>{step.position}</span>
              )}
            </div>

            <div className="step-details">
              <p className="step-title">{step.stepper[0]}</p>
              <p className="step-date">{step.stepper[1]}</p>
            </div>

            {step.position <= steps.length && (
              <div className="step-line-container">
                <div
                  className={`step-line first${step.position <= currentStep || (step.position === 2 && steps[0].done) || (step.position === 3 && steps[1].done) ? ' step-line-completed' : ''}`}
                />
                {step.position !== endProgressOnStep && (
                  <div
                    className={`step-line last${step.position <= currentStep || (step.position === 2 && steps[0].done) || (step.position === 3 && steps[1].done) ? ' step-line-completed' : ''}`}
                  />
                )}
                {step.position === endProgressOnStep && <div className="step-line last" />}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
});

export default Stepper;
