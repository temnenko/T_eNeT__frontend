/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoACheckbox, GoANotification, GoATable } from '@abgov/react-components';
import { useState } from 'react';
import { InviteUserRow } from './invite-user.row';
import { Role } from '../../../../types/role';

type Props = {
  renderIds: string[];
  removeInvite: (id: string) => void;
  showRoles?: boolean;
  roles?: Role[];
};

export function InviteUserTable({ renderIds, removeInvite, showRoles, roles = [] }: Props) {
  const [requestError, setRequestError] = useState<string>();

  const handleError = (error: string) => {
    setRequestError(error);
  };

  return (
    <>
      {requestError && (
        <GoANotification type="emergency" ariaLive="polite">
          {requestError}
        </GoANotification>
      )}
      <GoATable width="100%">
        <thead>
          <tr>
            <th>
              <GoACheckbox id="check-all-invite" checked={false} name="check-all-invite" />
            </th>
            <th>Name</th>
            <th>Email</th>
            {showRoles && <th>Role</th>}
            <th>{}</th>
            <th>{}</th>
          </tr>
        </thead>
        <tbody>
          {renderIds.map((renderId) => (
            <InviteUserRow
              key={renderId}
              renderId={renderId}
              removeInvite={removeInvite}
              showRoles={showRoles}
              roles={roles}
              handleError={handleError}
            />
          ))}
        </tbody>
      </GoATable>
    </>
  );
}

InviteUserTable.defaultProps = {
  showRoles: false,
  roles: [],
};
