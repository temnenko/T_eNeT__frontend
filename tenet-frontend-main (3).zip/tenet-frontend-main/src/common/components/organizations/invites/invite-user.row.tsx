/* eslint-disable jsx-a11y/control-has-associated-label */
import {
  GoAButton,
  GoACheckbox,
  GoADropdown,
  GoADropdownItem,
  GoAFormItem,
  GoAIconButton,
  GoAInput,
} from '@abgov/react-components';
import useInviteUser from './hooks/use-invite-user.hook';
import { Role } from '../../../../types/role';

type Props = {
  renderId: string;
  removeInvite: (id: string) => void;
  showRoles?: boolean;
  roles?: Role[];
  handleError: (error: string) => void;
};

export function InviteUserRow({ renderId, removeInvite, showRoles, roles, handleError }: Props) {
  const {
    inviteResendHandler,
    inviting,
    invited,
    resending,
    formFields,
    onChangeHandler,
    storedValue,
    getValues,
    errors,
    handleSubmit,
    roleDropdownChangeHandler,
    userInviteHandler,
  } = useInviteUser({ renderId, removeInvite, showRoles, handleError });
  const { inviteUserCheck, userName, userEmail, roleId } = formFields;

  return (
    <tr>
      <td>
        <GoACheckbox
          id={`check-invite-${renderId}`}
          name={inviteUserCheck}
          onChange={onChangeHandler}
          checked={false}
        />
      </td>
      <td>
        <GoAFormItem error={errors.userName?.message as unknown as string}>
          <GoAInput
            type="text"
            onChange={onChangeHandler}
            name={userName}
            id={`userName-${renderId}`}
            value={storedValue?.name ?? getValues(userName)}
            width="19.5rem"
            disabled={invited}
          />
        </GoAFormItem>
      </td>
      <td>
        <GoAFormItem error={errors.userEmail?.message as unknown as string}>
          <GoAInput
            type="text"
            onChange={onChangeHandler}
            name={userEmail}
            id={`userEmail-${renderId}`}
            value={storedValue?.emailAddress ?? getValues(userEmail)}
            width="320px"
            disabled={invited}
          />
        </GoAFormItem>
      </td>
      {showRoles && (
        <td>
          <GoAFormItem error={errors.roleId?.message as unknown as string}>
            <GoADropdown
              name="roleId"
              value={storedValue?.roleId ?? getValues(roleId)}
              onChange={roleDropdownChangeHandler}
              disabled={invited}
            >
              <GoADropdownItem value="" label="-- Select a role --" />
              {roles?.map((role) => <GoADropdownItem key={role.id} value={role.id} label={role.name} />)}
            </GoADropdown>
          </GoAFormItem>
        </td>
      )}
      <td>
        {invited ? (
          `Invited`
        ) : (
          <GoAButton
            disabled={inviting}
            onClick={handleSubmit(userInviteHandler)}
            type="submit"
            leadingIcon="mail"
            size="compact"
          >
            {inviting ? 'Inviting...' : 'Invite'}
          </GoAButton>
        )}
      </td>
      <td>
        {invited ? (
          <GoAButton disabled={resending} onClick={inviteResendHandler} type="secondary" size="compact">
            {resending ? 'Resending...' : 'Resend'}
          </GoAButton>
        ) : (
          <GoAIconButton
            onClick={() => removeInvite(renderId)}
            icon="close"
            size="medium"
            variant="dark"
            ariaLabel="Remove invite"
          />
        )}
      </td>
    </tr>
  );
}

InviteUserRow.defaultProps = {
  showRoles: false,
  roles: [],
};
