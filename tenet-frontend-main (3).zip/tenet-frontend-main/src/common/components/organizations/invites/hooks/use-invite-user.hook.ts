/* eslint-disable no-console */
import { useCallback, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useParams } from 'react-router-dom';

import { AxiosError } from 'axios';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { organizationService } from '../../../../../services/organizations/organization.service';
import { useStore } from '../../../../../hooks/use-store.hook';
import { RequestError } from '../../../../../types/errors/errors';

type InviteUserFormData = {
  inviteUserCheck: boolean;
  userName: string;
  userEmail: string;
  roleId: string | undefined;
};

type FormFieldName = 'inviteUserCheck' | 'userName' | 'userEmail' | 'roleId';

const useInviteUser = ({
  renderId,
  removeInvite,
  showRoles,
  handleError,
}: {
  renderId: string;
  removeInvite: (id: string) => void;
  showRoles?: boolean;
  handleError: (error: string) => void;
}) => {
  const requestErrorHandler = useRequestErrorHandler();

  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    formState: { errors },
  } = useForm<InviteUserFormData>();
  const { id: organizationId } = useParams<{ id: string }>();
  const {
    organizationStore: { getOrganizationUserInvites, userInvites },
    userStore: { organizationId: userOrganizationId },
  } = useStore();

  const { name: userName } = register(`userName`, {
    required: { value: true, message: 'Name is required.' },
    pattern: { value: /^[^-\s].*$/, message: 'Name cannot begin with a space' },
    min: 3,
  });
  const { name: userEmail } = register('userEmail', {
    required: { value: true, message: 'Email is required.' },
    pattern: { value: /^[^\s@<>&]+@[^\s@<>&]+\.[^\s@<>&]+$/, message: 'Invalid email' },
    min: 5,
  });
  const { name: inviteUserCheck } = register('inviteUserCheck');

  const { name: roleId } = register('roleId', {
    required: showRoles ? { value: true, message: 'Role is required.' } : false,
  });

  const formFields = {
    userName,
    userEmail,
    inviteUserCheck,
    roleId,
  };

  const [inviting, setInviting] = useState(false);
  const [invited, setInvited] = useState(false);
  const [resending, setResending] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  const userInviteHandler = useCallback(async () => {
    try {
      const name = getValues('userName');
      const email = getValues('userEmail')?.trim()?.toLowerCase();
      const userRoleId = getValues('roleId');
      const orgId = organizationId ?? userOrganizationId!;

      setInviting(true);

      await organizationService.inviteOrganization({
        organizationId: orgId,
        givenName: name,
        emailAddress: email,
        roleId: userRoleId,
      });

      setInvited(true);

      await getOrganizationUserInvites(orgId);
      removeInvite(renderId);
    } catch (e) {
      console.error(e);
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
      if (handleError && e instanceof AxiosError) {
        handleError(e?.response?.data.message || 'An error occurred');
      } else {
        handleError('An error occurred');
      }
    } finally {
      setInviting(false);
    }
  }, [
    getOrganizationUserInvites,
    getValues,
    handleError,
    organizationId,
    removeInvite,
    renderId,
    requestErrorHandler,
    userOrganizationId,
  ]);

  const inviteResendHandler = useCallback(async () => {
    try {
      const name = getValues('userName');
      const email = getValues('userEmail')?.trim()?.toLowerCase();

      setResending(true);

      await organizationService.inviteOrganization({
        organizationId: organizationId!,
        givenName: name,
        emailAddress: email,
      });
    } catch (e) {
      console.error(e);
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setResending(false);
    }
  }, [getValues, organizationId, requestErrorHandler]);

  const onChangeHandler = useCallback(
    (name: string, value: string | boolean) => {
      setValue(name as FormFieldName, value);
    },
    [setValue],
  );

  const roleDropdownChangeHandler = useCallback(
    (name: string, values: string | string[]) => {
      setValue(name as FormFieldName, values as string);
    },
    [setValue],
  );

  const storedValue = useMemo(() => {
    const userInvite = userInvites.find((invite) => invite.id === renderId);

    setInvited(!!userInvite);
    if (userInvite) {
      setValue(userName, userInvite?.name ?? '');
      setValue(userEmail, userInvite.emailAddress);
      setValue(roleId, userInvite.roleId);
    }

    return userInvite;
  }, [renderId, roleId, setValue, userEmail, userInvites, userName]);

  return {
    inviting,
    invited,
    resending,
    requestError,
    formFields,
    getValues,
    userInviteHandler,
    inviteResendHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    storedValue,
    roleDropdownChangeHandler,
  };
};

export default useInviteUser;
