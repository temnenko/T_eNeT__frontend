import { useCallback, useEffect, useMemo, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useParams } from 'react-router-dom';
import { useStore } from '../../../../../hooks/use-store.hook';

const useManageUserInviteTable = (overrideId?: string) => {
  const {
    organizationStore: { userInvites, getOrganizationUserInvites },
  } = useStore();
  const { id: orgId } = useParams<{ id: string }>();
  const organizationId = overrideId || orgId;
  const [inviteRows, setInviteRows] = useState<string[]>([uuidv4()]);

  const addInviteRow = useCallback(() => {
    setInviteRows([...inviteRows, uuidv4()]);
  }, [inviteRows]);
  const removeInviteRow = useCallback(
    (id: string) => setInviteRows([...inviteRows.filter((val) => val !== id)]),
    [inviteRows],
  );

  const allInviteRows = useMemo(
    () => [...inviteRows, ...userInvites.map((item) => item.id)],
    [inviteRows, userInvites],
  );

  useEffect(() => {
    getOrganizationUserInvites(organizationId!).catch((err) => {
      // eslint-disable-next-line no-console
      console.error(err);
    });
  }, [getOrganizationUserInvites, organizationId]);

  return {
    inviteRows,
    allInviteRows,
    addInviteRow,
    removeInviteRow,
  };
};

export default useManageUserInviteTable;
