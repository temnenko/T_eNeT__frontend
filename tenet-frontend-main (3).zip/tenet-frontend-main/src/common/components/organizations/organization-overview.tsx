/* eslint-disable jsx-a11y/control-has-associated-label */
/* eslint-disable react/no-array-index-key */
import { observer } from 'mobx-react-lite';
import { GoABlock, GoAButton, GoADivider, GoAModal, GoASpacer } from '@abgov/react-components';

import useOrganizationProfile from './hooks/use-organization-profile';
import { useFormatPhoneNumber } from '../../../hooks/use-format-phone-number';
import { PrimaryDetails } from '../forms/organizations/enrollment/primary-details';

const OrganizationOverview = observer(() => {
  const {
    selectedOrganization,
    modalContent,
    modalVisible,
    setModalContent,
    setModalVisible,
    canUpdateOrganizationDetails,
  } = useOrganizationProfile();
  const formatPhoneNumber = useFormatPhoneNumber();

  const hideModal = () => {
    setModalVisible(false);
    setModalContent(null);
  };

  return (
    <div className="org-info-card">
      {modalVisible && modalContent}
      <div className="client-info-card-heading client-margin-b-10">
        <h3 className="client-no-padding-no-margin">Overview</h3>
        <GoABlock>
          {canUpdateOrganizationDetails && (
            <GoAButton
              type="tertiary"
              size="compact"
              onClick={() => {
                setModalVisible(true);
                setModalContent(
                  <GoAModal
                    maxWidth="1000px"
                    open
                    width="1000px"
                    transition="slow"
                    heading="Update Organization Details"
                    onClose={hideModal}
                  >
                    <PrimaryDetails isModal hideModal={hideModal} />
                  </GoAModal>,
                );
              }}
            >
              Update
            </GoAButton>
          )}
        </GoABlock>
      </div>
      <GoADivider />
      <div className="client-info-card-details">
        <GoABlock>
          <div className="client-info-card-label">
            <span className="color-interactive">Operating as</span>
          </div>
          <div className="client-info-card-value">
            <span className="client-bold-600">{selectedOrganization?.operatingName}</span>
          </div>
        </GoABlock>
        <GoASpacer vSpacing="m" />
        <GoABlock>
          <div className="client-info-card-label">
            <span className="color-interactive">Legal Name</span>
          </div>
          <div className="client-info-card-value">
            <span className="client-bold-600">{selectedOrganization?.legalName}</span>
          </div>
        </GoABlock>
        <GoASpacer vSpacing="m" />
        <GoABlock>
          <div className="client-info-card-label">
            <span className="color-interactive">Main business phone</span>
          </div>
          <div className="client-info-card-value">
            <span className="client-bold-600">{formatPhoneNumber(selectedOrganization?.phoneNumber)}</span>
          </div>
        </GoABlock>
        <GoASpacer vSpacing="m" />
        <GoABlock>
          <div className="client-info-card-label">
            <span className="color-interactive">Main business email</span>
          </div>
          <div className="client-info-card-value">
            <span className="client-bold-600">{selectedOrganization?.emailAddress}</span>
          </div>
        </GoABlock>
        <GoASpacer vSpacing="m" />
        <GoABlock>
          <div className="client-info-card-label">
            <span className="color-interactive">Website</span>
          </div>
          <div className="client-info-card-value">
            {selectedOrganization?.website && (
              <a
                href={
                  selectedOrganization.website.indexOf('http') === -1
                    ? `https://${selectedOrganization.website}`
                    : selectedOrganization.website
                }
                target="_blank"
                className="client-bold-600"
                rel="noopener noreferrer"
              >
                {selectedOrganization.website}
              </a>
            )}
          </div>
        </GoABlock>
      </div>
    </div>
  );
});

export default OrganizationOverview;
