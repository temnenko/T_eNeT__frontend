/* eslint-disable react/require-default-props */
import { GoAButton, GoADivider, GoASpacer } from '@abgov/react-components';
import { format } from 'date-fns';
import { observer } from 'mobx-react-lite';
import OrganizationFileCard from './organization-file-card';
import { Upload } from '../../../types/files';
import { toIsoDate } from '../../../utils/date.util';

type SectionProps = {
  title: string;
  dateLabel: string;
  dateValue: string | Date | undefined;
  documents: Upload[] | undefined;
  addNewHandler: () => void;
  additonalInfoLabel?: string;
  additonalInfoValue?: string;
  corporateIdentityNumberLabel?: string;
  corporateIdentityNumberValue?: string;
  downloadFile?: (fileId: string, filename: string, filesize: number) => void;
  canEditOrganizationCompliance?: boolean;
};

export const OrganizationComplianceSection = observer(
  ({
    title,
    dateLabel,
    dateValue,
    documents,
    addNewHandler,
    additonalInfoLabel,
    additonalInfoValue,
    corporateIdentityNumberLabel,
    corporateIdentityNumberValue,
    downloadFile,
    canEditOrganizationCompliance,
  }: SectionProps) => {
    return (
      <>
        <div className="d-flex">
          <div className="flex-grow-1">
            <h3>{title}</h3>
          </div>
          {addNewHandler && canEditOrganizationCompliance && (
            <GoAButton type="tertiary" onClick={addNewHandler}>
              Add new
            </GoAButton>
          )}
        </div>
        <GoADivider />
        <GoASpacer vSpacing="m" />
        {dateLabel && (
          <div className="d-flex">
            <span className="color-interactive flex-grow-1">{dateLabel}</span>
            <span className="organization-value">{dateValue ? format(toIsoDate(dateValue), 'MMMM d, yyyy') : ''}</span>
          </div>
        )}
        {corporateIdentityNumberLabel && (
          <div className="d-flex">
            <span className="color-interactive org-compliance-label">{corporateIdentityNumberLabel}</span>
            <span className="organization-value">{corporateIdentityNumberValue}</span>
          </div>
        )}
        {additonalInfoLabel && (
          <>
            <div>
              <span className="color-interactive org-compliance-label">{additonalInfoLabel}</span>
              <span className="organization-value">{additonalInfoValue}</span>
            </div>
            <GoASpacer vSpacing="s" />
          </>
        )}
        <OrganizationFileCard documents={documents} downloadFile={downloadFile} />
        <GoASpacer vSpacing="m" />
      </>
    );
  },
);
