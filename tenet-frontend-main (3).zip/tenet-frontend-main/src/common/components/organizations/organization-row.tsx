/* eslint-disable jsx-a11y/control-has-associated-label */
import { useCallback } from 'react';
import { observer } from 'mobx-react-lite';
import { useNavigate } from 'react-router-dom';
import { GoABadge, GoAButton } from '@abgov/react-components';
// import { format } from 'date-fns/format';
import { OrganizationStatus, organizationBadgeMap, organzaitionBadgeLabelMap } from '../../../types/organization';
import { useStore } from '../../../hooks/use-store.hook';

type Props = {
  id: string;
  status: OrganizationStatus;
  operatingName: string;
  legalName: string;
};

export const OrganizationRow = observer(({ id, status, operatingName, legalName }: Props) => {
  const navigate = useNavigate();
  const openHandler = useCallback(() => {
    if (status === OrganizationStatus.IN_PROGRESS) {
      navigate(`/organizations/${id}/enroll/primary-details`);
    } else {
      navigate(`/organizations/${id}`);
    }
  }, [status, navigate, id]);

  const {
    permissionStore: { canViewOrganizationProfile },
  } = useStore();

  return (
    <tr>
      <td>
        <GoABadge type={organizationBadgeMap[status]} content={organzaitionBadgeLabelMap[status]} />
      </td>
      <td>{operatingName}</td>
      <td>{legalName.replaceAll('_', ' ')}</td>
      <td>
        {canViewOrganizationProfile(id) && (
          <GoAButton onClick={openHandler} type="tertiary">
            {status === OrganizationStatus.IN_PROGRESS ? 'Open' : 'View'}
          </GoAButton>
        )}
      </td>
    </tr>
  );
});
