import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';

import { useStore } from '../../../../hooks/use-store.hook';

type FormFieldNames = 'nameSearch';

const useOrganizationFilters = () => {
  const navigate = useNavigate();
  const {
    organizationListStore: { setNameSearch, setCurrentListPosition, getOrganizationsList },
    organizationEnrollmentStore: { resetStore },
    organizationFormStepperStore: { resetSteppers },
    permissionStore: { canCreateOrganization },
  } = useStore();

  const { getValues, setValue, handleSubmit, register, reset, watch } = useForm<{ nameSearch?: string }>();

  const { name: nameSearch } = register('nameSearch', {
    required: { value: true, message: '' },
  });

  const startNewOrganizationCreation = useCallback(() => {
    resetStore();
    resetSteppers();

    navigate('/organizations/enroll/primary-details');
  }, [navigate, resetSteppers, resetStore]);

  const nameSearchHandler = useCallback(async () => {
    const nameSearchValue = getValues(nameSearch);
    setCurrentListPosition(1);
    setNameSearch(nameSearchValue);

    try {
      await getOrganizationsList();
    } catch (e) {
      // some API based error log considerations
    }
  }, [getOrganizationsList, getValues, nameSearch, setCurrentListPosition, setNameSearch]);

  const onChange = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldNames, value);
    },
    [setValue],
  );

  const resetSearch = useCallback(async () => {
    setNameSearch(undefined);
    reset({ nameSearch: undefined });

    try {
      await getOrganizationsList();
    } catch (e) {
      // some API based error log considerations
    }
  }, [getOrganizationsList, reset, setNameSearch]);

  setNameSearch(undefined);

  return {
    getValues,
    onChange,
    nameSearchHandler,
    handleSubmit,
    resetSearch,
    startNewOrganizationCreation,
    watch,
    nameSearch,
    canCreateOrganization,
  };
};

export default useOrganizationFilters;
