/* eslint-disable no-plusplus */
import { useCallback, useMemo, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { LocationRow } from '../locations/location-row';

const useLocations = (isAgreement: boolean = false) => {
  const [expandedRecordId, setExpandedRecordId] = useState<string>();

  const {
    organizationStore: { selectedOrganization },
    agreementStore: { selectedAgreement },
  } = useStore();

  const toggleExpansion = useCallback(
    (id: string) => {
      if (id === expandedRecordId) {
        setExpandedRecordId(undefined);
      } else {
        setExpandedRecordId(id);
      }
    },
    [expandedRecordId],
  );

  const locationRows = useMemo(() => {
    const locations = isAgreement ? selectedAgreement?.locations : selectedOrganization?.locations;
    return locations?.map((location) => (
      <LocationRow
        key={location.id}
        location={location}
        expandedRecordId={expandedRecordId}
        toggleExpansion={toggleExpansion}
        showHQ={!isAgreement}
      />
    ));
  }, [expandedRecordId, isAgreement, selectedAgreement?.locations, selectedOrganization?.locations, toggleExpansion]);

  return {
    locationRows,
  };
};

export default useLocations;
