import { useCallback, useEffect, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import useLoadOrganization from '../../forms/organizations/enrollment/hooks/use-load-organization.hook';
import useRequestErrorHandler from '../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../types/errors/errors';
import { fileService } from '../../../../services/clients/client-files.service';

const useOrganizationCompliance = () => {
  const {
    organizationEnrollmentStore: {
      fetchFiles,
      corporateIdentityDocuments,
      lobbyistCheckProof,
      wcbVerificationProof,
      liabilityPolicyProof,
      assessmentResult,
    },
  } = useStore();

  const { organization, isLoading } = useLoadOrganization();

  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  useEffect(() => {
    if (organization && !isLoading) {
      fetchFiles();
    }
  }, [fetchFiles, isLoading, organization]);

  const downloadFile = useCallback(
    (fileId: string, filename: string, filesize: number) => {
      try {
        setLoading(true);
        fileService.downloadFileByAdspId(fileId, filename, filesize);
      } catch (error) {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    },
    [requestErrorHandler],
  );

  return {
    organization,
    corporateIdentityDocuments,
    lobbyistCheckProof,
    wcbVerificationProof,
    liabilityPolicyProof,
    assessmentResult,
    downloadFile,
    requestError,
    loading,
  };
};

export default useOrganizationCompliance;
