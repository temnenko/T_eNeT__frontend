import { useCallback, useMemo } from 'react';

import { useStore } from '../../../../hooks/use-store.hook';
import { ListPagination } from '../../list-pagination';

const useAgreementsPagination = () => {
  const {
    organizationStore: {
      hasAgreements,
      setCurrentAgreementsListPosition,
      setAgreementsListSize,
      getAgreementsListSize,
      currentAgreementsListPosition,
      totalAgreementsCount,
    },
  } = useStore();

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      const newSize = Array.isArray(value) ? value[0] : value;

      setAgreementsListSize(Number.parseInt(newSize, 10));
    },
    [setAgreementsListSize],
  );

  return useMemo(() => {
    if (hasAgreements) {
      const actualPageSize =
        totalAgreementsCount < getAgreementsListSize ? totalAgreementsCount : getAgreementsListSize;

      return (
        <ListPagination
          perPageSize={getAgreementsListSize}
          actualPageSize={actualPageSize}
          perPageSizeOptions={[15, 50]}
          changePerPageSize={changePerPageSize}
          pagePosition={currentAgreementsListPosition}
          changePagePosition={setCurrentAgreementsListPosition}
          totalCount={totalAgreementsCount}
        />
      );
    }

    return undefined;
  }, [
    hasAgreements,
    totalAgreementsCount,
    getAgreementsListSize,
    changePerPageSize,
    currentAgreementsListPosition,
    setCurrentAgreementsListPosition,
  ]);
};

export default useAgreementsPagination;
