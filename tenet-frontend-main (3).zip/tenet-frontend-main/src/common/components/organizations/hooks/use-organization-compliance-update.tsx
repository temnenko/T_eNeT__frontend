import { useForm } from 'react-hook-form';
import { useCallback, useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';

import { useStore } from '../../../../hooks/use-store.hook';
import useOrganizationCompliance from './use-organization-compliance';
import { Organization, OrganizationComplianceFilesTypeMap } from '../../../../types/organization';
import { MockUploader, Upload } from '../../../../types/files';
import useRequestErrorHandler from '../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../types/errors/errors';
import useFileNotValid from '../../../../utils/file.util';
import { InvalidFileUploadError } from '../../../../types/errors/invalid-file-upload.error';

type FormValues = {
  updatedValue: string | undefined;
};

export const useOrganizationComplianceUpdate = (
  fieldValue: string | undefined,
  fieldType: string,
  fieldFormName: string,
  uploadType: string,
  hideModal: () => void,
) => {
  const {
    control,
    handleSubmit,
    register,
    setValue,
    getValues,
    reset,
    formState: { errors },
  } = useForm<FormValues>({
    defaultValues: { updatedValue: fieldValue },
  });

  const { organization } = useOrganizationCompliance();
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});
  const [isLoading, setIsLoading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  const {
    organizationEnrollmentStore: { updateOrganization, uploadFiles },
  } = useStore();

  const [uploads, setUploads] = useState<Upload[]>([]);
  const [progressList, setProgressList] = useState<Record<string, number>>({});

  const noFutureDates = ['lobbyistCheckedDate', 'wcbVerifiedOn', 'assessmentCompletedOn'];
  const noPastDates = ['liabilityPolicyExpiresOn'];

  const { name: updatedValue } = register('updatedValue', {
    required: {
      value: true,
      message: 'This field is required',
    },
    validate: {
      notFutureDate: (value) => {
        if (value && fieldType === 'date' && new Date(value) > new Date() && noFutureDates.includes(fieldFormName)) {
          return 'Date cannot be in the future';
        }
        return true;
      },
      notPastDate: (value) => {
        if (value && fieldType === 'date' && new Date(value) < new Date() && noPastDates.includes(fieldFormName)) {
          return 'Date cannot be in the past';
        }
        return true;
      },
    },
  });

  useEffect(() => {
    reset({
      updatedValue: fieldValue,
    });
  }, [fieldValue, reset]);

  const onChangeHandler = useCallback(
    (name: string, value: string | undefined) => {
      setValue('updatedValue', value);
    },
    [setValue],
  );

  const saveHandler = useCallback(async () => {
    if (!organization || !organization.id) {
      return;
    }

    const payload: Partial<Organization> = {
      id: organization.id,
      [fieldFormName]: fieldType === 'date' ? new Date(getValues('updatedValue')!) : getValues('updatedValue'),
    };

    try {
      setIsLoading(true);
      await Promise.all([
        await updateOrganization(payload as Organization),
        await uploadFiles(uploads, uploadType as OrganizationComplianceFilesTypeMap),
      ]);
      hideModal();
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setIsLoading(false);
    }
  }, [
    fieldFormName,
    fieldType,
    getValues,
    hideModal,
    organization,
    requestErrorHandler,
    updateOrganization,
    uploadFiles,
    uploadType,
    uploads,
  ]);

  const { fileNotValidHandler } = useFileNotValid();

  const uploadFile = useCallback(
    (file: File) => {
      try {
        fileNotValidHandler(file.name, file.type);
        const reader = new FileReader();

        reader.onload = (e: ProgressEvent<FileReader>) => {
          if (!e.target) return;
          const url = e.target.result;
          const uploader: MockUploader = {
            onprogress: (percent) => {
              setProgressList((old) => ({ ...old, [file.name]: percent }));
            },
          };

          setUploads((old) => [
            ...old,
            {
              file,
              uploader,
              fileType: uploadType,
              id: uuidv4(),
              createdAt: new Date().toISOString(),
              size: file.size,
              adspId: '',
            },
          ]);

          if (url) {
            uploader.upload?.(url);
          }
        };

        reader.readAsDataURL(file);
      } catch (e) {
        if (e instanceof InvalidFileUploadError) {
          setUploadError(e.message);
        }
      }
    },
    [fileNotValidHandler, uploadType],
  );

  const deleteFile = useCallback(
    (file: Upload) => {
      setUploads((old) => old.filter((upload) => upload.id !== file.id));
    },
    [setUploads],
  );

  return {
    control,
    handleSubmit,
    errors,
    setValue,
    saveHandler,
    onChangeHandler,
    getValues,
    updatedValue,
    uploadFile,
    progressList,
    uploads,
    deleteFile,
    requestError,
    isLoading,
    uploadError,
    setUploadError,
  };
};
