import { ReactNode, useCallback, useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';

import { useStore } from '../../../../hooks/use-store.hook';
import { Agreement } from '../../../../types/agreement';

type AgreementKey = 'name' | 'agreementNumber' | 'programType' | 'startDate' | 'endDate';

const useOrganizationProfile = () => {
  const {
    organizationStore: {
      selectedOrganization,
      agreements,
      setAgreements,
      getOrganizationById,
      showExpiredAgreements,
      setShowExpiredAgreements,
    },
    agreementFormsStore: { resetAgreement },
    agreementFormStepperStore: { resetSteppers },
    permissionStore: { canUpdateOrganizationDetails },
  } = useStore();
  const { id } = useParams();
  const navigate = useNavigate();

  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);
  const newAgreementBtnClickHandler = useCallback(() => {
    resetAgreement();
    resetSteppers();
    navigate(`/agreements/new/program-type`);
  }, [navigate, resetAgreement, resetSteppers]);
  const openAgreement = useCallback(
    (agreementId: string, completed: boolean) => {
      if (!completed) {
        resetAgreement();
        resetSteppers();
        navigate(`/agreements/new/program-type/${agreementId}`);
      } else {
        navigate(`/agreements/${agreementId}`);
      }
    },
    [navigate, resetAgreement, resetSteppers],
  );
  const sortAgreementData = useCallback(
    (sortBy: string, sortDir: number) => {
      const sortedAgreements = [...agreements];
      sortedAgreements.sort((a: Agreement, b: Agreement) => {
        return (a[sortBy as AgreementKey]! > b[sortBy as AgreementKey]! ? 1 : -1) * sortDir;
      });

      setAgreements(sortedAgreements);
    },
    [agreements, setAgreements],
  );

  useEffect(() => {
    const loadOrganization = async () => {
      if (id) {
        await getOrganizationById(id);
      }
    };

    loadOrganization();
  }, [id, getOrganizationById]);

  return {
    selectedOrganization,
    navigate: useNavigate(),
    modalContent,
    modalVisible,
    setModalContent,
    setModalVisible,
    newAgreementBtnClickHandler,
    openAgreement,
    sortAgreementData,
    canUpdateOrganizationDetails,
    showExpiredAgreements,
    setShowExpiredAgreements,
  };
};

export default useOrganizationProfile;
