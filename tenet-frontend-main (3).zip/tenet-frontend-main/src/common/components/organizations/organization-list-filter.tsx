import { GoAButton, GoAFormItem, GoAInput, GoASpacer } from '@abgov/react-components';

import useOrganizationFilters from './hooks/use-organizations-filter.hook';

export function OrganizationsListFilter() {
  const {
    onChange,
    watch,
    nameSearch,
    nameSearchHandler,
    handleSubmit,
    resetSearch,
    startNewOrganizationCreation,
    canCreateOrganization,
  } = useOrganizationFilters();

  return (
    <section className="org-filter-section">
      <form className="org-filter-form-group">
        <GoAFormItem>
          <GoAInput
            type="text"
            leadingIcon="search"
            trailingIcon="close"
            value={watch(nameSearch)}
            onChange={onChange}
            onTrailingIconClick={resetSearch}
            name={nameSearch}
            width="36ch"
          />
        </GoAFormItem>
        <GoASpacer hSpacing="xs" />
        <GoAFormItem>
          <GoAButton type="secondary" onClick={handleSubmit(nameSearchHandler)}>
            Search
          </GoAButton>
        </GoAFormItem>
      </form>
      {canCreateOrganization && (
        <GoAButton size="compact" onClick={startNewOrganizationCreation} leadingIcon="add">
          New Organization
        </GoAButton>
      )}
    </section>
  );
}
