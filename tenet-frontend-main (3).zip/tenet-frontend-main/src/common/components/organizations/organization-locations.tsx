import { GoAButton, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useModal } from '../../../hooks/use-modal.hook';
import { OfficeLocation } from '../forms/organizations/modals/office-location';
import useOrganizationLocation from './hooks/use-locations';
import { LocationTable } from './locations/location-table';

export const OrganizationLocations = observer(() => {
  const { locationRows } = useOrganizationLocation();

  const { showModal, hideModal } = useModal();
  return (
    <>
      <h2>Organization Locations</h2>
      <div className="org-office-locations">
        <p>View manage office locations of this organizations.</p>
        <GoAButton
          size="compact"
          onClick={() => {
            showModal(<OfficeLocation hideModal={hideModal} />);
          }}
        >
          Add location
        </GoAButton>
      </div>
      <GoASpacer vSpacing="l" />
      <LocationTable locationRows={locationRows} />
    </>
  );
});
