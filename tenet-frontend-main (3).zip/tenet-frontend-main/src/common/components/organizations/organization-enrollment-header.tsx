import { observer } from 'mobx-react-lite';

import { useStore } from '../../../hooks/use-store.hook';
import { organizationFormStepperTitles } from '../../../types/organization-forms';
import { StepperFormHeader } from '../stepper-form/stepper-form-header';

export const OrganizationEnrollmentHeader = observer(() => {
  const {
    organizationFormStepperStore: { currentlyActive },
  } = useStore();

  return (
    <StepperFormHeader
      headingText="Complete organization profile"
      currentlyActive={currentlyActive}
      formStepperTitles={organizationFormStepperTitles}
    />
  );
});
