import { GoABadge, GoABlock, GoAContainer, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import useOrganizationProfile from './hooks/use-organization-profile';
import { useFormatPhoneNumber } from '../../../hooks/use-format-phone-number';
import { organizationBadgeMap, organzaitionBadgeLabelMap } from '../../../types/organization';

const OrganizationProfileSummary = observer(() => {
  const { selectedOrganization } = useOrganizationProfile();
  const formatPhoneNumber = useFormatPhoneNumber();

  return (
    <div style={{ width: '1032px' }}>
      <GoAContainer type="info" maxWidth="1032px" width="full">
        <GoABlock alignment="center" gap="3xs">
          <h1 className="client-no-padding-no-margin heading-xl">{`${selectedOrganization?.operatingName ?? ''}`}</h1>
          <GoASpacer hSpacing="m" />
          {selectedOrganization?.status && (
            <GoABadge
              type={organizationBadgeMap[selectedOrganization.status]}
              content={organzaitionBadgeLabelMap[selectedOrganization.status]}
            />
          )}
        </GoABlock>
        <GoASpacer vSpacing="xl" />
        <GoABlock gap="4xl" mb="2xl">
          <GoABlock direction="column" gap="xs">
            <b>Legal Name</b>
            <span>{selectedOrganization?.legalName}</span>
          </GoABlock>
          <GoABlock direction="column" gap="m">
            <b>Business phone number</b>
            <span>{formatPhoneNumber(`+1${selectedOrganization?.phoneNumber}`)}</span>
          </GoABlock>
          <GoABlock direction="column" gap="xs">
            <b>Website</b>
            {selectedOrganization?.website && (
              <a
                href={
                  selectedOrganization.website.indexOf('http') === -1
                    ? `https://${selectedOrganization.website}`
                    : selectedOrganization.website
                }
                target="_blank"
                className="client-bold-600"
                rel="noopener noreferrer"
              >
                {selectedOrganization.website}
              </a>
            )}
          </GoABlock>
          <GoABlock direction="column" gap="xs">
            <b>Business contact</b>
            <span>{selectedOrganization?.emailAddress}</span>
          </GoABlock>
        </GoABlock>
      </GoAContainer>
    </div>
  );
});

export default OrganizationProfileSummary;
