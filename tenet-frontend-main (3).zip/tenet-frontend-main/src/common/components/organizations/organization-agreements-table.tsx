import { useEffect } from 'react';
import { useParams } from 'react-router';
import { format, isFuture } from 'date-fns';
import {
  GoABadge,
  GoABlock,
  GoAButton,
  GoACheckbox,
  GoAIcon,
  GoAInput,
  GoASpacer,
  GoATable,
  GoATableSortHeader,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useOrganizationProfile from './hooks/use-organization-profile';
import { useStore } from '../../../hooks/use-store.hook';
import useAgreementsPagination from './hooks/use-agreements-pagination.hook';
import { AgreementProgramTypeAbbr } from '../../../types/agreement';
import { toIsoDate } from '../../../utils/date.util';

const OrganizationAgreementsTable = observer(() => {
  const {
    newAgreementBtnClickHandler,
    openAgreement,
    sortAgreementData,
    showExpiredAgreements,
    setShowExpiredAgreements,
  } = useOrganizationProfile();
  const {
    organizationStore: {
      hasAgreements,
      agreements,
      getOrganizationAgreements,
      getAgreementsListSize,
      currentAgreementsListPosition,
    },
    agreementFilesStore: { resetStore },
    permissionStore: { canCreateAgreement },
  } = useStore();
  const agreementsPagination = useAgreementsPagination();
  const { id: organizationId } = useParams();

  useEffect(() => {
    getOrganizationAgreements(organizationId!);
    resetStore();
  }, [organizationId, getOrganizationAgreements, currentAgreementsListPosition, getAgreementsListSize, resetStore]);

  return (
    <>
      <GoABlock gap="l" direction="column">
        <div className="contracts-header">
          <GoABlock direction="column" gap="m">
            <h3>
              <span className="heading-xs color-interactive">Contracts and grants</span>
            </h3>
            <span className="body-medium color-default">View and manage agreements</span>
          </GoABlock>
          {canCreateAgreement && (
            <GoABlock gap="1">
              <GoAButton type="primary" leadingIcon="add" onClick={newAgreementBtnClickHandler}>
                New agreement
              </GoAButton>
            </GoABlock>
          )}
        </div>
        <GoASpacer vSpacing="l" />
        <div className="contracts-search">
          <GoABlock>
            <GoAInput
              leadingIcon="search"
              name="searchContracts"
              onChange={() => {}}
              placeholder="Search agreement name, number"
              width="299px"
            />
            <GoAButton type="secondary" onClick={() => {}}>
              Search agreement
            </GoAButton>
          </GoABlock>
          <GoACheckbox
            text="Show expired agreements"
            name="showExpired"
            onChange={() => {
              setShowExpiredAgreements();
              getOrganizationAgreements(organizationId!);
            }}
            checked={showExpiredAgreements}
          />
        </div>
      </GoABlock>
      <GoATable onSort={sortAgreementData} width="1032px">
        <thead>
          <tr>
            <th>
              <GoATableSortHeader name="name">Agreement Name</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="agreementNumber">Number</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="programType">Type</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="startDate">Start</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="endDate">End</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="csc">CSC</GoATableSortHeader>
            </th>
          </tr>
        </thead>
        {hasAgreements && (
          <tbody>
            {agreements.map(({ id, name, agreementNumber, programType, startDate, endDate, creationCompleted }) => {
              return (
                <tr key={id} className="hand-cursor" onClick={() => openAgreement(id, !!creationCompleted)}>
                  <td className="color-interactive-default">{name}</td>
                  <td>{agreementNumber}</td>
                  <td>{AgreementProgramTypeAbbr[programType]}</td>
                  <td>{startDate && format(toIsoDate(startDate), 'MMM d, yyyy')}</td>
                  <td>
                    {endDate && (
                      <GoABadge
                        type={isFuture(toIsoDate(endDate)) ? 'success' : 'information'}
                        content={format(toIsoDate(endDate), 'MMM d, yyyy')}
                      />
                    )}
                  </td>
                  <td>{}</td>
                </tr>
              );
            })}
          </tbody>
        )}
      </GoATable>
      {!hasAgreements && (
        <div className="orgContractsBadgeDisplay">
          <div className="container">
            <div className="ellipse">
              <GoAIcon theme="outline" size="xlarge" type="file-tray" testId="noOrganizationContractBadge" />
            </div>
          </div>
          <p>{`There isn't any agreement yet.`}</p>
          <GoASpacer vSpacing="m" />
        </div>
      )}
      <div className="contracts-pagination">{agreementsPagination}</div>
    </>
  );
});

export default OrganizationAgreementsTable;
