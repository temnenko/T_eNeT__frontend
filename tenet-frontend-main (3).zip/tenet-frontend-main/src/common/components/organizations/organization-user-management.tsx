import { observer } from 'mobx-react-lite';
import { useEffect, useState } from 'react';
import { GoAButton, GoASpacer, GoATab, GoATabs } from '@abgov/react-components';
import { useParams } from 'react-router-dom';

import { OrganizationsUsersFilter } from './organization-users-filter';
import { useStore } from '../../../hooks/use-store.hook';
import useUsersListPagination from '../../../hooks/use-users-list-pagination.hook';
import { UsersTable } from '../users/users-table';
import useOrganizationProfile from './hooks/use-organization-profile';
import { InviteUserTable } from './invites/invite-user.table';
import useManageUserInviteTable from './invites/hooks/use-manage-user-invite-table.hook';

export const OrganizationUserManagement = observer(() => {
  const [isLoading, setIsLoading] = useState(true);
  const { id: organizationId } = useParams();
  const {
    usersListStore: { getUsers, hasUsers, getListSize, currentListPosition },
  } = useStore();
  const usersListPagination = useUsersListPagination();
  const { selectedOrganization } = useOrganizationProfile();
  const { allInviteRows, addInviteRow, removeInviteRow } = useManageUserInviteTable();

  useEffect(() => {
    getUsers(organizationId).finally(() => setIsLoading(false));
  }, [getUsers, getListSize, currentListPosition, organizationId]);

  return (
    <>
      <h3 className="org-heading-medium">Manage users</h3>
      <span>View, manage and invite users under this organization.</span>
      <GoASpacer vSpacing="xl" />
      <OrganizationsUsersFilter />
      <GoASpacer vSpacing="l" />
      <GoATabs>
        <GoATab heading="Manage users">
          <UsersTable
            organizationName={selectedOrganization?.legalName ?? ''}
            isOrgRender
            hasUsers={hasUsers}
            isLoading={isLoading}
          />
          {usersListPagination}
        </GoATab>
        <GoATab heading="Invite users">
          <GoAButton leadingIcon="add" onClick={addInviteRow} type="secondary" size="compact">
            Add a row
          </GoAButton>
          <GoASpacer vSpacing="m" />
          <InviteUserTable renderIds={allInviteRows} removeInvite={removeInviteRow} />
        </GoATab>
      </GoATabs>
    </>
  );
});
