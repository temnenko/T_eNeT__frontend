import { GoAButton, GoACheckbox, GoAFormItem, GoAInput, GoASpacer } from '@abgov/react-components';

export function OrganizationsUsersFilter() {
  return (
    <section className="org-filter-section">
      <form className="org-filter-form-group">
        <GoAFormItem>
          <GoAInput
            type="search"
            leadingIcon="search"
            placeholder="Search user"
            onChange={() => {}}
            name="userSearch"
            width="32ch"
          />
        </GoAFormItem>
        <GoASpacer hSpacing="xs" />
        <GoAFormItem>
          <GoAButton type="secondary" onClick={() => {}}>
            Search
          </GoAButton>
        </GoAFormItem>
      </form>
      <GoACheckbox name="showDeactivatedUsers" text="Show deactivated users" onChange={() => {}} checked={false} />
    </section>
  );
}
