/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoATable } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

type Props = {
  locationRows?: JSX.Element[];
};

export const LocationTable = observer(({ locationRows }: Props) => {
  return (
    <GoATable width="64.5rem">
      <thead>
        <th />
        <th>Location name</th>
        <th>Headquarter</th>
        <th>Address</th>
        <th />
      </thead>
      {locationRows?.length ? <tbody>{locationRows}</tbody> : <div>No locations found</div>}
    </GoATable>
  );
});
