/* eslint-disable no-plusplus */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { useMemo } from 'react';
import { GoABlock, GoAButton, GoAIcon } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useModal } from '../../../../hooks/use-modal.hook';
import { OfficeLocation } from '../../forms/organizations/modals/office-location';
import { Location } from '../../../../types/organization';
import { useFormatPhoneNumber } from '../../../../hooks/use-format-phone-number';
import { useStore } from '../../../../hooks/use-store.hook';

type Props = {
  location: Location;
  expandedRecordId?: string;
  showHQ?: boolean;
  toggleExpansion: (id: string) => void;
};

export const LocationRow = observer(({ expandedRecordId, location, toggleExpansion, showHQ = true }: Props) => {
  const isOpen = useMemo(() => expandedRecordId === location.id, [expandedRecordId, location.id]);
  const iconType = useMemo(() => (isOpen ? 'chevron-down' : 'chevron-forward'), [isOpen]);
  const formatPhoneNumber = useFormatPhoneNumber();
  const { showModal, hideModal } = useModal();
  const {
    permissionStore: { canUpdateOrganizationDetails },
  } = useStore();

  return (
    <>
      <tr key={location.id}>
        <td>
          <button type="button" className="org-location-openBtn" onClick={() => toggleExpansion(location.id)}>
            <GoAIcon type={iconType} />
          </button>
        </td>
        <td>{location.name}</td>
        <td>{location.isPrimaryLocation ? 'Yes' : '-'}</td>
        <td>{`${location?.street}, ${location?.city} ${location?.postalCode}`}</td>
        <td>
          {canUpdateOrganizationDetails && (
            <GoAButton
              type="tertiary"
              onClick={() => {
                showModal(
                  <OfficeLocation hideModal={hideModal} hideHeadquarterField={!showHQ} selectedLocation={location} />,
                );
              }}
            >
              Edit
            </GoAButton>
          )}
        </td>
      </tr>
      {isOpen && (
        <tr>
          <td colSpan={6}>
            <div className="org-location-content">
              <GoABlock>
                <GoABlock direction="column">
                  <div>
                    <p>Phone</p>
                    <p>{formatPhoneNumber(location.phoneNumber)}</p>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div>
                    <p>Email</p>
                    <p>{location.email}</p>
                  </div>
                </GoABlock>
              </GoABlock>
            </div>
          </td>
        </tr>
      )}
    </>
  );
});
