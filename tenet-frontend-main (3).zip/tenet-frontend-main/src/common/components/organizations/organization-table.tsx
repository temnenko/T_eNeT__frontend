/* eslint-disable jsx-a11y/control-has-associated-label */

import { observer } from 'mobx-react-lite';
import { GoATable, GoAIcon, GoAButton, GoATableSortHeader } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useStore } from '../../../hooks/use-store.hook';
import { OrganizationRow } from './organization-row';
import useOrganizationsListPagination from './hooks/use-organizations-pagination.hook';
import { LoadingSkeleton } from '../users/users-list.skeleton';
import { OrganizationKey } from '../../../types/organization';

export const OrganizationTable = observer(() => {
  const {
    organizationStore: { resetSelectedOrganization },
    organizationListStore: {
      organizationsList,
      getOrganizationsList,
      getListSize,
      currentListPosition,
      hasOrganizations,
      nameSearch,
      sortData,
    },
  } = useStore();

  const orgListPagination = useOrganizationsListPagination();

  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const sortOrganizationData = useCallback(
    (sortBy: string, sortDir: number) => {
      sortData(sortBy as OrganizationKey, sortDir);
    },
    [sortData],
  );

  useEffect(() => {
    resetSelectedOrganization();
    getOrganizationsList().finally(() => setIsLoading(false));
  }, [getOrganizationsList, getListSize, currentListPosition, resetSelectedOrganization]);

  const loadingListWithSkeleton = useMemo(
    () =>
      isLoading ? (
        <LoadingSkeleton />
      ) : (
        <tbody>
          {organizationsList.map(({ id, operatingName, legalName, status }) => (
            <OrganizationRow key={id} id={id} status={status} operatingName={operatingName} legalName={legalName} />
          ))}
        </tbody>
      ),
    [isLoading, organizationsList],
  );
  const messagePostFix = useMemo(() => (nameSearch ? `for ${nameSearch}` : undefined), [nameSearch]);

  return (
    <div className="organization-list-view">
      <GoATable width="100%" onSort={sortOrganizationData}>
        <thead>
          <tr>
            <th>
              <GoATableSortHeader name="status">Status</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="operatingName">Operating Name</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="legalName">Legal Name</GoATableSortHeader>
            </th>
            <th />
          </tr>
        </thead>
        {hasOrganizations ? loadingListWithSkeleton : undefined}
      </GoATable>
      {!hasOrganizations && (
        <div className="organization-empty-list">
          <div className="orgBadgeDisplay">
            <div className="ellipse">
              <GoAIcon theme="outline" size="large" type="search" />
            </div>
          </div>
          <div>
            <b>{`We found 0 result ${messagePostFix}`}</b>
            {messagePostFix && (
              <>
                <p>Try the following to see more results:</p>
                <br />
                <p>Check your spelling</p>
                <p>Try a different keyword</p>
                <b>or</b>
              </>
            )}
            <br />
            <GoAButton type="tertiary" onClick={() => navigate('/organizations/enroll/primary-details')}>
              Create a new organization
            </GoAButton>
          </div>
        </div>
      )}
      {orgListPagination}
    </div>
  );
});
