import { useMemo } from 'react';
import { GoABadge, GoABlock, GoAContainer, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { format } from 'date-fns';

import { useStore } from '../../../../hooks/use-store.hook';
import { toIsoDate } from '../../../../utils/date.util';

const AgreementDetailsSummary = observer(() => {
  const {
    agreementStore: { selectedAgreement },
  } = useStore();

  const formattedInterventionLength = useMemo(() => {
    const interventionLength = selectedAgreement?.activeInterventionLength;

    return typeof interventionLength === 'number' && interventionLength > 1
      ? `${interventionLength} weeks`
      : `${interventionLength ?? 0} week`;
  }, [selectedAgreement?.activeInterventionLength]);

  return (
    <div style={{ width: '1032px' }}>
      <GoAContainer type="info" maxWidth="1032px" width="full">
        <GoABlock alignment="center" gap="3xs">
          <h1 className="client-no-padding-no-margin heading-xl">{`${selectedAgreement?.name ?? ''}`}</h1>
          <GoASpacer hSpacing="m" />
          {!selectedAgreement?.agreementNumber && <GoABadge type="important" content="Pending" />}
          {selectedAgreement?.agreementNumber && <GoABadge type="information" content="Active" />}
        </GoABlock>
        <GoASpacer vSpacing="xl" />
        <GoABlock gap="4xl" mb="l" alignment="start">
          <GoABlock direction="column" gap="s">
            <b>Agreement number</b>
            <span>{selectedAgreement?.agreementNumber}</span>
          </GoABlock>
          <GoABlock direction="column" gap="s">
            <b>Start date</b>
            <span>
              {selectedAgreement?.startDate ? format(toIsoDate(selectedAgreement.startDate), 'dd MMM, yyyy') : ''}
            </span>
          </GoABlock>
          <GoABlock direction="column" gap="s">
            <b>Last intake date</b>
            <span>
              {selectedAgreement?.lastIntakeDate
                ? format(toIsoDate(selectedAgreement.lastIntakeDate), 'dd MMM, yyyy')
                : ''}
            </span>
          </GoABlock>
          <GoABlock direction="column" gap="s">
            <b>End date</b>
            <span>
              {selectedAgreement?.endDate ? format(toIsoDate(selectedAgreement.endDate), 'dd MMM, yyyy') : ''}
            </span>
          </GoABlock>
        </GoABlock>
        <GoABlock gap="4xl" mb="xl" alignment="start">
          <GoABlock direction="column" gap="s">
            <b>LMDA/WDA split</b>
            <span>{selectedAgreement?.targetLmdaWdaSplit}</span>
          </GoABlock>
          <GoABlock direction="column" gap="s">
            <b>Max starter</b>
            <span>{selectedAgreement?.participantsMaxNumber}</span>
          </GoABlock>
          <GoABlock direction="column" gap="s">
            <b>Expected length of active intervention</b>
            <span>{formattedInterventionLength}</span>
          </GoABlock>
        </GoABlock>
      </GoAContainer>
    </div>
  );
});

export default AgreementDetailsSummary;
