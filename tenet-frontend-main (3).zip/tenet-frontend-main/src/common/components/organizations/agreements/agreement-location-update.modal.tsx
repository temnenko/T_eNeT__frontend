/* eslint-disable consistent-return */
import { useCallback, useMemo } from 'react';
import {
  GoAButton,
  GoAButtonGroup,
  GoADivider,
  GoAFormItem,
  GoAModal,
  GoANotification,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useAgreementDeliveryLocation from '../../forms/agreements/new/hooks/use-agreement-delivery-location.hook';
import AutocompleteInput from '../../auto-complete-input';
import LocationCard from '../../forms/agreements/new/delivery-locations/location-card';
import { LocationFormModal } from '../../forms/agreements/new/delivery-locations/location-form.modal';

export const AgreementLocationUpdateModal = observer(({ hideModal }: { hideModal: () => void }) => {
  const {
    locationSearch,
    filteredLocations,
    selectedLocations,
    locationData,
    onSelectLocation,
    onErrorDismiss,
    addDeliveryLocationHandler,
    editLocationHandler,
    removeLocationHandler,
    setSearchableField,
    makeModalVisible,
    hideVisibleModal,
    modalContent,
    modalVisible,
    requestError,
  } = useAgreementDeliveryLocation({ hideModal });
  const isLocations = useMemo(() => !!locationData.length, [locationData.length]);
  const helpText = useMemo(
    () =>
      isLocations ? 'You can type in a location name to find existing office location.' : 'No existing locations found',
    [isLocations],
  );
  const addNewLocationHandler = useCallback(() => {
    makeModalVisible(<LocationFormModal hideModal={hideVisibleModal} submitLabel={undefined} />);
  }, [hideVisibleModal, makeModalVisible]);

  return (
    <GoAModal maxWidth="1000px" open width="88px" transition="slow" heading="Add a location" onClose={hideModal}>
      {modalVisible && modalContent}
      <div className="agreement-form">
        <GoAFormItem helpText={helpText}>
          <span>
            Choose from locations previously added. If it’s not listed, you will still be able to add additional
            locations below.
          </span>
          <AutocompleteInput
            name="locationSearch"
            id="locationSearch"
            placeholder=""
            width="42rem"
            onSelectAddress={undefined}
            onSelectUser={undefined}
            onSelectSuggestion={onSelectLocation}
            value={locationSearch}
            subType=""
            setField={setSearchableField}
            addAction={addNewLocationHandler}
            addLabel="Add a delivery location"
            suggestionData={filteredLocations}
          />
        </GoAFormItem>
        {selectedLocations.map((loc, pos) => (
          <LocationCard
            key={loc.id}
            location={loc}
            onRemoveHandler={() => removeLocationHandler({ id: loc.id, pos })}
            onEditHandler={
              loc.canEdit
                ? () => {
                    addNewLocationHandler();
                    editLocationHandler(pos);
                  }
                : undefined
            }
          />
        ))}
        <GoADivider mb="5" mt="5" />
        {requestError?.message && (
          <GoANotification type="important" onDismiss={onErrorDismiss}>
            {requestError.message}
          </GoANotification>
        )}

        <GoASpacer vSpacing="2xl" />
        <GoAButtonGroup alignment="start">
          <GoAButton type="primary" onClick={addDeliveryLocationHandler}>
            <span>Save</span>
          </GoAButton>
          <GoAButton type="secondary" onClick={hideModal}>
            <span>Cancel</span>
          </GoAButton>
        </GoAButtonGroup>
      </div>
    </GoAModal>
  );
});
