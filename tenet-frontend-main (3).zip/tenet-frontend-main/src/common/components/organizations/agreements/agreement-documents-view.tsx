import { observer } from 'mobx-react-lite';

import { GoAFileUploadInput, GoAFormItem, GoANotification, GoASpacer, GoATable } from '@abgov/react-components';
import useAgreementDocuments from './hooks/use-agreement-documents-view.hook';
import { AgreementDocumentsRow } from './agreement-document-row';

export const AgreementDocumentsView = observer(() => {
  const {
    loading,
    requestError,
    invalidUploadError,
    setInvalidUploadError,
    selectedAgreement,
    uploads,
    fileBeingDeleted,
    fileDeletedSuccessfully,
    openDeleteConfirmationDialog,
    uploadFile,
    onFileTypeChange,
    progressList,
    setFileDeletedSuccessfully,
    downloadFile,
    uploadError,
    setUploadError,
    canDeleteFiles,
  } = useAgreementDocuments();
  return (
    <div className="create-client-form">
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {invalidUploadError && (
        <>
          <GoANotification type="emergency" onDismiss={() => setInvalidUploadError(null)}>
            {invalidUploadError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {uploadError && (
        <>
          <GoASpacer vSpacing="l" />
          <GoANotification type="important" onDismiss={() => setUploadError(null)}>
            {uploadError}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {selectedAgreement && (
        <form>
          <GoAFormItem requirement="optional">
            <GoAFileUploadInput onSelectFile={uploadFile} maxFileSize="100MB" />
          </GoAFormItem>
          <GoASpacer vSpacing="l" />
          {fileDeletedSuccessfully && (
            <GoANotification type="information" onDismiss={() => setFileDeletedSuccessfully(false)}>
              File deleted successfully
            </GoANotification>
          )}
          <GoATable width="58.125rem">
            <thead>
              <tr>
                <th data-testid="clientCreationUploadedFiles">Files</th>
                <th data-testid="clientCreationFileType">Type</th>
                <th data-testid="clientCreationFileUser">User</th>
                <th data-testid="clientCreationFilesDateAdded">Date added</th>
                <th>{}</th>
                <th>{}</th>
              </tr>
            </thead>
            {uploads?.length ? (
              <tbody data-testid="clientCreationUploadedFilesTableBody">
                <AgreementDocumentsRow
                  uploads={uploads}
                  progressList={progressList}
                  deleteHandler={openDeleteConfirmationDialog}
                  onFileTypeChange={onFileTypeChange}
                  fileBeingDeleted={fileBeingDeleted}
                  downloadFile={downloadFile}
                  loading={loading}
                  canDeleteFiles={canDeleteFiles}
                />
              </tbody>
            ) : undefined}
          </GoATable>
          <GoASpacer vSpacing="2xl" />
        </form>
      )}
      <GoASpacer vSpacing="xl" />
    </div>
  );
});
