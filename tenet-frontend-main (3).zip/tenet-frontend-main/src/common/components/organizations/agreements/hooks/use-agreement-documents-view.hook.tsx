import { useCallback, useEffect, useMemo, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useStore } from '../../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../types/errors/errors';
import { InvalidFileUploadError } from '../../../../../types/errors/invalid-file-upload.error';
import { MockUploader, TenetFile, Upload } from '../../../../../types/files';
import { fileService } from '../../../../../services/clients/client-files.service';
import useFileNotValid from '../../../../../utils/file.util';
import { useModal } from '../../../../../hooks/use-modal.hook';
import { ConfirmationModal } from '../../../modals/confirmation.modal';

const useAgreementDocumentsView = () => {
  const {
    agreementStore: { documents, getAgreementDocuments, selectedAgreement },
    agreementFilesStore: { addToNewUploads, deleteDocument, removeDocumentFromUploads, uploadAgreementDocuments },
    permissionStore: { isSuperAdmin },
  } = useStore();

  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [invalidUploadError, setInvalidUploadError] = useState<InvalidFileUploadError | null>(null);
  const [fileDeletedSuccessfully, setFileDeletedSuccessfully] = useState(false);
  const [fileBeingDeleted, setFileBeingDeleted] = useState<string | null>(null);
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [progressList, setProgressList] = useState<Record<string, number>>({});
  const [uploadError, setUploadError] = useState<string | null>(null);
  const { hideModal, showModal } = useModal();

  useEffect(() => {
    if (documents?.length > 0) {
      setUploads(
        documents.map((doc) => ({
          id: doc.id,
          file: new File([], doc.fileName),
          fileType: doc.typeName,
          uploader: {
            onprogress: () => {},
          },
          addedByFullName: doc.addedByFullName,
          createdAt: doc.adspCreatedAt,
          size: doc.size,
          persisted: true,
          adspId: doc.adspId,
        })),
      );
    }
  }, [documents, documents?.length]);

  useEffect(() => {
    const fetchAgreement = async () => {
      if (selectedAgreement?.id) {
        await getAgreementDocuments(selectedAgreement?.id);
      }
    };

    fetchAgreement();
  }, [getAgreementDocuments, selectedAgreement?.id]);

  const submitHandler = useCallback(async () => {
    let persistedFiles: TenetFile[] = [];
    try {
      setInvalidUploadError(null);
      setLoading(true);
      persistedFiles = await uploadAgreementDocuments(selectedAgreement!.id);
    } catch (error) {
      if (error instanceof InvalidFileUploadError) {
        setInvalidUploadError(error);
      } else {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      }
    } finally {
      setLoading(false);
    }
    return persistedFiles;
  }, [requestErrorHandler, selectedAgreement, uploadAgreementDocuments]);

  const deleteFile = useCallback(
    async (file: Upload) => {
      hideModal();

      if (file.persisted) {
        setFileDeletedSuccessfully(false);
        setFileBeingDeleted(file.adspId);
        await deleteDocument(file.adspId);
        setFileBeingDeleted(null);
      } else {
        removeDocumentFromUploads(file.id);
      }
      setUploads((uploadz) => {
        return uploadz.filter((u) => u.id !== file.id);
      });
      await submitHandler();
      setFileDeletedSuccessfully(true);
    },
    [deleteDocument, hideModal, removeDocumentFromUploads, submitHandler],
  );

  const onFileTypeChange = useCallback(
    async (id: string, type: string | string[]) => {
      const upload = uploads.find((u) => u.id === id);
      if (!upload) return;

      const updatedUpload = { ...upload, fileType: type as string };

      await addToNewUploads(updatedUpload);
      const persisted = await submitHandler();
      setUploads(
        persisted.map((doc) => ({
          id: doc.id,
          file: new File([], doc.fileName),
          fileType: doc.typeName,
          uploader: {
            onprogress: () => {},
          },
          addedByFullName: doc.addedByFullName,
          createdAt: doc.adspCreatedAt,
          size: doc.size,
          persisted: true,
          adspId: doc.adspId,
        })),
      );
    },
    [addToNewUploads, submitHandler, uploads],
  );

  const downloadFile = useCallback(
    (fileId: string, filename: string, filesize: number) => {
      try {
        setLoading(true);
        fileService.downloadFileByAdspId(fileId, filename, filesize);
      } catch (error) {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    },
    [requestErrorHandler],
  );

  const { fileNotValidHandler } = useFileNotValid();

  const uploadFile = useCallback(
    async (file: File) => {
      try {
        fileNotValidHandler(file.name, file.type);
        const reader = new FileReader();
        reader.onload = async (e: ProgressEvent<FileReader>) => {
          if (!e.target) return;
          const url = e.target.result;
          const uploader: MockUploader = {
            onprogress: (percent) => {
              setProgressList((old) => ({ ...old, [file.name]: percent }));
            },
          };

          uploader.upload = () => {
            uploader.onprogress(200);
          };

          const newUpload = {
            file,
            uploader,
            fileType: '',
            id: uuidv4(),
            createdAt: new Date().toISOString(),
            size: file.size,
            addedByFullName: '',
            adspId: '',
          };

          setUploads((old) => [...old, newUpload]);

          await addToNewUploads(newUpload);

          if (url) {
            uploader.upload(url);
          }
        };
        reader.readAsDataURL(file);

        setLoading(false);
      } catch (e) {
        if (e instanceof InvalidFileUploadError) {
          setUploadError(e.message);
        }
      }
    },
    [addToNewUploads, fileNotValidHandler],
  );

  const formatBytes = useMemo(
    () =>
      (bytes: number, decimals = 1) => {
        if (!+bytes) return '0 Bytes';

        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return `${parseFloat((bytes / k ** i).toFixed(dm))} ${sizes[i]}`;
      },
    [],
  );

  const openDeleteConfirmationDialog = useCallback(
    (file: Upload) => {
      showModal(
        <ConfirmationModal
          heading="Delete file?"
          description="Are you sure you want to delete this file?"
          declineText="Oops, go back"
          confirmText="Yes, delete"
          onConfirm={() => deleteFile(file)}
          onDecline={hideModal}
          isDelete
        />,
      );
    },
    [deleteFile, hideModal, showModal],
  );

  return {
    loading,
    requestError,
    invalidUploadError,
    setInvalidUploadError,
    selectedAgreement,
    uploads,
    fileBeingDeleted,
    fileDeletedSuccessfully,
    formatBytes,
    deleteFile,
    uploadFile,
    onFileTypeChange,
    progressList,
    setFileDeletedSuccessfully,
    downloadFile,
    uploadError,
    setUploadError,
    canDeleteFiles: isSuperAdmin,
    openDeleteConfirmationDialog,
  };
};

export default useAgreementDocumentsView;
