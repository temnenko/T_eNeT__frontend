import { useCallback, useMemo } from 'react';
import { GoAIcon, GoASideMenu, GoASpacer } from '@abgov/react-components';
import { useNavigate, useParams, NavLink, useLocation } from 'react-router-dom';

import { useStore } from '../../../../../hooks/use-store.hook';

const useAgreementSideMenu = () => {
  const {
    authStore: { isAuthenticated },
    agreementStore: { selectedAgreement },
  } = useStore();
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const agreementDetailLink = `/agreements/${id}`;

  const getActive = useCallback((isActive: boolean) => {
    if (isActive) {
      return { fontWeight: 'bold' };
    }
    return { fontWeight: 'normal' };
  }, []);

  const getAgreementDetailActive = useCallback(
    (isActive: boolean) => {
      if (location.pathname === agreementDetailLink && isActive) {
        return { fontWeight: 'bold' };
      }
      return { fontWeight: 'normal' };
    },
    [agreementDetailLink, location.pathname],
  );

  return useMemo(() => {
    if (isAuthenticated) {
      return (
        <section className="org-side-menu-section">
          <NavLink
            className="organization-back-link"
            to="#"
            onClick={() => navigate(`/organizations/${selectedAgreement!.organizationId}/agreements`)}
          >
            <span>
              <GoAIcon type="chevron-back" />
            </span>
            Agreements
          </NavLink>
          <GoASpacer vSpacing="2xl" />
          <div className="organization-side-menu">
            <GoASideMenu>
              <NavLink
                data-testid="a-agreementDetails"
                to={agreementDetailLink}
                style={({ isActive }) => getAgreementDetailActive(isActive)}
              >
                Agreement details
              </NavLink>
              <NavLink
                data-testid="a-contactGroup"
                to={`/agreements/${id}/contacts`}
                style={({ isActive }) => getActive(isActive)}
              >
                Contact group
              </NavLink>
              <NavLink
                data-testid="a-deliveryLocations"
                to={`/agreements/${id}/locations`}
                style={({ isActive }) => getActive(isActive)}
              >
                Delivery locations
              </NavLink>
              <NavLink
                data-testid="a-performanceTracking"
                to={`/agreements/${id}/performance-tracking`}
                style={({ isActive }) => getActive(isActive)}
              >
                Performance tracking
              </NavLink>
              <NavLink
                data-testid="a-reports"
                to={`/agreements/${id}/reports`}
                style={({ isActive }) => getActive(isActive)}
              >
                Reports
              </NavLink>
              <NavLink
                data-testid="a-documents"
                to={`/agreements/${id}/documents`}
                style={({ isActive }) => getActive(isActive)}
              >
                Documents
              </NavLink>
            </GoASideMenu>
          </div>
        </section>
      );
    }

    return '';
  }, [isAuthenticated, agreementDetailLink, id, navigate, selectedAgreement, getAgreementDetailActive, getActive]);
};

export default useAgreementSideMenu;
