import { GoAButton, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useAgreementLocation from '../hooks/use-locations';
import { LocationTable } from '../locations/location-table';
import { useModal } from '../../../../hooks/use-modal.hook';
import { AgreementLocationUpdateModal } from './agreement-location-update.modal';
import { useStore } from '../../../../hooks/use-store.hook';

export const AgreementLocations = observer(() => {
  const { locationRows } = useAgreementLocation(true);
  const { showModal, hideModal } = useModal();
  const {
    permissionStore: { canCreateNewAgreementLocation },
  } = useStore();

  return (
    <>
      <h2>Delivery locations</h2>
      <div className="org-office-locations">
        <p>View and manage delivery locations of this agreement.</p>
        {canCreateNewAgreementLocation && (
          <GoAButton
            size="compact"
            leadingIcon="add"
            onClick={() => {
              showModal(<AgreementLocationUpdateModal hideModal={hideModal} />);
            }}
          >
            Add location
          </GoAButton>
        )}
      </div>
      <GoASpacer vSpacing="l" />
      <LocationTable locationRows={locationRows} />
    </>
  );
});
