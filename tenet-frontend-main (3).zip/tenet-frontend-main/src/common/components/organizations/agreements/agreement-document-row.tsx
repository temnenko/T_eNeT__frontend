/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { format } from 'date-fns';
import { GoABlock, GoADropdown, GoADropdownItem, GoAIconButton } from '@abgov/react-components';
import { Upload } from '../../../../types/files';
import ProgressBar from '../../progress-bar/progress-bar';
import { AgreementFileUploadTypes } from '../../../../types/agreement-forms';
import InlineLoadingIndicator from '../../forms/inline-loading-indicator';
import { toIsoDate } from '../../../../utils/date.util';

type Props = {
  uploads: Upload[];
  progressList: Record<string, number>;
  fileBeingDeleted: string | null;
  deleteHandler: (file: Upload) => void;
  onFileTypeChange: (name: string, value: string | string[]) => void;
  downloadFile: (fileId: string, filename: string, filesize: number) => void;
  loading: boolean;
  canDeleteFiles: boolean;
};

export function AgreementDocumentsRow({
  uploads,
  progressList,
  fileBeingDeleted,
  deleteHandler,
  onFileTypeChange,
  downloadFile,
  loading,
  canDeleteFiles,
}: Props) {
  return (
    <>
      {uploads.map((upload) => (
        <tr key={`${upload.id}-${progressList[upload.id]}`}>
          <td>
            <GoABlock direction="column" gap="xs">
              <span>{upload.file.name}</span>
              <ProgressBar
                visualParts={[
                  {
                    percentage: progressList[upload.file.name],
                    color: '#004A8F',
                  },
                ]}
              />
            </GoABlock>
          </td>
          <td>
            <GoADropdown
              width="200px"
              name={upload.id}
              ariaLabelledBy="fileTypeSelector"
              onChange={(name: string, value: string | string[]) => onFileTypeChange(name, value)}
              value={upload.fileType}
              disabled={upload.persisted || loading}
              relative
            >
              <GoADropdownItem value="" name="selectType" label="-- Select --" />
              <GoADropdownItem
                value={AgreementFileUploadTypes.AGREEMENTS_AND_SCHEDULES}
                name="agreements-and-schedules"
                label="Schedule A"
              />
              <GoADropdownItem
                value={AgreementFileUploadTypes.AGREEMENT_MONITOR_PLAN}
                name="agreement-monitor-plan"
                label="Monitoring Plan"
              />
              <GoADropdownItem
                value={AgreementFileUploadTypes.AGREEMENT_STAFFING_MATRIX}
                name="agreement-staffing-matrix"
                label="Staffing Matrix"
              />
              <GoADropdownItem value={AgreementFileUploadTypes.AGREEMENT_OTHER} name="agreement-other" label="Other" />
            </GoADropdown>
          </td>
          <td>{upload.addedByFullName}</td>
          <td>{format(toIsoDate(upload.createdAt), 'MMM dd, yyyy')}</td>
          <td>
            <GoAIconButton
              onClick={() => {
                if (upload.adspId) {
                  downloadFile(upload.adspId, upload.file.name, upload.size);
                }
              }}
              icon="download"
              disabled={fileBeingDeleted === upload.adspId || !upload.adspId || loading}
            />
          </td>
          <td>
            {canDeleteFiles && (
              <>
                {fileBeingDeleted === upload.adspId ? (
                  <InlineLoadingIndicator />
                ) : (
                  <GoAIconButton
                    onClick={() => deleteHandler(upload)}
                    icon="trash"
                    disabled={fileBeingDeleted === upload.adspId}
                    variant="dark"
                  />
                )}
              </>
            )}
          </td>
          <td>
            <progress id={`statusBar-${upload.adspId}`} style={{ display: 'none' }} />
          </td>
        </tr>
      ))}
    </>
  );
}
