import { observer } from 'mobx-react-lite';
import { GoABlock, GoASpacer } from '@abgov/react-components';

import { OrganizationTable } from './organization-table';
import { OrganizationsListFilter } from './organization-list-filter';

export const OrganizationView = observer(() => {
  return (
    <GoABlock direction="column" gap="2xs" alignment="center">
      <div>
        <h2>TENET Organizations</h2>
        <OrganizationsListFilter />
        <GoASpacer vSpacing="l" />
        <OrganizationTable />
      </div>
      <GoASpacer vSpacing="l" />
    </GoABlock>
  );
});
