/* eslint-disable prettier/prettier */
import { useCallback } from 'react';
import { observer } from 'mobx-react-lite';
import { GoANotification, GoASpacer } from '@abgov/react-components';
import useOrganizationCompliance from './hooks/use-organization-compliance';
import { useModal } from '../../../hooks/use-modal.hook';
import { OrganizationAddNewFile } from './organization-add-new-file';
import { OrganizationComplianceSection } from './organization-file-section';
import { useStore } from '../../../hooks/use-store.hook';
import { OrganizationComplianceFilesTypeMap } from '../../../types/organization';
import { toIsoFormat } from '../../../utils/date.util';

const OrganizationCompliance = observer(() => {
  const { organization, downloadFile, requestError } = useOrganizationCompliance();

  const {
    organizationEnrollmentStore: {
      corporateIdentityDocuments,
      lobbyistCheckProof,
      wcbVerificationProof,
      liabilityPolicyProof,
      assessmentResult,
    },
    permissionStore: { canEditOrganizationCompliance },
  } = useStore();

  const formatDate = useCallback((val?: Date) => {
    return val ? toIsoFormat(val) : undefined;
  }, []);

  const { showModal } = useModal();

  return (
    <>
      {/* Corporate Information */}
      <OrganizationComplianceSection
        title="Corporate Information"
        documents={corporateIdentityDocuments}
        addNewHandler={() =>
          showModal(
            <OrganizationAddNewFile
              modalTitle="Add new corporate information"
              fieldTitle="Corporate identity number"
              fieldFormName="corporateIdentityNumber"
              fieldValue={organization?.corporateIdentityNumber}
              fieldType="text"
              fileInputLabel="Upload proof of corporate identity documents"
              uploadType={OrganizationComplianceFilesTypeMap.corporateIdentityDocuments}
            />,
          )
        }
        dateLabel=""
        dateValue=""
        corporateIdentityNumberLabel="Corporate identity number"
        corporateIdentityNumberValue={organization?.corporateIdentityNumber}
        additonalInfoLabel="Partner number"
        additonalInfoValue={organization?.partnerNumber}
        downloadFile={downloadFile}
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />

      {/* Lobbyist Check */}
      <OrganizationComplianceSection
        title="Lobbyist Check"
        dateLabel="Lobbyist check date"
        dateValue={organization?.lobbyistCheckedDate}
        documents={lobbyistCheckProof}
        addNewHandler={() =>
          showModal(
            <OrganizationAddNewFile
              modalTitle="Add new Lobbyist check"
              fieldTitle="Lobbyist check date"
              fieldFormName="lobbyistCheckedDate"
              fieldValue={formatDate(organization?.lobbyistCheckedDate)}
              fieldType="date"
              fileInputLabel="Upload proof of Lobbyist check"
              uploadType={OrganizationComplianceFilesTypeMap.lobbyistCheckProof}
            />,
          )
        }
        downloadFile={downloadFile}
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />

      {/* Workers Compensation Board (WCB) */}
      <OrganizationComplianceSection
        title="Workers Compensation Board (WCB)"
        dateLabel="WCB verified on"
        dateValue={organization?.wcbVerifiedOn}
        documents={wcbVerificationProof}
        addNewHandler={() =>
          showModal(
            <OrganizationAddNewFile
              modalTitle="Add new WCB"
              fieldTitle="WCB verified on"
              fieldFormName="wcbVerifiedOn"
              fieldValue={formatDate(organization?.wcbVerifiedOn)}
              fieldType="date"
              fileInputLabel="Upload proof of WCB"
              uploadType={OrganizationComplianceFilesTypeMap.wcbVerificationProof}
            />,
          )
        }
        downloadFile={downloadFile}
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />

      {/* Liability Insurance */}
      <OrganizationComplianceSection
        title="Liability Insurance"
        dateLabel="Policy expires on"
        dateValue={organization?.liabilityPolicyExpiresOn}
        documents={liabilityPolicyProof}
        addNewHandler={() =>
          showModal(
            <OrganizationAddNewFile
              modalTitle="Add new liability insurance"
              fieldTitle="Policy expires on"
              fieldFormName="liabilityPolicyExpiresOn"
              fieldValue={formatDate(organization?.liabilityPolicyExpiresOn)}
              fieldType="date"
              fileInputLabel="Upload proof of liability insurance"
              uploadType={OrganizationComplianceFilesTypeMap.liabilityPolicyProof}
            />,
          )
        }
        downloadFile={downloadFile}
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />

      {/* Privacy Self Assessment */}
      <OrganizationComplianceSection
        title="Privacy Self Assessment"
        dateLabel="Assessment completed on"
        dateValue={organization?.privacyAssessmentCompletedOn}
        documents={assessmentResult}
        addNewHandler={() =>
          showModal(
            <OrganizationAddNewFile
              modalTitle="Add new privacy self assessment"
              fieldTitle="Assessment completed on"
              fieldFormName="privacyAssessmentCompletedOn"
              fieldValue={formatDate(organization?.privacyAssessmentCompletedOn)}
              fieldType="date"
              fileInputLabel="Upload proof of self assessment"
              uploadType={OrganizationComplianceFilesTypeMap.assessmentResult}
            />,
          )
        }
        downloadFile={downloadFile}
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
    </>
  );
});

export default OrganizationCompliance;
