/* eslint-disable no-nested-ternary */
import {
  GoAButton,
  GoAButtonGroup,
  GoACircularProgress,
  GoADivider,
  GoAFileUploadCard,
  GoAFileUploadInput,
  GoAFormItem,
  GoAInput,
  GoAModal,
  GoANotification,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useModal } from '../../../hooks/use-modal.hook';
import { useOrganizationComplianceUpdate } from './hooks/use-organization-compliance-update';
import { toIsoFormat } from '../../../utils/date.util';

type Props = {
  modalTitle: string;
  fieldTitle: string;
  fieldFormName: string;
  fieldValue: string | undefined;
  fieldType: string;
  fileInputLabel: string;
  uploadType: string;
};
export const OrganizationAddNewFile = observer(
  ({ modalTitle, fieldTitle, fieldFormName, fieldValue, fieldType, fileInputLabel, uploadType }: Props) => {
    const { hideModal } = useModal();
    const {
      handleSubmit,
      saveHandler,
      onChangeHandler,
      getValues,
      errors,
      uploadFile,
      uploads,
      progressList,
      deleteFile,
      requestError,
      isLoading,
      uploadError,
      setUploadError,
    } = useOrganizationComplianceUpdate(fieldValue, fieldType, fieldFormName, uploadType, hideModal);

    return (
      <GoAModal maxWidth="500px" open heading={modalTitle} onClose={() => hideModal()}>
        <form>
          {requestError?.message && (
            <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
              {requestError.message}
            </GoANotification>
          )}
          {uploadError && (
            <>
              <GoASpacer vSpacing="l" />
              <GoANotification type="important" onDismiss={() => setUploadError(null)}>
                {uploadError}
              </GoANotification>
              <GoASpacer vSpacing="s" />
            </>
          )}

          {fieldType === 'text' ? (
            <GoAFormItem label={fieldTitle} error={errors.updatedValue?.message}>
              <GoAInput
                type="text"
                name="updatedValue"
                id="updatedValue"
                value={getValues('updatedValue') as string}
                onChange={onChangeHandler}
              />
            </GoAFormItem>
          ) : fieldType === 'date' ? (
            <GoAFormItem label={fieldTitle} error={errors.updatedValue?.message}>
              <GoAInput
                type="date"
                name="updatedValue"
                value={getValues('updatedValue') ? toIsoFormat(getValues('updatedValue')!) : undefined}
                onChange={onChangeHandler}
                min="0000-01-01"
                max="9999-12-31"
              />
            </GoAFormItem>
          ) : undefined}
          <GoASpacer vSpacing="m" />
          <GoAFormItem label={fileInputLabel}>
            <GoAFileUploadInput onSelectFile={uploadFile} variant="button" maxFileSize="10 Mb" />
            {uploads.map((upload) => (
              <GoAFileUploadCard
                key={upload.file.name}
                filename={upload.file.name}
                type={upload.file.type}
                size={upload.file.size}
                progress={progressList[upload.file.name]}
                onDelete={() => deleteFile(upload)}
                onCancel={() => deleteFile(upload)}
              />
            ))}
          </GoAFormItem>
          <GoASpacer vSpacing="xl" />
          <GoADivider />
          <GoASpacer vSpacing="m" />
          {isLoading && (
            <div className="d-flex justify-content-center">
              <GoACircularProgress variant="inline" size="small" message="Uploading ..." visible />
            </div>
          )}
          {!isLoading && (
            <GoAButtonGroup alignment="start">
              <GoAButton type="primary" onClick={handleSubmit(saveHandler)}>
                Save
              </GoAButton>
              <GoAButton type="tertiary" onClick={() => hideModal()}>
                Cancel
              </GoAButton>
            </GoAButtonGroup>
          )}
        </form>
      </GoAModal>
    );
  },
);
