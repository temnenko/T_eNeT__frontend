/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import { GoAContainer, GoAIcon } from '@abgov/react-components';
import { format } from 'date-fns';
import { Upload } from '../../../types/files';
import { toIsoDate } from '../../../utils/date.util';

type Props = {
  documents: Upload[] | undefined;
  downloadFile?: (fileId: string, filename: string, filesize: number) => void;
};

function OrganizationFileCard({ documents, downloadFile }: Props) {
  return (
    <div>
      {documents &&
        documents?.map((document) => {
          return (
            <GoAContainer key={document.id} width="full" maxWidth="50%">
              <div>
                <span
                  className="org-file-name d-flex"
                  onClick={() => {
                    if (document.adspId) {
                      downloadFile!(document.adspId, document.file.name, document.size);
                    }
                  }}
                >
                  {document.file.name}
                  <GoAIcon type="download" opacity={1} />
                </span>

                <div className="org-file-description">
                  {document.createdAt ? format(toIsoDate(document.createdAt), 'MMMM d, yyyy') : ''}
                </div>
              </div>
              <div>
                <progress id={`statusBar-${document.adspId}`} style={{ display: 'none' }} />
              </div>
            </GoAContainer>
          );
        })}
      {documents?.length === 0 && <GoAContainer maxWidth="50%">No documents uploaded</GoAContainer>}
    </div>
  );
}

export default OrganizationFileCard;

OrganizationFileCard.defaultProps = {
  downloadFile: () => {},
};
