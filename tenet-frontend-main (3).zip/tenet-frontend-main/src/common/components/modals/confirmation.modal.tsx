import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';
import InlineLoadingIndicator from '../forms/inline-loading-indicator';

type Props = {
  heading: string;
  description: string;
  confirmText: string;
  declineText: string;
  onDecline: () => void;
  onConfirm: () => void;
  size?: 'sm' | 'md' | 'lg';
  loading?: boolean;
  isDelete?: boolean;
};

export function ConfirmationModal({
  heading,
  onDecline,
  onConfirm,
  description,
  confirmText,
  declineText,
  size = 'md',
  loading = false,
  isDelete = false,
}: Props) {
  const sizeMap = {
    sm: '500px',
    md: '700px',
    lg: '900px',
  };

  const modalSize = sizeMap[size];
  return (
    <GoAModal heading={heading} maxWidth={modalSize} open>
      <p>{description}</p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton type="secondary" onClick={onDecline} variant={isDelete ? 'normal' : 'destructive'}>
          {declineText}
        </GoAButton>
        <GoAButton
          {...{ leadingIcon: isDelete ? 'trash' : undefined }}
          type="primary"
          onClick={() => {
            onConfirm();
          }}
          variant={isDelete ? 'destructive' : 'normal'}
        >
          {loading && <InlineLoadingIndicator />}
          {confirmText}
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}

ConfirmationModal.defaultProps = {
  size: 'md',
  loading: false,
  isDelete: false,
};
