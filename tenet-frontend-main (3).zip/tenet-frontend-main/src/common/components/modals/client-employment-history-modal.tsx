import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';

type Props = {
  onDecline: () => void;
  onConfirm: () => void;
  lastName?: string;
  firstName?: string;
};

export function ClientEmploymentHistorySubmitModal({ onDecline, onConfirm, firstName, lastName }: Props) {
  return (
    <GoAModal heading={`Add this employment to ${firstName} ${lastName}'s record?`} maxWidth="500px" open>
      <p className="client-font-with-margin">
        {`Add this employment to client's record. You can delete the record within 48 hours. After that, you may still
        update the record.`}
      </p>
      <p className="client-font-with-margin">{`Click "cancel" to go back to editing, or proceed to add the record.`}</p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton type="secondary" onClick={onDecline}>
          Cancel
        </GoAButton>
        <GoAButton type="primary" onClick={onConfirm}>
          Yes, add record
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}

ClientEmploymentHistorySubmitModal.defaultProps = {
  firstName: undefined,
  lastName: undefined,
};

export function ClientEmploymentHistoryCancelModal({ onDecline, onConfirm }: Omit<Props, 'firstName' | 'lastName'>) {
  return (
    <GoAModal heading="Are you sure you want to cancel?" maxWidth="500px" open>
      <p className="client-font-with-margin">
        {`This employment record has not been saved. Click "Go back" to continue editing, or "Cancel" to discard your changes.`}
      </p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton type="secondary" variant="destructive" onClick={onDecline}>
          Cancel
        </GoAButton>
        <GoAButton type="primary" onClick={onConfirm}>
          Go back
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
