import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';

type Props = {
  givenName: string;
  familyName: string;
  onDecline: () => void;
  onConfirm: () => void;
};

export function DeactivateUserPermissionsModal({ onDecline, onConfirm, givenName, familyName }: Props) {
  return (
    <GoAModal heading="Changing Permissions" maxWidth="500px" open>
      <p>
        {givenName} {familyName} will be deactivated. This means that the user will no longer have access to TENET.
      </p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton
          type="primary"
          variant="destructive"
          onClick={() => {
            onConfirm();
          }}
        >
          Deactivate User
        </GoAButton>
        <GoAButton onClick={onDecline} type="secondary">
          Go back
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
