import CancelRecordModal from '../cancel-record.modal';

type Props = {
  onConfirm: () => void;
  onDecline: () => void;
  firstName: string;
  lastName: string;
  loading: boolean;
};

export default function CancelEducationModal({ onConfirm, onDecline, firstName, lastName, loading }: Props) {
  return (
    <CancelRecordModal
      recordName="education"
      onConfirm={onConfirm}
      onDecline={onDecline}
      firstName={firstName}
      lastName={lastName}
      loading={loading}
    />
  );
}
