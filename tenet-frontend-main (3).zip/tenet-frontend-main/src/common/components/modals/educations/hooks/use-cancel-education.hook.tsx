/* eslint-disable @typescript-eslint/no-unused-expressions */
import { ReactNode, useCallback, useMemo, useState } from 'react';

import { Education } from '../../../../../types/client';
import { useModal } from '../../../../../hooks/use-modal.hook';
import { useStore } from '../../../../../hooks/use-store.hook';
import CancelEducationModal from '../cancel-education.modal';
import useEducationChangeMessage from '../../../clients/hooks/use-education-change-message.hooks';

const useCancelEducation = (education?: Education) => {
  const { hideModal } = useModal();
  const { setMessage } = useEducationChangeMessage();

  const {
    clientsStore: { selectedClient, archiveEducation },
  } = useStore();

  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(undefined);

  const clientFirstName = useMemo(() => selectedClient?.firstName ?? 'Homer', [selectedClient]);
  const clientLastName = useMemo(() => selectedClient?.lastName ?? 'Simpson', [selectedClient]);

  const archiveEducationRecord = useCallback(async () => {
    try {
      setLoading(true);

      if (education) {
        await archiveEducation(education.id, true);

        setMessage(`${clientFirstName} ${clientLastName}'s education has been cancelled.`);
      }
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
      setModalVisible(false);
      hideModal();
    }
  }, [archiveEducation, clientFirstName, clientLastName, education, hideModal, setMessage]);

  const cancelEducationClickHandler = useCallback(() => {
    setModalVisible(true);
    setModalContent(
      <CancelEducationModal
        onConfirm={archiveEducationRecord}
        onDecline={() => setModalVisible(false)}
        firstName={clientFirstName}
        lastName={clientLastName}
        loading={loading}
      />,
    );
  }, [archiveEducationRecord, clientFirstName, clientLastName, loading]);

  return {
    loading,
    cancelEducationClickHandler,
    hideModal,
    modalContent,
    modalVisible,
  };
};

export default useCancelEducation;
