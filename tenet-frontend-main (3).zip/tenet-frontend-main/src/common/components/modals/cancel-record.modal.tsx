import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';

import InlineLoadingIndicator from '../forms/inline-loading-indicator';

type Props = {
  recordName: string;
  onConfirm: () => void;
  onDecline: () => void;
  firstName: string;
  lastName: string;
  loading: boolean;
};

export default function CancelRecordModal({ recordName, onConfirm, onDecline, firstName, lastName, loading }: Props) {
  return (
    <GoAModal heading={`Cancel ${recordName}`} transition="slow" maxWidth="500px" open>
      <p className="client-font-with-margin">
        {`You will still have read-only access to this record after cancelling. To show cancelled record(s), check "show cancelled records" on client's ${recordName} page.`}
      </p>
      <br />
      <p className="client-font-with-margin">{`Are you sure you want to archive client's ${firstName} ${lastName} ${recordName}?`}</p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton disabled={loading} type="secondary" variant="normal" onClick={onConfirm}>
          {loading && <InlineLoadingIndicator />} Yes, cancel and exit
        </GoAButton>
        <GoAButton disabled={loading} type="primary" onClick={onDecline}>
          No, go back
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
