import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';

type Props = {
  onDecline: () => void;
  onConfirm: () => void;
  confirmText: JSX.Element;
  heading: string;
  educationId?: string;
};

export function ClientEducationHistorySubmitModal({ onDecline, onConfirm, confirmText, heading, educationId }: Props) {
  return (
    <GoAModal heading={heading} maxWidth="500px" open>
      <p className="client-font-with-margin">{confirmText}</p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton type="secondary" onClick={onDecline}>
          {educationId ? `Continue editing` : `Cancel`}
        </GoAButton>
        <GoAButton type="primary" onClick={onConfirm}>
          {educationId ? 'Save and exit' : 'Yes, add record'}
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}

ClientEducationHistorySubmitModal.defaultProps = {
  educationId: undefined,
};

export function ClientEducationHistoryCancelModal({
  onDecline,
  onConfirm,
}: Omit<Props, 'confirmText' | 'heading' | 'educationId'>) {
  return (
    <GoAModal heading="Are you sure you want to cancel?" maxWidth="500px" open>
      <p className="client-font-with-margin">
        {`This education record has not been saved. Click "Go back" to continue editing, or "Cancel" to discard your changes.`}
      </p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton type="secondary" variant="destructive" onClick={onDecline}>
          Cancel
        </GoAButton>
        <GoAButton type="primary" onClick={onConfirm}>
          Go back
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
