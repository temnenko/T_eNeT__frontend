import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';

type Props = {
  onDecline: () => void;
  onConfirm: () => void;
};

export function ClientEmploymentHistoryCancelModal({ onDecline, onConfirm }: Props) {
  return (
    <GoAModal heading="Are you sure you want to cancel?" maxWidth="500px" open>
      <p className="client-font-with-margin">
        {`This employment record has not been saved. Click "Go back" to continue editing, or "Cancel" to discard your
        changes.`}
      </p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton type="secondary" variant="destructive" onClick={onDecline}>
          Cancel
        </GoAButton>
        <GoAButton type="primary" onClick={onConfirm}>
          Go back
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
