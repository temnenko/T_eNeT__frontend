import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';

type Props = {
  onDecline: () => void;
  onConfirm: () => void;
};

export function ClientAssessmentServicePlanModal({ onDecline, onConfirm }: Props) {
  return (
    <GoAModal heading="Start service plan?" maxWidth="500px" open>
      <p className="client-font-with-margin">
        You have successfully completed the assessment. Would you like to start creating service plan now?
      </p>
      <p className="client-font-with-margin">You can also start it later whenever you are ready.</p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton type="secondary" onClick={onDecline}>
          Do it later
        </GoAButton>
        <GoAButton onClick={onConfirm}>Yes, start service plan</GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
