import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoACheckbox,
  GoADivider,
  GoAFormItem,
  GoAIconButton,
  GoAInput,
  GoAModal,
  GoARadioGroup,
  GoARadioItem,
  GoASpacer,
} from '@abgov/react-components';
import { Controller, FieldErrors } from 'react-hook-form';
import { observer } from 'mobx-react-lite';
import { AddressFields } from '../forms/fields/address-fields';
import { useModal } from '../../../hooks/use-modal.hook';
import { ConfirmationModal } from './confirmation.modal';
import useUpdateClientContactDetails, {
  AllContactFormData,
  EmailField,
  PhoneField,
} from '../forms/clients/update/use-update-client-contact-details.hook';
import { AddressesFormData } from '../forms/clients/registration/hooks/use-save-addresses.hook';
import { useStyleTrailingIcons } from '../../../hooks/use-style-trailing-icons';
import { AddressType } from '../../../types/client';
import { isPhoneNumberComplete } from '../../../utils/phone.util';

type Props = {
  onDecline: () => void;
  showSuccess: () => void;
};

export const ContactDetailsModal = observer(({ onDecline, showSuccess }: Props) => {
  const {
    formFields: addressFormFields,
    getValues: rawGetValues,
    onChangeHandler,
    onBlurHandler,
    isSameAsMailingAddress,
    handleToggleSameAsMailingAddress,
    errors: addressErrors,
    phoneFields,
    emailFields,
    control,
    handlePhoneChange,
    isEmailDisabled,
    isCheckboxDisabled,
    handleAddPhoneField,
    handleAddEmailField,
    handleEmailChange,
    handleCheckboxChange,
    submit,
    handleSubmit,
    handleRemoveEmailField,
    handleRemovePhoneField,
    onSelectAddress,
    setAddressStreetField,
  } = useUpdateClientContactDetails();

  const getValues = (name: string): string => {
    const value = rawGetValues(name as keyof AllContactFormData);
    return value ? value.toString() : '';
  };

  const { showModal, hideModal } = useModal();

  function formatValueForInput(value: string | Date | undefined | PhoneField[] | EmailField[]): string {
    if (value instanceof Date) {
      return value.toISOString().split('T')[0];
    }
    if (Array.isArray(value)) {
      return '';
    }
    return value || '';
  }

  const confirmation = async () => {
    hideModal();
    await submit();
    showSuccess();
  };

  const showConfirmationModal = () => {
    showModal(
      <ConfirmationModal
        heading="Contact details changed"
        description="Client's contact details have been changed. Do you want to save your changes?"
        confirmText="Yes, save changes"
        declineText="Cancel"
        onDecline={hideModal}
        onConfirm={confirmation}
      />,
    );
  };

  useStyleTrailingIcons('green', 'client-contact-form');

  return (
    <GoAModal heading="Update Contact Details" maxWidth="1000px" open>
      <form className="client-contact-form" onSubmit={handleSubmit(showConfirmationModal)}>
        <GoABlock direction="column">
          <div className="address-section-heading">Mailing address</div>
          <AddressFields
            fields={{
              streetAddress: addressFormFields.mailingStreetAddress,
              unit: addressFormFields.mailingUnit,
              city: addressFormFields.mailingCity,
              province: addressFormFields.mailingProvince,
              postalCode: addressFormFields.mailingPostalCode,
              country: addressFormFields.mailingCountry,
              addressEffectiveBy: addressFormFields.mailingAddressEffectiveBy,
              addressType: AddressType.MAILING,
            }}
            onChangeHandler={onChangeHandler}
            onBlurHandler={onBlurHandler}
            getValues={getValues}
            errors={addressErrors as FieldErrors<AddressesFormData>}
            onSelectAddress={onSelectAddress}
            setAddressStreetField={setAddressStreetField}
          />
          <GoASpacer vSpacing="xl" />
          <div className="address-section-heading">Residential address</div>
          <GoAFormItem label="Is the residential address the same as mailing address?" labelSize="regular">
            <GoARadioGroup
              name="sameAsMailingAddress"
              value={isSameAsMailingAddress ? '1' : '2'}
              onChange={handleToggleSameAsMailingAddress}
            >
              <GoARadioItem value="1" label="Yes" />
              <GoARadioItem value="2" label="No" />
            </GoARadioGroup>
          </GoAFormItem>
          {!isSameAsMailingAddress && (
            <AddressFields
              fields={{
                streetAddress: addressFormFields.residentialStreetAddress,
                unit: addressFormFields.residentialUnit,
                city: addressFormFields.residentialCity,
                province: addressFormFields.residentialProvince,
                postalCode: addressFormFields.residentialPostalCode,
                country: addressFormFields.residentialCountry,
                addressEffectiveBy: addressFormFields.residentialAddressEffectiveBy,
                addressType: AddressType.RESIDENTIAL,
              }}
              onChangeHandler={onChangeHandler}
              onBlurHandler={onBlurHandler}
              getValues={getValues}
              errors={addressErrors as FieldErrors<AddressesFormData>}
              onSelectAddress={onSelectAddress}
              setAddressStreetField={setAddressStreetField}
            />
          )}
        </GoABlock>

        <GoASpacer vSpacing="xl" />
        <GoABlock direction="column">
          <div className="address-section-heading">Phone Number</div>
          {phoneFields.map((field, index) => (
            <Controller
              key={field.id}
              name={`phone[${index}]` as keyof AllContactFormData}
              control={control}
              rules={{
                required: 'If the applicant does not have a phone number, please indicate',
              }}
              render={({ field: { onChange, value }, fieldState: { error } }) => (
                <GoAFormItem error={error && error.message}>
                  <div className="d-flex">
                    <GoAInput
                      type="tel"
                      onChange={(_name, val) => {
                        handlePhoneChange(field.id, val);
                        onChange(val);
                      }}
                      value={formatValueForInput(value)}
                      leadingContent="+1"
                      name={`phone-${field.id}`}
                      trailingIcon={isPhoneNumberComplete(field.value) ? 'checkmark-done' : undefined}
                    />
                    <GoAIconButton
                      variant="color"
                      size="medium"
                      icon="trash"
                      onClick={() => handleRemovePhoneField(field.id)}
                    />
                  </div>
                </GoAFormItem>
              )}
            />
          ))}
          <GoAButton type="tertiary" leadingIcon="add" onClick={handleAddPhoneField}>
            Add another phone number
          </GoAButton>
          <GoASpacer vSpacing="m" />
          <div className="address-section-heading">Email</div>
          {emailFields.map((field, index) => (
            <Controller
              key={field.id}
              name={`email[${index}]` as keyof AllContactFormData}
              control={control}
              rules={{
                required: 'If the applicant does not have an email address, please indicate',
                pattern: {
                  value: /^[^\s@<>&]+@[^\s@<>&]+\.[^\s@<>&]+$/,
                  message: 'The Email Address does not conform to the email address format standards',
                },
                maxLength: { value: 255, message: 'Email address must be less than 255 characters' },
                minLength: { value: 6, message: 'Email address must be at least 6 characters' },
              }}
              render={({ field: { onChange, value }, fieldState: { error, isDirty } }) => (
                <GoAFormItem error={error && error.message}>
                  <div className="d-flex">
                    <GoAInput
                      type="email"
                      onChange={(_name, val) => {
                        handleEmailChange(field.id, val);
                        onChange(val);
                      }}
                      value={formatValueForInput(value)}
                      name={`email-${field.id}`}
                      disabled={isEmailDisabled}
                      trailingIcon={!error && isDirty ? 'checkmark-done' : undefined}
                    />
                    <GoAIconButton
                      variant="color"
                      size="medium"
                      icon="trash"
                      onClick={() => handleRemoveEmailField(field.id)}
                    />
                  </div>
                </GoAFormItem>
              )}
            />
          ))}
          <GoAButton type="tertiary" leadingIcon="add" onClick={handleAddEmailField}>
            Add another email
          </GoAButton>
          <GoAFormItem>
            <GoACheckbox
              name="no-email"
              text="Check this box if the applicant doesn't have an email"
              onChange={handleCheckboxChange}
              checked={isEmailDisabled}
              disabled={isCheckboxDisabled}
            />
          </GoAFormItem>
          <GoASpacer vSpacing="xl" />
        </GoABlock>
        <GoADivider />
        <GoABlock>
          <div className="contact-details-form-buttons">
            <GoAButtonGroup alignment="end" mt="s">
              <GoAButton type="secondary" onClick={onDecline}>
                <span>Cancel</span>
              </GoAButton>
              <GoAButton type="submit" onClick={handleSubmit(showConfirmationModal)}>
                <span>Save</span>
              </GoAButton>
            </GoAButtonGroup>
          </div>
        </GoABlock>
      </form>
    </GoAModal>
  );
});

export default ContactDetailsModal;
