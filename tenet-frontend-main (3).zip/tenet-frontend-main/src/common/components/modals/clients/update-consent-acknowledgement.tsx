import { GoABlock, GoASpacer, GoAButton, GoAButtonGroup, GoAModal, GoADivider } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useSubmitConsentAcknowledgement from '../../forms/clients/registration/hooks/use-submit-consent-acknowledgement.hook';
import { ConsentAcknowledgementForm } from '../../forms/clients/consent-acknowledgement-form';
import InlineLoadingIndicator from '../../forms/inline-loading-indicator';
import useUpdateConsentAcknowledgement from './hooks/use-update-consent-acknowledgement.hook';

interface Props {
  hideModal: () => void;
  clientId?: string;
}

export const UpdateConsentAcknowledgement = observer(({ hideModal, clientId }: Props) => {
  const {
    loading,
    handleSubmit,
    errors,
    onChangeHandler,
    useUpdateSubmitHandler,
    getValues,
    canEditClientInProgress,
    client,
  } = useSubmitConsentAcknowledgement(clientId);
  const { closeUpdateModal, modalContent, modalVisible, useConsentUpdateSubmitHandler } =
    useUpdateConsentAcknowledgement(loading, hideModal);
  const updateSubmitHandler = useUpdateSubmitHandler(closeUpdateModal);
  const consentUpdateSubmitHandler = useConsentUpdateSubmitHandler(updateSubmitHandler);

  return (
    <GoAModal
      maxWidth="1000px"
      open
      width="88px"
      transition="slow"
      heading="Update consent and acknowledgement"
      onClose={hideModal}
    >
      {modalVisible && modalContent}
      <div>
        <form>
          <ConsentAcknowledgementForm errors={errors} onChangeHandler={onChangeHandler} getValues={getValues} />
          <GoASpacer vSpacing="l" />
          <GoADivider />
          <GoASpacer vSpacing="l" />

          <GoABlock>
            <div className="d-flex w-100">
              <div className="flex-grow-1">{}</div>
              {client && canEditClientInProgress(client) && (
                <GoAButtonGroup alignment="end">
                  <GoAButton type="secondary" disabled={loading} onClick={hideModal}>
                    <span>Cancel</span>
                  </GoAButton>
                  <GoAButton type="primary" disabled={loading} onClick={handleSubmit(consentUpdateSubmitHandler)}>
                    {loading ? <InlineLoadingIndicator label="Saving..." /> : <span>Save</span>}
                  </GoAButton>
                </GoAButtonGroup>
              )}
            </div>
          </GoABlock>
        </form>
      </div>
    </GoAModal>
  );
});
