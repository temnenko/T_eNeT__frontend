import { ReactNode, useCallback, useState } from 'react';
import ConfirmConsentUpdateModal from '../confirm-consent-update.modal';

const useUpdateConsentAcknowledgement = (loading: boolean, hideModal: () => void) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const updateCancelHandler = useCallback(() => {
    setModalVisible(false);
  }, [setModalVisible]);

  const closeUpdateModal = useCallback(() => {
    setModalVisible(false);
    hideModal();
  }, [hideModal]);

  const useConsentUpdateSubmitHandler = (submitHandler: () => Promise<void>) =>
    useCallback(async () => {
      setModalVisible(true);

      setModalContent(
        <ConfirmConsentUpdateModal onDecline={updateCancelHandler} onConfirm={submitHandler} loading={loading} />,
      );
    }, [submitHandler]);

  return {
    modalContent,
    modalVisible,
    closeUpdateModal,
    useConsentUpdateSubmitHandler,
  };
};

export default useUpdateConsentAcknowledgement;
