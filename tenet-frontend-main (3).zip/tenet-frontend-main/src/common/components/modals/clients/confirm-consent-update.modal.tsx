import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';
import InlineLoadingIndicator from '../../forms/inline-loading-indicator';

type Props = {
  onConfirm: () => Promise<void>;
  onDecline: () => void;
  loading: boolean;
};

export default function ConfirmConsentUpdateModal({ onConfirm, onDecline, loading }: Props) {
  return (
    <GoAModal heading="Consent information changed" transition="slow" maxWidth="500px" open>
      <p className="client-font-with-margin">
        {`Client's consent and acknowledgement information have been changed. Do you want to save your changes?`}
      </p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton disabled={loading} type="secondary" variant="destructive" onClick={onDecline}>
          Cancel
        </GoAButton>
        <GoAButton disabled={loading} type="primary" onClick={onConfirm}>
          {loading && <InlineLoadingIndicator />} Yes, save changes
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
