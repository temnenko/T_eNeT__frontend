import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';

type Props = {
  roleName: string;
  givenName: string;
  familyName: string;
  onDecline: () => void;
  onConfirm: () => void;
};

export function ChangePermissionsConfirmationModal({ roleName, onDecline, onConfirm, givenName, familyName }: Props) {
  return (
    <GoAModal heading="Changing Permissions" maxWidth="500px" open>
      <p>
        {givenName} {familyName} will be assigned as {roleName} user
      </p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton type="secondary" onClick={onDecline}>
          No, this is a mistake
        </GoAButton>
        <GoAButton
          type="primary"
          onClick={() => {
            onConfirm();
          }}
        >
          Yes, proceed
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
