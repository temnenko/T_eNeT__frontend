/* eslint-disable no-nested-ternary */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoATable, GoATableSortHeader } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import { useCallback, useState } from 'react';
import { AssessmentRow } from './assessment-row';
import { useStore } from '../../../../../hooks/use-store.hook';
import useAssessmentListPagination from '../../hooks/use-assessment-pagination.hook';
import { LoadingSkeleton } from '../../../users/users-list.skeleton';

export const AssessmentTable = observer(() => {
  const {
    dashboardAssessmentListStore: { assessments, setSortObject },
  } = useStore();

  const assessmentListPagination = useAssessmentListPagination();

  const [isLoading] = useState(false);

  const sortAssessments = useCallback(
    (sortColumn: string, sortDir: number) => {
      setSortObject({ [sortColumn]: sortDir === 1 ? 'asc' : 'desc' });
    },
    [setSortObject],
  );

  return (
    <>
      <GoATable width="100%" onSort={sortAssessments}>
        <thead>
          <tr>
            <th>
              <GoATableSortHeader name="status">Status</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="firstName">Name</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="tenetNumber">Tenet #</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="assessmentDate">Assessed on</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="agreementName">Agreement</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="givenName">Assessor</GoATableSortHeader>
            </th>
            <th>{}</th>
          </tr>
        </thead>
        {isLoading ? (
          <LoadingSkeleton />
        ) : (
          <tbody>
            {assessments.map(
              ({ id, status, clientName, tenetNumber, assessedBy, assessmentDate, agreementName, clientId }) => (
                <AssessmentRow
                  key={id}
                  id={id}
                  status={status}
                  tenetNumber={tenetNumber}
                  clientName={clientName}
                  assessmentDate={assessmentDate}
                  assessedBy={assessedBy}
                  agreementName={agreementName}
                  clientId={clientId}
                />
              ),
            )}
          </tbody>
        )}
      </GoATable>
      {assessmentListPagination}
    </>
  );
});
