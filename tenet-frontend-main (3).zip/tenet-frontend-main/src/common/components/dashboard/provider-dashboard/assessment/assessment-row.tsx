/* eslint-disable jsx-a11y/control-has-associated-label */
import { useCallback } from 'react';
import { observer } from 'mobx-react-lite';
import { useNavigate } from 'react-router-dom';
import { GoABadge, GoABlock, GoAButton, GoAIconButton, GoAPopover } from '@abgov/react-components';
import { format } from 'date-fns/format';
import { AssessmentStatus, assessmentBadgeMap, assessmentStatusMap } from '../../../../../types/assessment';
import { toIsoDate } from '../../../../../utils/date.util';

type Props = {
  id: string;
  status: AssessmentStatus;
  tenetNumber?: string;
  clientName?: string;
  assessmentDate?: Date;
  agreementName?: string;
  assessedBy: string;
  clientId: string;
};

export const AssessmentRow = observer(
  ({ id, status, assessmentDate, clientName, tenetNumber, assessedBy, agreementName, clientId }: Props) => {
    const navigate = useNavigate();
    const openProfileHandler = useCallback(() => navigate(`/clients/${clientId}/overview`), [clientId, navigate]);
    const openHandler = useCallback(() => navigate(`/clients/${clientId}/assessments/${id}`), [clientId, id, navigate]);

    return (
      <tr>
        <td>
          <GoABadge type={assessmentBadgeMap[status]} content={assessmentStatusMap[status]} />
        </td>
        <td>
          <a href={`/clients/${clientId}/overview`}>{clientName}</a>
        </td>
        <td>{tenetNumber}</td>
        <td>{assessmentDate ? format(toIsoDate(assessmentDate), 'MMM dd, yyy') : '-'}</td>
        <td>{agreementName}</td>
        <td>{assessedBy}</td>
        <td>
          <GoAPopover target={<GoAIconButton icon="ellipsis-vertical" />} position="auto">
            <GoABlock direction="column">
              <GoAButton onClick={openProfileHandler} type="tertiary">
                View profile
              </GoAButton>
              <GoAButton onClick={openHandler} type="tertiary">
                View assessment
              </GoAButton>
              <GoAButton onClick={() => {}} type="tertiary">
                Assign to
              </GoAButton>
            </GoABlock>
          </GoAPopover>
        </td>
      </tr>
    );
  },
);
