import { useEffect } from 'react';
import { observer } from 'mobx-react-lite';
import { GoAButton } from '@abgov/react-components';

import MultiSelectDropdown from '../../multiselect/multiselect.component';
import { useProviderDashboard } from '../hooks/use-provider-dashboard-hook';

export const ProviderDashboardFilters = observer(() => {
  const {
    usersList,
    selectedAssignees,
    setSelectedAssignees,
    agreementsList,
    selectedAgreements,
    setSelectedAgreements,
    clearFilters,
    getUserConfig,
  } = useProviderDashboard();

  useEffect(() => {
    getUserConfig().catch(() => {});
  }, [getUserConfig]);

  return (
    <>
      <div id="filters_section">
        <div className="d-flex">
          <div className="provider-filters-container">
            <MultiSelectDropdown
              data={usersList}
              selectedItems={selectedAssignees}
              setSelectedItems={setSelectedAssignees}
              width="18rem"
              title="Assignee"
              name="usersMultiselect"
              value="-- select --"
              onChange={() => {}}
              error=""
              noDataMessage="No matching result."
            />
          </div>

          <div className="provider-filters-container">
            <MultiSelectDropdown
              data={agreementsList}
              selectedItems={selectedAgreements}
              setSelectedItems={setSelectedAgreements}
              width="18rem"
              title="Agreement"
              name="agreementsMultiselect"
              value="-- select --"
              onChange={() => {}}
              error=""
              noDataMessage="No matching result."
            />
          </div>

          <div className="provider-filters-container clear-filters-button-container">
            <GoAButton type="tertiary" onClick={clearFilters}>
              Clear
            </GoAButton>
          </div>
        </div>
      </div>
      <div />
    </>
  );
});
