import { observer } from 'mobx-react-lite';
import {
  GoABadge,
  GoABadgeType,
  GoABlock,
  GoAButton,
  GoAIcon,
  GoAIconButton,
  GoAPopover,
  GoATable,
  GoATableSortHeader,
} from '@abgov/react-components';
import { format } from 'date-fns';
import { Link, useNavigate } from 'react-router-dom';
import {
  ServicePlanDashboardRow,
  ServicePlanStatusBadges,
  ServicePlanStatusLabels,
} from '../../../../../types/service-plan';
import { useProviderDashboardServicePlans } from '../../hooks/use-provider-dashboard-service-plans';
import useServicePlanDashboardPagination from '../../hooks/use-service-plan-dashboard-pagination';
import AssigneeList from './service-plans-assignment-window';
import { useModal } from '../../../../../hooks/use-modal.hook';
import { toIsoDate } from '../../../../../utils/date.util';

export const ServicePlansDashboardTable = observer(() => {
  const { sortData, isLoading, servicePlans, isServicePlanFollowedUp } = useProviderDashboardServicePlans();
  const navigate = useNavigate();
  const pagination = useServicePlanDashboardPagination();

  const renderStatusPill = (servicePlan: ServicePlanDashboardRow) => {
    if (isServicePlanFollowedUp(servicePlan)) {
      return <GoABadge type="important" content="In follow up" />;
    }
    const { status } = servicePlan;
    const badgeType = ServicePlanStatusBadges[status as keyof typeof ServicePlanStatusBadges] as GoABadgeType;
    const badgeContent = ServicePlanStatusLabels[status as keyof typeof ServicePlanStatusLabels];
    return <GoABadge type={badgeType} content={badgeContent} />;
  };

  const { showModal, hideModal } = useModal();

  return (
    <>
      <GoATable width="100%" onSort={sortData}>
        <thead>
          <tr>
            <th>
              <GoATableSortHeader name="status">Status</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="firstName">Name</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="tenetNumber">TENET #</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="startDate">Start</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="endDate">End</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="contactDate">Follow up</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="agreementName">Agreement</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="givenName">Assignee</GoATableSortHeader>
            </th>
            <th>{}</th>
          </tr>
        </thead>
        {isLoading ? (
          <div />
        ) : (
          <tbody data-testid="clientsTable-tableBody">
            {servicePlans.map((row) => (
              <tr key={row.id}>
                <td>
                  <Link to={`/clients/${row.clientId}/service-plans/transition-to-employment/${row.id}`}>
                    {renderStatusPill(row)}
                  </Link>
                </td>
                <td>
                  <Link to={`/clients/${row.clientId}/overview`}>{row.clientName}</Link>
                </td>
                <td>{row.tenetNumber}</td>
                <td>{row.startDate ? format(toIsoDate(row.startDate), 'MMMM d, yyyy') : ''}</td>
                <td>{row.endDate ? format(toIsoDate(row.endDate), 'MMMM d, yyyy') : ''}</td>
                <td>{row.contactDate ? format(toIsoDate(row.contactDate), 'MMMM d, yyyy') : ''}</td>
                <td>{row.agreementName}</td>
                <td>
                  <div className="d-flex align-items-center">
                    <GoAIcon type="person-circle" opacity={1} />

                    {row.assignee}
                  </div>
                </td>
                <td>
                  <GoAPopover target={<GoAIconButton icon="ellipsis-horizontal" onClick={() => {}} />} position="below">
                    <GoABlock direction="column">
                      <GoAButton onClick={() => navigate(`/clients/${row.clientId}/overview`)} type="tertiary">
                        View profile
                      </GoAButton>
                      <GoAButton
                        onClick={() => navigate(`/clients/${row.clientId}/assessments/${row.assessmentId}`)}
                        type="tertiary"
                      >
                        View assessment
                      </GoAButton>
                      <GoAButton
                        onClick={() =>
                          navigate(`/clients/${row.clientId}/service-plans/transition-to-employment/${row.id}`)
                        }
                        type="tertiary"
                      >
                        View service plan
                      </GoAButton>
                      <GoAButton
                        onClick={() => {
                          showModal(
                            <AssigneeList
                              hideModal={hideModal}
                              servicePlanId={row.id}
                              managedById={row.userId}
                              clientId={row.clientId}
                            />,
                          );
                        }}
                        type="tertiary"
                      >
                        Assign to
                      </GoAButton>
                    </GoABlock>
                  </GoAPopover>
                </td>
              </tr>
            ))}
          </tbody>
        )}
      </GoATable>
      <div>{pagination}</div>
    </>
  );
});
