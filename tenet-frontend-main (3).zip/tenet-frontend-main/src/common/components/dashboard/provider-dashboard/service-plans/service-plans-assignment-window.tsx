import { GoAButton, GoAModal, GoATable } from '@abgov/react-components';
import { useProviderDashboard } from '../../hooks/use-provider-dashboard-hook';

interface AssignProps {
  hideModal: () => void;
  servicePlanId: string;
  managedById: string;
  clientId: string;
}

function AssigneeList({ hideModal, servicePlanId, managedById, clientId }: AssignProps) {
  const { usersData, assignUserToServicePlan } = useProviderDashboard();
  return (
    <GoAModal transition="slow" heading="Assign User to Service Plan" open onClose={hideModal} width="500px">
      <GoATable>
        <thead>
          <tr>
            <th>Full Name</th>
            <th>{}</th>
          </tr>
        </thead>
        <tbody>
          {usersData.map((user) => {
            return (
              <tr key={user.id}>
                <td>{user.fullname}</td>
                <td>
                  <GoAButton
                    onClick={() => {
                      assignUserToServicePlan(servicePlanId, clientId, managedById, user.id);
                      hideModal();
                    }}
                    type="secondary"
                  >
                    Assign To
                  </GoAButton>
                </td>
              </tr>
            );
          })}
        </tbody>
      </GoATable>
    </GoAModal>
  );
}

export default AssigneeList;
