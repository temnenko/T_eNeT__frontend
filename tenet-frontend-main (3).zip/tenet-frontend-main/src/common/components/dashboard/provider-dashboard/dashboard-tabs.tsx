import { GoATab, GoATabs } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { AssessmentTable } from './assessment/assessment-table';
import { ServicePlansDashboardTable } from './service-plans/service-plans-dashboard-table';
import { useStore } from '../../../../hooks/use-store.hook';

export const DashboardTabs = observer(() => {
  const {
    providerDashboardStore: { setSelectedTab },
  } = useStore();

  return (
    <GoATabs
      onChange={(index: number) => {
        setSelectedTab(index);
      }}
    >
      <GoATab heading="Assessment">
        <AssessmentTable />
      </GoATab>
      <GoATab heading="Service plan">
        <ServicePlansDashboardTable />
      </GoATab>
    </GoATabs>
  );
});
