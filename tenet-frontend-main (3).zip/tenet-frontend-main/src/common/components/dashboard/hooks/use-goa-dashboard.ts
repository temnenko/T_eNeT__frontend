/* eslint-disable react-hooks/exhaustive-deps */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { SelectionType } from '../../multiselect/use-multiselect.hook';

export const useGoADashboard = () => {
  const {
    userConfigStore: { getUserConfig, setSelectedAssignees, clearConfig, selectedAssignees },
    goaDashboardStore: {
      getUsersForDashboard,
      usersData,
      agreements,
      sortObject,
      getAgreements,
      setSortObject,
      getAgreementFilters,
    },
    userStore: { organizationId },
  } = useStore();
  const [searchString, setSearchString] = useState<string>('');
  const [isLoading] = useState<boolean>(false);

  // Load users if not already available
  useEffect(() => {
    if (!usersData || usersData.length === 0) {
      getUsersForDashboard(organizationId!);
    }
  }, [getUsersForDashboard, organizationId, usersData]);

  const usersList = useMemo(() => {
    if (usersData && usersData.length > 0) {
      return [
        {
          region: '',
          items: usersData.map((u) => ({
            key: u.id!,
            value: u.fullname,
          })),
        },
      ];
    }
    return [];
  }, [usersData]);

  const onSearchStringChange = useCallback((name: string, value: string) => {
    setSearchString(value);
  }, []);

  const search = useCallback(
    (_selectedAssignees?: SelectionType, _search_string?: string, resetPagination?: boolean) => {
      getAgreements(_selectedAssignees, _search_string, resetPagination);
    },
    [getAgreements, getAgreementFilters],
  );

  const clearFilters = useCallback(() => {
    clearConfig();
    setSearchString('');
    search({}, '', true);
  }, [clearConfig]);

  useEffect(() => {
    getUserConfig()
      .catch(() => {})
      .finally(() => {
        search();
      });
  }, [sortObject]);

  const sortData = useCallback(
    (sortColumn: string, sortDir: number) => {
      setSortObject({ [sortColumn]: sortDir === 1 ? 'asc' : 'desc' });
    },
    [setSortObject],
  );

  return {
    usersData,
    selectedAssignees,
    setSelectedAssignees,
    getUserConfig,
    usersList,
    searchString,
    onSearchStringChange,
    agreements,
    isLoading,
    sortData,
    clearFilters,
    search,
  };
};
