import { useCallback, useEffect, useMemo, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { servicePlanService, ServicePlansSortableFields } from '../../../../services/clients/service-plan.service';
import { ProviderTab } from '../../../../stores/provider-dashboard.store';
import { SortableAssessmentField } from '../../../../services/organizations/agreement.service';

export const useProviderDashboard = () => {
  const {
    userConfigStore: {
      getUserConfig,
      setSelectedAgreements,
      setSelectedAssignees,
      clearConfig,
      selectedAgreements,
      selectedAssignees,
    },
    providerDashboardStore: {
      getUsersForDashboard,
      getAgreementsForDashboard,
      usersData,
      agreementsData,
      selectedTab,
      setSelectedTab,
    },
    providerDashboardServicePlansStore: {
      getServicePlans,
      skipCount: servicePlanSkipCount,
      getListSize: servicePlanBatchSize,
      sortObject: servicePlanSortObject,
    },
    dashboardAssessmentListStore: {
      getListSize: assessmentBatchSize,
      skipCount: assessmentSkipCount,
      sortObject: assessmentSortObject,
      getManyByAssessorOrganization,
    },
    userStore: { organizationId },
  } = useStore();

  const [agreementLoaded, setAgreementLoaded] = useState(false);

  useEffect(() => {
    if (!usersData || usersData.length === 0) {
      getUsersForDashboard(organizationId!);
    }
    if ((!agreementsData || agreementsData.length === 0) && !agreementLoaded) {
      getAgreementsForDashboard(organizationId!);
      setAgreementLoaded(true);
    }
  }, [
    agreementLoaded,
    agreementsData,
    getAgreementsForDashboard,
    getUsersForDashboard,
    organizationId,
    usersData,
    usersData.length,
  ]);

  const [isLoading] = useState<boolean>(false);

  const usersList = useMemo(() => {
    if (usersData && usersData.length > 0) {
      return [
        {
          region: '',
          items: usersData.map((u) => ({
            key: u.id!,
            value: u.fullname,
          })),
        },
      ];
    }
    return [];
  }, [usersData]);

  const agreementsList = useMemo(() => {
    if (agreementsData && agreementsData.length > 0) {
      return [
        {
          region: '',
          items: agreementsData.map((a) => ({
            key: a.id!,
            value: a.name,
          })),
        },
      ];
    }
    return [];
  }, [agreementsData]);

  const getServicePlanFilters = useCallback(() => {
    return {
      assigneeIds: Object.values(selectedAssignees).map((assigneeSet) => {
        const [firstAssignee] = Array.from(assigneeSet);
        return firstAssignee?.id;
      }),
      agreementIds: Object.values(selectedAgreements).map((agreementSet) => {
        const [firstAgreement] = Array.from(agreementSet);
        return firstAgreement?.id;
      }),
      skipCount: servicePlanSkipCount,
      batchSize: servicePlanBatchSize,
      sortBy: Object.keys(servicePlanSortObject)[0] as ServicePlansSortableFields,
      sortOrder: Object.values(servicePlanSortObject)[0] as 'asc' | 'desc',
    };
  }, [selectedAgreements, selectedAssignees, servicePlanBatchSize, servicePlanSkipCount, servicePlanSortObject]);

  const getAssessmentFilters = useCallback(() => {
    return {
      assigneeIds: Object.values(selectedAssignees).map((assigneeSet) => {
        const [firstAssignee] = Array.from(assigneeSet);
        return firstAssignee?.id;
      }),
      agreementIds: Object.values(selectedAgreements).map((agreementSet) => {
        const [firstAgreement] = Array.from(agreementSet);
        return firstAgreement?.id;
      }),
      skipCount: assessmentSkipCount,
      batchSize: assessmentBatchSize,
      sortBy: Object.keys(assessmentSortObject)[0] as SortableAssessmentField,
      sortOrder: Object.values(assessmentSortObject)[0] as 'asc' | 'desc',
    };
  }, [assessmentBatchSize, assessmentSkipCount, assessmentSortObject, selectedAgreements, selectedAssignees]);

  const fetchData = useCallback(() => {
    if (selectedTab === ProviderTab.Assessment) {
      getManyByAssessorOrganization(organizationId!, getAssessmentFilters());
    }
    if (selectedTab === ProviderTab.ServicePlan) {
      getServicePlans(organizationId!, getServicePlanFilters());
    }
  }, [
    getAssessmentFilters,
    getManyByAssessorOrganization,
    getServicePlanFilters,
    getServicePlans,
    organizationId,
    selectedTab,
  ]);

  useEffect(() => {
    fetchData();
  }, [
    selectedTab,
    servicePlanBatchSize,
    servicePlanSkipCount,
    selectedAssignees,
    selectedAgreements,
    assessmentBatchSize,
    assessmentSkipCount,
    servicePlanSortObject,
    assessmentSortObject,
    fetchData,
  ]);

  const clearFilters = useCallback(() => {
    clearConfig();
  }, [clearConfig]);

  const assignUserToServicePlan = useCallback(
    async (servicePlanId: string, clientId: string, currentAssigneeId: string, newAssigneeId: string) => {
      await servicePlanService.assign(servicePlanId, clientId, currentAssigneeId, newAssigneeId);
      getServicePlans(organizationId!, getServicePlanFilters());
    },
    [getServicePlanFilters, getServicePlans, organizationId],
  );

  return {
    usersData,
    agreementsData,
    usersList,
    agreementsList,
    selectedAssignees,
    selectedAgreements,
    setSelectedAssignees,
    setSelectedAgreements,
    isLoading,
    selectedTab,
    getUserConfig,
    fetchData,
    setSelectedTab,
    clearFilters,
    assignUserToServicePlan,
  };
};
