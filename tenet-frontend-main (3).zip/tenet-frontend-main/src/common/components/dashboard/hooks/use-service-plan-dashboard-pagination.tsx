import { useCallback, useMemo } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { ListPagination } from '../../list-pagination';

const useServicePlanDashboardPagination = () => {
  const {
    providerDashboardServicePlansStore: {
      setCurrentListPosition,
      setListSize,
      getListSize,
      currentListPosition,
      totalCount,
    },
  } = useStore();

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      setListSize(Number.parseInt(value as string, 10));
    },
    [setListSize],
  );

  return useMemo(() => {
    const actualPageSize = totalCount < getListSize ? totalCount : getListSize;
    return (
      <ListPagination
        perPageSize={getListSize}
        actualPageSize={actualPageSize}
        perPageSizeOptions={[15, 50]}
        changePerPageSize={changePerPageSize}
        pagePosition={currentListPosition}
        changePagePosition={setCurrentListPosition}
        totalCount={totalCount}
      />
    );
  }, [getListSize, changePerPageSize, currentListPosition, setCurrentListPosition, totalCount]);
};

export default useServicePlanDashboardPagination;
