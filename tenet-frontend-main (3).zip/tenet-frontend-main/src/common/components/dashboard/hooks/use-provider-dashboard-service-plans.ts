import { useCallback, useMemo, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { SelectionType } from '../../multiselect/use-multiselect.hook';
import { ServicePlanDashboardRow, ServicePlanOutcome } from '../../../../types/service-plan';

export const useProviderDashboardServicePlans = () => {
  const {
    providerDashboardServicePlansStore: { usersData, servicePlans, sortObject, setSortObject },
  } = useStore();

  const [selectedAssignees, setSelectedAssignees] = useState<SelectionType>({});
  const [isLoading] = useState<boolean>(false);

  const usersList = useMemo(() => {
    if (usersData && usersData.length > 0) {
      return [
        {
          region: '',
          items: usersData.map((u) => ({
            key: u.id!,
            value: u.fullname,
          })),
        },
      ];
    }
    return [];
  }, [usersData]);

  const isServicePlanFollowedUp = useCallback((servicePlanRow: ServicePlanDashboardRow) => {
    return (
      servicePlanRow.endDate &&
      servicePlanRow.outcome !== ServicePlanOutcome.INCOMPLETE &&
      !servicePlanRow.followUpOutcome
    );
  }, []);

  const sortData = useCallback(
    (sortColumn: string, sortDir: number) => {
      setSortObject({ [sortColumn]: sortDir === 1 ? 'asc' : 'desc' });
    },
    [setSortObject],
  );

  return {
    usersData,
    selectedAssignees,
    setSelectedAssignees,
    usersList,
    servicePlans,
    isLoading,
    isServicePlanFollowedUp,
    sortData,
    sortObject,
  };
};
