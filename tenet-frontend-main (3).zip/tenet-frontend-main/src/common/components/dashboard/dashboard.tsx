import { observer } from 'mobx-react-lite';
import { GoASpacer } from '@abgov/react-components';
import { useStore } from '../../../hooks/use-store.hook';
import { WelcomeView } from '../../../views/welcome.view';
import { UserType } from '../../../types/user';
import { ProviderDashboardFilters } from './provider-dashboard/provider-dashboard-filters';
import { DashboardTabs } from './provider-dashboard/dashboard-tabs';
import { GoaDashboard } from './goa-dashboard/goa-dashboard.component';

export const Dashboard = observer(() => {
  const {
    userStore: { userType },
  } = useStore();

  return (
    <>
      <WelcomeView />
      {userType === UserType.PROVIDER_STAFF && (
        <>
          <GoASpacer vSpacing="xl" />
          <h2>My work</h2>
          <GoASpacer vSpacing="m" />
          <ProviderDashboardFilters />
          <GoASpacer vSpacing="m" />
          <DashboardTabs />
          <GoASpacer vSpacing="l" />
        </>
      )}
      {userType === UserType.GOA_STAFF && <GoaDashboard />}
    </>
  );
});
