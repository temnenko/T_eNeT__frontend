import { observer } from 'mobx-react-lite';
import { GoAButton, GoACheckbox, GoAInput } from '@abgov/react-components';
import MultiSelectDropdown from '../../multiselect/multiselect.component';
import { useGoADashboard } from '../hooks/use-goa-dashboard';

export const Filters = observer(() => {
  const {
    usersList,
    selectedAssignees,
    setSelectedAssignees,
    searchString,
    onSearchStringChange,
    clearFilters,
    search,
  } = useGoADashboard();
  return (
    <div id="filters_section" className="d-flex align-items-end">
      <div className="flex-grow-1 d-flex">
        <div className="provider-filters-container">
          <MultiSelectDropdown
            data={usersList}
            selectedItems={selectedAssignees}
            setSelectedItems={setSelectedAssignees}
            width="18rem"
            title="Assignee"
            name="usersMultiselect"
            value="-- select --"
            onChange={() => {}}
            error=""
            noDataMessage="No matching result. You can add a new contact in the form below"
          />
        </div>
        <div className="provider-filters-container clear-filters-button-container">
          <GoAButton type="tertiary" onClick={clearFilters}>
            Clear
          </GoAButton>
        </div>
      </div>
      <div>
        <div className="d-flex">
          <GoAInput
            placeholder="Search agreement name, number"
            leadingIcon="search"
            width="30ch"
            name="item"
            value={searchString}
            onChange={onSearchStringChange}
            mt="7"
            mr="1"
          />
          <GoAButton type="secondary" mt="7" onClick={() => search(selectedAssignees, searchString, true)}>
            Search
          </GoAButton>
        </div>

        <div className="d-flex justify-content-end">
          <GoACheckbox checked={false} name="showDeactivatedContracts" text="Show deactivated contracts" mt="3" />
        </div>
      </div>
      <div />
    </div>
  );
});
