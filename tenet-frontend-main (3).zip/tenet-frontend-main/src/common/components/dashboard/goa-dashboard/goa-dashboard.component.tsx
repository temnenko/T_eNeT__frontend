import { observer } from 'mobx-react-lite';
import {
  GoABadge,
  GoABlock,
  GoAButton,
  GoAIconButton,
  GoAPopover,
  GoATable,
  GoATableSortHeader,
} from '@abgov/react-components';
import { format } from 'date-fns';
import { Link, useNavigate } from 'react-router-dom';
import { useGoADashboard } from '../hooks/use-goa-dashboard';
import { Filters } from './filters.component';
import { LoadingSkeleton } from '../../users/users-list.skeleton';
import { AgreementProgramTypeLabels } from '../../../../types/agreement';
import useGoADashboardPagination from '../hooks/use-goa-dashboard-pagination';
import { toIsoDate } from '../../../../utils/date.util';

export const GoaDashboard = observer(() => {
  const { sortData, isLoading, agreements } = useGoADashboard();
  const navigate = useNavigate();
  const pagination = useGoADashboardPagination();

  const renderDatePill = (date: Date | undefined) => {
    if (!date) {
      return null;
    }
    const formattedDate = format(toIsoDate(date), 'MMMM d, yyyy');
    const isExpired = new Date(date) < new Date();
    const type = isExpired ? 'information' : 'success';
    return <GoABadge type={type} content={formattedDate} />;
  };

  return (
    <>
      <div>
        <h2>My Work</h2>
      </div>
      <Filters />

      <GoATable width="100%" onSort={sortData}>
        <thead>
          <tr>
            <th>Agreement</th>
            <th>
              <GoATableSortHeader name="agreementNumber">Number</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="programType">Type</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="startDate">Start</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="endDate">End</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="givenName">CSC</GoATableSortHeader>
            </th>
            <th>{}</th>
            <th>{}</th>
          </tr>
        </thead>
        {isLoading ? (
          <LoadingSkeleton />
        ) : (
          <tbody data-testid="clientsTable-tableBody">
            {agreements?.map((row) => (
              <tr key={row.id}>
                <td>
                  <Link to={`/agreements/${row.id}`}>{row.name}</Link>
                </td>
                <td>{row.agreementNumber}</td>
                <td>{AgreementProgramTypeLabels[row.programType]}</td>
                <td>{row.startDate ? format(toIsoDate(row.startDate), 'MMMM d, yyyy') : ''}</td>
                <td>{renderDatePill(row.endDate)}</td>
                <td>{row.csc}</td>
                <td>
                  <Link to={`/agreements/${row.id}`}>View</Link>
                </td>
                <td>
                  <GoAPopover target={<GoAIconButton icon="ellipsis-horizontal" onClick={() => {}} />} position="below">
                    <GoABlock direction="column">
                      <GoAButton onClick={() => navigate(`/agreements/${row.id}`)} type="tertiary">
                        View
                      </GoAButton>
                    </GoABlock>
                  </GoAPopover>
                </td>
              </tr>
            ))}
          </tbody>
        )}
      </GoATable>
      <div>{pagination}</div>
    </>
  );
});
