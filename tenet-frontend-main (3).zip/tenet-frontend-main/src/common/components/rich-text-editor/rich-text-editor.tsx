/* eslint-disable @typescript-eslint/no-explicit-any */
import { useEffect, useRef } from 'react';
import ReactQuill from 'react-quill';
import { Controller, Control, RegisterOptions, FieldValues } from 'react-hook-form';
import 'react-quill/dist/quill.snow.css';

interface RichTextEditorProps {
  name: string;
  control: Control<any>;
  placeholder: string | undefined;
  rules:
    | Omit<RegisterOptions<FieldValues, string>, 'valueAsNumber' | 'valueAsDate' | 'setValueAs' | 'disabled'>
    | undefined;
}

function RichTextEditor({ name, control, placeholder, rules }: RichTextEditorProps) {
  const quillRef = useRef<ReactQuill | null>(null);

  useEffect(() => {
    const quill = quillRef.current?.getEditor();

    if (quill) {
      quill.clipboard.addMatcher(Node.ELEMENT_NODE, (_node, delta) => {
        const deltaVal = delta;
        // Remove image inserts from pasted content
        deltaVal.ops = delta.ops?.filter((op) => {
          if (op.insert && typeof op.insert === 'object' && 'image' in op.insert) {
            return false;
          }
          return true;
        });
        return deltaVal;
      });
    }
  }, []);

  return (
    <div className="rich-text-editor">
      <Controller
        name={name}
        control={control}
        rules={rules}
        render={({ field }) => (
          <ReactQuill
            ref={quillRef}
            value={field.value}
            onChange={field.onChange}
            placeholder={placeholder}
            modules={{
              toolbar: [
                /* [{ header: [1, 2, 3, 4, 5, false] }], */
                ['bold', 'italic', 'underline'],
                [{ list: 'ordered' }, { list: 'bullet' }],
              ],
            }}
            formats={['bold', 'italic', 'underline', 'list', 'bullet']}
          />
        )}
      />
    </div>
  );
}

export default RichTextEditor;
