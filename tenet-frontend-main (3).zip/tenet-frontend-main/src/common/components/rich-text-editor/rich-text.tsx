/* eslint-disable react/no-danger */
interface RichTextProps {
  html: string;
}

function RichText({ html }: RichTextProps) {
  return <div className="rendered-quill-content" dangerouslySetInnerHTML={{ __html: html }} />;
}

export default RichText;
