import { ReactNode, useCallback, useMemo, useState } from 'react';
import { GoAModal } from '@abgov/react-components';
import { useStore } from '../../../../hooks/use-store.hook';
import ContactRow from '../contact-row';
import { Contact } from '../../../../types/organization';
import { NewContactForm } from '../../forms/agreements/new/new-contact.form';

export const useContactRows = () => {
  const [expandedRecordId, setExpandedRecordId] = useState<string>();

  const {
    agreementStore: { selectedAgreement },
    permissionStore: { canCreateNewAgreementContact, canUpdateAgreementContact },
  } = useStore();

  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const toggleExpansion = useCallback(
    (id: string) => {
      if (id === expandedRecordId) {
        setExpandedRecordId(undefined);
      } else {
        setExpandedRecordId(id);
      }
    },
    [expandedRecordId],
  );

  const editContact = useCallback((contact: Contact) => {
    setModalVisible(true);
    setModalContent(
      <GoAModal
        maxWidth="1200px"
        open
        width="1200px"
        transition="slow"
        heading="Update Agreement Contacts"
        onClose={() => setModalVisible(false)}
      >
        <NewContactForm hideModal={() => setModalVisible(false)} submitLabel="Save" selectedContact={contact} />
      </GoAModal>,
    );
  }, []);

  const rows = useMemo(
    () =>
      selectedAgreement?.contacts?.map((record) => (
        <ContactRow
          key={record.id}
          record={record}
          expandedRecordId={expandedRecordId}
          toggleExpansion={toggleExpansion}
          editContact={editContact}
          canUpdateAgreementContact={canUpdateAgreementContact}
        />
      )),
    [canUpdateAgreementContact, editContact, expandedRecordId, selectedAgreement?.contacts, toggleExpansion],
  );

  return {
    rows,
    modalVisible,
    modalContent,
    setModalContent,
    setModalVisible,
    selectedAgreement,
    canCreateNewAgreementContact,
  };
};
