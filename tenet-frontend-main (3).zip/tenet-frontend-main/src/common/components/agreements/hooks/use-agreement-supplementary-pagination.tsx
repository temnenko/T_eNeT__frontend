import { useCallback, useMemo } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { ListPagination } from '../../list-pagination';

export const useAgreementActivityPagination = () => {
  const {
    agreementStore: {
      setActivityCurrentListPosition,
      setActivityListSize,
      getActivitiesListSize,
      activityCurrentListPosition,
      activityTotalCount,
    },
  } = useStore();

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      setActivityListSize(Number.parseInt(value as string, 10));
    },
    [setActivityListSize],
  );

  return useMemo(() => {
    const actualPageSize = activityTotalCount < getActivitiesListSize ? activityTotalCount : getActivitiesListSize;
    return (
      <ListPagination
        perPageSize={getActivitiesListSize}
        actualPageSize={actualPageSize}
        perPageSizeOptions={[15, 25, 50]}
        changePerPageSize={changePerPageSize}
        pagePosition={activityCurrentListPosition}
        changePagePosition={setActivityCurrentListPosition}
        totalCount={activityTotalCount}
      />
    );
  }, [
    activityTotalCount,
    getActivitiesListSize,
    changePerPageSize,
    activityCurrentListPosition,
    setActivityCurrentListPosition,
  ]);
};
