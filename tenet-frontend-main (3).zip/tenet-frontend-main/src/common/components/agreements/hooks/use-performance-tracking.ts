import { useCallback, useEffect, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { AgreementActivityFields, SortableAgreementField } from '../../../../services/organizations/agreement.service';

export const usePerformanceTracking = () => {
  const {
    agreementStore: {
      selectedAgreement,
      getAgreementClients,
      setClientsSortObject,
      clientsSkipCount,
      getClientsListSize,
      clientsSortObject,
      clientsBatchSize,
      includeInactive,
      setIncludeInactive,
      getAgreementActivities,
      getActivitiesListSize,
      activityBatchSize,
      activitySkipCount,
      sortAgreementActivities,
    },
  } = useStore();

  const [loading, setLoading] = useState<boolean>(false);

  const getClientsFilters = useCallback(() => {
    return {
      skipCount: clientsSkipCount,
      batchSize: clientsBatchSize,
      sortBy: Object.keys(clientsSortObject)[0] as SortableAgreementField,
      sortOrder: Object.values(clientsSortObject)[0] as 'asc' | 'desc',
      includeInactive,
    };
  }, [clientsBatchSize, clientsSkipCount, clientsSortObject, includeInactive]);

  const getActivitiesFilters = useCallback(() => {
    return {
      skipCount: activitySkipCount,
      batchSize: activityBatchSize,
    };
  }, [activityBatchSize, activitySkipCount]);

  const sortData = useCallback(
    (sortColumn: string, sortDir: number) => {
      setClientsSortObject({ [sortColumn]: sortDir === 1 ? 'asc' : 'desc' });
    },
    [setClientsSortObject],
  );

  const sortActivityData = useCallback(
    (sortColumn: string, sortDir: number) => {
      sortAgreementActivities({
        skipCount: activitySkipCount,
        batchSize: activityBatchSize,
        sortBy: {
          sortKey: sortColumn as AgreementActivityFields,
          sortOrder: sortDir === 1 ? 'asc' : 'desc',
        },
      });
    },
    [activityBatchSize, activitySkipCount, sortAgreementActivities],
  );

  const onShowClosedClientsChange = useCallback(
    (_: string, checked: boolean) => {
      setIncludeInactive(checked);
    },
    [setIncludeInactive],
  );

  const fetchData = useCallback(() => {
    if (selectedAgreement) {
      setLoading(true);
      getAgreementClients(
        { id: selectedAgreement.id, organizationId: selectedAgreement.organizationId },
        getClientsFilters(),
      ).finally(() => {
        setLoading(false);
      });
      getAgreementActivities(
        { id: selectedAgreement.id, organizationId: selectedAgreement.organizationId },
        getActivitiesFilters(),
      ).finally(() => {
        setLoading(false);
      });
    }
  }, [getActivitiesFilters, getAgreementActivities, getAgreementClients, getClientsFilters, selectedAgreement]);

  useEffect(() => {
    fetchData();
  }, [
    clientsBatchSize,
    clientsSkipCount,
    clientsSortObject,
    getClientsListSize,
    includeInactive,
    getActivitiesListSize,
    fetchData,
  ]);

  return {
    loading,
    fetchData,
    sortData,
    onShowClosedClientsChange,
    sortActivityData,
  };
};
