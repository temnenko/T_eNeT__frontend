import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useStore } from '../../../../hooks/use-store.hook';
import { ListPagination } from '../../list-pagination';
import { validateNotFutureDate } from '../../../../utils/validate-date.util';
import { RequestError } from '../../../../types/errors/errors';
import { AgreementReportType } from '../../../../types/agreement-report';

type FormFieldName = 'dateFrom' | 'dateTo';

type ReportFormData = {
  dateFrom: string;
  dateTo: string;
};

const useAgreementReports = () => {
  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    reset,
    formState: { errors },
  } = useForm<ReportFormData>();

  const {
    agreementStore: { selectedAgreement: agreement },
    agreementReportStore: {
      requestReport,
      getReportRequests,
      getReportDetails,
      reportRequests,
      batchSize,
      skipCount,
      setCurrentReportPosition,
      setCurrentReportBatchSize,
      totalCount,
    },
    permissionStore: { canCreateAgreement, canGenerateReportBySupervisor },
  } = useStore();

  useEffect(() => {
    if (agreement) {
      getReportRequests(agreement.id);
    }
  }, [agreement, getReportRequests]);
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  const { name: dateFrom } = register('dateFrom', {
    required: { value: true, message: 'This field is required' },
    validate: validateNotFutureDate,
  });
  const { name: dateTo } = register('dateTo', {
    required: { value: true, message: 'This field is required' },
    validate: validateNotFutureDate,
  });

  const formFields = {
    dateFrom,
    dateTo,
  };

  const onChangeHandler = useCallback(
    (key: string, value: string) => {
      setValue(key as FormFieldName, value);
    },
    [setValue],
  );

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      const newSize = Array.isArray(value) ? value[0] : value;

      setCurrentReportBatchSize(Number.parseInt(newSize, 10));
    },
    [setCurrentReportBatchSize],
  );

  const requestSubmitHandler = useCallback(
    async (type: AgreementReportType) => {
      const payload = {
        reportType: type || AgreementReportType.OUTCOME,
        dateFrom: new Date(getValues(dateFrom)),
        dateTo: new Date(getValues(dateTo)),
      };

      setLoading(true);
      try {
        if (agreement?.id && (canCreateAgreement || canGenerateReportBySupervisor)) {
          await requestReport(agreement.id, payload);
        }
      } catch {
        setRequestError({
          isUserError: true,
          message:
            'An error occurred while submitting the form. Please try again or contact support if the issue persists.',
          onDismiss: () => setRequestError({}),
        });
      } finally {
        setLoading(false);
      }
    },
    [agreement?.id, canCreateAgreement, canGenerateReportBySupervisor, dateFrom, dateTo, getValues, requestReport],
  );

  const outcomeSubmitHandler = useCallback(async () => {
    await requestSubmitHandler(AgreementReportType.OUTCOME);
  }, [requestSubmitHandler]);

  const supplementarySubmitHandler = useCallback(async () => {
    await requestSubmitHandler(AgreementReportType.SUPPLEMENTARY);
  }, [requestSubmitHandler]);

  const downloadReport = (requestId: string) => {
    if (canCreateAgreement || canGenerateReportBySupervisor) {
      getReportDetails(requestId);
    }
  };
  const pagination = () => {
    return (
      <ListPagination
        perPageSize={batchSize}
        actualPageSize={reportRequests.length}
        perPageSizeOptions={[10, 20, 50]}
        changePerPageSize={changePerPageSize}
        pagePosition={batchSize ? skipCount / batchSize + 1 : 1}
        changePagePosition={setCurrentReportPosition}
        totalCount={totalCount}
      />
    );
  };
  return {
    ReportsPagination: pagination,
    getValues,
    handleSubmit,
    register,
    onChangeHandler,
    reset,
    errors,
    outcomeSubmitHandler,
    supplementarySubmitHandler,
    loading,
    requestError,
    reportRequests,
    downloadReport,
    formFields,
    canCreateAgreement,
    canGenerateReportBySupervisor,
    agreementNumber: agreement?.agreementNumber,
  };
};

export default useAgreementReports;
