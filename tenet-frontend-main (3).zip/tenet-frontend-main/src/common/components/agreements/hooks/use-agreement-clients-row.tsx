import { useCallback, useMemo, useState } from 'react';

import { useStore } from '../../../../hooks/use-store.hook';
import { AgreementClientsRow } from '../performance-tracking/agreement-clients-row';

export const useAgreementClientsRow = () => {
  const {
    agreementStore: { agreementClients },
  } = useStore();
  const [expandedRecordId, setExpandedRecordId] = useState<string>();

  const toggleExpansion = useCallback(
    (id: string) => {
      if (id === expandedRecordId) {
        setExpandedRecordId(undefined);
      } else {
        setExpandedRecordId(id);
      }
    },
    [expandedRecordId],
  );

  const agreementClientsRows = useMemo(() => {
    return agreementClients?.map((client) => (
      <AgreementClientsRow
        key={client.servicePlanId}
        client={client}
        expandedRecordId={expandedRecordId}
        toggleExpansion={toggleExpansion}
      />
    ));
  }, [agreementClients, expandedRecordId, toggleExpansion]);

  return useMemo(() => {
    return { agreementClients, agreementClientsRows };
  }, [agreementClients, agreementClientsRows]);
};
