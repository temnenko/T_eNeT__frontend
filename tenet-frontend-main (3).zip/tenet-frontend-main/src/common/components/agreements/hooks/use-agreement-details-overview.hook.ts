import { format } from 'date-fns';
import { ReactNode, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import {
  AgreementAmendmentOptionsLabels,
  AgreementLanguageLabel,
  AgreementTargetGroupsList,
  InterventionCredential,
} from '../../../../types/agreement';
import { getEnumValue } from '../../../../utils/enums.util';
import { industryData } from '../../forms/agreements/new/lists/industry.data';
import { economicRegionLabels } from '../../../../types/core';
import { communitiesData } from '../../forms/agreements/new/lists/communities.data';
import { useCapitalizeFirstCharOfEveryWord } from '../../../../hooks/use-capitalize.hook';
import { toIsoDate } from '../../../../utils/date.util';

const useAgreementDetailsOverview = () => {
  const {
    agreementStore: { selectedAgreement: agreement },
  } = useStore();

  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const capitalizeFirst = useCapitalizeFirstCharOfEveryWord();

  const data = [
    {
      label: 'Official language',
      value: getEnumValue(AgreementLanguageLabel, agreement?.serviceLanguage),
    },
    { label: 'Agreement name', value: agreement?.name ?? '' },
    { label: 'Agreement number', value: agreement?.agreementNumber ?? '' },
    {
      label: 'Agreement start date',
      value: agreement?.startDate ? format(toIsoDate(agreement.startDate), 'MMMM d, yyyy') : 'unknown',
    },
    {
      label: 'Intervention credential',
      value: agreement?.interventionCredential
        ? capitalizeFirst(InterventionCredential[agreement?.interventionCredential])
        : '',
    },
    {
      label: 'Last intake date',
      value: agreement?.lastIntakeDate ? format(toIsoDate(agreement.lastIntakeDate), 'MMMM d, yyyy') : 'unknown',
    },
    {
      label: 'Agreement end date',
      value: agreement?.endDate ? format(toIsoDate(agreement.endDate), 'MMMM d, yyyy') : 'unknown',
    },
    {
      label: 'Expected length',
      value: agreement?.activeInterventionLength ? `${agreement?.activeInterventionLength} weeks` : '',
    },
    { label: 'Amendment Options', value: getEnumValue(AgreementAmendmentOptionsLabels, agreement?.amendmentOption) },
    { label: 'Max participants', value: agreement?.participantsMaxNumber ?? '' },
    { label: 'LMDA/WDA split', value: agreement?.targetLmdaWdaSplit ?? '' },
    {
      label: 'Target groups',
      value:
        agreement?.targetGroups
          .map((group) => AgreementTargetGroupsList.find((item) => item.key === group)?.label)
          .filter((label): label is string => !!label)
          .join(', ') ?? '',
    },
    {
      label: 'Target sectors',
      value:
        agreement?.targetSectors
          ?.map((key) => industryData.flatMap((region) => region.items).find((item) => item.key === key)?.value)
          .filter(Boolean)
          .join(', ') ?? '',
    },
    {
      label: 'Economic regions',
      value: agreement?.economicRegions.map((region) => economicRegionLabels[region]).join(', ') ?? '',
    },
    {
      label: 'Communities served',
      value:
        agreement?.communitiesServed
          .map((key) => communitiesData.flatMap((region) => region.items).find((item) => item.key === key)?.value)
          .filter(Boolean)
          .join(', ') ?? '',
    },
  ];

  return { data, modalVisible, modalContent, setModalContent, setModalVisible };
};

export default useAgreementDetailsOverview;
