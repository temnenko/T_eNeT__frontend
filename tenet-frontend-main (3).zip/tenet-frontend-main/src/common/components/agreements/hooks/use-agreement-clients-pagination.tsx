import { useCallback, useMemo } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { ListPagination } from '../../list-pagination';

export const useAgreementClientsPagination = () => {
  const {
    agreementStore: {
      setClientsCurrentListPosition,
      setClientsListSize,
      getClientsListSize,
      clientsCurrentListPosition,
      clientsTotalCount,
    },
  } = useStore();

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      setClientsListSize(Number.parseInt(value as string, 10));
    },
    [setClientsListSize],
  );

  return useMemo(() => {
    const actualPageSize = clientsTotalCount < getClientsListSize ? clientsTotalCount : getClientsListSize;
    return (
      <ListPagination
        perPageSize={getClientsListSize}
        actualPageSize={actualPageSize}
        perPageSizeOptions={[15, 25, 50]}
        changePerPageSize={changePerPageSize}
        pagePosition={clientsCurrentListPosition}
        changePagePosition={setClientsCurrentListPosition}
        totalCount={clientsTotalCount}
      />
    );
  }, [
    clientsTotalCount,
    getClientsListSize,
    changePerPageSize,
    clientsCurrentListPosition,
    setClientsCurrentListPosition,
  ]);
};
