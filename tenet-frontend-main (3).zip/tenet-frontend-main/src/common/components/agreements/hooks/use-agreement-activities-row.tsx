import { useMemo } from 'react';

import { useStore } from '../../../../hooks/use-store.hook';
import { AgreementActivitiesRow } from '../performance-tracking/agreement-activities-row';

export const useAgreementActivitiesRow = () => {
  const {
    agreementStore: { agreementActivities },
  } = useStore();

  const agreementActivitiesRows = useMemo(() => {
    return agreementActivities?.map((activity) => <AgreementActivitiesRow key={activity.id} activity={activity} />);
  }, [agreementActivities]);

  return useMemo(() => {
    return { agreementActivitiesRows };
  }, [agreementActivitiesRows]);
};
