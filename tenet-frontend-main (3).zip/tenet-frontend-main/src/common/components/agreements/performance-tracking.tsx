import { useEffect } from 'react';
import { GoACheckbox, GoAContainer, GoADivider, GoAGrid, GoATab, GoATabs, GoAText } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useStore } from '../../../hooks/use-store.hook';
import { useAgreementClientsRow } from './hooks/use-agreement-clients-row';
import { useAgreementClientsPagination } from './hooks/use-agreement-clients-pagination';
import { usePerformanceTracking } from './hooks/use-performance-tracking';
import { AgreementClientsTable } from './performance-tracking/agreement-clients-table';
import { useAgreementActivityPagination } from './hooks/use-agreement-supplementary-pagination';
import { AgreementActivityTable } from './performance-tracking/agreement-activity-table';
import { useAgreementActivitiesRow } from './hooks/use-agreement-activities-row';

export const PerformanceTracking = observer(() => {
  const {
    agreementStore: { metrics, getMetrics, selectedAgreement, includeInactive },
  } = useStore();
  const { agreementClientsRows } = useAgreementClientsRow();
  const { agreementActivitiesRows } = useAgreementActivitiesRow();
  const agreementClientsPagination = useAgreementClientsPagination();
  const agreementActivityPagination = useAgreementActivityPagination();
  const { sortData, onShowClosedClientsChange, sortActivityData } = usePerformanceTracking();

  useEffect(() => {
    if (selectedAgreement?.id && selectedAgreement.organizationId) {
      getMetrics({
        id: selectedAgreement.id,
        organizationId: selectedAgreement.organizationId,
      });
    }
  }, [getMetrics, selectedAgreement?.id, selectedAgreement?.organizationId]);

  return (
    <>
      <div className="d-flex">
        <div className="flex-grow-1">
          <h3 className="agreement-section-heading">Performance tracking</h3>
        </div>
      </div>
      <GoAGrid minChildWidth="233px" mt="m">
        <GoAContainer accent="thick" title="Starters">
          <GoAText color="secondary" size="heading-s">
            Total
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {metrics?.starters ?? 0}
          </GoAText>
          <GoADivider mt="s" mb="s" />
          <GoAText color="secondary" size="heading-s">
            LMDA/WDA %
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {`${metrics?.lmda ?? 0}/${metrics?.wda ?? 0}`}
          </GoAText>
        </GoAContainer>
        <GoAContainer accent="thick" title="Intervention">
          <GoAText color="secondary" size="heading-s">
            Complete
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {metrics?.interventionComplete ?? 0}
          </GoAText>
          <GoADivider mt="s" mb="s" />
          <GoAText color="secondary" size="heading-s">
            Incomplete
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {metrics?.interventionIncomplete ?? 0}
          </GoAText>
          <GoADivider mt="s" mb="s" />
          <GoAText color="secondary" size="heading-s">
            In-progress
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {metrics?.interventionInprogress ?? 0}
          </GoAText>
        </GoAContainer>
        <GoAContainer accent="thick" title="Employment">
          <GoAText color="secondary" size="heading-s">
            Related Employment
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {metrics?.employmentRelated ?? 0}
          </GoAText>
          <GoADivider mt="s" mb="s" />
          <GoAText color="secondary" size="heading-s">
            In-progress
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {metrics?.employmentInprogress ?? 0}
          </GoAText>
        </GoAContainer>
        <GoAContainer accent="thick" title="Follow Up">
          <GoAText color="secondary" size="heading-s">
            Successful
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {metrics?.followupSuccessful ?? 0}
          </GoAText>
          <GoADivider mt="s" mb="s" />
          <GoAText color="secondary" size="heading-s">
            Unsuccessful
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {metrics?.followupUnsuccessful ?? 0}
          </GoAText>
          <GoADivider mt="s" mb="s" />
          <GoAText color="secondary" size="heading-s">
            Overdue
          </GoAText>
          <GoAText color="primary" size="heading-s">
            {metrics?.followupOverdue ?? 0}
          </GoAText>
        </GoAContainer>
      </GoAGrid>
      <GoADivider mt="m" mb="m" />
      <GoATabs initialTab={1}>
        <GoATab heading="Client roster">
          <div className="client-tables-display">
            <section className="d-flex-row justify-content-end">
              <GoACheckbox
                name="showClosedClients"
                text="Show closed clients"
                onChange={onShowClosedClientsChange}
                checked={includeInactive}
              />
            </section>
            <AgreementClientsTable clientsRows={agreementClientsRows} sortData={sortData} />
            {agreementClientsPagination}
          </div>
        </GoATab>
        <GoATab heading="Supplementary activities">
          <AgreementActivityTable activitiesRows={agreementActivitiesRows} sortData={sortActivityData} />
          {agreementActivityPagination}
        </GoATab>
      </GoATabs>
    </>
  );
});
