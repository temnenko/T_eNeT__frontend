import { GoABlock, GoAButton, GoADivider, GoAModal, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useAgreementDetailsOverview from './hooks/use-agreement-details-overview.hook';
import { AgreementDetailsForm } from '../forms/agreements/new/agreement-details.form';
import { useStore } from '../../../hooks/use-store.hook';

export const AgreementDetailsOverview = observer(() => {
  const { data, modalVisible, modalContent, setModalContent, setModalVisible } = useAgreementDetailsOverview();
  const {
    permissionStore: { canUpdateOrganizationDetails },
  } = useStore();
  const hideModal = () => {
    setModalVisible(false);
    setModalContent(null);
  };

  return (
    <>
      {modalVisible && modalContent}
      <div className="d-flex">
        <div className="flex-grow-1">
          <h3 className="agreement-section-heading">Overview</h3>
        </div>
        {canUpdateOrganizationDetails && (
          <GoAButton
            type="tertiary"
            size="compact"
            onClick={() => {
              setModalVisible(true);
              setModalContent(
                <GoAModal
                  maxWidth="1200px"
                  open
                  width="1200px"
                  transition="slow"
                  heading="Update Agreement Details"
                  onClose={hideModal}
                >
                  <AgreementDetailsForm isModal hideModal={hideModal} />
                </GoAModal>,
              );
            }}
          >
            Update
          </GoAButton>
        )}
      </div>
      <GoADivider />
      <GoASpacer vSpacing="m" />
      <div>
        <GoABlock direction="column">
          {data.map((entry) => (
            <GoABlock key={entry.label} gap="none">
              <div className="client-info-card-label">
                <span className="color-interactive">{entry.label}</span>
              </div>
              <div>
                <span className="client-bold-600">{entry.value as string}</span>
              </div>
            </GoABlock>
          ))}
        </GoABlock>
      </div>
    </>
  );
});
