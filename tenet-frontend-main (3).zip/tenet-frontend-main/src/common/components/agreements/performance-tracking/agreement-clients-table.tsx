/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoATable, GoATableSortHeader } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

type Props = {
  sortData: (sortBy: string, sortDir: number) => void;
  clientsRows?: JSX.Element[];
};

export const AgreementClientsTable = observer(({ sortData, clientsRows }: Props) => {
  return (
    <GoATable width="100%" onSort={sortData}>
      <thead>
        <th />
        <th>
          <GoATableSortHeader name="tenetNumber">TENET ID</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="firstName">First name</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="lastName">Last name</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="startDate">Start</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="endDate">End</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="status">Service status</GoATableSortHeader>
        </th>
        <th />
      </thead>
      {clientsRows?.length ? <tbody>{clientsRows}</tbody> : <div>No clients found</div>}
    </GoATable>
  );
});
