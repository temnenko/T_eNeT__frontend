import { observer } from 'mobx-react-lite';
import { format } from 'date-fns';
import { toIsoDate } from '../../../../utils/date.util';
import { AgreementActivity } from '../../../../services/organizations/agreement.service';
import { useCapitalizeFirstCharOfEveryWord } from '../../../../hooks/use-capitalize.hook';

type Props = {
  activity: AgreementActivity;
};

export const AgreementActivitiesRow = observer(({ activity }: Props) => {
  const capitalize = useCapitalizeFirstCharOfEveryWord();
  return (
    <tr key={activity.id}>
      <td>{activity.tenetNumber}</td>
      <td>{capitalize(activity.activityType)}</td>
      <td>{activity.title}</td>
      <td>{activity.outcomeDate ? format(toIsoDate(activity.outcomeDate), 'dd MMM yyyy') : undefined}</td>
      <td>{activity.cost?.toFixed(2)}</td>
      <td>{capitalize(activity.outcome)}</td>
    </tr>
  );
});
