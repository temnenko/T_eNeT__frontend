/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoATable, GoATableSortHeader } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

type Props = {
  sortData: (sortBy: string, sortDir: number) => void;
  activitiesRows?: JSX.Element[];
};

export const AgreementActivityTable = observer(({ sortData, activitiesRows }: Props) => {
  return (
    <GoATable width="100%" onSort={sortData}>
      <thead>
        <th>
          <GoATableSortHeader name="tenetNumber">TENET ID</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="activityType">Activity type</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="title">Title</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="outcomeDate">Outcome date</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="cost">Cost</GoATableSortHeader>
        </th>
        <th>
          <GoATableSortHeader name="outcome">Outcome</GoATableSortHeader>
        </th>
        <th />
      </thead>
      {activitiesRows?.length ? <tbody>{activitiesRows}</tbody> : <div>No activity found</div>}
    </GoATable>
  );
});
