/* eslint-disable no-plusplus */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { GoABadge, GoABlock, GoAButton, GoAIcon } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { format } from 'date-fns';
import { toIsoDate } from '../../../../utils/date.util';
import useCapitalize from '../../../../hooks/use-capitalize.hook';
import { AgreementClient } from '../../../../services/organizations/agreement.service';
import { ServicePlanStatusLabels } from '../../../../types/service-plan';
import { LMDAIntakeTypes } from '../../../../types/assessment-forms';

type Props = {
  client: AgreementClient;
  expandedRecordId?: string;
  toggleExpansion: (id: string) => void;
};

export const AgreementClientsRow = observer(({ expandedRecordId, client, toggleExpansion }: Props) => {
  const isOpen = useMemo(() => expandedRecordId === client.servicePlanId, [expandedRecordId, client.servicePlanId]);
  const iconType = useMemo(() => (isOpen ? 'chevron-down' : 'chevron-forward'), [isOpen]);
  const navigate = useNavigate();
  const capitalize = useCapitalize();

  return (
    <>
      <tr key={client.servicePlanId}>
        <td>
          <button type="button" className="org-location-openBtn" onClick={() => toggleExpansion(client.servicePlanId)}>
            <GoAIcon type={iconType} />
          </button>
        </td>
        <td>{client.tenetNumber}</td>
        <td>{client.firstName}</td>
        <td>{client.lastName}</td>
        <td>{format(toIsoDate(client.startDate), 'dd MMM yyyy')}</td>
        <td>{client.endDate ? format(toIsoDate(client.endDate), 'dd MMM yyyy') : '-'}</td>
        <td>
          <GoABadge type="information" content={ServicePlanStatusLabels[client.status]} />
        </td>
        <td>
          <GoAButton onClick={() => navigate(`/clients/${client.clientId}/overview`)} type="tertiary">
            View
          </GoAButton>
        </td>
      </tr>
      {isOpen && (
        <tr>
          <td colSpan={8}>
            <div className="client-employment-content">
              <GoABlock>
                <GoABlock direction="column">
                  <div>
                    <p className="detail-heading">Service outcome</p>
                    <p>{capitalize(client.serviceOutcome?.replaceAll('_', ' ') ?? '-')}</p>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div>
                    <p className="detail-heading">Service outcome date</p>
                    <p>
                      {client.serviceOutcomeDate ? format(toIsoDate(client.serviceOutcomeDate), 'dd MMM yyyy') : '-'}
                    </p>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div>
                    <p className="detail-heading">Employment outcome</p>
                    <p>{client.employmentOutcome ?? '-'}</p>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div>
                    <p className="detail-heading">Employment outcome date</p>
                    <p>
                      {client.employmentOutcomeDate
                        ? format(toIsoDate(client.employmentOutcomeDate), 'dd MMM yyyy')
                        : '-'}
                    </p>
                  </div>
                </GoABlock>
              </GoABlock>
              <GoABlock>
                <GoABlock direction="column">
                  <div>
                    <p className="detail-heading">Follow-up outcome</p>
                    <p>{capitalize(client.followUpOutcome?.replaceAll('_', ' ') ?? '-')}</p>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div>
                    <p className="detail-heading">Follow-up outcome date</p>
                    <p>
                      {client.followUpOutcomeDate ? format(toIsoDate(client.followUpOutcomeDate), 'dd MMM yyyy') : '-'}
                    </p>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div>
                    <p className="detail-heading">LMDA Eligible</p>
                    <p>
                      {!client.lmdaIntakeType && '-'}
                      {client.lmdaIntakeType && client.lmdaIntakeType !== LMDAIntakeTypes.INELIGIBLE ? 'Yes' : 'No'}
                    </p>
                  </div>
                </GoABlock>
              </GoABlock>
            </div>
          </td>
        </tr>
      )}
    </>
  );
});
