import { useMemo } from 'react';
import { GoAButton, GoAIconButton } from '@abgov/react-components';
import { Contact } from '../../../types/organization';

type Props = {
  record: Contact;
  expandedRecordId: string | undefined;
  toggleExpansion: (id: string) => void;
  editContact: (contact: Contact) => void;
  canUpdateAgreementContact: boolean;
};

function ContactRow({ record, expandedRecordId, toggleExpansion, editContact, canUpdateAgreementContact }: Props) {
  const isOpen = useMemo(() => expandedRecordId === record.id, [expandedRecordId, record.id]);
  const iconType = useMemo(() => (isOpen ? 'chevron-down' : 'chevron-forward'), [isOpen]);

  return (
    <>
      <tr>
        <td>
          <GoAIconButton
            variant="color"
            size="medium"
            icon={iconType}
            ariaLabel="toggleExpansion"
            onClick={() => toggleExpansion(record.id!)}
          />
        </td>
        <td>{record.name}</td>
        <td>{record.agreementSignatory}</td>
        <td>{record.role}</td>
        <td>{record.phoneNumber}</td>
        <td>{record.emailAddress}</td>
        <td>
          {canUpdateAgreementContact && (
            <GoAButton type="tertiary" onClick={() => editContact(record)}>
              Edit
            </GoAButton>
          )}
        </td>
      </tr>
      {isOpen && (
        <tr>
          <td colSpan={7} className="expanded-contact-container">
            <div className="notes-header">Notes</div>
            <div>{record.note}</div>
          </td>
        </tr>
      )}
    </>
  );
}

export default ContactRow;
