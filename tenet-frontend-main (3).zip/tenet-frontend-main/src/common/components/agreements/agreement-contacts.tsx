/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoAButton, GoAModal, GoATable } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useContactRows } from './hooks/use-contact-rows';
import { AgreementContactGroups } from '../forms/agreements/new/agreement-contact-groups.form';

export const AgreementContacts = observer(() => {
  const { rows, modalVisible, modalContent, setModalContent, setModalVisible, canCreateNewAgreementContact } =
    useContactRows();
  const hideModal = () => {
    setModalVisible(false);
    setModalContent(null);
  };
  return (
    <>
      {modalVisible && modalContent}

      <div className="d-flex">
        <div className="flex-grow-1">
          <h3 className="agreement-section-heading">Contact group</h3>
          <span>View and manage contacts of this agreement</span>
        </div>
        <div>
          {canCreateNewAgreementContact && (
            <GoAButton
              type="secondary"
              size="compact"
              onClick={() => {
                setModalVisible(true);
                setModalContent(
                  <GoAModal
                    maxWidth="1200px"
                    open
                    width="1200px"
                    transition="slow"
                    heading="Update Agreement Contacts"
                    onClose={hideModal}
                  >
                    <AgreementContactGroups isModal hideModal={hideModal} />
                  </GoAModal>,
                );
              }}
              leadingIcon="add"
            >
              Add contact person
            </GoAButton>
          )}
        </div>
      </div>
      <GoATable width="100%">
        <thead>
          <tr>
            <th>&nbsp;</th>
            <th data-testid="agreementContactsTable_Name">Name</th>
            <th data-testid="agreementContactsTable_Signatory">Signatory</th>
            <th data-testid="agreementContactsTable_Title">Title</th>
            <th data-testid="agreementContactsTable_Phone">Phone</th>
            <th data-testid="agreementContactsTable_Phone">Email</th>
            <th>&nbsp;</th>
          </tr>
        </thead>
        {rows && <tbody data-testid="agreementContactsTable_TableBody">{rows}</tbody>}
      </GoATable>
    </>
  );
});
