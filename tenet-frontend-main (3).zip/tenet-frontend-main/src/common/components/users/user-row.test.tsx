/* eslint-disable react/jsx-props-no-spreading */
import '@testing-library/jest-dom';
import { BrowserRouter } from 'react-router-dom';
import { render, getByTestId } from '@testing-library/react';

import { UserRow } from './user-row';
import { Roles } from '../../../types/role';
import RootStore from '../../../stores/root.store';
import * as storeHooks from '../../../hooks/use-store.hook';
import { UserStatus } from '../../../types/user';
import { ModalProvider } from '../../../contexts/modal.context';

jest.mock('../../../services/user.service', () => ({
  userService: {},
}));

jest.mock('./user-role-list', () => ({
  UserRoleList: () => <div>test-list</div>,
}));

describe('UserRow', () => {
  const mockStore = {
    permissionStore: { isSuperAdmin: false },
    userStore: {
      role: Roles.SUPER_ADMIN,
    },
  } as unknown as RootStore;

  const testProps = {
    id: 'test-id',
    givenName: 'Lisa',
    organizationName: 'Test Company',
    familyName: 'Simpson',
    emailAddress: 'lisa.simpson@abc.com',
    currentRole: 'ADMIN',
    status: UserStatus.ACTIVE,
    roleObj: {
      id: 'test-role-id',
      status: 'ACTIVE',
      description: 'test-desc',
      name: 'ADMIN',
    },
    userRoleList: <div />,
    changedAt: undefined,
    reactivateHandler: async () => {},
    deactivateHandler: async () => {},
    profileViewHandler: async () => {},
  };

  test('Renders UserRow with role column', () => {
    jest.spyOn(storeHooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: userRow } = render(
      <ModalProvider>
        <BrowserRouter>
          <UserRow {...testProps} />
        </BrowserRouter>
      </ModalProvider>,
    );

    expect(userRow).toBeInTheDocument();
  });

  test('Renders UserRow without role column', () => {
    mockStore.userStore.role = Roles.ADMIN;
    jest.spyOn(storeHooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: userRow } = render(
      <ModalProvider>
        <BrowserRouter>
          <UserRow {...testProps} />
        </BrowserRouter>
      </ModalProvider>,
    );

    expect(userRow).toBeInTheDocument();
    expect(() => getByTestId(userRow, 'rolelistCell')).toThrow();
  });
});
