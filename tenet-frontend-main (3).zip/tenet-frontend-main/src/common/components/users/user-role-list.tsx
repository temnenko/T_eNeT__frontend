import { GoABlock, GoADropdown, GoADropdownItem } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useEffect, useState } from 'react';
import { format } from 'date-fns';

import useRolesItems from '../../../hooks/use-roles-list.hook';
import { Role } from '../../../types/role';
import { ChangePermissionsConfirmationModal } from '../modals/change-permissions-confirmation.modal';
import { userService } from '../../../services/user.service';
import { useModal } from '../../../hooks/use-modal.hook';
import { DeactivateUserPermissionsModal } from '../modals/deactivate-user-confirmation-modal';
import { useStore } from '../../../hooks/use-store.hook';
import { toIsoDate } from '../../../utils/date.util';

type Props = {
  roleObj?: Role;
  userId?: string;
  givenName?: string;
  familyName?: string;
  changedAt?: string;
  isOrgRender?: boolean;
};

export const UserRoleList = observer(({ isOrgRender, roleObj, userId, givenName, familyName, changedAt }: Props) => {
  const rolesItems = useRolesItems(isOrgRender);
  const { showModal, hideModal } = useModal();

  const {
    usersListStore: { getUsers },
  } = useStore();

  const [currentRoleId, setCurrentRoleId] = useState('');
  const [pendingRoleId, setPendingRoleId] = useState('');
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);

  const showRoleChangeConfirmationModal = () => {
    const newRole = rolesItems?.find((role) => role.id === currentRoleId);
    if (showConfirmationModal) {
      showModal(
        <ChangePermissionsConfirmationModal
          givenName={givenName ?? ''}
          familyName={familyName ?? ''}
          roleName={newRole?.name ?? 'Unassigned'}
          onDecline={() => {
            hideModal();
            setShowConfirmationModal(false);
            setCurrentRoleId(pendingRoleId);
          }}
          onConfirm={async () => {
            await Promise.all([userService.assignRole(userId ?? '0', currentRoleId), getUsers()]);
            await getUsers();
            hideModal();
            setShowConfirmationModal(false);
          }}
        />,
      );
    }
  };

  const showDeactivateUserConfirmationModal = () => {
    if (showConfirmationModal) {
      showModal(
        <DeactivateUserPermissionsModal
          givenName={givenName ?? ''}
          familyName={familyName ?? ''}
          onDecline={() => {
            hideModal();
            setShowConfirmationModal(false);
            setCurrentRoleId(pendingRoleId);
          }}
          onConfirm={async () => {
            await Promise.all([userService.unassignRole(userId!), getUsers()]);
            hideModal();
            setShowConfirmationModal(false);
            setCurrentRoleId('0');
          }}
        />,
      );
    }
  };
  // set initial dropdown value
  useEffect(() => {
    setCurrentRoleId(roleObj?.id ?? '0');
  }, [roleObj?.id]);

  useEffect(() => {
    if (currentRoleId === 'deactivate') {
      showDeactivateUserConfirmationModal();
    } else {
      showRoleChangeConfirmationModal();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showConfirmationModal]);

  const handleRoleChange = (name: string, value: string | string[]) => {
    const newRoleId = value;
    setPendingRoleId(currentRoleId);
    setCurrentRoleId(newRoleId as string);
    setShowConfirmationModal(true);
  };

  return (
    <GoABlock direction="column" gap="1">
      <GoADropdown
        name="roleSelector"
        ariaLabelledBy="roleSelector"
        value={currentRoleId}
        onChange={handleRoleChange}
        placeholder="-Select-"
      >
        {rolesItems?.map(({ id, name }) => <GoADropdownItem value={id} name="role" label={name} key={id} />)}
      </GoADropdown>
      <span className="color-interactive">{changedAt ? format(toIsoDate(changedAt), 'MMM dd, yyy') : ''}</span>
    </GoABlock>
  );
});
