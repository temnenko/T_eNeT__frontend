import { observer } from 'mobx-react-lite';

import { useStore } from '../../../hooks/use-store.hook';
import { StepperFormHeader } from '../stepper-form/stepper-form-header';
import { userFormsStepperTitles } from '../../../types/user-forms';

export const UserAccessRequestHeader = observer(() => {
  const {
    userAccessFormsStepperStore: { currentlyActive },
  } = useStore();

  return (
    <StepperFormHeader
      headingText="TENET access request"
      currentlyActive={currentlyActive}
      formStepperTitles={userFormsStepperTitles}
    />
  );
});
