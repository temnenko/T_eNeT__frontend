import '@testing-library/jest-dom';
import { BrowserRouter } from 'react-router-dom';

import { getByTestId, render, waitFor } from '@testing-library/react';
import { UsersListTab } from './users-list-tab';
import * as hooks from '../../../hooks/use-store.hook';
import RootStore from '../../../stores/root.store';
import { User, UserStatus } from '../../../types/user';
import * as useModalHook from '../../../hooks/use-modal.hook';

jest.mock('../../../services/user.service', () => ({
  userService: {
    assignRole: jest.fn(),
  },
}));

describe('UsersListTab', () => {
  const mockStore = {
    usersListStore: {
      users: [],
      get hasUsers() {
        return this.users.length > 0;
      },
      getUsers: jest.fn().mockResolvedValue([]),
    },
    rolesStore: {
      roles: [],
      hasRoles: false,
      getAllRoles: jest.fn(),
    },
    permissionStore: { isSuperAdmin: true },
    userStore: {
      role: 'ADMIN',
    },
    userFileStore: { documents: [], softDeleteDocument: jest.fn().mockResolvedValue([]) },
  } as unknown as RootStore;

  const mockModalContextValue = {
    showModal: jest.fn(),
    hideModal: jest.fn(),
    isVisible: false,
    modalContent: null,
  };

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('Renders UsersListTab with no users table', async () => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);
    jest.spyOn(useModalHook, 'useModal').mockImplementation(() => mockModalContextValue);

    const { baseElement: usersListTab } = render(
      <BrowserRouter>
        <UsersListTab />
      </BrowserRouter>,
    );

    await waitFor(() => {
      const noUserFound = getByTestId(usersListTab, 'noUserFound');

      expect(usersListTab).toBeInTheDocument();
      expect(noUserFound).toBeInTheDocument();
      expect(noUserFound).toHaveTextContent('No users found');
    });
  });

  test('Renders UsersListTab with users table', async () => {
    const users: User[] = [
      {
        id: 'test-id',
        sid: 'test-sid',
        givenName: 'test-g-name',
        familyName: 'test-f-name',
        emailAddress: 'test@abc.com',
        type: 'GOA',
        role: 'unassigned',
        roleObj: {
          id: '1',
          name: 'unassigned',
          status: 'ACTIVE',
          description: 'Unassigned',
        },
        changeLog: [],
        status: UserStatus.ACTIVE,
      },
    ];

    mockStore.usersListStore.users = users;
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: usersListTab } = render(
      <BrowserRouter>
        <UsersListTab />
      </BrowserRouter>,
    );

    await waitFor(() => {
      const tableBody = getByTestId(usersListTab, 'usersTable-tableBody');
      const statusHeader = getByTestId(usersListTab, 'usersTable-statusHeader');
      const nameHeader = getByTestId(usersListTab, 'usersTable-nameHeader');
      const organizationHeader = getByTestId(usersListTab, 'usersTable-organizationHeader');
      const detailsHeader = getByTestId(usersListTab, 'usersTable-detailsHeader');

      expect(usersListTab).toBeInTheDocument();
      expect(tableBody).toBeInTheDocument();
      expect(statusHeader).toBeInTheDocument();
      expect(statusHeader).toHaveTextContent('Status');
      expect(nameHeader).toBeInTheDocument();
      expect(nameHeader).toHaveTextContent('Name');
      expect(organizationHeader).toBeInTheDocument();
      expect(organizationHeader).toHaveTextContent('Organization');
      expect(detailsHeader).toBeInTheDocument();

      expect(() => getByTestId(usersListTab, 'noUserFound')).toThrow();
    });
  });
});
