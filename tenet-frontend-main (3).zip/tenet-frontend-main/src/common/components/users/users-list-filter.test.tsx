import '@testing-library/jest-dom';
import { render, getByTestId } from '@testing-library/react';
import * as hooks from '../../../hooks/use-store.hook';
import { UsersListFilter } from './users-list-filter';
import RootStore from '../../../stores/root.store';

describe('UsersListFilter', () => {
  const mockStore = {
    usersListStore: {
      users: [],
      get hasUsers() {
        return this.users.length > 0;
      },
      getUsers: jest.fn(),
    },
    rolesStore: {
      roles: [],
      get hasRoles() {
        return this.roles.length > 0;
      },
      getAllRoles: jest.fn(),
    },
  } as unknown as RootStore;

  test('Renders UsersListFilter', () => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: usersListFilter } = render(<UsersListFilter />);
    const usersFilterSection = getByTestId(usersListFilter, 'usersFilterSection');
    const usersFilterDropdowns = getByTestId(usersListFilter, 'usersFilterDropdowns');
    const usersFilterForm = getByTestId(usersListFilter, 'usersFilterForm');

    expect(usersListFilter).toBeInTheDocument();
    expect(usersFilterSection).toBeInTheDocument();
    expect(usersFilterDropdowns).toBeInTheDocument();
    expect(usersFilterForm).toBeInTheDocument();
  });
});
