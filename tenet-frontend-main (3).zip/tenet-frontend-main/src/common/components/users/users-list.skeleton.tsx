/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoASkeleton } from '@abgov/react-components';
import useHasRole from '../../../hooks/use-has-role.hook';
import { Roles } from '../../../types/role';

export function LoadingSkeleton() {
  const hasRole = useHasRole([Roles.SUPER_ADMIN]);
  return (
    <tbody>
      {Array.from({ length: 5 }, (_, index) => (
        <tr key={index}>
          <td>
            <GoASkeleton type="text" size={4} />
          </td>
          <td>
            <GoASkeleton type="text" size={4} />
          </td>
          <td>
            <GoASkeleton type="text" size={4} />
          </td>
          <td>
            <GoASkeleton type="text" size={4} />
          </td>
          <td>
            <GoASkeleton type="text" size={4} />
          </td>
          {hasRole && (
            <td>
              <GoASkeleton type="text" size={4} />
            </td>
          )}
          <td>
            <GoASkeleton type="text" size={4} />
          </td>
        </tr>
      ))}
    </tbody>
  );
}
