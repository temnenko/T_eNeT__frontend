import { GoAButton, GoADropdown, GoADropdownItem, GoAFormItem, GoAInput } from '@abgov/react-components';

export function UsersListFilter() {
  return (
    <section data-testid="usersFilterSection" className="users-filter-section">
      <div data-testid="usersFilterDropdowns" className="users-filter-dropdown-group">
        <GoAFormItem label="Role" id="usersFilterRole">
          <GoADropdown
            name="filterRoles"
            ariaLabelledBy="usersFilterRole"
            error={false}
            value=""
            onChange={() => {}}
            placeholder="-Select-"
            width="220px"
          >
            <GoADropdownItem name="roles" value="Admin" label="Admin" />
            <GoADropdownItem name="roles" value="User" label="User" />
          </GoADropdown>
        </GoAFormItem>
        <GoAFormItem label="Organization Type" id="usersFilterOrgType">
          <GoADropdown
            name="filterOrgTypes"
            ariaLabelledBy="usersFilterOrgType"
            error={false}
            value=""
            onChange={() => {}}
            placeholder="-Select-"
            width="220px"
            filterable
          >
            <GoADropdownItem name="orgTypes" value="CP" label="Contracted Provider" />
            <GoADropdownItem name="orgTypes" value="GOA" label="Government of Alberta" />
          </GoADropdown>
        </GoAFormItem>
      </div>
      <form data-testid="usersFilterForm" className="users-filter-form-group">
        <GoAFormItem>
          <GoAInput
            type="search"
            leadingIcon="search"
            value=""
            onChange={() => {}}
            name="usersFilterSearch"
            placeholder="Search name, organization"
            width="36ch"
          />
        </GoAFormItem>
        <GoAFormItem>
          <GoAButton type="secondary" onClick={() => {}}>
            Search Users
          </GoAButton>
        </GoAFormItem>
      </form>
    </section>
  );
}
