/* eslint-disable no-nested-ternary */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoATable, GoATableSortHeader } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import useUserRows from '../../../hooks/use-user-rows.hook';
import useHasRole from '../../../hooks/use-has-role.hook';
import { Roles } from '../../../types/role';
import { LoadingSkeleton } from './users-list.skeleton';

type Props = {
  isLoading: boolean;
  hasUsers: boolean;
  organizationName: string;
  isOrgRender?: boolean;
  allowAssignUsers?: boolean;
  setSuccessMessage?: React.Dispatch<React.SetStateAction<string | undefined>>;
};

export const UsersTable = observer(
  ({ isLoading, hasUsers, organizationName, isOrgRender, allowAssignUsers, setSuccessMessage }: Props) => {
    const { userRows, sortUsersData } = useUserRows(organizationName, isOrgRender, allowAssignUsers, setSuccessMessage);
    const hasRole = useHasRole([Roles.SUPER_ADMIN]);

    return hasUsers && userRows.length && !isLoading ? (
      <GoATable width="100%" onSort={sortUsersData}>
        <thead>
          <tr>
            <th data-testid="usersTable-statusHeader">
              <GoATableSortHeader name="status">Status</GoATableSortHeader>
            </th>
            <th data-testid="usersTable-nameHeader">
              <GoATableSortHeader name="givenName">Name</GoATableSortHeader>
            </th>
            {(hasRole || isOrgRender) && (
              <th data-testid="usersTable-availableRoles">
                <GoATableSortHeader name="role">Role</GoATableSortHeader>
              </th>
            )}
            {isOrgRender && (
              <th data-testid="usersTable-organizationHeader">
                <GoATableSortHeader name="organization">Organization</GoATableSortHeader>
              </th>
            )}
            <th data-testid="usersTable-detailsHeader">{}</th>
          </tr>
        </thead>
        {isLoading ? <LoadingSkeleton /> : <tbody data-testid="usersTable-tableBody">{userRows}</tbody>}
      </GoATable>
    ) : (
      <p data-testid="noUserFound">No users found</p>
    );
  },
);
