/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoABadge, GoABlock, GoAButton, GoAIconButton } from '@abgov/react-components';

import { useMemo, useState } from 'react';
import { observer } from 'mobx-react-lite';
import { useModal } from '../../../hooks/use-modal.hook';
import CSCUserAccessRequestReview from '../forms/users/csc-reviews/request-review';
import { useStore } from '../../../hooks/use-store.hook';
import { UserStatus } from '../../../types/user';
import useCapitalize from '../../../hooks/use-capitalize.hook';

type Props = {
  id: string;
  organizationName: string;
  givenName: string;
  familyName: string;
  emailAddress: string;
  currentRole: string;
  userRoleList: JSX.Element;
  accessRequestReviewedById?: string;
  isOrgRender?: boolean;
  allowAssignUsers?: boolean;
  status: UserStatus;
  deactivateHandler: () => Promise<void> | undefined;
  reactivateHandler: () => Promise<void> | undefined;
  profileViewHandler: () => Promise<void> | undefined;
};

export const UserRow = observer(
  ({
    id,
    organizationName,
    givenName,
    familyName,
    emailAddress,
    currentRole,
    userRoleList,
    accessRequestReviewedById,
    isOrgRender,
    allowAssignUsers,
    status,
    deactivateHandler,
    reactivateHandler,
    profileViewHandler,
  }: Props) => {
    const {
      permissionStore: { isCSC, isSuperAdmin },
      userStore: { id: loggedInUserId, getUserById },
    } = useStore();
    const hasRole = isCSC || isSuperAdmin;
    const { showModal, hideModal } = useModal();
    const [popOpen, setPopOpen] = useState(false);
    const capitalize = useCapitalize();
    const isAccessRequestReviewer = useMemo(
      () => accessRequestReviewedById === loggedInUserId || hasRole || isCSC,
      [accessRequestReviewedById, hasRole, isCSC, loggedInUserId],
    );
    const isPendingUser = useMemo(
      () =>
        isOrgRender &&
        [UserStatus.ACCESS_REQUEST_COMPLETED, UserStatus.ACCESS_REQUEST_SUBMITTED, UserStatus.ACCESS_PENDING].includes(
          status as UserStatus,
        ),
      [isOrgRender, status],
    );

    const statusType = useMemo(() => {
      if (status === UserStatus.ACTIVE) {
        return 'success';
      }
      if ([UserStatus.INACTIVE, UserStatus.DENIED].includes(status)) {
        return 'information';
      }
      return 'important';
    }, [status]);
    const statusText = useMemo(() => {
      if ([UserStatus.ACTIVE, UserStatus.INACTIVE, UserStatus.DENIED].includes(status)) {
        return capitalize(status);
      }
      return 'Pending';
    }, [capitalize, status]);

    return (
      <tr>
        <td>
          <GoABadge type={statusType} content={statusText} />
        </td>
        <td>
          <GoABlock direction="column" alignment="start" gap="none">
            <GoAButton type="tertiary" onClick={profileViewHandler}>{`${givenName} ${familyName}`}</GoAButton>
            <span className="users-sub-text">{emailAddress}</span>
          </GoABlock>
        </td>
        {hasRole && status === UserStatus.ACTIVE ? (
          <td data-testid="rolelistCell">{userRoleList}</td>
        ) : (
          <td data-testid="roleCell">{currentRole}</td>
        )}
        {isOrgRender && <td>{organizationName}</td>}
        <td>
          {isPendingUser && (
            <>
              <GoAIconButton icon="ellipsis-horizontal" onClick={() => setPopOpen(!popOpen)} />
              {popOpen && (
                <div className="user-row-popover">
                  <GoABlock direction="column">
                    {isAccessRequestReviewer && (
                      <GoAButton
                        type="tertiary"
                        size="compact"
                        onClick={() => {
                          getUserById(id);
                          showModal(<CSCUserAccessRequestReview hideModal={hideModal} />);
                          setPopOpen(false);
                        }}
                      >
                        Review Request
                      </GoAButton>
                    )}
                    {allowAssignUsers && (
                      <GoAButton type="tertiary" size="compact" onClick={() => setPopOpen(false)}>
                        Assign to user
                      </GoAButton>
                    )}

                    <GoAButton type="tertiary" size="compact" onClick={() => setPopOpen(false)}>
                      Remove
                    </GoAButton>
                  </GoABlock>
                </div>
              )}
            </>
          )}
          {status === UserStatus.INACTIVE && (
            <div className="users-sub-status">
              <GoAButton size="compact" type="tertiary" onClick={reactivateHandler}>
                Reactivate
              </GoAButton>
            </div>
          )}
          {status === UserStatus.ACTIVE && (
            <div className="users-sub-status">
              <GoAButton leadingIcon="trash" size="compact" type="tertiary" onClick={deactivateHandler}>
                Deactivate
              </GoAButton>
            </div>
          )}
        </td>
      </tr>
    );
  },
);
