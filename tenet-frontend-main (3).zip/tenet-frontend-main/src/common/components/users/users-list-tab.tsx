import { GoATab, GoATabs } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useEffect, useState } from 'react';

import { useStore } from '../../../hooks/use-store.hook';
import { UsersTable } from './users-table';
import useUsersListPagination from '../../../hooks/use-users-list-pagination.hook';

export const UsersListTab = observer(() => {
  const [isLoading, setIsLoading] = useState(true);
  const {
    usersListStore: { getUsers, hasUsers, getListSize, currentListPosition },
  } = useStore();
  const usersListPagination = useUsersListPagination();

  useEffect(() => {
    getUsers().finally(() => setIsLoading(false));
  }, [getUsers, getListSize, currentListPosition]);

  return (
    <GoATabs>
      <GoATab heading="All Users">
        <UsersTable organizationName="" hasUsers={hasUsers} isLoading={isLoading} isOrgRender />
        {usersListPagination}
      </GoATab>
      <GoATab heading="Active">
        <p>Active Users [coming soon!]</p>
      </GoATab>
      <GoATab heading="Unassigned">
        <p>Unassigned Users [coming soon!]</p>
      </GoATab>
      <GoATab heading="Inactive">
        <p>Inactive Users [coming soon!]</p>
      </GoATab>
    </GoATabs>
  );
});
