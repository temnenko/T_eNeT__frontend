/* eslint-disable no-plusplus */
import { useCallback, useEffect, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../types/errors/errors';
import { fileService } from '../../../../services/clients/client-files.service';
import useFetchSelectedUser from '../../../../hooks/use-fetch-selectedUser.hook';
import { Roles } from '../../../../types/role';
import { InvalidFileUploadError } from '../../../../types/errors/invalid-file-upload.error';

export interface AccessRequestUpload {
  fileName: string;
  fileType: string;
  completedOn?: Date;
  size: number;
  adspId: string;
}

const useUserDocumentsHook = () => {
  const {
    permissionStore: { isSuperAdmin },
    userStore: { selectedUser },
    userFileStore: { documents, softDeleteDocument, newUploads, uploadUserDocuments },
  } = useStore();

  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const { user } = useFetchSelectedUser();
  const [invalidUploadError, setInvalidUploadError] = useState<InvalidFileUploadError | null>(null);

  const [accessRequestDocs, setAccessRequestDocs] = useState<AccessRequestUpload[]>([]);

  const [isSuccess, setIsSuccess] = useState(false);

  useEffect(() => {
    if (documents?.length) {
      const docs: AccessRequestUpload[] = [];
      for (let i = 0; i < documents.length; i++) {
        const { fileName, typeName, size, adspId, id } = documents[i];
        const completedOn = selectedUser?.accessRequestFiles?.find(
          (fileRequest) => fileRequest.fileRecordId === id,
        )?.completedOnDate;
        docs.push({
          fileName,
          fileType: typeName,
          completedOn,
          size,
          adspId,
        });
      }
      setAccessRequestDocs([...docs]);
    }
  }, [documents, selectedUser?.accessRequestFiles]);

  const submitHandler = async () => {
    try {
      setIsSuccess(false);
      setInvalidUploadError(null);
      setLoading(true);
      await uploadUserDocuments(selectedUser!.id!);
      setIsSuccess(true);
    } catch (error) {
      setIsSuccess(false);
      if (error instanceof InvalidFileUploadError) {
        setInvalidUploadError(error);
      } else {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
        // eslint-disable-next-line no-console
        console.error(error);
      }
    } finally {
      setLoading(false);
    }
  };
  const downloadFile = useCallback(
    async (adspId: string, filename: string, filesize: number) => {
      try {
        fileService.downloadFileByAdspId(adspId, filename, filesize);
      } catch (error) {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    },
    [requestErrorHandler],
  );

  const deleteFile = useCallback(
    async (adspId: string) => {
      if (adspId) {
        setLoading(true);
        await softDeleteDocument(adspId);
      }
    },
    [softDeleteDocument],
  );

  return {
    loading,
    requestError,
    downloadFile,
    selectedUser: user,
    isSuperAdmin: isSuperAdmin || user?.role === Roles.SUPER_ADMIN,
    deleteFile,
    invalidUploadError,
    isSuccess,
    submitHandler,
    newUploads,
    accessRequestDocs,
  };
};

export default useUserDocumentsHook;
