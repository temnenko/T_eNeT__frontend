import { useCallback, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useForm } from 'react-hook-form';

import { useStore } from '../../../../hooks/use-store.hook';
import { MockUploader, Upload } from '../../../../types/files';
import { RequestError } from '../../../../types/errors/errors';
import useFetchSelectedUser from '../../../../hooks/use-fetch-selectedUser.hook';
import { useModal } from '../../../../hooks/use-modal.hook';
import { UserAccessRequestArgs, UserAccessRequestFilesTypeMap } from '../../../../types/user';
import { InvalidFileUploadError } from '../../../../types/errors/invalid-file-upload.error';

type DocumentModalFieldName = 'policeCheckCompletionDate' | 'foipTrainingCompletionDate';

type DocumentModalFieldData = {
  policeCheckCompletionDate?: string;
  foipTrainingCompletionDate?: string;
};

const useDocumentModal = () => {
  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    formState: { errors },
  } = useForm<DocumentModalFieldData>();

  const {
    userFileStore: { getUserDocuments, addToNewUploads, removeFromNewUploads, clearNewUploads, uploadUserDocuments },
    userAccessStore: { updateAccessRequest },
  } = useStore();

  const {
    user: { id },
  } = useFetchSelectedUser();

  const [requestError, setRequestError] = useState<RequestError>({});
  const [progressList, setProgressList] = useState<Record<string, number>>({});
  const [invalidUploadError, setInvalidUploadError] = useState<InvalidFileUploadError | null>(null);
  const [loading, setLoading] = useState(false);

  const { hideModal } = useModal();

  const handleCancel = useCallback(() => {
    clearNewUploads();
    hideModal();
  }, [clearNewUploads, hideModal]);

  const [policeRecordCheckFile, setPoliceRecordCheckFile] = useState<Upload>();
  const [foipTrainingFile, setFoipTrainingFIle] = useState<Upload>();

  const { name: policeCheckCompletionDate } = register('policeCheckCompletionDate', {
    required: { value: policeRecordCheckFile !== undefined, message: 'This field is required' },
  });

  const { name: foipTrainingCompletionDate } = register('foipTrainingCompletionDate', {
    required: { value: foipTrainingFile !== undefined, message: 'This field is required' },
  });

  const formFields = {
    policeCheckCompletionDate,
    policeRecordCheckFile,
    foipTrainingCompletionDate,
    foipTrainingFile,
  };

  const onChangeHandler = useCallback(
    (name: string, value: string | undefined) => {
      setValue(name as DocumentModalFieldName, value);
    },
    [setValue],
  );

  const submitHandler = useCallback(async () => {
    setLoading(true);
    try {
      setInvalidUploadError(null);
      const { policeFileRecordId, foipFileRecordId } = await uploadUserDocuments(id!);
      const { policeCheckCompletionDate: checkDateVal, foipTrainingCompletionDate: foipDateVal } = getValues();
      const payload: UserAccessRequestArgs = {
        policeRecordCheckCompletedOn: checkDateVal ? new Date(checkDateVal) : undefined,
        foipTrainingCompletedOn: foipDateVal ? new Date(foipDateVal) : undefined,
        policeFileRecordId,
        foipFileRecordId,
      };
      await updateAccessRequest(payload);
      await getUserDocuments(id!);
      hideModal();
    } catch {
      setRequestError({
        isUserError: true,
        message:
          'An error occurred while submitting the form. Please try again or contact support if the issue persists.',
        onDismiss: () => setRequestError({}),
      });
    } finally {
      setLoading(false);
    }
  }, [getUserDocuments, getValues, hideModal, id, updateAccessRequest, uploadUserDocuments]);

  const handleSelectFile = useCallback(
    (fileType: UserAccessRequestFilesTypeMap) => (file: File) => {
      const uploader: MockUploader = {
        onprogress: (percent) => {
          setProgressList((old) => ({ ...old, [file.name]: percent }));
        },
      };
      const createdAt =
        fileType === UserAccessRequestFilesTypeMap.policeCheckProof
          ? getValues(policeCheckCompletionDate)
          : getValues(foipTrainingCompletionDate);

      uploader.upload = () => {
        uploader.onprogress(200);
      };

      const newUpload = {
        file,
        uploader,
        fileType,
        id: uuidv4(),
        createdAt: createdAt ? new Date(createdAt).toISOString() : new Date().toISOString(),
        size: file.size,
        adspId: '',
      };
      if (fileType === UserAccessRequestFilesTypeMap.policeCheckProof) {
        setPoliceRecordCheckFile(newUpload);
      } else if (fileType === UserAccessRequestFilesTypeMap.foipTrainingProof) {
        setFoipTrainingFIle(newUpload);
      }
      addToNewUploads(newUpload);
    },
    [addToNewUploads, foipTrainingCompletionDate, getValues, policeCheckCompletionDate],
  );

  return {
    submitHandler,
    handleSubmit,
    onChangeHandler,
    formFields,
    handleCancel,
    setPoliceRecordCheckFile,
    setFoipTrainingFIle,
    progressList,
    handleSelectFile,
    requestError,
    errors,
    getValues,
    removeFromNewUploads,
    loading,
    invalidUploadError,
  };
};

export default useDocumentModal;
