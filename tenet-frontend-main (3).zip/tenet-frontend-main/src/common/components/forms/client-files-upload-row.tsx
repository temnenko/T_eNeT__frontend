/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { format } from 'date-fns';
import { GoABlock, GoADropdown, GoADropdownItem, GoAFormItem, GoAIconButton } from '@abgov/react-components';

import ProgressBar from '../progress-bar/progress-bar';
import { FileUploadTypes } from '../../../types/client-forms';
import { Upload } from '../../../types/files';
import InlineLoadingIndicator from './inline-loading-indicator';
import { toIsoDate } from '../../../utils/date.util';

type Props = {
  uploads: Upload[];
  progressList: Record<string, number>;
  fileBeingDeleted: string | null;
  deleteHandler: (file: Upload) => void;
  onFileTypeChange: (name: string, value: string | string[]) => void;
  downloadFile: (fileId: string, filename: string, filesize: number) => void;
  canDeleteFiles: boolean;
  errorMessage?: string;
};

export function ClientFilesUploadRow({
  uploads,
  progressList,
  fileBeingDeleted,
  deleteHandler,
  onFileTypeChange,
  downloadFile,
  canDeleteFiles,
  errorMessage,
}: Props) {
  return (
    <>
      {uploads.map((upload) => (
        <tr key={`${upload.id}-${progressList[upload.id]}`}>
          <td>
            <GoABlock direction="column" gap="xs">
              <span
                className="client-document-span"
                onClick={() => {
                  if (upload.adspId) {
                    downloadFile(upload.adspId, upload.file.name, upload.size);
                  }
                }}
              >
                {upload.file.name}
              </span>
              <ProgressBar
                visualParts={[
                  {
                    percentage: progressList[upload.file.name],
                    color: '#004A8F',
                  },
                ]}
              />
            </GoABlock>
          </td>
          <td>
            <GoAFormItem error={upload.fileType === '' && errorMessage}>
              <GoADropdown
                width="200px"
                name={upload.id}
                ariaLabelledBy="fileTypeSelector"
                onChange={(name: string, value: string | string[]) => onFileTypeChange(name, value)}
                value={upload.fileType}
                disabled={upload.persisted}
                relative
              >
                <GoADropdownItem value="" name="selectType" label="-- Select --" />
                <GoADropdownItem value={FileUploadTypes.RESUME} name="resume" label="Resume" />
                <GoADropdownItem
                  value={FileUploadTypes.PARTICIPANT_AGREEMENT}
                  name="participantAgreement"
                  label="Participant agreement"
                />
                <GoADropdownItem
                  value={FileUploadTypes.COURSE_CERTIFICATE}
                  name="courseCertificate"
                  label="Course certificate"
                />
                <GoADropdownItem
                  value={FileUploadTypes.SHORT_COURSE_RECEIPT}
                  name="shortCourseReceipt"
                  label="Short course receipt"
                />
                <GoADropdownItem value={FileUploadTypes.OTHER} name="other" label="Other" />
              </GoADropdown>
            </GoAFormItem>
          </td>
          <td>{upload.addedByFullName}</td>
          <td>{format(toIsoDate(upload.createdAt), 'MMM dd, yyyy')}</td>
          <td>
            {canDeleteFiles && (
              <>
                {fileBeingDeleted === upload.adspId ? (
                  <InlineLoadingIndicator />
                ) : (
                  <GoAIconButton
                    onClick={() => deleteHandler(upload)}
                    icon="trash"
                    disabled={fileBeingDeleted === upload.id}
                    variant="dark"
                  />
                )}
              </>
            )}
          </td>
          <td>
            <progress id={`statusBar-${upload.adspId}`} style={{ display: 'none' }} />
          </td>
        </tr>
      ))}
    </>
  );
}

ClientFilesUploadRow.defaultProps = {
  errorMessage: '',
};
