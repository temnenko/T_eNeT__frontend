import { GoABlock, GoACheckbox, GoAFormItem, GoAInput, GoANotification, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { FileUploadControl } from '../file-upload-control';
import { FileHandlerResult, Upload } from '../../../types/files';
import { toIsoFormat } from '../../../utils/date.util';

type Props = {
  label: string;
  checkInputName?: string;
  inputLabel: string;
  inputName: string;
  fileInputName: string;
  uploadType: string;
  checkInputError: string | undefined;
  inputError: string | undefined;
  checkOnChangeHandler?: (name: string, value: boolean) => void;
  inputOnChangeHandler: (name: string, value: string | undefined) => void;
  isDateInput?: boolean;
  fileInputLabel: string;
  fileInputError: string | undefined;
  maxSizeInMb: number;
  setFileValue: (name: string, value: Upload[]) => void;
  getValues: <T>(name: string) => T;
  fileHandler: FileHandlerResult;
  uploadOptional?: boolean;
  canEditOrganizationCompliance?: boolean;
};

export const FileDateInputGroup = observer(
  ({
    label,
    checkInputName,
    inputLabel,
    inputName,
    inputError,
    checkInputError,
    inputOnChangeHandler,
    checkOnChangeHandler,
    isDateInput = true,
    fileInputLabel,
    fileInputError,
    maxSizeInMb,
    getValues,
    fileHandler,
    uploadOptional,
  }: Props) => {
    const { uploads, progressList, selectFile, deleteFile, isLoading, requestError, uploadErrors, setUploadErrors } =
      fileHandler;

    return (
      <GoABlock direction="column" mb="l">
        {checkInputName ? (
          <GoAFormItem error={checkInputError}>
            <GoACheckbox
              name={checkInputName}
              value={getValues(checkInputName)}
              checked={getValues(checkInputName)}
              onChange={checkOnChangeHandler}
              text={label}
            />
          </GoAFormItem>
        ) : (
          <span>{label}</span>
        )}
        {requestError?.message && (
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
        )}
        {uploadErrors.length ? (
          <>
            <GoASpacer vSpacing="l" />
            <GoANotification type="important" onDismiss={() => setUploadErrors([])}>
              {uploadErrors[0]}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        ) : undefined}
        <GoAFormItem label={inputLabel} error={inputError}>
          {/* {!isRequired && <span className="client-small-faint-text">(optional)</span>} */}
          {!isDateInput ? (
            <GoAInput
              type="text"
              onChange={inputOnChangeHandler}
              name={inputName}
              id={inputName}
              value={getValues(inputName)}
              width="100%"
            />
          ) : (
            <GoAInput
              type="date"
              onChange={inputOnChangeHandler}
              name={inputName}
              value={getValues(inputName) ? toIsoFormat(getValues(inputName)!) : undefined}
              min="0000-01-01"
              max="9999-12-31"
            />
          )}
        </GoAFormItem>
        <FileUploadControl
          label={fileInputLabel}
          error={fileInputError}
          maxSizeInMb={maxSizeInMb}
          uploads={uploads}
          progressList={progressList}
          selectHandler={selectFile}
          deleteHandler={deleteFile}
          isLoading={isLoading}
          uploadOptional={uploadOptional}
        />
      </GoABlock>
    );
  },
);
