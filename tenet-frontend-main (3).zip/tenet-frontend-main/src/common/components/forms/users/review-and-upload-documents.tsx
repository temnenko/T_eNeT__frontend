import {
  GoABlock,
  GoAButton,
  GoAContainer,
  GoAFormItem,
  GoAGrid,
  GoANotification,
  GoASpacer,
  GoAText,
} from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';
import { observer } from 'mobx-react-lite';
import { useCallback } from 'react';
import useReviewDetailsForm, { ReviewDetailsFieldNames } from './hooks/use-review-and-upload-documents.hook';
import { FileDateInputGroup } from '../file-date-input-group';
import { Upload } from '../../../../types/files';
import { UserAccessRequestFilesTypeMap } from '../../../../types/user';
import useRequestFileHandler from './hooks/use-request-file-handler';
import AutocompleteInput from '../../auto-complete-input';

export const ReviewAndUploadDocuments = observer(() => {
  const navigate = useNavigate();
  const {
    formFields,
    getValues,
    setValue,
    onChangeHandler,
    onCheckChangeHandler,
    onSelectUser,
    setUserField,
    handleSubmit,
    watch,
    errors,
    previousButtonHandler,
    requestSubmitHandler,
    reviewFields,
    requestError,
  } = useReviewDetailsForm();
  const {
    isPoliceCheckCompleted,
    policeCheckProof,
    policeCheckCompletionDate,
    isFoipTrainingCompleted,
    foipTrainingProof,
    foipTrainingCompletionDate,
    reviewer,
  } = formFields;
  const { familyName, givenName, emailAddress, phoneNumber, jobTitle, id, termsAcceptedOn } = reviewFields;

  const setFileValue = (name: string, value: Upload[]) => setValue(name as ReviewDetailsFieldNames, value);
  const policeCheckProofHandler = useRequestFileHandler({
    name: policeCheckProof,
    uploadType: UserAccessRequestFilesTypeMap.policeCheckProof,
    setValue: setFileValue,
  });
  const foipTrainingProofHandler = useRequestFileHandler({
    name: foipTrainingProof,
    uploadType: UserAccessRequestFilesTypeMap.foipTrainingProof,
    setValue: setFileValue,
  });
  const actions = useCallback(
    (navigateAction: () => void) => (
      <GoAButton type="tertiary" size="compact" onClick={navigateAction} disabled={false}>
        <span style={{ color: 'white' }}>Edit</span>
      </GoAButton>
    ),
    [],
  );

  return (
    <div className="client-review-overview">
      <GoAGrid gap="xl" minChildWidth="754px">
        <GoAText size="heading-m">Review</GoAText>
        <GoAContainer
          heading="User details"
          accent="thick"
          actions={actions(() => navigate(`/users/access/user-details/${id}`))}
          padding="relaxed"
        >
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">First name</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{givenName}</span>
            </div>
          </GoABlock>
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">Last name</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{familyName}</span>
            </div>
          </GoABlock>
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">Role</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{jobTitle}</span>
            </div>
          </GoABlock>
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">Email</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{emailAddress}</span>
            </div>
          </GoABlock>
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">Phone number</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{phoneNumber}</span>
            </div>
          </GoABlock>
        </GoAContainer>
        <GoAContainer
          heading="Terms of use"
          accent="thick"
          actions={actions(() => navigate(`/users/access/request-details/${id}`))}
          padding="relaxed"
        >
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">Agreed</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{termsAcceptedOn ? 'Yes' : 'No'}</span>
            </div>
          </GoABlock>
        </GoAContainer>
        <form className="stepper-form-container">
          <GoAText size="heading-m">Upload document</GoAText>
          <GoAText size="body-m">
            Users directly accessing personal information provided by the Government of Canada must provide a
            Canada-Wide Criminal Record Check(CRC). A CRC will require an update at least every 10 years. It is the
            external user’s responsibility to self disclose to their supervisor if charged with a criminal offence after
            the CRC is completed.
          </GoAText>
          {requestError?.message && (
            <>
              <GoANotification type="emergency">{requestError.message}</GoANotification>
              <GoASpacer vSpacing="s" />
            </>
          )}
          <FileDateInputGroup
            isDateInput
            maxSizeInMb={10}
            label="I have completed Canada-Wide Criminal Record Check (CRC)"
            inputLabel="Completion date"
            fileInputLabel="Upload your Criminal Record Check"
            checkInputName={isPoliceCheckCompleted}
            inputName={policeCheckCompletionDate}
            fileInputName={policeCheckProof}
            inputOnChangeHandler={onChangeHandler}
            checkOnChangeHandler={onCheckChangeHandler}
            checkInputError={errors.isPoliceCheckCompleted?.message}
            inputError={errors.policeCheckCompletionDate?.message}
            fileInputError={errors.policeCheckProof?.message}
            getValues={getValues}
            setFileValue={(name: string, value: Upload[]) => setValue(name as ReviewDetailsFieldNames, value)}
            uploadType={UserAccessRequestFilesTypeMap.policeCheckProof}
            fileHandler={policeCheckProofHandler}
          />
          <FileDateInputGroup
            isDateInput
            maxSizeInMb={10}
            label="I have completed FOIP training."
            inputLabel="Completion date"
            fileInputLabel="Upload your FOIP training certificate"
            checkInputName={isFoipTrainingCompleted}
            inputName={foipTrainingCompletionDate}
            fileInputName={foipTrainingProof}
            inputOnChangeHandler={onChangeHandler}
            checkOnChangeHandler={onCheckChangeHandler}
            checkInputError={errors.isFoipTrainingCompleted?.message}
            inputError={errors.foipTrainingCompletionDate?.message}
            fileInputError={errors.foipTrainingProof?.message}
            getValues={getValues}
            setFileValue={(name: string, value: Upload[]) => setValue(name as ReviewDetailsFieldNames, value)}
            uploadType={UserAccessRequestFilesTypeMap.foipTrainingProof}
            fileHandler={foipTrainingProofHandler}
          />
          <GoAFormItem label="Type and select your CSC for request review" error={errors.reviewer?.message}>
            <AutocompleteInput
              name={reviewer}
              id={reviewer}
              placeholder=""
              width="42rem"
              onSelectAddress={undefined}
              onSelectUser={onSelectUser}
              value={watch(reviewer)}
              subType=""
              setField={setUserField}
            />
          </GoAFormItem>
          <GoASpacer vSpacing="xl" />
          <div className="row-space-between">
            <GoAButton type="secondary" onClick={previousButtonHandler} leadingIcon="arrow-back">
              <span className="client-bold-600">Back:</span> Terms of use
            </GoAButton>
            <GoAButton type="submit" onClick={handleSubmit(requestSubmitHandler)} trailingIcon="arrow-forward">
              Submit
            </GoAButton>
          </div>
          <GoASpacer vSpacing="2xl" />
        </form>
      </GoAGrid>
    </div>
  );
});
