/* eslint-disable react/no-array-index-key */
import {
  GoABlock,
  GoAButton,
  GoACallout,
  GoACheckbox,
  GoAFormItem,
  GoAGrid,
  GoASpacer,
  GoAText,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import InlineLoadingIndicator from '../inline-loading-indicator';
import useSubmitAccessRequestTerms from './hooks/use-access-request-terms.hook';

const UserAccessRequestTerms = observer(() => {
  const { loading, termsOfUse, errored, onChangeHandler, accessRequestSubmitHandler, previousButtonHandler } =
    useSubmitAccessRequestTerms();

  return (
    <div className="client-review-overview">
      <GoAGrid gap="xl" minChildWidth="754px">
        <div className="access-request-review-consent">
          {errored && (
            <GoACallout size="large" type="emergency">
              Please agree to all Terms of use before continuing.
            </GoACallout>
          )}
          <GoAText size="heading-m">Terms of use</GoAText>
          <GoABlock direction="column">
            <GoAText mb="s" size="body-m">
              I understand and agree to the following:
            </GoAText>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="purpose"
                onChange={onChangeHandler}
                checked={termsOfUse.purpose}
                value={termsOfUse.purpose}
              >
                I shall access and use TENET only for the purpose for which it was granted
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="safeguard"
                onChange={onChangeHandler}
                checked={termsOfUse.safeguard}
                value={termsOfUse.safeguard}
              >
                I shall safeguard my user name and password, taking all reasonable and necessary measures to prevent the
                loss, disclosure, modification and unauthorized use of username and password, and immediately advise my
                manager/supervisor of any suspected compromise
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="abApplicable"
                onChange={onChangeHandler}
                checked={termsOfUse.abApplicable}
                value={termsOfUse.abApplicable}
              >
                That the Alberta.ca Account Terms of Use apply to my usage of TENET, except to the extent that the
                Alberta.ca Terms of Use are added to or amended
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="lossLiability"
                onChange={onChangeHandler}
                checked={termsOfUse.lossLiability}
                value={termsOfUse.lossLiability}
              >
                That I may be held personally liable for any losses to the GOA or any third party resulting from the
                account being used for an unauthorized purpose, and
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="employerAccess"
                onChange={onChangeHandler}
                checked={termsOfUse.employerAccess}
                value={termsOfUse.employerAccess}
              >
                That I represent having authority from the employer to access TENET and that GOA may hold the employer
                liable for any losses suffered because of my unauthorized use of TENET.
              </GoACheckbox>
            </GoAFormItem>
            <GoAText mb="s" size="body-m">
              I agree not to:
            </GoAText>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="contentModeration"
                onChange={onChangeHandler}
                checked={termsOfUse.contentModeration}
                value={termsOfUse.contentModeration}
              >
                post or upload any inappropriate, promotional, defamatory, destructive, obscene, or unlawful content.
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="othersRight"
                onChange={onChangeHandler}
                checked={termsOfUse.othersRight}
                value={termsOfUse.othersRight}
              >
                defame, abuse, harass, stalk, threaten or otherwise violate the legal rights (such as rights of privacy
                and publicity) of others
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="othersPatentRight"
                onChange={onChangeHandler}
                checked={termsOfUse.othersPatentRight}
                value={termsOfUse.othersPatentRight}
              >
                post or upload any content that infringes on any patent, trademark, copyright, trade secret or other
                intellectual property right of any party
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="impersonation"
                onChange={onChangeHandler}
                checked={termsOfUse.impersonation}
                value={termsOfUse.impersonation}
              >
                impersonate another person, or falsify or delete any author attributions, legal or other proper notices
                or proprietary designations or labels of the origin or source of any content
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="robotUse"
                onChange={onChangeHandler}
                checked={termsOfUse.robotUse}
                value={termsOfUse.robotUse}
              >
                use any robot, spider, site search/retrieval application, or other device to retrieve or index any
                portion of the website to collect information about other users or domain names
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="malwareUpload"
                onChange={onChangeHandler}
                checked={termsOfUse.malwareUpload}
                value={termsOfUse.malwareUpload}
              >
                upload files that contain bugs, viruses, trojan horses, worms, or any other similar software or programs
                that may damage the operation of the computer or property of another
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="partyMisrepresented"
                onChange={onChangeHandler}
                checked={termsOfUse.partyMisrepresented}
                value={termsOfUse.partyMisrepresented}
              >
                submit content that falsely expresses or implies that such content is sponsored or endorsed by any party
                where it is not sponsored or endorsed by such party
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="accessBlockOnViolation"
                onChange={onChangeHandler}
                checked={termsOfUse.accessBlockOnViolation}
                value={termsOfUse.accessBlockOnViolation}
              >
                I understand that if I do any of the above, the GoA may immediately take any and all action it deems
                necessary in the sole discretion of the GoA to stop, limit, remediate or cure such harm, and to prevent
                any other or further occurrences of harm, including blocking access to TENET by me and by my employer.
              </GoACheckbox>
            </GoAFormItem>
            <GoAText mb="s" size="body-m">
              In addition, I agree and understand the following:
            </GoAText>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="changeWithoutNotice"
                onChange={onChangeHandler}
                checked={termsOfUse.changeWithoutNotice}
                value={termsOfUse.changeWithoutNotice}
              >
                This website and any related services are provided on an “as-is” and “as-available basis” and is subject
                to change without notice. The GoA does not warrant or make any other representations regarding the use,
                accuracy, timelines, applicability, performance, security, availability or reliability of this website
                or any sites linked to this site, or the results from the use of this website or any sites linked to
                this website, or otherwise respecting the materials on this website or any sites linked to this website,
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="termsOfUse"
                onChange={onChangeHandler}
                checked={termsOfUse.termsOfUse}
                value={termsOfUse.termsOfUse}
              >
                These Terms of Use shall be governed by and interpreted in accordance with the laws in force in Alberta,
                and the parties irrevocably attorn to the exclusive jurisdiction of courts in Alberta, and
              </GoACheckbox>
            </GoAFormItem>
            <GoAFormItem>
              <GoASpacer vSpacing="s" />
              <GoACheckbox
                name="partlyEnforceable"
                onChange={onChangeHandler}
                checked={termsOfUse.partlyEnforceable}
                value={termsOfUse.partlyEnforceable}
              >
                If any term or provision of these Terms of Use is invalid, illegal or unenforceable, all other terms and
                provisions of these Terms of Use shall nonetheless remain in full force and effect.
              </GoACheckbox>
            </GoAFormItem>
          </GoABlock>
        </div>
        <div className="organization-form-buttons">
          <GoAButton type="secondary" onClick={previousButtonHandler} leadingIcon="arrow-back">
            <span className="client-bold-600">Back:</span> User detail
          </GoAButton>
          <GoAButton type="primary" onClick={accessRequestSubmitHandler} trailingIcon="arrow-forward">
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span className="client-bold-600">Next: </span>
                Review and upload documents
              </>
            )}
          </GoAButton>
        </div>
      </GoAGrid>
    </div>
  );
});

export default UserAccessRequestTerms;
