import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoAFormItem,
  GoAGrid,
  GoAInput,
  GoANotification,
  GoASpacer,
  GoAText,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useSubmitAccessRequest from './hooks/use-user-access-request.hook';
import InlineLoadingIndicator from '../inline-loading-indicator';
import { useFormatPhoneInput } from '../../../../hooks/use-format-phone-input.hook';

export const UserAccessRequest = observer(() => {
  const {
    loading,
    accessSubmitHandler,
    handleSubmit,
    errors,
    getValues,
    onChangeHandler,
    requestError,
    formsFields,
    watch,
  } = useSubmitAccessRequest();

  const { firstName, lastName, emailAddress, jobTitle, phoneNumber } = formsFields;
  const formatPhoneNum = useFormatPhoneInput();

  return (
    <div className="access-request-form">
      <GoAText size="heading-m">User detail</GoAText>
      <form>
        <GoABlock direction="column">
          <GoAGrid minChildWidth="20.063rem" gap="m">
            <GoAFormItem error={errors.firstName?.message} label="First name">
              <GoAInput
                name={firstName}
                onChange={onChangeHandler}
                type="text"
                id={firstName}
                value={getValues(firstName)}
                width="20.063rem"
                disabled
              />
            </GoAFormItem>
            <GoAFormItem error={errors.lastName?.message} label="Last name">
              <GoAInput
                name={lastName}
                onChange={onChangeHandler}
                type="text"
                id={lastName}
                value={getValues(lastName)}
                width="20.063rem"
                disabled
              />
            </GoAFormItem>
          </GoAGrid>
          <GoASpacer vSpacing="m" />
          <GoABlock>
            <GoAFormItem maxWidth="20.063rem" error={errors.emailAddress?.message} label="Email Address">
              <GoAInput
                name={emailAddress}
                onChange={onChangeHandler}
                type="text"
                id={emailAddress}
                value={getValues(emailAddress)}
                width="23.063rem"
                disabled
              />
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="m" />
          <GoAGrid minChildWidth="20.063rem">
            <GoAFormItem error={errors.jobTitle?.message} label="Job Title">
              <GoAInput
                name={jobTitle}
                onChange={onChangeHandler}
                type="text"
                id={jobTitle}
                value={getValues(jobTitle)}
                width="20.063rem"
              />
            </GoAFormItem>
          </GoAGrid>
          <GoASpacer vSpacing="m" />
          <GoABlock>
            <GoAFormItem
              maxWidth="20.063rem"
              label="Phone number"
              error={errors.phoneNumber?.message}
              requirement="optional"
            >
              <GoAInput
                name={phoneNumber}
                onChange={onChangeHandler}
                type="text"
                leadingContent="+1"
                id={phoneNumber}
                value={formatPhoneNum(watch(phoneNumber))}
                width="20.063rem"
              />
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="m" />
          {requestError?.message && (
            <>
              <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
                {requestError.message}
              </GoANotification>
              <GoASpacer vSpacing="s" />
            </>
          )}
          <GoASpacer vSpacing="m" />
          <div className="access-request-form-buttons">
            <GoAButtonGroup alignment="end">
              <GoAButton
                type="primary"
                onClick={handleSubmit(accessSubmitHandler)}
                trailingIcon={loading ? undefined : 'arrow-forward'}
              >
                {loading ? (
                  <InlineLoadingIndicator label="Saving changes..." />
                ) : (
                  <>
                    <span>Next:</span> Terms of use
                  </>
                )}
              </GoAButton>
            </GoAButtonGroup>
          </div>
        </GoABlock>
      </form>
    </div>
  );
});
