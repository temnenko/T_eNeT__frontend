import { observer } from 'mobx-react-lite';
import useAccessFormSteppers from './hooks/use-access-form-steppers.hook';

export const UserAccessRequestFormsStepper = observer(() => {
  const steppers = useAccessFormSteppers();

  return (
    <ul className="tabs" role="tablist">
      {steppers}
    </ul>
  );
});
