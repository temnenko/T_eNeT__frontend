import { useCallback, useMemo, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';

import { useStore } from '../../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { getEnumKeyByValue } from '../../../../../utils/enums.util';
import { RequestError } from '../../../../../types/errors/errors';
import { MockUploader, Upload, FileHandlerInput } from '../../../../../types/files';
import { UserAccessRequestFilesTypeMap } from '../../../../../types/user';
import useFileNotValid from '../../../../../utils/file.util';
import { InvalidFileUploadError } from '../../../../../types/errors/invalid-file-upload.error';
import { ConfirmationModal } from '../../../modals/confirmation.modal';
import { useModal } from '../../../../../hooks/use-modal.hook';

const useRequestFileHandler = ({
  name,
  setValue,
  uploadType,
  postUploadCallback,
  postDeleteCallback,
}: FileHandlerInput) => {
  const [progressList, setProgressList] = useState<Record<string, number>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [uploadErrors, setUploadErrors] = useState<string[]>([]);
  const {
    userAccessStore: { policeCheckProof, foipTrainingProof, uploadFiles, removeFile },
  } = useStore();
  const { hideModal, showModal } = useModal();

  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});

  const uploads = useMemo(() => {
    if (getEnumKeyByValue(UserAccessRequestFilesTypeMap, UserAccessRequestFilesTypeMap.policeCheckProof) === name) {
      const upload = policeCheckProof ?? [];
      setValue(name, upload);
      return upload;
    }

    if (getEnumKeyByValue(UserAccessRequestFilesTypeMap, UserAccessRequestFilesTypeMap.foipTrainingProof) === name) {
      const upload = foipTrainingProof ?? [];
      setValue(name, upload);
      return upload;
    }

    setValue(name, []);
    return [];
  }, [foipTrainingProof, name, policeCheckProof, setValue]);

  const deleteFile = useCallback(
    async (upload: Upload) => {
      try {
        await removeFile(upload, uploadType as UserAccessRequestFilesTypeMap);
        if (postDeleteCallback) {
          postDeleteCallback(upload);
        }
      } catch (e) {
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
      } finally {
        hideModal();
      }
    },
    [hideModal, postDeleteCallback, removeFile, requestErrorHandler, uploadType],
  );

  const deleteFileHandler = useCallback(
    async (file: Upload) => {
      showModal(
        <ConfirmationModal
          heading="Confirm file removal"
          description="Are you sure you want to remove this file?"
          declineText="Cancel"
          confirmText="Remove file"
          onConfirm={() => deleteFile(file)}
          onDecline={hideModal}
          isDelete
        />,
      );
    },
    [deleteFile, hideModal, showModal],
  );

  const { fileNotValidHandler } = useFileNotValid();

  const selectFile = useCallback(
    (file: File) => {
      try {
        fileNotValidHandler(file.name, file.type);
        const reader = new FileReader();
        reader.onload = (e: ProgressEvent<FileReader>) => {
          if (!e.target) return;
          const url = e.target.result;
          const uploader: MockUploader = {
            onprogress: (percent) => {
              setProgressList((old) => ({ ...old, [file.name]: percent }));
            },
          };

          const selectedFileAsUpload: Upload = {
            file,
            uploader,
            fileType: uploadType,
            id: uuidv4(),
            createdAt: new Date().toISOString(),
            size: file.size,
            adspId: '',
          };

          uploader.upload = async () => {
            setIsLoading(true);
            const uploadedFiles = await uploadFiles(
              [selectedFileAsUpload],
              uploadType as UserAccessRequestFilesTypeMap,
            ).finally(() => {
              setIsLoading(false);
            });
            if (uploadedFiles.length === 0) {
              setUploadErrors(['Failed to upload file']);
            } else if (postUploadCallback) {
              postUploadCallback(
                uploadedFiles.map((f) => {
                  return {
                    file,
                    uploader,
                    fileType: uploadType,
                    id: f.id,
                    createdAt: f.createdAt,
                    size: f.size,
                    adspId: f.adspId,
                  };
                }),
              );
            }
            uploader.onprogress(200);
          };

          if (url) {
            uploader.upload(url);
          }
        };
        reader.readAsDataURL(file);
      } catch (ex) {
        if (ex instanceof InvalidFileUploadError) {
          setUploadErrors([ex.message]);
        } else {
          requestErrorHandler({
            error: ex,
            setError: setRequestError,
          });
        }
      }
    },
    [fileNotValidHandler, postUploadCallback, requestErrorHandler, uploadFiles, uploadType],
  );

  return {
    uploads,
    progressList,
    selectFile,
    deleteFile: deleteFileHandler,
    isLoading,
    uploadErrors,
    requestError,
    setUploadErrors,
  };
};

export default useRequestFileHandler;
