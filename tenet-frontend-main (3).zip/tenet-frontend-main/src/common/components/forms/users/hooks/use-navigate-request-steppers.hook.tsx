import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../../../hooks/use-store.hook';
import { UserFormsStepperKeys, userFormsStepperPaths } from '../../../../../types/user-forms';

export const useNavigateRequestStepper = () => {
  const navigate = useNavigate();
  const { userAccessFormsStepperStore } = useStore();

  const setActiveStep = useCallback(
    (stepKey: UserFormsStepperKeys) => {
      userAccessFormsStepperStore.setActiveStep(stepKey);
    },
    [userAccessFormsStepperStore],
  );

  const goToNextStep = useCallback(
    (id: string) => {
      const nextStepKey = userAccessFormsStepperStore.next();
      if (nextStepKey) {
        let nextStepPath = userFormsStepperPaths[nextStepKey];
        nextStepPath = nextStepPath.replace(':id', id);
        navigate(nextStepPath);
      }
    },
    [userAccessFormsStepperStore, navigate],
  );

  const goToPreviousStep = useCallback(
    (id: string) => {
      const previousStepKey = userAccessFormsStepperStore.previous();
      if (previousStepKey) {
        let previousStepPath = userFormsStepperPaths[previousStepKey];
        previousStepPath = previousStepPath.replace(':id', id);
        navigate(previousStepPath);
      }
    },
    [userAccessFormsStepperStore, navigate],
  );

  const jumpToStep = useCallback(
    (stepKey: UserFormsStepperKeys, id: string) => {
      let stepPath = userFormsStepperPaths[stepKey];
      stepPath = stepPath.replace(':id', id);
      navigate(stepPath);
    },
    [navigate],
  );

  return { goToNextStep, goToPreviousStep, setActiveStep, jumpToStep };
};
