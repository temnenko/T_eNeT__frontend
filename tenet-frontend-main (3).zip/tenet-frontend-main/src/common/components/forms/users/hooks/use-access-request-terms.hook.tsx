/* eslint-disable no-console */
import { useCallback, useEffect, useMemo, useState } from 'react';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { useStore } from '../../../../../hooks/use-store.hook';
import { RequestError } from '../../../../../types/errors/errors';
import { useNavigateRequestStepper } from './use-navigate-request-steppers.hook';
import { UserFormsStepperKeys } from '../../../../../types/user-forms';

interface TermsOfUse {
  purpose: boolean;
  safeguard: boolean;
  abApplicable: boolean;
  lossLiability: boolean;
  malwareUpload: boolean;
  contentModeration: boolean;
  othersRight: boolean;
  othersPatentRight: boolean;
  impersonation: boolean;
  robotUse: boolean;
  employerAccess: boolean;
  partyMisrepresented: boolean;
  accessBlockOnViolation: boolean;
  changeWithoutNotice: boolean;
  termsOfUse: boolean;
  partlyEnforceable: boolean;
}

const useSubmitAccessRequestTerms = () => {
  const [requestError, setRequestError] = useState<RequestError>({});
  const {
    userStore: { id },
    userAccessStore: { termsAcceptedOn, updateAccessRequest },
  } = useStore();

  const { setActiveStep, goToPreviousStep, goToNextStep } = useNavigateRequestStepper();

  const termsAccepted = useMemo(() => !!termsAcceptedOn, [termsAcceptedOn]);
  const [termsOfUse, setTermsOfUse] = useState<TermsOfUse>({
    purpose: termsAccepted,
    safeguard: termsAccepted,
    abApplicable: termsAccepted,
    lossLiability: termsAccepted,
    malwareUpload: termsAccepted,
    contentModeration: termsAccepted,
    othersRight: termsAccepted,
    othersPatentRight: termsAccepted,
    impersonation: termsAccepted,
    robotUse: termsAccepted,
    employerAccess: termsAccepted,
    partyMisrepresented: termsAccepted,
    accessBlockOnViolation: termsAccepted,
    changeWithoutNotice: termsAccepted,
    termsOfUse: termsAccepted,
    partlyEnforceable: termsAccepted,
  });
  const [loading, setLoading] = useState(false);
  const [errored, setErrored] = useState<boolean>(false);

  const onChangeHandler = useCallback((key: string, checked: boolean) => {
    setTermsOfUse((prev) => ({
      ...prev,
      [key]: checked,
    }));
  }, []);

  const requestErrorHandler = useRequestErrorHandler();

  const files = {
    data: [
      {
        filename: '',
        dateAdded: new Date().toLocaleDateString(),
        filetype: '',
      },
    ],
  };

  const accessRequestSubmitHandler = useCallback(async () => {
    try {
      setLoading(true);
      if (Object.values(termsOfUse).find((item) => item === false) === undefined) {
        setErrored(false);
        await updateAccessRequest({
          termsAcceptedOn: new Date(),
        });
        goToNextStep(id!);
      } else {
        setErrored(true);
      }
    } catch (e) {
      console.log(e);
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setLoading(false);
    }
  }, [goToNextStep, id, requestErrorHandler, termsOfUse, updateAccessRequest]);

  const previousButtonHandler = useCallback(() => goToPreviousStep(id!), [goToPreviousStep, id]);

  useEffect(() => {
    setActiveStep(UserFormsStepperKeys.REQUEST_DETAILS);
  }, [setActiveStep]);

  return {
    loading,
    accessRequestSubmitHandler,
    files,
    requestError,
    errored,
    termsOfUse,
    onChangeHandler,
    previousButtonHandler,
  };
};

export default useSubmitAccessRequestTerms;
