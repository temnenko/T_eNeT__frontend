import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useNavigate, useParams } from 'react-router-dom';

import { Upload } from '../../../../../types/files';
import { validateNotFutureDate } from '../../../../../utils/validate-date.util';
import { useStore } from '../../../../../hooks/use-store.hook';
import { UserFormsStepperKeys } from '../../../../../types/user-forms';
import { useNavigateRequestStepper } from './use-navigate-request-steppers.hook';
import { User, UserAccessRequestArgs } from '../../../../../types/user';
import { RequestError } from '../../../../../types/errors/errors';

type ReviewDetailsFormData = {
  isPoliceCheckCompleted: boolean;
  policeCheckCompletionDate?: string;
  policeCheckProof: Upload[];
  isFoipTrainingCompleted: boolean;
  foipTrainingCompletionDate?: string;
  foipTrainingProof: Upload[];
  reviewer: string;
};

export type ReviewDetailsFieldNames =
  | 'isPoliceCheckCompleted'
  | 'policeCheckCompletionDate'
  | 'policeCheckProof'
  | 'isFoipTrainingCompleted'
  | 'foipTrainingCompletionDate'
  | 'foipTrainingProof'
  | 'reviewer';
type SetValueKeys =
  | 'isPoliceCheckCompleted'
  | 'policeCheckCompletionDate'
  | 'isFoipTrainingCompleted'
  | 'foipTrainingCompletionDate'
  | 'reviewer';

const useReviewDetailsForm = () => {
  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<ReviewDetailsFormData>();

  const { id } = useParams();

  const { setActiveStep, goToPreviousStep } = useNavigateRequestStepper();
  const {
    userStore: { familyName, givenName, emailAddress, id: userId },
    userAccessStore: {
      id: userAccessId,
      jobTitle,
      phoneNumber,
      termsAcceptedOn,
      policeRecordCheckCompletedOn,
      foipTrainingCompletedOn,
      policeCheckProof: policeCheckDoc,
      foipTrainingProof: foipTrainingDoc,
      accessRequestReviewedById,
      accessRequestReviewer,
      completeAccessRequest,
      setReviewer,
      fetchFiles,
      updateAccessRequest,
      getUserAccessRequest,
    },
  } = useStore();
  const navigate = useNavigate();

  const [reviewerUserId, setReviewerUserId] = useState<string>();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  const { name: isPoliceCheckCompleted } = register('isPoliceCheckCompleted', {
    required: { value: true, message: 'This field is required' },
  });
  const { name: policeCheckCompletionDate } = register('policeCheckCompletionDate', {
    required: { value: true, message: 'This field is required' },
    validate: validateNotFutureDate,
  });
  const { name: policeCheckProof } = register('policeCheckProof', {
    required: { value: true, message: 'This field is required' },
  });
  const { name: isFoipTrainingCompleted } = register('isFoipTrainingCompleted', {
    required: { value: true, message: 'This field is required' },
  });
  const { name: foipTrainingCompletionDate } = register('foipTrainingCompletionDate', {
    required: { value: true, message: 'This field is required' },
    validate: validateNotFutureDate,
  });
  const { name: foipTrainingProof } = register('foipTrainingProof', {
    required: { value: true, message: 'This field is required' },
  });
  const { name: reviewer } = register('reviewer', {
    required: { value: true, message: 'This field is required' },
  });

  const formFields = {
    isPoliceCheckCompleted,
    policeCheckCompletionDate,
    policeCheckProof,
    isFoipTrainingCompleted,
    foipTrainingCompletionDate,
    foipTrainingProof,
    reviewer,
  };

  const reviewFields = {
    id: userId,
    familyName,
    givenName,
    emailAddress,
    phoneNumber,
    jobTitle,
    termsAcceptedOn,
  };

  useEffect(() => {
    setValue('isPoliceCheckCompleted', !!policeCheckDoc?.length);
    setValue('isFoipTrainingCompleted', !!foipTrainingDoc?.length);

    setReviewerUserId(accessRequestReviewedById);
    setActiveStep(UserFormsStepperKeys.REVIEW);
    if (userAccessId) {
      fetchFiles(userAccessId);
    } else if (id) {
      fetchFiles(id);
      getUserAccessRequest(id);
    }
  }, [
    accessRequestReviewedById,
    accessRequestReviewer,
    fetchFiles,
    foipTrainingCompletedOn,
    foipTrainingDoc?.length,
    getUserAccessRequest,
    id,
    policeCheckDoc?.length,
    policeRecordCheckCompletedOn,
    reset,
    setActiveStep,
    setValue,
    userAccessId,
  ]);

  useEffect(() => {
    if (policeRecordCheckCompletedOn) {
      setValue('policeCheckCompletionDate', new Date(policeRecordCheckCompletedOn)?.toISOString()?.slice(0, 10));
    }
    if (foipTrainingCompletedOn) {
      setValue('foipTrainingCompletionDate', new Date(foipTrainingCompletedOn)?.toISOString()?.slice(0, 10));
    }
    if (accessRequestReviewer) {
      setValue('reviewer', accessRequestReviewer);
    }
  }, [accessRequestReviewer, foipTrainingCompletedOn, policeRecordCheckCompletedOn, setValue]);

  const onChangeHandler = useCallback(
    (key: string, value: string | undefined) => {
      setValue(key as SetValueKeys, value);
    },
    [setValue],
  );

  const setUserField = useCallback(
    (key: string, value: string) => {
      setValue(key as SetValueKeys, value);
    },
    [setValue],
  );

  const onSelectUser = useCallback(
    (_user: User) => {
      setReviewerUserId(_user.id);
      const userFullName = `${_user.givenName} ${_user.familyName}`;
      setValue(reviewer, userFullName);
      setReviewer(_user.id, userFullName);
    },
    [setValue, reviewer, setReviewer],
  );

  const onCheckChangeHandler = useCallback(
    (key: string, value: boolean) => {
      setValue(key as SetValueKeys, value);
    },
    [setValue],
  );

  const previousButtonHandler = useCallback(() => goToPreviousStep(userAccessId!), [goToPreviousStep, userAccessId]);

  const requestSubmitHandler = useCallback(async () => {
    const payload: UserAccessRequestArgs = {
      policeRecordCheckCompletedOn: getValues(policeCheckCompletionDate)
        ? new Date(getValues(policeCheckCompletionDate)!)
        : undefined,
      foipTrainingCompletedOn: getValues(foipTrainingCompletionDate)
        ? new Date(getValues(foipTrainingCompletionDate)!)
        : undefined,
      accessRequestReviewedById: reviewerUserId,
      policeFileRecordId: policeCheckDoc![0].id,
      foipFileRecordId: foipTrainingDoc![0].id,
    };
    setLoading(true);
    try {
      await updateAccessRequest(payload);
      await completeAccessRequest();
      navigate(`/user/access/request-submitted/${id}`);
    } catch {
      setRequestError({
        isUserError: true,
        message:
          'An error occurred while submitting the form. Please try again or contact support if the issue persists.',
        onDismiss: () => setRequestError({}),
      });
    } finally {
      setLoading(false);
    }
  }, [
    getValues,
    policeCheckCompletionDate,
    foipTrainingCompletionDate,
    reviewerUserId,
    policeCheckDoc,
    foipTrainingDoc,
    updateAccessRequest,
    completeAccessRequest,
    navigate,
    id,
  ]);

  return {
    formFields,
    getValues,
    setValue,
    onChangeHandler,
    onCheckChangeHandler,
    onSelectUser,
    setUserField,
    handleSubmit,
    watch,
    errors,
    previousButtonHandler,
    requestSubmitHandler,
    reviewFields,
    loading,
    requestError,
  };
};

export default useReviewDetailsForm;
