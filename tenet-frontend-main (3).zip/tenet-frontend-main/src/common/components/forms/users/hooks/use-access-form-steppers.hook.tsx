import { useCallback, useMemo } from 'react';
import { GoAIcon } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';

import { useStore } from '../../../../../hooks/use-store.hook';
import { UserFormsStepperKeys, userFormsStepperPaths, userFormsStepperTitles } from '../../../../../types/user-forms';
import { TabsTextState } from '../../../../../types/client-forms';
import { Stepper } from '../../stepper';

const useAccessFormSteppers = () => {
  const {
    authStore: { isAuthenticated },
    userAccessFormsStepperStore: { steppers, active },
    userAccessStore: { id: userAccessId },
  } = useStore();
  const { userDetails, requestDetails, review } = steppers;
  const navigate = useNavigate();

  const clickHandler = useCallback(
    (key: UserFormsStepperKeys, path: string) => () => {
      const updatedPath = userAccessId ? path.replace(':id?', userAccessId!) : path;

      if (userAccessId) {
        active(key);
        navigate(updatedPath);
      }
    },
    [active, navigate, userAccessId],
  );

  const getTabIcon = useCallback((tabState: TabsTextState) => {
    if (tabState === TabsTextState.ACTIVE) {
      return <GoAIcon type="pencil" theme="filled" size="small" />;
    }

    if (tabState === TabsTextState.DONE) {
      return <GoAIcon type="checkmark" theme="filled" size="small" />;
    }

    return '';
  }, []);

  const steppersProps = useMemo(
    () => [
      {
        text: userFormsStepperTitles.userDetails,
        icon: getTabIcon(userDetails.tabText),
        clickHandler: clickHandler(UserFormsStepperKeys.USER_DETAILS, userFormsStepperPaths.userDetails),
        className: '',
        tabClassName: userDetails.tab,
        textClassName: userDetails.tabText,
      },
      {
        text: userFormsStepperTitles.requestDetails,
        icon: getTabIcon(requestDetails.tabText),
        clickHandler: clickHandler(UserFormsStepperKeys.REQUEST_DETAILS, userFormsStepperPaths.requestDetails),
        className: '',
        tabClassName: requestDetails.tab,
        textClassName: requestDetails.tabText,
      },
      {
        text: userFormsStepperTitles.review,
        icon: getTabIcon(review.tabText),
        clickHandler: clickHandler(UserFormsStepperKeys.REVIEW, userFormsStepperPaths.review),
        className: '',
        tabClassName: review.tab,
        textClassName: review.tabText,
      },
    ],
    [
      getTabIcon,
      userDetails.tabText,
      userDetails.tab,
      clickHandler,
      requestDetails.tabText,
      requestDetails.tab,
      review.tabText,
      review.tab,
    ],
  );

  return useMemo(() => {
    if (isAuthenticated) {
      return steppersProps.map((val) => (
        <Stepper
          key={val.text}
          text={val.text}
          icon={val.icon}
          clickHandler={val.clickHandler}
          className={val.className}
          tabClassName={val.tabClassName}
          textClassName={val.textClassName}
        />
      ));
    }

    return '';
  }, [isAuthenticated, steppersProps]);
};

export default useAccessFormSteppers;
