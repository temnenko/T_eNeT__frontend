/* eslint-disable no-console */
import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { useStore } from '../../../../../hooks/use-store.hook';
import { UserAccessRequestArgs } from '../../../../../types/user';
import { useNavigateRequestStepper } from './use-navigate-request-steppers.hook';
import { UserFormsStepperKeys } from '../../../../../types/user-forms';
import { RequestError } from '../../../../../types/errors/errors';

type FormFieldName = 'firstName' | 'lastName' | 'emailAddress' | 'phoneNumber' | 'jobTitle';

type AccessRequestData = {
  firstName: string;
  lastName: string;
  emailAddress: string;
  jobTitle: string;
  phoneNumber: string;
};
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const useSubmitAccessRequest = () => {
  const [requestError, setRequestError] = useState<RequestError>({});
  const {
    userStore: { familyName, givenName, emailAddress: email, id },
    userAccessStore: {
      getUserAccessRequest,
      updateAccessRequest,
      phoneNumber: requestPhoneNumber,
      jobTitle: requestJobTitle,
    },
  } = useStore();
  const { goToNextStep, setActiveStep } = useNavigateRequestStepper();

  const requestErrorHandler = useRequestErrorHandler();

  const {
    getValues,
    handleSubmit,
    register,
    reset,
    setValue,
    formState: { errors },
    watch,
  } = useForm<AccessRequestData>();

  useEffect(() => {
    setActiveStep(UserFormsStepperKeys.USER_DETAILS);
    getUserAccessRequest(id);
    reset({
      firstName: givenName,
      lastName: familyName,
      emailAddress: email,
      phoneNumber: requestPhoneNumber,
      jobTitle: requestJobTitle,
    });
  }, [
    email,
    familyName,
    getUserAccessRequest,
    givenName,
    id,
    requestJobTitle,
    requestPhoneNumber,
    reset,
    setActiveStep,
  ]);

  const [loading, setLoading] = useState(false);

  const { name: firstName } = register('firstName', {
    required: { value: true, message: 'First name is required!' },
  });

  const { name: lastName } = register('lastName', {
    required: { value: true, message: 'Last name is required!' },
  });

  const { name: phoneNumber } = register('phoneNumber', {
    validate: (value) => {
      if (!value) return true; // allow blank
      const pattern = /^\(?\d{3}\)?([\s])?\d{3}([-])?\d{4}$/;
      return pattern.test(value) || 'Invalid Canadian phone number';
    },
  });

  const { name: jobTitle } = register('jobTitle', {
    required: { value: true, message: 'Job title is required!' },
  });

  const { name: emailAddress } = register('emailAddress', {
    required: { value: true, message: 'Email address is required!' },
    pattern: { value: /^\S+@\S+\.\S+$/, message: 'Invalid email address' },
  });

  const formsFields = {
    firstName,
    lastName,
    emailAddress,
    jobTitle,
    phoneNumber,
  };

  const accessSubmitHandler = useCallback(async () => {
    const continueSave = async () => {
      try {
        setLoading(true);
        const request: UserAccessRequestArgs = {
          jobTitle: getValues('jobTitle'),
          phoneNumber: getValues('phoneNumber'),
        };
        await updateAccessRequest(request);
        goToNextStep(id);
        // navigate(`/user/${id}/access-request-review`);

        reset();
      } catch (e) {
        console.log(e);
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    };
    continueSave();
  }, [getValues, goToNextStep, id, requestErrorHandler, reset, updateAccessRequest]);

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value);
    },
    [setValue],
  );

  return {
    loading,
    accessSubmitHandler,
    handleSubmit,
    errors,
    getValues,
    onChangeHandler,
    requestError,
    formsFields,
    watch,
  };
};

export default useSubmitAccessRequest;
