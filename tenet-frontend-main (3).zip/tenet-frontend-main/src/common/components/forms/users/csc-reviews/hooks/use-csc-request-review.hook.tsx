/* eslint-disable no-console */
import { useCallback, useState, useEffect } from 'react';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { fileService } from '../../../../../../services/clients/client-files.service';
// eslint-disable-next-line @typescript-eslint/no-unused-vars

const useSubmitCSCAccessRequestReview = (hideModal?: () => void) => {
  const [requestError, setRequestError] = useState<RequestError>({});
  const {
    userStore: { reviewAccessRequest, selectedUser, givenName, familyName },
    userAccessStore: { fetchFiles, getUserAccessRequest },
    usersListStore: { getUsers },
  } = useStore();

  const [loading, setLoading] = useState(false);

  const requestErrorHandler = useRequestErrorHandler();

  const files = {
    data: [
      {
        filename: '',
        dateAdded: new Date().toLocaleDateString(),
        filetype: '',
      },
    ],
  };

  useEffect(() => {
    const fetchData = async () => {
      if (selectedUser?.id) {
        await fetchFiles(selectedUser.id);
        await getUserAccessRequest(selectedUser.id);
      }
    };

    fetchData();
  }, [fetchFiles, getUserAccessRequest, selectedUser?.id]);

  const accessRequestReviewSubmitHandler = useCallback(
    async (decision: boolean) => {
      const continueSave = async () => {
        try {
          setLoading(true);
          if (selectedUser?.id) {
            await reviewAccessRequest(decision, selectedUser.id);
            hideModal!();
            await getUsers(selectedUser?.organization?.id);
          }
        } catch (e) {
          console.log(e);
          requestErrorHandler({
            error: e,
            setError: setRequestError,
          });
        } finally {
          setLoading(false);
        }
      };
      continueSave();
    },
    [getUsers, hideModal, requestErrorHandler, reviewAccessRequest, selectedUser?.id, selectedUser?.organization?.id],
  );

  const downloadFile = useCallback(
    (adspId: string, filename: string, filesize: number) => {
      try {
        setLoading(true);
        fileService.downloadFileByAdspId(adspId, filename, filesize);
      } catch (error) {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    },
    [requestErrorHandler],
  );

  return {
    loading,
    accessRequestReviewSubmitHandler,
    files,
    requestError,
    selectedUser,
    givenName,
    familyName,
    downloadFile,
  };
};

export default useSubmitCSCAccessRequestReview;
