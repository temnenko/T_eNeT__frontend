/* eslint-disable react/no-array-index-key */
import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoACheckbox,
  GoAContainer,
  GoAGrid,
  GoAModal,
  GoANotification,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import useSubmitCSCAccessRequestReview from './hooks/use-csc-request-review.hook';
import { AccessReviewFilesList } from '../review-files-list';

interface Props {
  hideModal?: () => void;
}

const CSCUserAccessRequestReview = observer(({ hideModal }: Props) => {
  const { loading, requestError, accessRequestReviewSubmitHandler, selectedUser, givenName, familyName, downloadFile } =
    useSubmitCSCAccessRequestReview(hideModal);

  return (
    <GoAModal maxWidth="1000px" open width="88px" transition="slow" heading="User access request" onClose={hideModal}>
      <GoAGrid gap="xl" minChildWidth="754px">
        <GoAContainer heading="User details" accent="thick" padding="relaxed">
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">First name</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{selectedUser?.givenName}</span>
            </div>
          </GoABlock>
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">Last name</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{selectedUser?.familyName}</span>
            </div>
          </GoABlock>
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">Role</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{selectedUser?.jobTitle}</span>
            </div>
          </GoABlock>
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">Email</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{selectedUser?.emailAddress}</span>
            </div>
          </GoABlock>
          <GoABlock gap="none">
            <div className="client-review-card-label">
              <span className="color-interactive">Phone number</span>
            </div>
            <div className="client-review-card-value">
              <span className="client-bold-600">{selectedUser?.phoneNumber}</span>
            </div>
          </GoABlock>
        </GoAContainer>
        <AccessReviewFilesList cscName={`${givenName} ${familyName}`} downloadFile={downloadFile} />
        <div className="access-request-review-consent">
          <h3>Consent</h3>
          <GoABlock direction="column">
            <span className="font-smaller">I understand and agree to the following:</span>
            <GoASpacer vSpacing="s" />
            <GoACheckbox name="purpose" checked disabled>
              I shall access and use TENET only for the purpose for which it was granted, and
            </GoACheckbox>
            <GoASpacer vSpacing="s" />
            <GoACheckbox name="safeguard" checked disabled>
              I shall safeguard my username and password, taking all reasonable and necessary measures to prevent the
              loss, disclosure, modification and unauthorized use of username and password, and immediately advise my
              manager/supervisor of any suspected compromise, and
            </GoACheckbox>
            <GoASpacer vSpacing="s" />
            <GoACheckbox name="immediateReport" checked disabled>
              I shall immediately report any criminal charges to my supervisor or designated personnel identified by the
              company.
            </GoACheckbox>
            <GoASpacer vSpacing="s" />
            <GoACheckbox name="willDisable" checked disabled>
              I agree that the my access to TENET will be disabled when I am no longer employed in my organization or no
              longer need access to TENET to conduct my job duties.
            </GoACheckbox>
          </GoABlock>
        </div>
        {requestError?.message && (
          <>
            <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
              {requestError.message}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
        <div className="organization-form-buttons">
          <GoAButtonGroup alignment="start">
            <GoAButton type="primary" onClick={() => accessRequestReviewSubmitHandler(true)} disabled={false}>
              {loading ? (
                <InlineLoadingIndicator label="Saving changes..." />
              ) : (
                <span className="client-bold-600">Approve</span>
              )}
            </GoAButton>
            <GoAButton type="secondary" onClick={() => accessRequestReviewSubmitHandler(false)}>
              Decline
            </GoAButton>
          </GoAButtonGroup>
        </div>
      </GoAGrid>
    </GoAModal>
  );
});

export default CSCUserAccessRequestReview;
