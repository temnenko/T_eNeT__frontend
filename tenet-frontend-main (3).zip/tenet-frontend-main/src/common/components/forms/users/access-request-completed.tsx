import { GoABlock, GoAButton, GoAIcon, GoASpacer } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';

export default function AccessRequestSubmissionCompleted() {
  const navigate = useNavigate();

  return (
    <GoABlock direction="column" gap="2xs" alignment="center">
      <span className="access-request-submit-line" />
      <GoASpacer vSpacing="2xl" />
      <span className="circle-175">
        <GoAIcon type="paper-plane" size="xlarge" />
      </span>
      <GoASpacer vSpacing="xl" />
      <center>
        Your user access request has been submitted successfully. Once it’s reviewed, you will receive an email.
      </center>
      <GoASpacer vSpacing="2xl" />
      <GoAButton size="compact" onClick={() => navigate(`/dashboard`)} leadingIcon="home">
        Go back to Home
      </GoAButton>
      <GoASpacer vSpacing="2xl" />
    </GoABlock>
  );
}
