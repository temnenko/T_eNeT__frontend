/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import { GoABlock, GoAContainer, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { ReactNode } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { formatIsoDateUTC } from '../../../../utils/date.util';

interface EditAction {
  action?: ReactNode;
  cscName?: string;
  downloadFile?: (adspId: string, filename: string, filesize: number) => void;
}

export const AccessReviewFilesList = observer(({ action, cscName, downloadFile }: EditAction) => {
  const {
    userAccessStore: {
      policeRecordCheckCompletedOn,
      foipTrainingCompletedOn,
      policeCheckProof,
      foipTrainingProof,
      accessRequestReviewer,
    },
  } = useStore();

  return (
    <GoAContainer heading="Request detail" accent="thick" actions={action} padding="compact">
      <GoABlock direction="column">
        <GoABlock>
          <div className="client-review-card-label">
            <span className="color-interactive">Police Information Check</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">{policeRecordCheckCompletedOn ? 'Yes' : 'No'}</span>
          </div>
        </GoABlock>
        <GoABlock>
          <div className="client-review-card-label">
            <span className="color-interactive">Completion date</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">
              {policeRecordCheckCompletedOn ? formatIsoDateUTC(policeRecordCheckCompletedOn) : ''}
            </span>
          </div>
        </GoABlock>
        <GoABlock>
          <div className="client-review-card-label">
            {policeCheckProof?.length ? (
              <span
                className="client-document-span"
                onClick={() => {
                  if (policeCheckProof?.length) {
                    downloadFile!(
                      policeCheckProof[0]?.adspId,
                      policeCheckProof[0]?.file.name,
                      policeCheckProof[0]?.file.size,
                    );
                  }
                }}
              >
                {policeCheckProof[0]?.file?.name}
              </span>
            ) : (
              ''
            )}
          </div>
          <div className="client-review-card-value">
            <span>{policeRecordCheckCompletedOn ? formatIsoDateUTC(policeRecordCheckCompletedOn) : ''}</span>
          </div>
        </GoABlock>
      </GoABlock>
      <GoASpacer vSpacing="xl" />
      <GoABlock direction="column">
        <GoABlock>
          <div className="client-review-card-label">
            <span className="color-interactive">FOIP training</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">{foipTrainingCompletedOn ? 'Yes' : 'No'}</span>
          </div>
        </GoABlock>
        <GoABlock>
          <div className="client-review-card-label">
            <span className="color-interactive">Completion date</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">
              {foipTrainingCompletedOn ? formatIsoDateUTC(foipTrainingCompletedOn) : ''}
            </span>
          </div>
        </GoABlock>
        <GoABlock>
          <div className="client-review-card-label">
            {foipTrainingProof?.length ? (
              <span
                className="client-document-span"
                onClick={() => {
                  if (foipTrainingProof?.length) {
                    downloadFile!(
                      foipTrainingProof[0]?.adspId,
                      foipTrainingProof[0]?.file.name,
                      foipTrainingProof[0]?.file.size,
                    );
                  }
                }}
              >
                {foipTrainingProof[0]?.file?.name}
              </span>
            ) : (
              ''
            )}
          </div>
          <div className="client-review-card-value">
            <span>{foipTrainingCompletedOn ? formatIsoDateUTC(foipTrainingCompletedOn) : ''}</span>
          </div>
        </GoABlock>
      </GoABlock>
      <GoASpacer vSpacing="xl" />
      <GoABlock>
        <div className="client-review-card-label">
          <span className="color-interactive">CSC to review</span>
        </div>
        <div className="client-review-card-value">
          <span className="client-bold-600">{accessRequestReviewer ?? cscName}</span>
        </div>
      </GoABlock>
      <GoASpacer vSpacing="l" />
    </GoAContainer>
  );
});
