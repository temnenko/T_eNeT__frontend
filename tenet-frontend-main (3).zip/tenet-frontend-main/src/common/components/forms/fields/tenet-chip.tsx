import { GoABlock, GoAIconButton } from '@abgov/react-components';

type Props = {
  content: string;
  onRemoveHandler: () => void;
  onEditHandler: (() => void) | undefined;
  editable: boolean | undefined;
};

export function TenetChip({ content, onRemoveHandler, onEditHandler, editable = false }: Props) {
  return (
    <span className="tenet-chip">
      <GoABlock gap="2" alignment="center">
        <span>{content}</span>
        {editable && !!onEditHandler && (
          <GoAIconButton icon="pencil" variant="dark" size="small" onClick={onEditHandler} />
        )}
        <GoAIconButton icon="close-circle" variant="dark" size="small" onClick={onRemoveHandler} />
      </GoABlock>
    </span>
  );
}
