import { GoABlock, GoAFormItem, GoAGrid, GoAInput } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { FieldErrors } from 'react-hook-form';
import AutocompleteInput from '../../auto-complete-input';
import { CanadaPostAddressFullAddress } from '../../../../services/canada-post.service';
import { AddressType } from '../../../../types/client';
import { toIsoFormat } from '../../../../utils/date.util';

export type AddressOnChangeHandler = (name: string, value: string | undefined) => void;

type AddressFieldProps = {
  fields: {
    streetAddress: string;
    unit: string;
    city: string;
    province: string;
    postalCode: string;
    country: string;
    addressEffectiveBy?: string;
    addressType: AddressType;
  };
  onChangeHandler: AddressOnChangeHandler;
  onBlurHandler: (name: string, value: string) => void;
  getValues: (name: string) => string;
  errors: FieldErrors;
  onSelectAddress: (addressData: CanadaPostAddressFullAddress, addressType: AddressType) => void;
  setAddressStreetField: (name: string, value: string) => void;
};

export const AddressFields = observer(
  ({
    fields,
    onChangeHandler,
    onBlurHandler,
    getValues,
    errors,
    onSelectAddress,
    setAddressStreetField,
  }: AddressFieldProps) => {
    const { streetAddress, unit, city, province, postalCode, country, addressEffectiveBy, addressType } = fields;

    const addressEffectiveByDate = getValues(addressEffectiveBy!) ? getValues(addressEffectiveBy!) : undefined;

    return (
      <GoABlock direction="column">
        <GoAFormItem label="Street address" error={errors[streetAddress]?.message as unknown as string}>
          <AutocompleteInput
            name={streetAddress}
            id={streetAddress}
            placeholder="Enter street address"
            width="100%"
            onSelectAddress={onSelectAddress}
            onSelectUser={undefined}
            value={getValues(streetAddress)}
            subType={addressType}
            setField={setAddressStreetField}
          />
        </GoAFormItem>
        <GoAFormItem label="Unit" requirement="optional">
          <GoAInput
            type="text"
            onChange={onChangeHandler}
            name={unit}
            id={unit}
            value={getValues(unit)}
            width="167px"
          />
        </GoAFormItem>
        <GoAGrid minChildWidth="10rem">
          <GoAFormItem label="City/Town" error={errors[city]?.message as unknown as string}>
            <GoAInput
              type="text"
              onChange={onChangeHandler}
              onBlur={onBlurHandler}
              name={city}
              id={city}
              value={getValues(city)}
              width="10rem"
            />
          </GoAFormItem>
          <GoAFormItem label="Province" error={errors[province]?.message as unknown as string}>
            <GoAInput
              type="text"
              onChange={onChangeHandler}
              onBlur={onBlurHandler}
              name={province}
              id={province}
              value={getValues(province)}
              width="10rem"
            />
          </GoAFormItem>
          <GoAFormItem label="Postal/ZIP Code" error={errors[postalCode]?.message as unknown as string}>
            <GoAInput
              type="text"
              onChange={onChangeHandler}
              onBlur={onBlurHandler}
              name={postalCode}
              id={postalCode}
              value={getValues(postalCode)}
              width="10rem"
            />
          </GoAFormItem>
          <GoAFormItem label="Country" error={errors[country]?.message as unknown as string}>
            <GoAInput
              type="text"
              onChange={onChangeHandler}
              onBlur={onBlurHandler}
              name={country}
              id={country}
              value={getValues(country)}
              width="10rem"
            />
          </GoAFormItem>
        </GoAGrid>
        {addressEffectiveBy && (
          <GoAFormItem label="Address effective by" error={errors[addressEffectiveBy]?.message as unknown as string}>
            <GoAInput
              type="date"
              onChange={onChangeHandler}
              name={addressEffectiveBy}
              value={addressEffectiveByDate ? toIsoFormat(addressEffectiveByDate) : undefined}
              min="0000-01-01"
              max="9999-12-31"
            />
          </GoAFormItem>
        )}
      </GoABlock>
    );
  },
);
