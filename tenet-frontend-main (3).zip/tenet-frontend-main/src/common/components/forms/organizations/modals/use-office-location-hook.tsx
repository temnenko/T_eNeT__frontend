/* eslint-disable no-plusplus */
import { ReactNode, useCallback, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { GoAButton, GoAModal } from '@abgov/react-components';
import { useStore } from '../../../../../hooks/use-store.hook';
import { Location } from '../../../../../types/organization';
import { ConfirmationModal } from '../../../modals/confirmation.modal';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../types/errors/errors';
import { CanadaPostAddressFullAddress } from '../../../../../services/canada-post.service';
import { AddressType } from '../../../../../types/client';

type LocationFormData = {
  street: string;
  city: string;
  province: string;
  postalCode: string;
  countryCode: string;
  phoneNumber: string;
  email: string;
  locationName?: string;
  unit?: string;
  isPrimaryLocation?: boolean;
};

type FormFieldName =
  | 'locationName'
  | 'street'
  | 'city'
  | 'province'
  | 'postalCode'
  | 'countryCode'
  | 'phoneNumber'
  | 'email'
  | 'unit'
  | 'isPrimaryLocation';

const useOfficeLocationForm = (hideModal: () => void, selectedLocation?: Location) => {
  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    formState: { errors },
    reset,
    watch,
  } = useForm<LocationFormData>();

  const [loading, setLoading] = useState<boolean>(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);
  const [primaryLocation, setPrimaryLocation] = useState(false);

  const {
    organizationStore: { setOfficeLocation, selectedOrganization, updateOfficeLocation },
    agreementStore: { selectedAgreement, getAgreementById },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();

  const { name: locationName } = register(`locationName`, {
    required: { value: true, message: 'Location name is required.' },
    pattern: { value: /^[^-\s].*$/, message: 'Name cannot begin with a space' },
    min: 3,
  });
  const { name: street } = register('street', {
    required: { value: true, message: 'Address is required.' },
    min: 3,
  });
  const { name: city } = register('city', {
    required: { value: true, message: 'City is required.' },
    min: 3,
  });
  const { name: province } = register('province');
  const { name: postalCode } = register('postalCode', {
    required: { value: true, message: 'Postal code is required.' },
    min: 3,
  });
  const { name: countryCode } = register('countryCode');
  const { name: phoneNumber } = register('phoneNumber', {
    min: 3,
  });
  const { name: email } = register('email', {
    pattern: {
      value: /^[^\s@<>&]+@[^\s@<>&]+\.[^\s@<>&]+$/,
      message: 'The Email Address does not conform to the email address format standards',
    },
  });

  const { name: isPrimaryLocation } = register('isPrimaryLocation');

  const { name: unit } = register('unit');

  const formFields = {
    locationName,
    street,
    city,
    province,
    postalCode,
    countryCode,
    phoneNumber,
    email,
    unit,
    isPrimaryLocation,
    addressType: AddressType.NONE,
  };

  const loadLocation = useCallback(() => {
    if (selectedLocation && !getValues(street)) {
      reset({
        street: selectedLocation.street,
        unit: selectedLocation.unit,
        city: selectedLocation.city,
        postalCode: selectedLocation.postalCode,
        locationName: selectedLocation.name,
        province: selectedLocation.province,
        countryCode: selectedLocation.countryCode,
        email: selectedLocation.email,
        isPrimaryLocation: selectedLocation.isPrimaryLocation,
        phoneNumber: selectedLocation.phoneNumber,
      });
      setPrimaryLocation(selectedLocation.isPrimaryLocation ?? false);
    }
  }, [getValues, reset, selectedLocation, street]);

  const setLocation = useCallback(async () => {
    try {
      const office = {
        name: getValues('locationName'),
        street: getValues('street'),
        unit: getValues('unit'),
        city: getValues('city'),
        province: getValues('province') ?? 'AB',
        postalCode: getValues('postalCode'),
        countryCode: getValues('countryCode') ?? 'CA',
        phoneNumber: getValues('phoneNumber')?.replace(/\D/g, '')?.trim(),
        email: getValues('email')?.trim()?.toLowerCase(),
        isPrimaryLocation: primaryLocation,
      };
      if (selectedLocation?.id) {
        await updateOfficeLocation(selectedLocation!.id, office, selectedOrganization!.id);
        reset();
      } else {
        await setOfficeLocation(selectedOrganization!.id, office);
      }
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      if (selectedAgreement) {
        await getAgreementById(selectedAgreement.id);
      }
    }
  }, [
    getAgreementById,
    getValues,
    primaryLocation,
    requestErrorHandler,
    reset,
    selectedAgreement,
    selectedLocation,
    selectedOrganization,
    setOfficeLocation,
    updateOfficeLocation,
  ]);

  const confirmationText = useMemo(
    () =>
      selectedLocation
        ? 'Are you sure you want to apply the changes to this location?'
        : 'Are you sure you want to add this location to the selected organization?',
    [selectedLocation],
  );

  const addLocationHandler = useCallback(async () => {
    try {
      setLoading(true);
      const loc = selectedOrganization?.locations?.find((f) => f.isPrimaryLocation);
      if (loc?.isPrimaryLocation && primaryLocation && loc.id !== selectedLocation?.id) {
        setModalVisible(true);
        setModalContent(
          <GoAModal heading="Headquarters exists" maxWidth="md" open>
            <p>Organization headquarters already exists!</p>
            <GoAButton type="secondary" onClick={() => setModalVisible(false)} variant="normal">
              Go back
            </GoAButton>
          </GoAModal>,
        );
      } else {
        setModalVisible(true);
        setModalContent(
          <ConfirmationModal
            onConfirm={async () => {
              await setLocation();
              setModalVisible(false);
              hideModal();
            }}
            onDecline={() => setModalVisible(false)}
            heading="Add location"
            description={confirmationText}
            loading={loading}
            confirmText="Add"
            declineText="No, go back"
            isDelete={false}
          />,
        );
      }
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
    }
  }, [
    confirmationText,
    hideModal,
    loading,
    primaryLocation,
    selectedLocation?.id,
    selectedOrganization?.locations,
    setLocation,
  ]);

  const onChangeHandler = useCallback(
    (key: string, value: string | Date | undefined) => {
      const processedValue = typeof value === 'string' ? value.trim() : '';
      setValue(key as FormFieldName, processedValue ?? value);
    },
    [setValue],
  );

  const onCheckChangeHandler = useCallback(
    (key: string, value: string | boolean | undefined) => {
      if (key === isPrimaryLocation && typeof value === 'boolean') {
        setPrimaryLocation(value);
      }
    },
    [isPrimaryLocation],
  );

  const onBlurHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value.trim(), { shouldValidate: true });
    },
    [setValue],
  );

  const setSearchableField = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value);
    },
    [setValue],
  );

  const onSelectAddress = useCallback(
    (addressData: CanadaPostAddressFullAddress) => {
      const addressValue =
        !addressData.BuildingNumber || !addressData.Street
          ? addressData.Line1
          : `${addressData.BuildingNumber} ${addressData.Street}`;

      setValue(street, addressValue, {
        shouldValidate: true,
      });
      setValue(unit, addressData.SubBuilding, { shouldValidate: true });
      setValue(city, addressData.City, { shouldValidate: true });
      setValue(province, addressData.Province, { shouldValidate: true });
      setValue(postalCode, addressData.PostalCode, { shouldValidate: true });
      setValue(countryCode, addressData.CountryName, { shouldValidate: true });
    },
    [city, countryCode, postalCode, province, setValue, street, unit],
  );

  return {
    formFields,
    getValues,
    addLocationHandler,
    onChangeHandler,
    onCheckChangeHandler,
    onBlurHandler,
    onSelectAddress,
    handleSubmit,
    errors,
    loading,
    primaryLocation,
    requestError,
    modalContent,
    modalVisible,
    setSearchableField,
    loadLocation,
    watch,
  };
};

export default useOfficeLocationForm;
