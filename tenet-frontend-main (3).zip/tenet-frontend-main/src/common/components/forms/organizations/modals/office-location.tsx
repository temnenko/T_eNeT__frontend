import { observer } from 'mobx-react-lite';
import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoACheckbox,
  GoAFormItem,
  GoAInput,
  GoAModal,
  GoANotification,
  GoASpacer,
} from '@abgov/react-components';
import useOfficeLocationForm from './use-office-location-hook';
import { Location } from '../../../../../types/organization';
import { AddressFields } from '../../fields/address-fields';
import { useFormatPhoneInput } from '../../../../../hooks/use-format-phone-input.hook';

interface Props {
  hideModal: () => void;
  selectedLocation?: Location;
  hideHeadquarterField?: boolean;
}

export const OfficeLocation = observer(({ hideModal, selectedLocation, hideHeadquarterField }: Props) => {
  const {
    formFields,
    getValues,
    errors,
    watch,
    onChangeHandler,
    onCheckChangeHandler,
    onBlurHandler,
    onSelectAddress,
    setSearchableField,
    addLocationHandler,
    handleSubmit,
    primaryLocation,
    requestError,
    modalContent,
    modalVisible,
    loadLocation,
  } = useOfficeLocationForm(hideModal, selectedLocation);
  loadLocation();
  const {
    locationName,
    street,
    unit,
    city,
    postalCode,
    phoneNumber,
    email,
    isPrimaryLocation,
    province,
    addressType,
    countryCode,
  } = formFields;
  const formatPhone = useFormatPhoneInput();

  return (
    <GoAModal maxWidth="1000px" open width="88px" transition="slow" heading="Add a location" onClose={hideModal}>
      {modalVisible && modalContent}
      <form>
        <GoABlock direction="column">
          <GoAFormItem label="Location name" error={errors[locationName]?.message as unknown as string}>
            <GoAInput
              type="text"
              onChange={onChangeHandler}
              name={locationName}
              id={locationName}
              value={getValues(locationName)}
              width="600px"
            />
          </GoAFormItem>
          {!hideHeadquarterField && (
            <>
              <GoASpacer vSpacing="xs" />
              <GoACheckbox
                name={isPrimaryLocation}
                text="This is the headquarter."
                onChange={onCheckChangeHandler}
                checked={primaryLocation}
                value={getValues(isPrimaryLocation)}
              />
            </>
          )}
        </GoABlock>
        <GoASpacer vSpacing="m" />
        <AddressFields
          fields={{
            streetAddress: street,
            unit,
            city,
            province,
            postalCode,
            country: countryCode,
            addressType,
          }}
          onChangeHandler={onChangeHandler}
          getValues={watch}
          errors={errors}
          onBlurHandler={onBlurHandler}
          onSelectAddress={onSelectAddress}
          setAddressStreetField={setSearchableField}
        />
        <GoASpacer vSpacing="m" />
        <GoAFormItem
          label="Phone number"
          error={errors[phoneNumber]?.message as unknown as string}
          requirement="optional"
        >
          <GoAInput
            leadingContent="+1"
            type="tel"
            onChange={onChangeHandler}
            name={phoneNumber}
            id={phoneNumber}
            value={formatPhone(getValues(phoneNumber))}
            width="244px"
          />
        </GoAFormItem>
        <GoASpacer vSpacing="m" />
        <GoAFormItem label="Email" requirement="optional">
          <GoAInput
            type="email"
            onChange={onChangeHandler}
            name={email}
            id={email}
            value={getValues(email)}
            width="397px"
          />
        </GoAFormItem>
        <GoASpacer vSpacing="2xl" />
        {requestError?.message && (
          <>
            <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
              {requestError.message}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
        <GoASpacer vSpacing="2xl" />
        <div>
          <GoAButtonGroup alignment="start">
            <GoAButton type="primary" onClick={handleSubmit(addLocationHandler)}>
              <span>Save</span>
            </GoAButton>
            <GoAButton type="secondary" onClick={hideModal}>
              <span>Cancel</span>
            </GoAButton>
          </GoAButtonGroup>
        </div>
      </form>
    </GoAModal>
  );
});
