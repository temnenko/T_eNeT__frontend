import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { OrganizationFormStepperKeys, organizationFormStepperPaths } from '../../../../../../types/organization-forms';

export const useNavigateOrganizationStepper = () => {
  const navigate = useNavigate();
  const { organizationFormStepperStore } = useStore();

  const setActiveStep = useCallback(
    (stepKey: OrganizationFormStepperKeys) => {
      organizationFormStepperStore.setActiveStep(stepKey);
    },
    [organizationFormStepperStore],
  );

  const goToNextStep = useCallback(
    (organizationId: string) => {
      const nextStepKey = organizationFormStepperStore.next();
      if (nextStepKey) {
        let nextStepPath = organizationFormStepperPaths[nextStepKey];
        nextStepPath = nextStepPath.replace(':id?', organizationId);
        navigate(nextStepPath);
      }
    },
    [organizationFormStepperStore, navigate],
  );

  const goToPreviousStep = useCallback(
    (organizationId: string) => {
      const previousStepKey = organizationFormStepperStore.previous();
      if (previousStepKey) {
        let previousStepPath = organizationFormStepperPaths[previousStepKey];
        previousStepPath = previousStepPath.replace(':id?', organizationId);
        navigate(previousStepPath);
      }
    },
    [organizationFormStepperStore, navigate],
  );

  const jumpToStep = useCallback(
    (stepKey: OrganizationFormStepperKeys, organizationId: string) => {
      let stepPath = organizationFormStepperPaths[stepKey];
      stepPath = stepPath.replace(':id?', organizationId);
      navigate(stepPath);
    },
    [navigate],
  );

  return { goToNextStep, goToPreviousStep, setActiveStep, jumpToStep };
};
