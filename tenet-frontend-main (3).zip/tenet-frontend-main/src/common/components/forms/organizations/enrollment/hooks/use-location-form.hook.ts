import { useCallback, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { LocationArgs } from '../../../../../../types/organization';
import { EconomicRegions } from '../../../../../../types/core';

type LocationFormData = {
  street: string;
  city: string;
  province: string;
  postalCode: string;
  countryCode: string;
  phoneNumber?: string;
  email?: string;
  economicRegion?: EconomicRegions;
  locationName?: string;
  unit?: string;
};

type FormFieldName =
  | 'locationName'
  | 'street'
  | 'city'
  | 'province'
  | 'postalCode'
  | 'countryCode'
  | 'phoneNumber'
  | 'email'
  | 'economicRegion'
  | 'unit';

const useLocationForm = (
  location?: LocationArgs,
  primaryLocationError?: string,
  addLocation?: (args: LocationArgs) => void,
  setPrimaryEconomicRegion?: (val: EconomicRegions) => void,
) => {
  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    setError,
    formState: { errors },
    reset,
  } = useForm<LocationFormData>();

  const { name: locationName } = register(`locationName`, {
    required: { value: true, message: 'Location name is required.' },
    pattern: { value: /^[^-\s].*$/, message: 'Name cannot begin with a space' },
    min: 3,
  });
  const { name: street } = register('street', {
    required: { value: true, message: 'Address is required.' },
    min: 3,
  });
  const { name: city } = register('city', {
    required: { value: true, message: 'City is required.' },
    min: 3,
  });
  const { name: province } = register('province', {
    required: { value: true, message: 'Province is required.' },
    min: 3,
  });
  const { name: postalCode } = register('postalCode', {
    required: { value: true, message: 'Postal code is required.' },
    min: 3,
  });
  const { name: countryCode } = register('countryCode', {
    required: { value: true, message: 'Country is required.' },
    min: 3,
  });
  const { name: phoneNumber } = register('phoneNumber', {
    pattern: {
      value: /^\(?\d{3}\)?([\s])?\d{3}([-])?\d{4}$/,
      message: 'Phone number must be valid',
    },
    min: 3,
  });
  const { name: email } = register('email', {
    pattern: { value: /^\S+@\S+\.\S+$/, message: 'Invalid email address' },
    min: 3,
  });
  const { name: economicRegion } = register('economicRegion', {
    required: { value: true, message: 'Economic region is required.' },
    min: 3,
  });
  const { name: unit } = register('unit');

  const formFields = {
    locationName,
    street,
    city,
    province,
    postalCode,
    countryCode,
    phoneNumber,
    email,
    economicRegion,
    unit,
  };

  const loadLocation = useCallback(() => {
    if (location) {
      setValue(locationName, location.name);
      setValue(city, location.city);
      setValue(countryCode, location.countryCode);
      setValue(economicRegion, location?.economicRegion);
      setValue(email, location.email);
      setValue(phoneNumber, location.phoneNumber);
      setValue(postalCode, location.postalCode);
      setValue(province, location.province);
      setValue(street, location.street);
      setValue(unit, location.unit);
    }

    setError(economicRegion, { message: primaryLocationError });
  }, [
    city,
    countryCode,
    economicRegion,
    email,
    location,
    locationName,
    phoneNumber,
    postalCode,
    primaryLocationError,
    province,
    setError,
    setValue,
    street,
    unit,
  ]);

  useEffect(() => {
    loadLocation();
  }, [loadLocation]);

  const addLocationHandler = useCallback(async () => {
    addLocation?.({
      name: getValues('locationName'),
      street: getValues('street'),
      unit: getValues('unit'),
      city: getValues('city'),
      province: getValues('province'),
      postalCode: getValues('postalCode'),
      countryCode: getValues('countryCode'),
      phoneNumber: getValues('phoneNumber'),
      email: getValues('email')?.trim()?.toLowerCase(),
      economicRegion: getValues('economicRegion'),
    });
    reset();
  }, [addLocation, getValues, reset]);

  const onChangeHandler = useCallback(
    (key: string, value: string | undefined) => {
      setValue(key as FormFieldName, value);
    },
    [setValue],
  );

  const onRegionChangeHandler = useCallback(
    (key: string, value: string | string[]) => {
      setValue(key as FormFieldName, value as EconomicRegions);
      setPrimaryEconomicRegion?.(value as EconomicRegions);
    },
    [setPrimaryEconomicRegion, setValue],
  );

  return {
    formFields,
    getValues,
    addLocationHandler,
    onChangeHandler,
    onRegionChangeHandler,
    handleSubmit,
    errors,
  };
};

export default useLocationForm;
