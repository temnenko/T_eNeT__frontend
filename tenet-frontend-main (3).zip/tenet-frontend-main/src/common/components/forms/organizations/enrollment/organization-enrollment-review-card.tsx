import { GoABlock, GoAButton, GoAContainer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

type Props = {
  title: string;
  data: {
    label?: string;
    value?: string;
  }[];
  additionalData?: {
    label?: string;
    value?: string;
  }[];
  editDisabled?: boolean;
};

const OrganizationEnrollmentCard = observer(({ title, data, additionalData = [], editDisabled }: Props) => {
  const actions = (
    <GoAButton type="tertiary" size="compact" onClick={() => {}} disabled={editDisabled}>
      <span style={{ color: 'white' }}>Edit</span>
    </GoAButton>
  );
  return (
    <GoAContainer heading={title} accent="thick" actions={actions} padding="compact">
      <GoABlock direction="column">
        {data &&
          data.map((entry) => {
            if (entry.label === 'Immigrant' && title === 'Factors' && additionalData?.length) {
              return (
                <GoABlock key={entry.label} gap="none">
                  <div className="client-review-card-label">
                    <span className="color-interactive" key={entry.label}>
                      {entry.label}
                    </span>
                  </div>
                  <div className="client-review-card-value">
                    <span className="client-bold-600" key={entry.value}>
                      {entry.value}
                    </span>
                  </div>
                  <div className="client-review-card-label-yol">
                    <span className="color-interactive" key={additionalData[0]?.label}>
                      {additionalData[0]?.label}
                    </span>
                  </div>
                  <div>
                    <span className="client-bold-600" key={additionalData[0]?.value}>
                      {additionalData[0]?.value}
                    </span>
                  </div>
                </GoABlock>
              );
            }
            return (
              <GoABlock key={entry.label} gap="none">
                <div className="client-review-card-label">
                  <span className="color-interactive">{entry.label}</span>
                </div>
                <div className="client-review-card-value">
                  <span className="client-bold-600">{entry.value}</span>
                </div>
              </GoABlock>
            );
          })}
      </GoABlock>
    </GoAContainer>
  );
});

export default OrganizationEnrollmentCard;
