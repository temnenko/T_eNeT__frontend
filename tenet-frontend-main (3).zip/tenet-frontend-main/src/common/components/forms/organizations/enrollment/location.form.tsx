import {
  GoABlock,
  GoAButton,
  GoADropdown,
  GoADropdownItem,
  GoAFormItem,
  GoAInput,
  GoASpacer,
} from '@abgov/react-components';

import { LocationArgs } from '../../../../../types/organization';
import useLocationForm from './hooks/use-location-form.hook';
import { economicRegionLabels, EconomicRegions } from '../../../../../types/core';

interface Props {
  isPrimary?: boolean;
  location?: LocationArgs;
  primaryLocationError?: string;
  addLocation?: (args: LocationArgs) => void;
  setPrimaryEconomicRegion?: (value: EconomicRegions) => void;
}

export function LocationForm({
  isPrimary,
  location,
  primaryLocationError,
  addLocation,
  setPrimaryEconomicRegion,
}: Props) {
  const { formFields, getValues, errors, onChangeHandler, onRegionChangeHandler, addLocationHandler, handleSubmit } =
    useLocationForm(location, primaryLocationError, addLocation, setPrimaryEconomicRegion);
  const { locationName, street, unit, city, province, postalCode, countryCode, phoneNumber, email, economicRegion } =
    formFields;

  return (
    <form>
      {!isPrimary && (
        <GoAFormItem
          label="Location name"
          requirement="required"
          error={errors[locationName]?.message as unknown as string}
        >
          <GoAInput
            type="text"
            onChange={onChangeHandler}
            name={locationName}
            id={locationName}
            value={getValues(locationName)}
            width="600px"
          />
        </GoAFormItem>
      )}
      <GoAFormItem label="Address" requirement="required" error={errors[street]?.message as unknown as string}>
        <GoAInput
          type="text"
          disabled={isPrimary}
          onChange={onChangeHandler}
          name={street}
          id={street}
          value={getValues(street)}
          width="600px"
        />
      </GoAFormItem>
      <GoAFormItem label="Unit" error={errors[unit]?.message as unknown as string}>
        <GoAInput
          type="text"
          disabled={isPrimary}
          onChange={onChangeHandler}
          name={unit}
          id={unit}
          value={getValues(unit)}
          width="156px"
        />
      </GoAFormItem>
      <GoABlock>
        <GoAFormItem label="City" requirement="required" error={errors[city]?.message as unknown as string}>
          <GoAInput
            type="text"
            disabled={isPrimary}
            onChange={onChangeHandler}
            name={city}
            id={city}
            value={getValues(city)}
            width="156px"
          />
        </GoAFormItem>
        <GoAFormItem label="Province" requirement="required" error={errors[province]?.message as unknown as string}>
          <GoAInput
            type="text"
            disabled={isPrimary}
            onChange={onChangeHandler}
            name={province}
            id={province}
            value={getValues(province)}
            width="156px"
          />
        </GoAFormItem>
        <GoAFormItem
          label="Postal code"
          requirement="required"
          error={errors[postalCode]?.message as unknown as string}
        >
          <GoAInput
            type="text"
            disabled={isPrimary}
            onChange={onChangeHandler}
            name={postalCode}
            id={postalCode}
            value={getValues(postalCode)}
            width="156px"
          />
        </GoAFormItem>
        <GoAFormItem label="Country" requirement="required" error={errors[countryCode]?.message as unknown as string}>
          <GoAInput
            type="text"
            disabled={isPrimary}
            onChange={onChangeHandler}
            name={countryCode}
            id={countryCode}
            value={getValues(countryCode)}
            width="156px"
          />
        </GoAFormItem>
      </GoABlock>
      <GoAFormItem label="Phone number" error={errors[phoneNumber]?.message as unknown as string}>
        <GoAInput
          leadingContent="+1"
          disabled={isPrimary}
          type="tel"
          onChange={onChangeHandler}
          name={phoneNumber}
          id={phoneNumber}
          value={getValues(phoneNumber)}
          width="244px"
        />
      </GoAFormItem>
      <GoAFormItem label="Email" error={errors[email]?.message as unknown as string}>
        <GoAInput
          disabled={isPrimary}
          type="email"
          onChange={onChangeHandler}
          name={email}
          id={email}
          value={getValues(email)}
          width="397px"
        />
      </GoAFormItem>
      <GoAFormItem
        requirement="required"
        label="Select the economic region this location is in"
        error={errors[economicRegion]?.message as unknown as string}
      >
        <GoADropdown
          name={economicRegion}
          value={getValues(economicRegion)}
          onChange={onRegionChangeHandler}
          width="397px"
        >
          <GoADropdownItem
            value={EconomicRegions.ATHABASCA_GRANDE_PRAIRIE_PEACE_RIVER}
            label={economicRegionLabels.ATHABASCA_GRANDE_PRAIRIE_PEACE_RIVER}
          />
          <GoADropdownItem
            value={EconomicRegions.BANFF_JASPER_ROCKY_MOUNTAIN_HOUSE}
            label={economicRegionLabels.BANFF_JASPER_ROCKY_MOUNTAIN_HOUSE}
          />
          <GoADropdownItem value={EconomicRegions.CALGARY} label={economicRegionLabels.CALGARY} />
          <GoADropdownItem value={EconomicRegions.CAMROSE_DRUMHELLER} label={economicRegionLabels.CAMROSE_DRUMHELLER} />
          <GoADropdownItem value={EconomicRegions.EDMONTON} label={economicRegionLabels.EDMONTON} />
          <GoADropdownItem
            value={EconomicRegions.LETHBRIDGE_MEDICINE_HAT}
            label={economicRegionLabels.LETHBRIDGE_MEDICINE_HAT}
          />
          <GoADropdownItem value={EconomicRegions.RED_DEER} label={economicRegionLabels.RED_DEER} />
          <GoADropdownItem
            value={EconomicRegions.WOOD_BUFFALO_COLD_LAKE}
            label={economicRegionLabels.WOOD_BUFFALO_COLD_LAKE}
          />
        </GoADropdown>
      </GoAFormItem>
      {!isPrimary && (
        <>
          <GoASpacer vSpacing="m" />
          <GoAButton type="secondary" onClick={handleSubmit(addLocationHandler)}>
            Add location
          </GoAButton>
        </>
      )}
    </form>
  );
}

LocationForm.defaultProps = {
  isPrimary: false,
  location: undefined,
  primaryLocationError: undefined,
  addLocation: undefined,
  setPrimaryEconomicRegion: undefined,
};
