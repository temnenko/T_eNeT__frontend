/* eslint-disable react/no-array-index-key */
import { GoABlock, GoAButton, GoAContainer, GoAGrid, GoANotification, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import { useOrganizationEnrollReview } from './hooks/use-organization-review-cards.hook';
import { useOrganizationReviewEdit } from './hooks/use-organization-review-edit.hook';
import { ReviewFilesList } from './review-files-list';
import { OrganizationFormStepperKeys } from '../../../../../types/organization-forms';
import { useFormatPhoneNumber } from '../../../../../hooks/use-format-phone-number';

const OrganizationEnrollmentReview = observer(() => {
  const { organization } = useOrganizationEnrollReview();
  const formatPhoneNumber = useFormatPhoneNumber();
  const { completeOrganizationEnrollmentHandler, previousButtonHandler, jumpToStep, requestError } =
    useOrganizationReviewEdit();
  const actions = (stepKey: OrganizationFormStepperKeys) => (
    <GoAButton type="tertiary" size="compact" onClick={() => jumpToStep(stepKey, organization!.id)} disabled={false}>
      <span style={{ color: 'white' }}>Edit</span>
    </GoAButton>
  );

  return (
    <div className="client-review-overview">
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      <GoAGrid gap="xl" minChildWidth="350px">
        <GoAContainer
          heading="Primary details"
          accent="thick"
          actions={actions(OrganizationFormStepperKeys.PRIMARY)}
          padding="compact"
        >
          <GoABlock direction="column">
            <GoAGrid minChildWidth="200px" gap="none">
              <div className="client-review-card-label">
                <span className="color-interactive">Operating Name</span>
              </div>
              <div className="client-review-card-value">
                <span className="client-bold-600">{organization?.operatingName}</span>
              </div>
            </GoAGrid>
            <GoAGrid minChildWidth="200px" gap="none">
              <div className="client-review-card-label">
                <span className="color-interactive">Registered legal name</span>
              </div>
              <div className="client-review-card-value">
                <span className="client-bold-600">{organization?.legalName}</span>
              </div>
            </GoAGrid>
            <GoABlock gap="none">
              <div className="client-review-card-label">
                <span className="color-interactive">Main business email</span>
              </div>
              <div className="client-review-card-value">
                <span className="client-bold-600">{organization?.emailAddress}</span>
              </div>
            </GoABlock>
            <GoAGrid minChildWidth="200px" gap="none">
              <div className="client-review-card-label">
                <span className="color-interactive">Main phone number</span>
              </div>
              <div className="client-review-card-value">
                <span className="client-bold-600">{formatPhoneNumber(organization?.phoneNumber)}</span>
              </div>
            </GoAGrid>
            <GoAGrid minChildWidth="200px" gap="none">
              <div className="client-review-card-label">
                <span className="color-interactive">Website</span>
              </div>
              <div className="client-review-card-value">
                <span className="client-bold-600">{organization?.website}</span>
              </div>
            </GoAGrid>
          </GoABlock>
        </GoAContainer>

        <ReviewFilesList />

        <GoAContainer
          heading="First User"
          accent="thick"
          actions={actions(OrganizationFormStepperKeys.FIRST_USER)}
          padding="compact"
        >
          <GoABlock direction="column">
            <GoABlock gap="none">
              <div className="client-review-card-label">
                <span className="color-interactive">Name</span>
              </div>
              <div className="client-review-card-value">
                <span className="client-bold-600">{organization?.firstUserName}</span>
              </div>
            </GoABlock>
            <GoABlock gap="none">
              <div className="client-review-card-label">
                <span className="color-interactive">Email</span>
              </div>
              <div className="client-review-card-value">
                <span className="client-bold-600">{organization?.firstUserEmail}</span>
              </div>
            </GoABlock>
          </GoABlock>
        </GoAContainer>
        <GoASpacer vSpacing="m" />
        <div className="organization-form-buttons client-demographic-prev-next">
          <GoAButton type="secondary" onClick={previousButtonHandler} leadingIcon="arrow-back">
            <span className="client-bold-600">Back:</span> First User
          </GoAButton>
          <GoAButton
            type="primary"
            onClick={() => completeOrganizationEnrollmentHandler()}
            disabled={false}
            trailingIcon="arrow-forward"
          >
            Complete and invite
          </GoAButton>
        </div>
      </GoAGrid>
    </div>
  );
});

export default OrganizationEnrollmentReview;
