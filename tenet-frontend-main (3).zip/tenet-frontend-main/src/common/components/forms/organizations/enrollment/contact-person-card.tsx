/* eslint-disable no-nested-ternary */
import { GoABlock, GoAButton, GoAContainer, GoASpacer } from '@abgov/react-components';

import { useFormatPhoneNumber } from '../../../../../hooks/use-format-phone-number';

interface Props {
  contactPerson: {
    contactName: string;
    contactRole: string;
    phoneNumber: string;
    extension?: string;
    emailAddress: string;
    contactId: number;
  };
  editContact: (id: number) => void;
  removeContact: (id: number) => void;
}
export default function OrganizationContactCard({ contactPerson, editContact, removeContact }: Props) {
  const formatPhoneNumber = useFormatPhoneNumber();

  return (
    <>
      <GoASpacer vSpacing="m" />
      <GoAContainer accent="thin" mb="none" type="info">
        <GoABlock direction="column" gap="none">
          <span className="organization-card-text-medium">{contactPerson.contactName}</span>
          <span className="organization-card-text-small">{contactPerson.contactRole}</span>
          <span className="organization-card-text-small">{`${formatPhoneNumber(contactPerson.phoneNumber)} ext ${contactPerson.extension}`}</span>
          <span className="organization-card-text-small">{contactPerson.emailAddress}</span>
          <GoASpacer vSpacing="l" />
          <GoABlock>
            <GoAButton
              type="secondary"
              leadingIcon="pencil"
              onClick={() => {
                editContact(contactPerson.contactId);
              }}
            >
              Edit
            </GoAButton>
            <GoAButton
              type="tertiary"
              leadingIcon="trash"
              onClick={() => {
                removeContact(contactPerson.contactId);
              }}
            >
              Remove
            </GoAButton>
          </GoABlock>
        </GoABlock>
      </GoAContainer>
    </>
  );
}
