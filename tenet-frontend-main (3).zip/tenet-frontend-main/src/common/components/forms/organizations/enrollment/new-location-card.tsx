import { GoABlock, GoAButton, GoAContainer } from '@abgov/react-components';

import { LocationArgs } from '../../../../../types/organization';
import { useFormatPhoneNumber } from '../../../../../hooks/use-format-phone-number';

interface Props {
  location: LocationArgs;
  editLocation: (args: LocationArgs) => void;
  removeLocation: (args: LocationArgs) => void;
}

export function NewLocationCard({ location, editLocation, removeLocation }: Props) {
  const { name, street, city, province, postalCode, phoneNumber, email } = location;
  const formatPhoneNumber = useFormatPhoneNumber();

  return (
    <div className="form-info-card">
      <GoAContainer type="interactive" accent="thin" padding="compact">
        <GoABlock direction="column" gap="none">
          <strong>{`${name} ${city}`}</strong>
          <span>{`${street}, ${city}, ${province} ${postalCode}`}</span>
          <span>{formatPhoneNumber(phoneNumber)}</span>
          <span>{email}</span>
        </GoABlock>
        <GoABlock mt="m">
          <GoAButton leadingIcon="pencil" type="secondary" onClick={() => editLocation(location)}>
            Edit
          </GoAButton>
          <GoAButton leadingIcon="trash" type="secondary" onClick={() => removeLocation(location)}>
            Remove
          </GoAButton>
        </GoABlock>
      </GoAContainer>
    </div>
  );
}
