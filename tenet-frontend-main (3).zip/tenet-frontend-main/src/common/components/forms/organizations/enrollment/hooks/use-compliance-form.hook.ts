import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';

import { Upload } from '../../../../../../types/files';
import { useNavigateOrganizationStepper } from './use-navigate-organization-stepper';
import { OrganizationFormStepperKeys } from '../../../../../../types/organization-forms';
import useLoadOrganization from './use-load-organization.hook';
import { validateNotFutureDate, validateNotPastDate } from '../../../../../../utils/validate-date.util';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { Organization } from '../../../../../../types/organization';
import { RequestError } from '../../../../../../types/errors/errors';
import { toIsoFormat } from '../../../../../../utils/date.util';

type ComplianceFormData = {
  corporateIdentityNumber: string;
  corporateIdentityDocuments: Upload[];
  lobbyistCheckDate?: string;
  lobbyistCheckProof: Upload[];
  wcbVerifiedOn?: string;
  wcbVerificationProof: Upload[];
  liabilityPolicyExpiresOn?: string;
  liabilityPolicyProof: Upload[];
  assessmentCompletedOn?: string;
  assessmentResult: Upload[];
};

export type ComplianceFieldNames =
  | 'corporateIdentityNumber'
  | 'corporateIdentityDocuments'
  | 'lobbyistCheckDate'
  | 'lobbyistCheckProof'
  | 'wcbVerifiedOn'
  | 'wcbVerificationProof'
  | 'liabilityPolicyExpiresOn'
  | 'liabilityPolicyProof'
  | 'assessmentCompletedOn'
  | 'assessmentResult';
type SetValueKeys =
  | 'corporateIdentityNumber'
  | 'lobbyistCheckDate'
  | 'wcbVerifiedOn'
  | 'liabilityPolicyExpiresOn'
  | 'assessmentCompletedOn';

const useComplianceForm = () => {
  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    reset,
    formState: { errors },
  } = useForm<ComplianceFormData>();

  const { organization } = useLoadOrganization();
  const { setActiveStep, goToNextStep, goToPreviousStep } = useNavigateOrganizationStepper();
  const {
    organizationEnrollmentStore: { orgWatch, watchOrg, retrieveOrg, fetchFiles, updateOrganization },
    permissionStore: { canEditOrganizationCompliance },
  } = useStore();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  const { name: corporateIdentityNumber } = register(`corporateIdentityNumber`, {
    required: { value: true, message: 'This field is required' },
    pattern: { value: /^\d+$/, message: 'Numbers only' },
  });
  const { name: corporateIdentityDocuments } = register('corporateIdentityDocuments');
  const { name: lobbyistCheckDate } = register('lobbyistCheckDate', {
    required: { value: true, message: 'This field is required' },
    validate: validateNotFutureDate,
  });
  const { name: lobbyistCheckProof } = register('lobbyistCheckProof');
  const { name: wcbVerifiedOn } = register('wcbVerifiedOn', {
    required: { value: true, message: 'This field is required' },
    validate: validateNotFutureDate,
  });
  const { name: wcbVerificationProof } = register('wcbVerificationProof');
  const { name: liabilityPolicyExpiresOn } = register('liabilityPolicyExpiresOn', {
    required: { value: true, message: 'This field is required' },
    validate: validateNotPastDate,
  });
  const { name: liabilityPolicyProof } = register('liabilityPolicyProof');
  const { name: assessmentCompletedOn } = register('assessmentCompletedOn', {
    required: { value: true, message: 'This field is required' },
    validate: validateNotFutureDate,
  });
  const { name: assessmentResult } = register('assessmentResult');

  const formFields = {
    corporateIdentityNumber,
    corporateIdentityDocuments,
    lobbyistCheckDate,
    lobbyistCheckProof,
    wcbVerifiedOn,
    wcbVerificationProof,
    liabilityPolicyExpiresOn,
    liabilityPolicyProof,
    assessmentCompletedOn,
    assessmentResult,
  };

  useEffect(() => {
    if (orgWatch || organization) {
      reset({
        corporateIdentityNumber: retrieveOrg(corporateIdentityNumber) ?? (organization?.corporateIdentityNumber || ''),
        lobbyistCheckDate:
          retrieveOrg(lobbyistCheckDate) ??
          (organization?.lobbyistCheckedDate ? toIsoFormat(new Date(organization!.lobbyistCheckedDate!)) : undefined),
        wcbVerifiedOn:
          retrieveOrg(wcbVerifiedOn) ??
          (organization?.wcbVerifiedOn ? toIsoFormat(new Date(organization!.wcbVerifiedOn!)) : undefined),
        liabilityPolicyExpiresOn:
          retrieveOrg(liabilityPolicyExpiresOn) ??
          (organization?.liabilityPolicyExpiresOn
            ? toIsoFormat(new Date(organization!.liabilityPolicyExpiresOn!))
            : undefined),
        assessmentCompletedOn:
          retrieveOrg(assessmentCompletedOn) ??
          (organization?.privacyAssessmentCompletedOn
            ? toIsoFormat(new Date(organization!.privacyAssessmentCompletedOn!))
            : undefined),
      });
    }
    setActiveStep(OrganizationFormStepperKeys.FILES);
    fetchFiles();
  }, [
    fetchFiles,
    setActiveStep,
    organization,
    reset,
    orgWatch,
    retrieveOrg,
    corporateIdentityNumber,
    lobbyistCheckDate,
    wcbVerifiedOn,
    liabilityPolicyExpiresOn,
    assessmentCompletedOn,
  ]);

  const onChangeHandler = useCallback(
    (key: string, value: string | undefined) => {
      setValue(key as SetValueKeys, value);
      watchOrg(key, value);
    },
    [setValue, watchOrg],
  );

  const previousButtonHandler = useCallback(() => goToPreviousStep(organization!.id), [goToPreviousStep, organization]);

  const complianceSubmitHandler = useCallback(async () => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const payload = {
      corporateIdentityNumber: getValues('corporateIdentityNumber'),
    };

    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const payloadForFuture = {
      corporateIdentityNumber: getValues(corporateIdentityNumber),
      corporateIdentityDocuments: getValues(corporateIdentityDocuments),
      lobbyistCheckedDate: getValues(lobbyistCheckDate) ? new Date(getValues(lobbyistCheckDate)!) : undefined,
      lobbyistCheckProof: getValues(lobbyistCheckProof),
      wcbVerifiedOn: getValues(wcbVerifiedOn) ? new Date(getValues(wcbVerifiedOn)!) : undefined,
      wcbVerificationProof: getValues(wcbVerificationProof),
      liabilityPolicyExpiresOn: getValues(liabilityPolicyExpiresOn)
        ? new Date(getValues(liabilityPolicyExpiresOn)!)
        : undefined,
      liabilityPolicyProof: getValues(liabilityPolicyProof),
      privacyAssessmentCompletedOn: getValues(assessmentCompletedOn)
        ? new Date(getValues(assessmentCompletedOn)!)
        : undefined,
      assessmentResult: getValues(assessmentResult),
    };
    setLoading(true);
    try {
      await updateOrganization({
        id: organization!.id,
        ...payloadForFuture,
      } as Organization);
      goToNextStep(organization!.id);
    } catch {
      setRequestError({
        isUserError: true,
        message:
          'An error occurred while submitting the form. Please try again or contact support if the issue persists.',
        onDismiss: () => setRequestError({}),
      });
    } finally {
      setLoading(false);
    }
  }, [
    assessmentCompletedOn,
    assessmentResult,
    corporateIdentityDocuments,
    corporateIdentityNumber,
    getValues,
    goToNextStep,
    liabilityPolicyExpiresOn,
    liabilityPolicyProof,
    lobbyistCheckDate,
    lobbyistCheckProof,
    organization,
    updateOrganization,
    wcbVerificationProof,
    wcbVerifiedOn,
  ]);

  return {
    formFields,
    getValues,
    setValue,
    onChangeHandler,
    handleSubmit,
    errors,
    previousButtonHandler,
    complianceSubmitHandler,
    loading,
    requestError,
    canEditOrganizationCompliance,
  };
};

export default useComplianceForm;
