import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { useStore } from '../../../../../../hooks/use-store.hook';
import useLoadOwnOrganization from './use-load-organization.hook';
import { RequestError } from '../../../../../../types/errors/errors';

type FormFieldName = 'contactName' | 'contactRole' | 'phoneNumber' | 'extension';

type ContactPersonData = {
  contactName: string;
  contactRole: string;
  phoneNumber: string;
  extension: string;
  emailAddress: string;
  contactId: number;
};
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const useSubmitContact = () => {
  const [contactPersons, setContactPersons] = useState<ContactPersonData[]>([]);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [editingContactId, setEditingContactId] = useState<number>(0);
  const { organizationEnrollmentStore } = useStore();
  const { organization } = useLoadOwnOrganization();

  const requestErrorHandler = useRequestErrorHandler();

  const {
    getValues,
    handleSubmit,
    register,
    reset,
    setValue,
    formState: { errors },
  } = useForm<ContactPersonData>();

  useEffect(() => {
    reset();
  }, [reset]);

  const [loading, setLoading] = useState(false);

  const { name: contactName } = register('contactName', {
    required: { value: true, message: "Contact's name is required!" },
  });

  const { name: contactRole } = register('contactRole', {
    required: { value: true, message: "Contact's role is required!" },
  });

  const { name: phoneNumber } = register('phoneNumber', {
    required: { value: true, message: "Contact's phone number is required!" },
    pattern: { value: /[0-9]{10}/, message: '10 digits phone number  required!' },
  });

  const { name: extension } = register('extension', {
    pattern: { value: /^\d{3}$/, message: 'Required 3 digits extension' },
  });

  const { name: emailAddress } = register('emailAddress', {
    required: { value: true, message: "Contact's email address is required!" },
    pattern: { value: /^\S+@\S+\.\S+$/, message: 'Invalid email address' },
  });

  const formsFields = {
    contactName,
    contactRole,
    phoneNumber,
    extension,
    emailAddress,
  };

  const addContactPerson = useCallback(() => {
    try {
      const name = getValues(contactName);
      const role = getValues(contactRole);
      const contactExists = contactPersons.find((c) => c.contactId === editingContactId);
      const contacts = [...contactPersons];
      if (contactExists) {
        contacts?.splice(
          contacts?.findIndex(({ contactId }) => contactId === editingContactId),
          1,
          {
            contactName: name,
            contactRole: role,
            phoneNumber: getValues(phoneNumber),
            extension: getValues(extension),
            emailAddress: getValues(emailAddress)?.trim()?.toLowerCase(),
            contactId: editingContactId,
          },
        );
      } else {
        const contact = {
          contactName: name,
          contactRole: role,
          phoneNumber: getValues(phoneNumber),
          extension: getValues(extension),
          emailAddress: getValues(emailAddress)?.trim()?.toLowerCase(),
          contactId: contactPersons!.length + 1,
        };
        contacts.push(contact);
      }
      setContactPersons(contacts);
      setEditingContactId(0);

      reset({
        contactName: '',
        contactRole: '',
        phoneNumber: '',
        extension: '',
        emailAddress: '',
      });
    } catch (error) {
      requestErrorHandler({
        error,
        setError: setRequestError,
      });
    }
  }, [
    contactName,
    contactPersons,
    contactRole,
    editingContactId,
    emailAddress,
    getValues,
    phoneNumber,
    extension,
    requestErrorHandler,
    reset,
  ]);

  const editContact = useCallback(
    (id: number) => {
      const contact = contactPersons!.find((c) => c.contactId === id);

      reset({
        contactName: contact?.contactName,
        contactRole: contact?.contactRole,
        phoneNumber: contact?.phoneNumber,
        extension: contact?.extension,
        emailAddress: contact?.emailAddress,
      });
      setEditingContactId(id);
    },
    [contactPersons, reset],
  );

  const removeContact = useCallback(
    (id: number) => {
      let contacts = [...contactPersons];
      contacts = contacts.filter((c) => c.contactId !== id);
      setContactPersons(contacts);
    },
    [contactPersons],
  );

  const contactSubmitHandler = useCallback(async () => {
    const continueSave = async () => {
      try {
        setLoading(true);
        if (!contactPersons?.length) {
          throw new Error('No contact provided!');
        }

        await organizationEnrollmentStore.updateOrganizationContact(
          [
            ...contactPersons.map((c) => {
              return {
                name: c.contactName,
                role: c.contactRole,
                phoneNumber: c.phoneNumber,
                extension: c.extension,
                emailAddress: c.emailAddress,
              };
            }),
          ],
          organization?.id ?? '',
        );

        reset();
      } catch (e) {
        /* empty */
      } finally {
        setLoading(false);
      }
    };
    continueSave();
  }, [contactPersons, organization?.id, organizationEnrollmentStore, reset]);

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value);
    },
    [setValue],
  );

  return {
    loading,
    contactSubmitHandler,
    handleSubmit,
    errors,
    getValues,
    addContactPerson,
    onChangeHandler,
    contactPersons,
    formsFields,
    editContact,
    removeContact,
    requestError,
  };
};

export default useSubmitContact;
