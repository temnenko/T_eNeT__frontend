// TO DEPRECATE -- NO LONGER USED
import { GoAButton, GoACallout, GoACheckbox, GoADivider, GoASpacer } from '@abgov/react-components';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import useSubmitLocations from './hooks/use-submit-locations';
import { LocationForm } from './location.form';
import { NewLocationCard } from './new-location-card';

export function DeliveryLocationsForm() {
  const {
    otherLocations,
    primaryLocation,
    locationToEdit,
    primaryLocationOnly,
    primaryLocationError,
    loading,
    addLocation,
    editLocation,
    removeLocation,
    setPrimaryEconomicRegion,
    togglePrimaryLocationOnly,
    locationsSubmitHandler,
  } = useSubmitLocations();

  return (
    <div className="enroll-org-form">
      <GoACallout type="information" size="medium">
        Disabled fields below contains information that
        <br />
        can only be updated via your alberta.ca organization
        <br />
        account.
      </GoACallout>
      <strong>Primary location</strong>
      <GoADivider mb="s" />
      <LocationForm
        isPrimary
        location={primaryLocation}
        setPrimaryEconomicRegion={setPrimaryEconomicRegion}
        primaryLocationError={primaryLocationError}
      />
      <GoASpacer vSpacing="s" />
      <strong>Other delivery locations</strong>
      <GoADivider mb="s" />
      <span>
        Be sure to add all locations that will be deliver the contracts or grants below. Added locations will display at
        the bottom.
      </span>
      <GoACheckbox
        name="primaryLocationOnly"
        checked={primaryLocationOnly}
        text="Our primary location is the only delivery location"
        mt="s"
        onChange={togglePrimaryLocationOnly}
      />
      {!primaryLocationOnly && (
        <>
          <LocationForm location={locationToEdit} addLocation={addLocation} />
          <GoADivider mt="m" mb="m" />
        </>
      )}
      {otherLocations.map((location) => (
        <NewLocationCard
          key={location.email}
          location={location}
          editLocation={editLocation}
          removeLocation={removeLocation}
        />
      ))}
      <GoASpacer vSpacing="xl" />
      <div className="row-space-between">
        <GoAButton type="secondary" onClick={() => {}} leadingIcon="arrow-back">
          <span className="client-bold-600">Back:</span> Contact person
        </GoAButton>
        <GoAButton
          onClick={locationsSubmitHandler}
          trailingIcon={loading ? undefined : 'arrow-forward'}
          disabled={loading}
        >
          {loading ? (
            <InlineLoadingIndicator label="Saving changes..." />
          ) : (
            <>
              <span className="client-bold-600">Next:</span> Files
            </>
          )}
        </GoAButton>
      </div>
      <GoASpacer vSpacing="2xl" />
    </div>
  );
}
