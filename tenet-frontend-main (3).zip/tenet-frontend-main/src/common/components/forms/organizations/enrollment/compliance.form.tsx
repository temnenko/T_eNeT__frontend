import { GoAButton, GoANotification, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useComplianceForm, { ComplianceFieldNames } from './hooks/use-compliance-form.hook';
import { FileDateInputGroup } from '../../file-date-input-group';
import { Upload } from '../../../../../types/files';
import { OrganizationComplianceFilesTypeMap } from '../../../../../types/organization';
import useSelectFile from '../../hooks/use-select-file.hook';

export const ComplianceForm = observer(() => {
  const {
    formFields,
    getValues,
    setValue,
    onChangeHandler,
    handleSubmit,
    errors,
    previousButtonHandler,
    complianceSubmitHandler,
    requestError,
    canEditOrganizationCompliance,
  } = useComplianceForm();
  const {
    corporateIdentityNumber,
    corporateIdentityDocuments,
    lobbyistCheckDate,
    lobbyistCheckProof,
    wcbVerifiedOn,
    wcbVerificationProof,
    liabilityPolicyExpiresOn,
    liabilityPolicyProof,
    assessmentCompletedOn,
    assessmentResult,
  } = formFields;

  const setFileValue = (name: string, value: Upload[]) => setValue(name as ComplianceFieldNames, value);
  const corporateIdentityDocumentsHandler = useSelectFile({
    name: corporateIdentityDocuments,
    uploadType: OrganizationComplianceFilesTypeMap.corporateIdentityDocuments,
    setValue: setFileValue,
  });
  const lobbyistCheckProofHandler = useSelectFile({
    name: lobbyistCheckProof,
    uploadType: OrganizationComplianceFilesTypeMap.lobbyistCheckProof,
    setValue: setFileValue,
  });
  const wcbVerificationProofHandler = useSelectFile({
    name: wcbVerificationProof,
    uploadType: OrganizationComplianceFilesTypeMap.wcbVerificationProof,
    setValue: setFileValue,
  });
  const liabilityPolicyProofHandler = useSelectFile({
    name: liabilityPolicyProof,
    uploadType: OrganizationComplianceFilesTypeMap.liabilityPolicyProof,
    setValue: setFileValue,
  });
  const assessmentResultHandler = useSelectFile({
    name: assessmentResult,
    uploadType: OrganizationComplianceFilesTypeMap.assessmentResult,
    setValue: setFileValue,
  });

  return (
    <form className="stepper-form-container">
      {requestError?.message && (
        <>
          <GoANotification type="emergency">{requestError.message}</GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      <FileDateInputGroup
        isDateInput={false}
        maxSizeInMb={10}
        label="Corporate identity"
        inputLabel="Corporate identity number"
        fileInputLabel="Upload proof of corporate identity document"
        inputName={corporateIdentityNumber}
        fileInputName={corporateIdentityDocuments}
        inputOnChangeHandler={onChangeHandler}
        checkInputError={undefined}
        inputError={errors.corporateIdentityNumber?.message}
        fileInputError={errors.corporateIdentityDocuments?.message}
        getValues={getValues}
        setFileValue={(name: string, value: Upload[]) => setValue(name as ComplianceFieldNames, value)}
        uploadType={OrganizationComplianceFilesTypeMap.corporateIdentityDocuments}
        fileHandler={corporateIdentityDocumentsHandler}
        uploadOptional
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />
      <FileDateInputGroup
        maxSizeInMb={10}
        label="Lobbyist check"
        inputLabel="Lobbyist check date"
        fileInputLabel="Upload proof of lobbyist check"
        inputName={lobbyistCheckDate}
        fileInputName={lobbyistCheckProof}
        inputOnChangeHandler={onChangeHandler}
        checkInputError={undefined}
        inputError={errors.lobbyistCheckDate?.message}
        fileInputError={errors.lobbyistCheckProof?.message}
        getValues={getValues}
        setFileValue={(name: string, value: Upload[]) => setValue(name as ComplianceFieldNames, value)}
        uploadType={OrganizationComplianceFilesTypeMap.lobbyistCheckProof}
        fileHandler={lobbyistCheckProofHandler}
        uploadOptional
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />
      <FileDateInputGroup
        maxSizeInMb={10}
        label="Workers Compensation Board (WCB)"
        inputLabel="WCB verified on"
        fileInputLabel="Upload proof of WCB verification"
        inputName={wcbVerifiedOn}
        fileInputName={wcbVerificationProof}
        inputOnChangeHandler={onChangeHandler}
        checkInputError={undefined}
        inputError={errors.wcbVerifiedOn?.message}
        fileInputError={errors.wcbVerificationProof?.message}
        getValues={getValues}
        setFileValue={(name: string, value: Upload[]) => setValue(name as ComplianceFieldNames, value)}
        uploadType={OrganizationComplianceFilesTypeMap.wcbVerificationProof}
        fileHandler={wcbVerificationProofHandler}
        uploadOptional
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />
      <FileDateInputGroup
        maxSizeInMb={10}
        label="Liability insurance"
        inputLabel="Policy expires on"
        fileInputLabel="Upload proof of liability insurance"
        inputName={liabilityPolicyExpiresOn}
        fileInputName={liabilityPolicyProof}
        inputOnChangeHandler={onChangeHandler}
        checkInputError={undefined}
        inputError={errors.liabilityPolicyExpiresOn?.message}
        fileInputError={errors.liabilityPolicyProof?.message}
        getValues={getValues}
        setFileValue={(name: string, value: Upload[]) => setValue(name as ComplianceFieldNames, value)}
        uploadType={OrganizationComplianceFilesTypeMap.liabilityPolicyProof}
        fileHandler={liabilityPolicyProofHandler}
        uploadOptional
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />
      <FileDateInputGroup
        maxSizeInMb={10}
        label="Privacy self assessment"
        inputLabel="Assessment completed on"
        fileInputLabel="Upload Privacy self assessment result"
        inputName={assessmentCompletedOn}
        fileInputName={assessmentResult}
        inputOnChangeHandler={onChangeHandler}
        checkInputError={undefined}
        inputError={errors.assessmentCompletedOn?.message}
        fileInputError={errors.assessmentResult?.message}
        getValues={getValues}
        setFileValue={(name: string, value: Upload[]) => setValue(name as ComplianceFieldNames, value)}
        uploadType={OrganizationComplianceFilesTypeMap.assessmentResult}
        fileHandler={assessmentResultHandler}
        uploadOptional
        canEditOrganizationCompliance={canEditOrganizationCompliance}
      />
      <GoASpacer vSpacing="xl" />
      <div className="row-space-between client-demographic-prev-next">
        <GoAButton type="secondary" onClick={previousButtonHandler} leadingIcon="arrow-back">
          <span className="client-bold-600">Back:</span> Profile
        </GoAButton>
        <GoAButton type="submit" onClick={handleSubmit(complianceSubmitHandler)} trailingIcon="arrow-forward">
          <span className="client-bold-600">Next:</span> First user
        </GoAButton>
      </div>
      <GoASpacer vSpacing="2xl" />
    </form>
  );
});
