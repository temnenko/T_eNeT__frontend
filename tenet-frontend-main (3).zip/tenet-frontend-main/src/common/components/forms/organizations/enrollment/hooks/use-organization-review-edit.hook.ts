import { useCallback, useEffect, useState } from 'react';
import { formatDate } from 'date-fns';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { useNavigateOrganizationStepper } from './use-navigate-organization-stepper';
import { OrganizationFormStepperKeys } from '../../../../../../types/organization-forms';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';

export const formatInputDate = (dateVal: string) => {
  const val = formatDate(dateVal, 'MMM do, yyyy h:mm a');
  return val;
};

export const useOrganizationReviewEdit = () => {
  const {
    organizationEnrollmentStore: { selectedOrganization, completeOrganizationEnrollment },
  } = useStore();

  const { setActiveStep, goToNextStep, goToPreviousStep, jumpToStep } = useNavigateOrganizationStepper();
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});
  const {
    organizationEnrollmentStore: { fetchFiles },
  } = useStore();

  useEffect(() => {
    fetchFiles();
    setActiveStep(OrganizationFormStepperKeys.REVIEW);
  }, [fetchFiles, setActiveStep]);

  const completeOrganizationEnrollmentHandler = useCallback(async () => {
    try {
      await completeOrganizationEnrollment();
      goToNextStep(selectedOrganization!.id);
    } catch (error) {
      requestErrorHandler({
        error,
        setError: setRequestError,
      });
    }
  }, [completeOrganizationEnrollment, goToNextStep, requestErrorHandler, selectedOrganization]);

  const previousButtonHandler = useCallback(() => {
    goToPreviousStep(selectedOrganization!.id);
  }, [goToPreviousStep, selectedOrganization]);

  return {
    completeOrganizationEnrollmentHandler,
    partnerNumber: selectedOrganization?.partnerNumber,
    previousButtonHandler,
    jumpToStep,
    selectedOrganization,
    corporateIdentityNumber: selectedOrganization?.corporateIdentityNumber,
    requestError,
    liabilityPolicyExpiresOn: selectedOrganization?.liabilityPolicyExpiresOn,
    lobbyistCheckDate: selectedOrganization?.lobbyistCheckedDate,
    wcbVerifiedOn: selectedOrganization?.wcbVerifiedOn,
    assessmentCompletedOn: selectedOrganization?.privacyAssessmentCompletedOn,
    formatInputDate,
  };
};
