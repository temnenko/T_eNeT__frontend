import { observer } from 'mobx-react-lite';
import { GoAButton, GoAFormItem, GoAInput, GoANotification, GoASpacer } from '@abgov/react-components';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import { useFirstUserHook } from './hooks/use-first-user-form-hook';

export const FirstUserForm = observer(() => {
  const {
    errors,
    getValues,
    handleSubmit,
    firstUserFormSubmitHandler,
    loading,
    firstUserName,
    firstUserEmail,
    requestError,
    onChangeHandler,
    previousButtonHandler,
  } = useFirstUserHook();

  return (
    <form className="stepper-form-container">
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      <strong>Invite the first TENET user for this organization. </strong>
      <p>
        In order for users from this Provider to start using TENET, we&apos;ll need to invite a first user from the
        organization to activate it.
      </p>
      <p>
        To start, this can be anyone from the organization that will use TENET who has a pre-existing alberta.ca account
        with the organization. Please ensure you invite them with the email account they use with their alberta.ca
        account.
      </p>
      <p>This new user will receive an email asking them to login to TENET with their alberta.ca account.</p>

      <p>
        Voila, this will activate the organization so more users can be added to it! Note: This first user will still
        need to submit a TENET access request form to receive permissions.
      </p>

      <GoAFormItem label="Name of first user" error={errors.firstUserName?.message as unknown as string}>
        <GoAInput
          onChange={onChangeHandler}
          name="firstUserName"
          width="100%"
          value={getValues(firstUserName) as string}
        />
      </GoAFormItem>
      <GoASpacer vSpacing="m" />
      <GoAFormItem label="Email" error={errors.firstUserEmail?.message as unknown as string}>
        <div>
          <span>The invite will send to this email upon the submission of this form</span>
        </div>
        <GoAInput
          onChange={onChangeHandler}
          name="firstUserEmail"
          width="100%"
          value={getValues(firstUserEmail) as string}
        />
      </GoAFormItem>
      <GoASpacer vSpacing="m" />

      <GoASpacer vSpacing="l" />
      <div className="row-space-between client-demographic-prev-next">
        <GoAButton type="secondary" onClick={previousButtonHandler} leadingIcon="arrow-back">
          <span className="client-bold-600">Back:</span> Compliance
        </GoAButton>
        <GoAButton
          onClick={handleSubmit(firstUserFormSubmitHandler)}
          trailingIcon={loading ? undefined : 'arrow-forward'}
          disabled={loading}
        >
          {loading ? (
            <InlineLoadingIndicator label="Saving changes..." />
          ) : (
            <>
              <span className="client-bold-600">Next:</span> Review and Invite
            </>
          )}
        </GoAButton>
      </div>
    </form>
  );
});
