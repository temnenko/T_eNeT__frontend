/* eslint-disable no-console */
import { useCallback, useState } from 'react';
import { LocationArgs, Location } from '../../../../../../types/organization';
import { organizationService } from '../../../../../../services/organizations/organization.service';
import { EconomicRegions } from '../../../../../../types/core';

const useSubmitLocations = () => {
  const [otherLocations, setOtherLocations] = useState<LocationArgs[]>([]);
  const [primaryLocation, setPrimaryLocation] = useState<Location>();
  const [locationToEdit, setLocationToEdit] = useState<LocationArgs>();

  const [primaryLocationOnly, setPrimaryLocationOnly] = useState<boolean>(false);
  const [primaryLocationError, setPrimaryLocationError] = useState<string>();
  const [loading, setLoading] = useState<boolean>(false);

  const togglePrimaryLocationOnly = useCallback((_: string, checked: boolean) => {
    setPrimaryLocationOnly(checked);
  }, []);

  const setPrimaryEconomicRegion = useCallback(
    (value: EconomicRegions) => {
      if (primaryLocation) {
        setPrimaryLocation({ ...primaryLocation, economicRegion: value });
      }
    },
    [primaryLocation],
  );

  const removeLocation = useCallback(
    (args: LocationArgs) => {
      setOtherLocations([...otherLocations.filter(({ email }) => email !== args.email)]);
    },
    [otherLocations],
  );
  const addLocation = useCallback(
    (args: LocationArgs) => {
      setOtherLocations([...otherLocations.filter(({ email }) => email !== args.email), args]);
      setLocationToEdit(undefined);
    },
    [otherLocations],
  );

  const editLocation = useCallback((args: LocationArgs) => {
    setLocationToEdit({ ...args });
  }, []);

  const locationsSubmitHandler = useCallback(async () => {
    if (!primaryLocation || !primaryLocation?.economicRegion) {
      setPrimaryLocationError('Economic region is required');

      return;
    }

    try {
      setPrimaryLocationError(undefined);
      setLoading(true);

      await organizationService.updateLocation(primaryLocation.id, { economicRegion: primaryLocation.economicRegion });
      await Promise.all(
        otherLocations.map((entry) => organizationService.createLocation(primaryLocation.organizationId, entry)),
      );
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
    }
  }, [otherLocations, primaryLocation]);

  return {
    otherLocations,
    primaryLocation,
    locationToEdit,
    primaryLocationOnly,
    loading,
    addLocation,
    editLocation,
    removeLocation,
    setPrimaryEconomicRegion,
    locationsSubmitHandler,
    togglePrimaryLocationOnly,
    primaryLocationError,
  };
};

export default useSubmitLocations;
