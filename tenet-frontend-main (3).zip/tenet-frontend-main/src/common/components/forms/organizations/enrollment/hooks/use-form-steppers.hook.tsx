import { useCallback, useMemo } from 'react';
import { GoAIcon } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';

import { useStore } from '../../../../../../hooks/use-store.hook';
import { Stepper } from '../../../stepper';
import { TabsTextState } from '../../../../../../types/client-forms';
import {
  OrganizationFormStepperKeys,
  organizationFormStepperPaths,
  organizationFormStepperTitles,
} from '../../../../../../types/organization-forms';

const useFormSteppers = () => {
  const {
    authStore: { isAuthenticated },
    organizationFormStepperStore: { steppers, active },
    organizationEnrollmentStore: { selectedOrganization },
  } = useStore();
  const { primary, firstUser, files, review } = steppers;
  const navigate = useNavigate();

  const clickHandler = useCallback(
    (key: OrganizationFormStepperKeys, path: string) => () => {
      const updatedPath = selectedOrganization?.id ? path.replace(':id?', selectedOrganization.id!) : path;

      // Do not move past the first organization form until submitted
      if (selectedOrganization?.id) {
        active(key);
        navigate(updatedPath);
      }
    },
    [active, navigate, selectedOrganization?.id],
  );

  const getTabIcon = useCallback((tabState: TabsTextState) => {
    if (tabState === TabsTextState.ACTIVE) {
      return <GoAIcon type="pencil" theme="filled" size="small" />;
    }

    if (tabState === TabsTextState.DONE) {
      return <GoAIcon type="checkmark" theme="filled" size="small" />;
    }

    return '';
  }, []);

  const steppersProps = useMemo(
    () => [
      {
        text: organizationFormStepperTitles.primary,
        icon: getTabIcon(primary.tabText),
        clickHandler: clickHandler(OrganizationFormStepperKeys.PRIMARY, organizationFormStepperPaths.primary),
        className: '',
        tabClassName: primary.tab,
        textClassName: primary.tabText,
      },
      {
        text: organizationFormStepperTitles.files,
        icon: getTabIcon(files.tabText),
        clickHandler: clickHandler(OrganizationFormStepperKeys.FILES, organizationFormStepperPaths.files),
        className: '',
        tabClassName: files.tab,
        textClassName: files.tabText,
      },
      {
        text: organizationFormStepperTitles.firstUser,
        icon: getTabIcon(firstUser.tabText),
        clickHandler: clickHandler(OrganizationFormStepperKeys.FIRST_USER, organizationFormStepperPaths.firstUser),
        className: '',
        tabClassName: firstUser.tab,
        textClassName: firstUser.tabText,
      },
      {
        text: organizationFormStepperTitles.review,
        icon: getTabIcon(review.tabText),
        clickHandler: clickHandler(OrganizationFormStepperKeys.REVIEW, organizationFormStepperPaths.review),
        className: '',
        tabClassName: review.tab,
        textClassName: review.tabText,
      },
    ],
    [
      getTabIcon,
      primary.tabText,
      primary.tab,
      clickHandler,
      firstUser.tabText,
      firstUser.tab,
      files.tabText,
      files.tab,
      review.tabText,
      review.tab,
    ],
  );

  return useMemo(() => {
    if (isAuthenticated) {
      return steppersProps.map((val) => (
        <Stepper
          key={val.text}
          text={val.text}
          icon={val.icon}
          clickHandler={val.clickHandler}
          className={val.className}
          tabClassName={val.tabClassName}
          textClassName={val.textClassName}
        />
      ));
    }

    return '';
  }, [isAuthenticated, steppersProps]);
};

export default useFormSteppers;
