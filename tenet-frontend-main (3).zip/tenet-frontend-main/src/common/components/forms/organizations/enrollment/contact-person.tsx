import { GoABlock, GoAButton, GoADivider, GoAFormItem, GoAInput, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useSubmitContactPerson from './hooks/use-contact-person-hook';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import OrganizationContactCard from './contact-person-card';

export const ContactPersonForm = observer(() => {
  const {
    loading,
    contactSubmitHandler,
    handleSubmit,
    errors,
    getValues,
    addContactPerson,
    onChangeHandler,
    contactPersons,
    formsFields,
    editContact,
    removeContact,
  } = useSubmitContactPerson();

  const { contactName, contactRole, phoneNumber, extension, emailAddress } = formsFields;

  return (
    <form className="organization-create-form">
      <GoABlock direction="column">
        <GoABlock>
          <GoAFormItem error={errors.contactName?.message} label="Name of the contact">
            <GoAInput
              name={contactName}
              onChange={onChangeHandler}
              type="text"
              id={contactName}
              value={getValues(contactName)}
              width="576px"
            />
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="m" />
        <GoABlock>
          <GoAFormItem error={errors.contactRole?.message} label="Role">
            <GoAInput
              name={contactRole}
              onChange={onChangeHandler}
              type="text"
              id={contactRole}
              value={getValues(contactRole)}
              width="576px"
            />
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="m" />
        <GoABlock gap="s">
          <GoAFormItem error={errors.phoneNumber?.message} label="Phone Number">
            <GoAInput
              name={phoneNumber}
              onChange={onChangeHandler}
              type="text"
              id={phoneNumber}
              value={getValues(phoneNumber)}
              leadingContent="+1"
              width="244px"
            />
          </GoAFormItem>
          <GoASpacer hSpacing="m" />
          <GoAFormItem error={errors.extension?.message} label="Ext" requirement="optional">
            <GoAInput
              name={extension}
              onChange={onChangeHandler}
              type="text"
              id={extension}
              value={getValues(extension)}
              width="109px"
            />
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="m" />
        <GoABlock>
          <GoAFormItem error={errors.emailAddress?.message} label="Email Address">
            <GoAInput
              name={emailAddress}
              onChange={onChangeHandler}
              type="text"
              id={emailAddress}
              value={getValues(emailAddress)}
              width="397px"
            />
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="m" />
        <GoABlock>
          <GoAButton type="secondary" onClick={handleSubmit(addContactPerson)}>
            Add contact person
          </GoAButton>
        </GoABlock>
        <div className="organization-form-divider">
          <GoADivider mt="l" mb="l" />
        </div>

        {contactPersons?.length
          ? contactPersons.map((contact, index) => {
              return (
                // eslint-disable-next-line react/no-array-index-key
                <GoABlock key={index}>
                  <OrganizationContactCard
                    contactPerson={contact}
                    editContact={editContact}
                    removeContact={removeContact}
                  />
                </GoABlock>
              );
            })
          : undefined}
        <GoASpacer vSpacing="m" />
        <div className="organization-form-buttons">
          <GoAButton type="secondary" onClick={() => {}} leadingIcon="arrow-back">
            <span className="client-bold-600">Back:</span> Primary Detail
          </GoAButton>
          <GoAButton type="primary" onClick={contactSubmitHandler} trailingIcon={loading ? undefined : 'arrow-forward'}>
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span>Next:</span> Delivery Location
              </>
            )}
          </GoAButton>
        </div>
      </GoABlock>
    </form>
  );
});
