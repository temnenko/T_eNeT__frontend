import { useEffect, useMemo } from 'react';

import useLoadOrganization from './use-load-organization.hook';
import { useNavigateOrganizationStepper } from './use-navigate-organization-stepper';
import { OrganizationFormStepperKeys } from '../../../../../../types/organization-forms';

export const useOrganizationEnrollReview = () => {
  const { organization } = useLoadOrganization();
  const { setActiveStep } = useNavigateOrganizationStepper();

  useEffect(() => {
    setActiveStep(OrganizationFormStepperKeys.REVIEW);
  }, [setActiveStep]);

  return useMemo(() => {
    if (!organization) {
      return { cards: [], organization: null };
    }
    const contacts = organization?.contacts;

    const cards = [
      {
        title: 'Primary details',
        data: [
          {
            label: 'Operating name',
            value: organization?.operatingName,
          },
          {
            label: 'Reporting legal name',
            value: organization?.legalName,
          },
          {
            label: 'Main business email',
            value: organization?.emailAddress,
          },
          {
            label: 'Website',
            value: organization?.website,
          },
        ],
      },
      {
        title: 'Contact person',
        data: contacts?.length
          ? [
              ...contacts.map((c) => {
                return {
                  value: c.name,
                };
              }),
            ]
          : [
              {
                label: '',
                value: '',
              },
            ],
      },
      {
        title: 'Delivery location',
        data: [
          {
            label: 'Disabiliy',
            value: 'disability',
          },
        ],
      },
    ];
    return { cards, organization };
  }, [organization]);
};
