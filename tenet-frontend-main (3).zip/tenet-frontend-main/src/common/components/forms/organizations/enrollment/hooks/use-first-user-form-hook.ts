import { useForm } from 'react-hook-form';
import { useCallback, useEffect, useState } from 'react';
import { AxiosError } from 'axios';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { Organization } from '../../../../../../types/organization';
import { useNavigateOrganizationStepper } from './use-navigate-organization-stepper';
import { OrganizationFormStepperKeys } from '../../../../../../types/organization-forms';
import useLoadOrganization from './use-load-organization.hook';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';

type OrganizationFirstUserFormData = {
  firstUserName: string;
  firstUserEmail: string;
};

type OrganizationFirstUserFormDataNames = 'firstUserName' | 'firstUserEmail';

export const useFirstUserHook = () => {
  const { organization } = useLoadOrganization();
  const {
    organizationEnrollmentStore: { orgWatch, watchOrg, retrieveOrg, updateOrganization },
  } = useStore();
  const [loading, setLoading] = useState(false);
  const { setActiveStep, goToNextStep, goToPreviousStep } = useNavigateOrganizationStepper();
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});

  const emailRegex = /^\S+@\S+\.\S+$/;

  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    reset,
    formState: { errors },
  } = useForm<OrganizationFirstUserFormData>({
    mode: 'onSubmit',
  });

  const { name: firstUserName } = register('firstUserName', { required: 'Name is required' });
  const { name: firstUserEmail } = register('firstUserEmail', {
    required: 'Email is required',
    validate: (value) => {
      if (value && !emailRegex.test(value)) {
        return 'Invalid email address';
      }
      return true;
    },
  });

  useEffect(() => {
    setActiveStep(OrganizationFormStepperKeys.FIRST_USER);
    if (orgWatch || organization) {
      reset({
        firstUserName: retrieveOrg(firstUserName) ?? (organization?.firstUserName || ''),
        firstUserEmail: retrieveOrg(firstUserEmail) ?? (organization?.firstUserEmail || ''),
      });
    }
  }, [firstUserEmail, firstUserName, orgWatch, organization, reset, retrieveOrg, setActiveStep, setValue]);

  const firstUserFormSubmitHandler = useCallback(async () => {
    const payload: Partial<Organization> = {
      firstUserName: getValues('firstUserName')?.trim(),
      firstUserEmail: getValues('firstUserEmail')?.trim()?.toLowerCase(),
      id: organization!.id,
    };
    setLoading(true);
    try {
      await updateOrganization(payload as Organization)
        .then(() => {
          goToNextStep(organization!.id);
        })
        .finally(() => {
          setLoading(false);
        });
    } catch (e) {
      setLoading(false);
      if ((e as AxiosError).response?.status === 400) {
        setRequestError({
          isUserError: true,
          message:
            'The email address you entered is already in use. Please use a different email address or contact support if you believe this is an error.',
          onDismiss: () => setRequestError({}),
        });
      } else {
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
      }
      // eslint-disable-next-line no-console
      console.error(e);
    }
  }, [getValues, goToNextStep, organization, updateOrganization, requestErrorHandler]);

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as OrganizationFirstUserFormDataNames, value);
      watchOrg(name, value);
    },
    [setValue, watchOrg],
  );

  const previousButtonHandler = useCallback(() => {
    goToPreviousStep(organization!.id);
  }, [goToPreviousStep, organization]);

  return {
    errors,
    organization,
    firstUserName,
    firstUserEmail,
    loading,
    getValues,
    handleSubmit,
    onChangeHandler,
    firstUserFormSubmitHandler,
    previousButtonHandler,
    requestError,
  };
};
