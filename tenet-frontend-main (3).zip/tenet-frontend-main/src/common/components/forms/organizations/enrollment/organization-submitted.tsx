import { GoABlock, GoAButton, GoAIcon, GoASpacer } from '@abgov/react-components';
import { useNavigate, useParams } from 'react-router-dom';

export function OrganizationSubmitted() {
  const { id: organizationId } = useParams<{ id: string }>();
  const navigate = useNavigate();

  return (
    <GoABlock direction="column" gap="2xs" alignment="center">
      <GoASpacer vSpacing="3xl" />
      <span className="circle-175">
        <GoAIcon type="paper-plane" size="large" />
      </span>
      <GoASpacer vSpacing="xl" />
      <center className="submitted-text">
        An invite with instructions has been sent to the contact person. The organization will be activated once the
        contact person logs into TENET with their Alberta.ca account credentials.
      </center>
      <GoASpacer vSpacing="2xl" />
      <GoAButton size="compact" onClick={() => navigate(`/organizations/${organizationId}`)}>
        {`Go to organizations's profile`}
      </GoAButton>
      <GoASpacer vSpacing="2xl" />
    </GoABlock>
  );
}
