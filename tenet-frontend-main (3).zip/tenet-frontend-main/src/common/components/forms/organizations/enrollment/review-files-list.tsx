import { GoABlock, GoAButton, GoAContainer, GoASpacer, GoATable } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { format } from 'date-fns';
import { useOrganizationReviewEdit } from './hooks/use-organization-review-edit.hook';
import { OrganizationFormStepperKeys } from '../../../../../types/organization-forms';
import { Upload } from '../../../../../types/files';
import { useStore } from '../../../../../hooks/use-store.hook';
import { toIsoDate } from '../../../../../utils/date.util';

interface UploadFiles {
  files: Upload[];
}
function FileListView({ files }: UploadFiles) {
  return (
    <GoATable width="100%">
      <tbody>
        {files?.length &&
          [...files].map((file) => {
            return (
              <tr key={`${file.file.name}-${file.createdAt}`}>
                <td style={{ color: '#0070C4', fontWeight: '400', lineHeight: '28px', width: '40%' }}>
                  {file.file.name}
                </td>
                <td style={{ width: '20%' }}>{file.fileType}</td>
                <td style={{ width: '40%' }}>{}</td>
              </tr>
            );
          })}
      </tbody>
    </GoATable>
  );
}

export const ReviewFilesList = observer(() => {
  const {
    partnerNumber,
    jumpToStep,
    selectedOrganization,
    corporateIdentityNumber,
    liabilityPolicyExpiresOn,
    lobbyistCheckDate,
    wcbVerifiedOn,
    assessmentCompletedOn,
  } = useOrganizationReviewEdit();

  const {
    organizationEnrollmentStore: {
      corporateIdentityDocuments,
      lobbyistCheckProof,
      wcbVerificationProof,
      liabilityPolicyProof,
      assessmentResult,
    },
  } = useStore();

  const actions = (
    <GoAButton
      type="tertiary"
      size="compact"
      onClick={() => jumpToStep(OrganizationFormStepperKeys.FILES, selectedOrganization!.id)}
      disabled={false}
    >
      <span style={{ color: 'white' }}>Edit</span>
    </GoAButton>
  );
  return (
    <GoAContainer heading="Compliance" accent="thick" actions={actions} padding="compact">
      <GoABlock direction="column">
        <GoABlock gap="none">
          <div className="client-review-card-label">
            <span className="color-interactive">Business partner number</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">{partnerNumber}</span>
          </div>
        </GoABlock>
        <GoABlock gap="none">
          <div className="client-review-card-label">
            <span className="color-interactive">Corporate identity number</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">{corporateIdentityNumber}</span>
          </div>
        </GoABlock>
        {corporateIdentityDocuments?.length ? <FileListView files={corporateIdentityDocuments} /> : undefined}
      </GoABlock>
      <GoASpacer vSpacing="l" />
      <GoABlock direction="column">
        <GoABlock gap="none">
          <div className="client-review-card-label">
            <span className="color-interactive">Lobbyist check date</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">
              {lobbyistCheckDate ? format(toIsoDate(lobbyistCheckDate), 'MMM d, yyyy') : ''}
            </span>
          </div>
        </GoABlock>
        {lobbyistCheckProof?.length ? <FileListView files={lobbyistCheckProof} /> : undefined}
      </GoABlock>
      <GoASpacer vSpacing="l" />
      <GoABlock direction="column">
        <GoABlock gap="none">
          <div className="client-review-card-label">
            <span className="color-interactive">WCB verified on</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">
              {wcbVerifiedOn ? format(toIsoDate(wcbVerifiedOn), 'MMM d, yyyy') : ''}
            </span>
          </div>
        </GoABlock>
        {wcbVerificationProof?.length ? <FileListView files={wcbVerificationProof} /> : undefined}
      </GoABlock>
      <GoASpacer vSpacing="l" />
      <GoABlock direction="column">
        <GoABlock gap="none">
          <div className="client-review-card-label">
            <span className="color-interactive">Policy expires on</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">
              {liabilityPolicyExpiresOn ? format(toIsoDate(liabilityPolicyExpiresOn), 'MMM d, yyyy') : ''}
            </span>
          </div>
        </GoABlock>
        {liabilityPolicyProof?.length ? <FileListView files={liabilityPolicyProof} /> : undefined}
      </GoABlock>
      <GoASpacer vSpacing="l" />
      <GoABlock direction="column">
        <GoABlock gap="none">
          <div className="client-review-card-label">
            <span className="color-interactive">Assessment completed on</span>
          </div>
          <div className="client-review-card-value">
            <span className="client-bold-600">
              {assessmentCompletedOn ? format(toIsoDate(assessmentCompletedOn) ?? '', 'MMM d, yyyy') : ''}
            </span>
          </div>
        </GoABlock>
        {assessmentResult?.length ? <FileListView files={assessmentResult} /> : undefined}
      </GoABlock>
      <GoASpacer vSpacing="l" />
    </GoAContainer>
  );
});
