import { observer } from 'mobx-react-lite';
import { GoABlock, GoAButton, GoAButtonGroup, GoAFormItem, GoAInput, GoASpacer } from '@abgov/react-components';
import { usePrimaryDetails } from './hooks/use-primary-details.hook';
import { useFormatPhoneInput } from '../../../../../hooks/use-format-phone-input.hook';

interface Props {
  isModal?: boolean;
  hideModal?: () => void;
}

export const PrimaryDetails = observer(({ isModal, hideModal }: Props) => {
  const {
    errors,
    getValues,
    handleSubmit,
    operatingName,
    registeredLegalName,
    mainBusinessEmail,
    website,
    partnerNumber,
    phoneNumber,
    organizationPrimaryDetailsSubmitHandler,
    onChangeHandler,
    watch,
  } = usePrimaryDetails(!!isModal, hideModal);
  const formatPhoneInput = useFormatPhoneInput();

  return (
    <form className="stepper-form-container">
      <GoAFormItem label="Operating name" error={errors.operatingName?.message as unknown as string}>
        <GoAInput
          onChange={onChangeHandler}
          name="operatingName"
          width={isModal ? '50%' : '100%'}
          value={getValues(operatingName) as string}
        />
      </GoAFormItem>
      <GoASpacer vSpacing="m" />
      <GoAFormItem label="Legal name" error={errors.registeredLegalName?.message as unknown as string}>
        <GoAInput
          onChange={onChangeHandler}
          name="registeredLegalName"
          width={isModal ? '50%' : '100%'}
          value={getValues(registeredLegalName) as string}
        />
      </GoAFormItem>
      <GoASpacer vSpacing="m" />

      <GoAFormItem
        label="Business Partner Number"
        helpText="You can find this information in 1GX"
        error={errors.partnerNumber?.message as unknown as string}
      >
        <GoAInput
          onChange={onChangeHandler}
          name="partnerNumber"
          width="23.32rem"
          value={getValues(partnerNumber) as string}
        />
      </GoAFormItem>
      <GoASpacer vSpacing="m" />

      <GoAFormItem label="Main phone number" error={errors.phoneNumber?.message as unknown as string}>
        <GoAInput
          onChange={onChangeHandler}
          name="phoneNumber"
          width="23.32rem"
          value={formatPhoneInput(watch(phoneNumber))}
        />
      </GoAFormItem>
      <GoASpacer vSpacing="m" />

      <GoAFormItem
        label="Main business email"
        requirement="optional"
        error={errors.mainBusinessEmail?.message as unknown as string}
      >
        <GoAInput
          onChange={onChangeHandler}
          name="mainBusinessEmail"
          width="23.32rem"
          value={getValues(mainBusinessEmail) as string}
        />
      </GoAFormItem>
      <GoASpacer vSpacing="m" />
      <GoAFormItem label="Website" requirement="optional" error={errors.website?.message as unknown as string}>
        <GoAInput onChange={onChangeHandler} name="website" width="23.32rem" value={getValues(website) as string} />
      </GoAFormItem>
      <GoASpacer vSpacing="2xl" />
      {isModal ? (
        <GoAButtonGroup alignment="start">
          <GoAButton onClick={handleSubmit(organizationPrimaryDetailsSubmitHandler)}>Save</GoAButton>
          <GoAButton type="secondary" onClick={hideModal}>
            Cancel
          </GoAButton>
        </GoAButtonGroup>
      ) : (
        <GoABlock>
          <div>
            <GoAButton
              type="submit"
              onClick={handleSubmit(organizationPrimaryDetailsSubmitHandler)}
              trailingIcon="arrow-forward"
            >
              <span>Next:</span> Compliance
            </GoAButton>
          </div>
        </GoABlock>
      )}
    </form>
  );
});
