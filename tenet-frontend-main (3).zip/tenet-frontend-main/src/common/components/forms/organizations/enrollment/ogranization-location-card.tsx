import { GoABlock, GoAButton, GoAContainer, GoASpacer } from '@abgov/react-components';

import { useFormatPhoneNumber } from '../../../../../hooks/use-format-phone-number';

interface Props {
  location: {
    id: string;
    name: string;
    street: string;
    unit?: string;
    city: string;
    province: string;
    postalCode: string;
    phoneNumber: string;
    email: string;
    isPrimaryLocation?: boolean;
  };
  removeLocation: (id: string) => void;
}

export default function OrganizationLocationCard({ location, removeLocation }: Props) {
  const formatPhoneNumber = useFormatPhoneNumber();

  return (
    <>
      <GoASpacer vSpacing="m" />
      <GoAContainer accent="thin" mb="none" type="info">
        <GoABlock direction="column" gap="none">
          <span className="organization-card-text-medium">{`${location.name} ${location.city}`}</span>
          <span className="organization-card-text-small">{`${location.street}, ${location.city} ${location.province} ${location.postalCode}`}</span>
          <span className="organization-card-text-small">{`${formatPhoneNumber(location.phoneNumber)}`}</span>
          <span className="organization-card-text-small">{location.email}</span>
          <GoASpacer vSpacing="l" />
          <GoABlock>
            {!location.isPrimaryLocation && (
              <GoAButton
                type="tertiary"
                leadingIcon="trash"
                onClick={() => {
                  removeLocation(location.id);
                }}
              >
                remove
              </GoAButton>
            )}
          </GoABlock>
        </GoABlock>
      </GoAContainer>
    </>
  );
}
