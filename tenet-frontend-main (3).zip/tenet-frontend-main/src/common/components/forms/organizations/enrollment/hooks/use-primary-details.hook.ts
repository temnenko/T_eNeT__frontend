/* eslint-disable no-nested-ternary */
import { useForm } from 'react-hook-form';
import { useCallback, useEffect } from 'react';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { Organization } from '../../../../../../types/organization';
import { useNavigateOrganizationStepper } from './use-navigate-organization-stepper';
import useLoadOrganization from './use-load-organization.hook';
import { OrganizationFormStepperKeys } from '../../../../../../types/organization-forms';

type OrganizationPrimaryDetailsFormData = {
  operatingName: string;
  registeredLegalName: string;
  mainBusinessEmail: string;
  website: string;
  partnerNumber: string;
  phoneNumber: string;
};

type OrganizationPrimaryDetailsFormDataNames =
  | 'operatingName'
  | 'registeredLegalName'
  | 'mainBusinessEmail'
  | 'website'
  | 'partnerNumber'
  | 'phoneNumber';

export const usePrimaryDetails = (isModal: boolean, hideModal?: () => void) => {
  const { organization } = useLoadOrganization();
  const {
    organizationEnrollmentStore: { orgWatch, watchOrg, retrieveOrg, updateOrganization, createOrganization },
    organizationStore: { getOrganizationById, selectedOrganization },
  } = useStore();
  const { setActiveStep, goToNextStep } = useNavigateOrganizationStepper();

  const emailRegex = /^\S+@\S+\.\S+$/;
  const urlRegex = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/;

  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    reset,
    formState: { errors },
    watch,
  } = useForm<OrganizationPrimaryDetailsFormData>({
    mode: 'onSubmit',
  });

  const { name: operatingName } = register('operatingName', { required: 'Operating name is required' });
  const { name: registeredLegalName } = register('registeredLegalName', { required: 'Legal name is required' });
  const { name: partnerNumber } = register('partnerNumber', {
    required: 'Partner number is required',
    validate: (value) => {
      if (!/^\d+$/.test(value?.trim())) {
        return 'Partner number must contain only numbers';
      }
      return true;
    },
  });
  const { name: phoneNumber } = register('phoneNumber', {
    required: 'Phone number is required',
    validate: (value) => {
      if (!/^\(?\d{3}\)?([\s])?\d{3}([-])?\d{4}$/.test(value?.trim())) {
        return 'Phone number must be valid';
      }
      return true;
    },
  });
  const { name: mainBusinessEmail } = register('mainBusinessEmail', {
    validate: (value) => {
      if (value && !emailRegex.test(value)) {
        return 'Invalid email address';
      }
      return true;
    },
  });
  const { name: website } = register('website', {
    validate: (value) => {
      if (value && !urlRegex.test(value)) {
        return 'Invalid website address';
      }
      return true;
    },
  });

  useEffect(() => {
    if (orgWatch || organization) {
      reset({
        operatingName: isModal
          ? selectedOrganization?.operatingName
          : (retrieveOrg('operatingName') ?? (organization?.operatingName || '')),
        registeredLegalName: isModal
          ? selectedOrganization?.legalName
          : (retrieveOrg('registeredLegalName') ?? (organization?.legalName || '')),
        partnerNumber: isModal
          ? selectedOrganization?.partnerNumber
          : (retrieveOrg('partnerNumber') ?? (organization?.partnerNumber || '')),
        phoneNumber: isModal
          ? selectedOrganization?.phoneNumber
          : (retrieveOrg('phoneNumber') ?? (organization?.phoneNumber || '')),
        mainBusinessEmail: isModal
          ? selectedOrganization?.emailAddress
          : (retrieveOrg('mainBusinessEmail') ?? (organization?.emailAddress || '')),
        website: isModal ? selectedOrganization?.website : (retrieveOrg('website') ?? (organization?.website || '')),
      });
    }
    setActiveStep(OrganizationFormStepperKeys.PRIMARY);
  }, [
    isModal,
    mainBusinessEmail,
    operatingName,
    orgWatch,
    organization,
    registeredLegalName,
    reset,
    retrieveOrg,
    selectedOrganization?.emailAddress,
    selectedOrganization?.legalName,
    selectedOrganization?.operatingName,
    selectedOrganization?.partnerNumber,
    selectedOrganization?.phoneNumber,
    selectedOrganization?.website,
    setActiveStep,
    setValue,
    website,
  ]);

  const organizationPrimaryDetailsSubmitHandler = useCallback(async () => {
    const payload: Partial<Organization> = {
      operatingName: getValues('operatingName')?.trim(),
      legalName: getValues('registeredLegalName')?.trim(),
      emailAddress: getValues('mainBusinessEmail')?.trim() || '',
      website: getValues('website')?.trim() || '',
      partnerNumber: getValues('partnerNumber')?.trim(),
      phoneNumber: getValues('phoneNumber')?.replace(/\D/g, '').trim(),
    };
    if (!isModal) {
      if (organization?.id) {
        await updateOrganization({ id: organization.id, ...payload } as Organization);
        goToNextStep(organization.id);
      } else {
        const created = await createOrganization(payload as Organization);
        if (created?.id) {
          goToNextStep(created.id);
        }
      }
    } else {
      await updateOrganization({ id: organization?.id, ...payload } as Organization);
      if (organization) {
        await getOrganizationById(organization.id);
      }
      reset();
      hideModal!();
    }
  }, [
    createOrganization,
    getOrganizationById,
    getValues,
    goToNextStep,
    hideModal,
    isModal,
    organization,
    reset,
    updateOrganization,
  ]);

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      const sanitizedValue = name === website ? value.toLowerCase() : value;
      setValue(name as OrganizationPrimaryDetailsFormDataNames, sanitizedValue);
      watchOrg(name, sanitizedValue);
    },
    [setValue, watchOrg, website],
  );

  return {
    errors,
    getValues,
    handleSubmit,
    operatingName,
    registeredLegalName,
    mainBusinessEmail,
    website,
    organization,
    partnerNumber,
    phoneNumber,
    organizationPrimaryDetailsSubmitHandler,
    onChangeHandler,
    watch,
  };
};
