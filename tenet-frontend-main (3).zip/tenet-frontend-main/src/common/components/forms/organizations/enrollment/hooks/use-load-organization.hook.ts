/* eslint-disable @typescript-eslint/no-unused-expressions */
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from '../../../../../../hooks/use-store.hook';

const useLoadOrganization = () => {
  const { id } = useParams<{ id: string }>();
  const {
    organizationEnrollmentStore: { selectedOrganization, getOrganizationById },
  } = useStore();

  useEffect(() => {
    const activeOrganizationId = id ?? selectedOrganization?.id;

    const fetchOrganization = async () => {
      if (activeOrganizationId) {
        await getOrganizationById(activeOrganizationId);
      }
    };
    fetchOrganization();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  return {
    organization: selectedOrganization,
    isLoading: !selectedOrganization,
  };
};

export default useLoadOrganization;
