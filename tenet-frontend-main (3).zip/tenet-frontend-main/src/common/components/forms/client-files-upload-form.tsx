import { GoAFileUploadInput, GoAFormItem, GoANotification, GoASpacer, GoATable } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useEffect } from 'react';
import { ClientFilesUploadRow } from './client-files-upload-row';
import useSubmitClientFileUploads from './hooks/use-submit-file-uploads.hook';
import { Upload } from '../../../types/files';
import { InvalidFileUploadError } from '../../../types/errors/invalid-file-upload.error';

type Props = {
  formItemLabel: string;
  canUploadClientFiles: boolean;
  newUploadsAvailable?: (uploads: Upload[]) => void;
  downloadFile: (fileId: string, filename: string, filesize: number) => void;
  invalidUploadError?: InvalidFileUploadError | null;
};

export const ClientFilesUploadForm = observer(
  ({ formItemLabel, newUploadsAvailable, downloadFile, canUploadClientFiles, invalidUploadError }: Props) => {
    const {
      uploads,
      progressList,
      uploadFile,
      onFileTypeChange,
      fileDeletedSuccessfully,
      fileBeingDeleted,
      setFileDeletedSuccessfully,
      uploadError,
      setUploadError,
      canDeleteFiles,
      openDeleteConfirmationDialog,
    } = useSubmitClientFileUploads();

    useEffect(() => {
      if (newUploadsAvailable) {
        newUploadsAvailable(uploads);
      }
    }, [newUploadsAvailable, uploads]);

    return (
      <form>
        {canUploadClientFiles && (
          <GoAFormItem label={formItemLabel} requirement="optional">
            <GoAFileUploadInput onSelectFile={uploadFile} maxFileSize="10MB" />
          </GoAFormItem>
        )}
        <GoASpacer vSpacing="l" />
        {fileDeletedSuccessfully && (
          <GoANotification type="information" onDismiss={() => setFileDeletedSuccessfully(false)}>
            File deleted successfully
          </GoANotification>
        )}
        {uploadError && (
          <>
            <GoASpacer vSpacing="l" />
            <GoANotification type="important" onDismiss={() => setUploadError(null)}>
              {uploadError}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
        <GoATable>
          <thead>
            <tr>
              <th data-testid="clientCreationUploadedFiles">Files</th>
              <th data-testid="clientCreationFileType">Type</th>
              <th data-testid="clientCreationFileUser">User</th>
              <th data-testid="clientCreationFilesDateAdded">Date added</th>
              <th>{}</th>
              <th>{}</th>
            </tr>
          </thead>
          <tbody data-testid="clientCreationUploadedFilesTableBody">
            <ClientFilesUploadRow
              uploads={uploads}
              progressList={progressList}
              deleteHandler={openDeleteConfirmationDialog}
              onFileTypeChange={onFileTypeChange}
              fileBeingDeleted={fileBeingDeleted}
              downloadFile={downloadFile}
              canDeleteFiles={canDeleteFiles}
              errorMessage={invalidUploadError?.message}
            />
          </tbody>
        </GoATable>
        <GoASpacer vSpacing="2xl" />
      </form>
    );
  },
);
