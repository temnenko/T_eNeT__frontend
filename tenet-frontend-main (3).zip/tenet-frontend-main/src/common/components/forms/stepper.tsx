import { observer } from 'mobx-react-lite';

type Props = {
  text: string;
  icon: JSX.Element | string;
  clickHandler: () => void;
  className: string;
  tabClassName: string;
  textClassName: string;
};

export const Stepper = observer(({ text, icon, clickHandler, className, tabClassName, textClassName }: Props) => {
  return (
    <li className={className} role="presentation">
      <button type="button" className="nav-link" onClick={clickHandler}>
        <span className={`round-tab ${tabClassName}`}>{icon}</span>
        <span className={textClassName}>{text}</span>
      </button>
    </li>
  );
});
