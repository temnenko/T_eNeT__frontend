import { renderHook } from '@testing-library/react';
import useValidateContactForm from './use-validate-contact-form.hook';

interface ValidateFunctions {
  validateStreetAddress: (value: string) => boolean | string;
  validateCity: (value: string) => boolean | string;
  validateCountry: (value: string) => boolean | string;
  validateProvince: (value: string) => boolean | string;
  validatePostalCode: (value: string, province: string, country: string) => boolean | string;
}

describe('useValidateContactForm', () => {
  let validate: ValidateFunctions;

  beforeEach(() => {
    const { result } = renderHook(() => useValidateContactForm());
    validate = result.current;
  });

  describe('validateStreetAddress', () => {
    it('validates "No Address" as valid', () => {
      expect(validate.validateStreetAddress('No Address')).toBe(true);
    });

    it('returns error for too short addresses', () => {
      expect(validate.validateStreetAddress('A')).toBe('Enter a valid street address.');
    });

    it('returns error for too long addresses', () => {
      const longAddress = 'A'.repeat(151);
      expect(validate.validateStreetAddress(longAddress)).toBe('Enter a valid street address.');
    });

    it('returns error for non-alphanumeric characters', () => {
      expect(validate.validateStreetAddress('123 Main St.!')).toBe('Enter a valid street address.');
    });

    it('validates correct address as true', () => {
      expect(validate.validateStreetAddress('123 Main St')).toBe(true);
    });
  });

  describe('validateCity', () => {
    it('returns error for too short city names', () => {
      expect(validate.validateCity('AB')).toBe('Enter a valid city name.');
    });

    it('returns error for too long city names', () => {
      const longCity = 'A'.repeat(101);
      expect(validate.validateCity(longCity)).toBe('Enter a valid city name.');
    });

    it('validates correct city name as true', () => {
      expect(validate.validateCity('Toronto')).toBe(true);
    });
  });

  describe('validateCountry', () => {
    it('returns error for too short country names', () => {
      expect(validate.validateCountry('AB')).toBe('Enter a valid country name.');
    });

    it('returns error for too long country names', () => {
      const longCountry = 'A'.repeat(101);
      expect(validate.validateCountry(longCountry)).toBe('Enter a valid country name.');
    });

    it('returns error for non-alphanumeric characters', () => {
      expect(validate.validateCountry('Cana%da')).toBe('Enter a valid country name.');
    });

    it('validates correct country name as true', () => {
      expect(validate.validateCountry('Canada')).toBe(true);
    });
  });

  describe('validateProvince', () => {
    it('returns error for too short province names', () => {
      expect(validate.validateProvince('A')).toBe('Enter a valid province name.');
    });

    it('returns error for too long province names', () => {
      const longProvince = 'A'.repeat(51);
      expect(validate.validateProvince(longProvince)).toBe('Enter a valid province name.');
    });

    it('validates correct province name as true', () => {
      expect(validate.validateProvince('Ontario')).toBe(true);
    });
  });

  describe('validatePostalCode', () => {
    it('accepts "no postal code" as valid', () => {
      expect(validate.validatePostalCode('no postal code', '', '')).toBe(true);
    });

    it('returns error if postal code and province do not match', () => {
      expect(validate.validatePostalCode('A1A 1A1', 'Ontario', 'Canada')).toBe(
        'The postal code and the province do not match.',
      );
    });

    it('validates correct postal code for Ontario', () => {
      expect(validate.validatePostalCode('K1A 0B1', 'Ontario', 'Canada')).toBe(true);
    });

    it('returns error for incorrect US postal code format', () => {
      expect(validate.validatePostalCode('1234', '', 'United States')).toBe(
        'The Zip Code for a US address must be 5 or 9 digits. If 9 digits, it must be in the format XXXXX-XXXX.',
      );
    });

    it('validates correct US postal code format', () => {
      expect(validate.validatePostalCode('12345-6789', '', 'United States')).toBe(true);
    });
  });
});
