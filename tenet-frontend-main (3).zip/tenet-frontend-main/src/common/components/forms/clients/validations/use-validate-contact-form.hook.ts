import { useCallback } from 'react';

const useValidateContactForm = () => {
  const validateStreetAddress = useCallback((value: string) => {
    if (value === 'No Address') return true;

    if (value.length < 2 || value.length > 150) return 'Enter a valid street address.';

    const alphanumericRegex = /^[a-z0-9\s]+$/i;
    if (!alphanumericRegex.test(value)) return 'Enter a valid street address.';

    return true;
  }, []);

  const validateCity = useCallback((value: string) => {
    if (value.length < 3 || value.length > 100) return 'Enter a valid city name.';

    return true;
  }, []);

  const validateCountry = useCallback((value: string) => {
    if (value.length < 3 || value.length > 100) {
      return 'Enter a valid country name.';
    }

    const alphanumericRegex = /^[a-z0-9\s]+$/i;
    if (!alphanumericRegex.test(value)) {
      return 'Enter a valid country name.';
    }

    return true;
  }, []);

  const validateProvince = useCallback((value: string) => {
    if (value.length < 2 || value.length > 50) return 'Enter a valid province name.';

    return true;
  }, []);

  const validatePostalCode = useCallback((value: string, province: string, country: string) => {
    if (value?.toLowerCase() === 'no postal code') {
      return true;
    }

    const provinceWatcher = province?.toLowerCase();
    const countryWatcher = country?.toLowerCase();

    const regexMap: { [key: string]: RegExp } = {
      'newfoundland/labrador': /^[Aa]/,
      'nova scotia': /^[Bb]/,
      'new brunswick': /^[Ee]/,
      'prince edward island': /^[Cc]/,
      quebec: /^[GgHhJj]/,
      ontario: /^[KkLlMmNnPp]/,
      manitoba: /^[Rr]/,
      saskatchewan: /^[Ss]/,
      alberta: /^[Tt]/,
      'british columbia': /^[Vv]/,
      yukon: /^[Yy]/,
      'northwest territories': /^[Xx]/,
      nunavut: /^[Xx]/,
    };

    // If Canadian Province
    if (provinceWatcher && regexMap[provinceWatcher] && !regexMap[provinceWatcher].test(value[0])) {
      return 'The postal code and the province do not match.';
    }

    // If US Address
    if (countryWatcher?.toLowerCase() === 'united states') {
      const USPostalCodeRegex = /^(\d{5}(-\d{4})?)$/;
      if (!USPostalCodeRegex.test(value)) {
        return 'The Zip Code for a US address must be 5 or 9 digits. If 9 digits, it must be in the format XXXXX-XXXX.';
      }
    }

    return true;
  }, []);

  return {
    validateStreetAddress,
    validateCity,
    validateCountry,
    validateProvince,
    validatePostalCode,
  };
};

export default useValidateContactForm;
