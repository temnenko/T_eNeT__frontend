import {
  GoABlock,
  GoASpacer,
  GoAFormItem,
  GoARadioGroup,
  GoARadioItem,
  GoAButton,
  GoAInput,
  GoAButtonGroup,
  GoADropdown,
  GoAModal,
  GoACheckbox,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { subYears } from 'date-fns';
import useSubmitEducation from './hooks/use-education-form-hook';
import { Education } from '../../../../../types/client';
import useCancelEducation from '../../../modals/educations/hooks/use-cancel-education.hook';
import { toIsoFormat } from '../../../../../utils/date.util';

interface Props {
  clientId: string;
  education?: Education;
  canEditEducation?: boolean;
}

export const EducationForm = observer(({ clientId, education, canEditEducation }: Props) => {
  const {
    formFields,
    getValues,
    educationSubmitHandler,
    educationCancelHandler,
    onChangeHandler,
    errors,
    modalContent,
    modalVisible,
    handleSubmit,
    isAttendingTraining,
    educationLevelOptions,
    trainingMethodOptions,
    startDateApproximate,
    setStartDateApproximate,
    endDateApproximate,
    setEndDateApproximate,
    personClassificationOptions,
    trainingLocationOptions,
    isTrainingInterferingWithEmployment,
    hideModal,
    completionDate,
    setCompletionApproximate,
    completionApproximate,
    exactCompletionDate,
    receivedCredential,
    educationLocation,
    TrainingLocations,
    credRecognized,
    canHardDelete,
    credAssessed,
    deleteEducationRecordHandler,
  } = useSubmitEducation(clientId, education);
  const { cancelEducationClickHandler } = useCancelEducation(education);

  const {
    levelOfEducation,
    educationalInstitution,
    fieldOfStudy,
    personAttendingTraining,
    startDate,
    exactStartDate,
    expectedEndDate,
    exactEndDate,
    trainingDeliveryMethod,
    personClassification,
    totalHoursPerWeek,
    trainingLocation,
    trainingInterferesWithEmployment,
    credentialReceived,
    reasonForWithdrawal,
    credentialName,
    credentialRecognized,
    credentialAssessed,
    assessmentAgencyName,
    assessmentDate,
    credentialEquivalency,
  } = formFields;

  const title = `${education ? 'Edit' : 'Add'} Education`;

  return (
    <GoAModal maxWidth="1000px" open width="888px" transition="slow" heading={title} onClose={hideModal}>
      {modalVisible && modalContent}
      <div className="relative">
        <form className=" form-modal">
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Level of education</h4>
            <GoAFormItem error={errors.levelOfEducation?.message as unknown as string}>
              <GoADropdown
                name={levelOfEducation}
                value={getValues(levelOfEducation)}
                onChange={(name: string, values: string[] | string) => onChangeHandler(name, values)}
                leadingIcon="search"
                width="824px"
                filterable
                relative
              >
                {educationLevelOptions}
              </GoADropdown>
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Educational Institution</h4>
            <GoAFormItem error={errors.educationalInstitution?.message as unknown as string}>
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={educationalInstitution}
                id={educationalInstitution}
                value={getValues(educationalInstitution)}
                width="824px"
              />
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <GoABlock>
              <h4 className="client-no-padding-no-margin">Field of study (if applicable)</h4>
            </GoABlock>
            <GoAFormItem error={errors.fieldOfStudy?.message as unknown as string} requirement="optional">
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={fieldOfStudy}
                id={fieldOfStudy}
                value={getValues(fieldOfStudy)}
                width="824px"
              />
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Is the person currently attending the training?</h4>
            <GoAFormItem error={errors.personAttendingTraining?.message as unknown as string}>
              <GoARadioGroup
                name={personAttendingTraining}
                value={isAttendingTraining}
                onChange={onChangeHandler}
                orientation="horizontal"
              >
                <GoARadioItem value="true" label="Yes" />
                <GoARadioItem value="false" label="No" />
              </GoARadioGroup>
            </GoAFormItem>
          </GoABlock>
          {isAttendingTraining !== '' && (
            <>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Start date</h4>
                <GoABlock>
                  <GoAFormItem error={errors.startDate?.message as unknown as string}>
                    <GoAInput
                      type="date"
                      name={startDate}
                      value={getValues(startDate) ? toIsoFormat(getValues(startDate)!) : undefined}
                      onChange={onChangeHandler}
                      min={toIsoFormat(subYears(new Date(), 50))}
                      max="9999-12-31"
                    />
                  </GoAFormItem>
                  <GoASpacer hSpacing="xs" />
                  <GoACheckbox
                    name="exactStartDate"
                    text="This date is approximate."
                    onChange={(name: string, checked: boolean) => {
                      setStartDateApproximate(checked);
                      onChangeHandler(name, checked);
                    }}
                    value={getValues(exactStartDate)}
                    checked={getValues(exactStartDate) ?? startDateApproximate}
                  />
                </GoABlock>
              </GoABlock>
            </>
          )}
          {isAttendingTraining === 'true' && (
            <GoABlock direction="column">
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Expected end date</h4>
                <GoABlock>
                  <GoAFormItem error={errors.expectedEndDate?.message as unknown as string}>
                    <GoAInput
                      type="date"
                      name={expectedEndDate}
                      value={getValues(expectedEndDate) ? toIsoFormat(getValues(expectedEndDate)!) : undefined}
                      onChange={onChangeHandler}
                      min={toIsoFormat(subYears(new Date(), 50))}
                      max="9999-12-31"
                    />
                  </GoAFormItem>
                  <GoASpacer hSpacing="xs" />
                  <GoACheckbox
                    name="exactEndDate"
                    text="This date is approximate."
                    onChange={(name: string, checked: boolean) => {
                      setEndDateApproximate(checked);
                      onChangeHandler(name, checked);
                    }}
                    value={getValues(exactEndDate)}
                    checked={getValues(exactEndDate) ?? endDateApproximate}
                  />
                </GoABlock>
              </GoABlock>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Training delivery method</h4>
                <GoAFormItem error={errors[trainingDeliveryMethod]?.message as unknown as string}>
                  <GoARadioGroup
                    name={trainingDeliveryMethod}
                    onChange={onChangeHandler}
                    value={getValues(trainingDeliveryMethod)}
                  >
                    {trainingMethodOptions}
                  </GoARadioGroup>
                </GoAFormItem>
              </GoABlock>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Is the person classified as</h4>
                <GoAFormItem error={errors.personClassification?.message as unknown as string}>
                  <GoARadioGroup
                    name={personClassification}
                    value={getValues(personClassification)}
                    onChange={onChangeHandler}
                    orientation="horizontal"
                  >
                    {personClassificationOptions}
                  </GoARadioGroup>
                </GoAFormItem>
              </GoABlock>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <GoABlock>
                  <h4 className="client-no-padding-no-margin">Total hours per week</h4>
                </GoABlock>
                <GoAFormItem error={errors.totalHoursPerWeek?.message as unknown as string}>
                  <GoAInput
                    type="text"
                    onChange={onChangeHandler}
                    name={totalHoursPerWeek}
                    id={totalHoursPerWeek}
                    value={getValues(totalHoursPerWeek)?.toString()}
                    width="824px"
                  />
                </GoAFormItem>
                <span className="client-medium-faint-text">
                  The hours should account for attending class, doing homework or study etc
                </span>
              </GoABlock>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Where is the location of training?</h4>
                <GoAFormItem error={errors[trainingLocation]?.message as unknown as string}>
                  <GoARadioGroup name={trainingLocation} onChange={onChangeHandler} value={getValues(trainingLocation)}>
                    {trainingLocationOptions}
                  </GoARadioGroup>
                </GoAFormItem>
              </GoABlock>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">
                  Is this training going to interfere with the person’s ability to accept full time employment?
                </h4>
                <GoAFormItem error={errors.trainingInterferesWithEmployment?.message as unknown as string}>
                  <GoARadioGroup
                    name={trainingInterferesWithEmployment}
                    value={isTrainingInterferingWithEmployment}
                    onChange={onChangeHandler}
                    orientation="horizontal"
                  >
                    <GoARadioItem value="true" label="Yes" />
                    <GoARadioItem value="false" label="No" />
                  </GoARadioGroup>
                </GoAFormItem>
              </GoABlock>
            </GoABlock>
          )}
          {isAttendingTraining === 'false' && (
            <>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Completion/last attended date</h4>
                <GoABlock>
                  <GoAFormItem error={errors.completionDate?.message as unknown as string}>
                    <GoAInput
                      type="date"
                      name={completionDate}
                      value={getValues(completionDate) ? toIsoFormat(getValues(completionDate)!) : undefined}
                      onChange={onChangeHandler}
                      min={toIsoFormat(subYears(new Date(), 50))}
                      max="9999-12-31"
                    />
                  </GoAFormItem>
                  <GoASpacer hSpacing="xs" />
                  <GoACheckbox
                    name="exactCompletionDate"
                    text="This date is approximate."
                    onChange={(name: string, checked: boolean) => {
                      setCompletionApproximate(checked);
                      onChangeHandler(name, checked);
                    }}
                    value={getValues(exactCompletionDate)}
                    checked={getValues(exactCompletionDate) ?? completionApproximate}
                  />
                </GoABlock>
              </GoABlock>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Credential received?</h4>
                <GoAFormItem error={errors.credentialReceived?.message as unknown as string}>
                  <GoARadioGroup
                    name={credentialReceived}
                    value={receivedCredential}
                    onChange={onChangeHandler}
                    orientation="horizontal"
                  >
                    <GoARadioItem value="true" label="Yes" />
                    <GoARadioItem value="false" label="No" />
                  </GoARadioGroup>
                </GoAFormItem>
              </GoABlock>
            </>
          )}
          {isAttendingTraining === 'false' && receivedCredential === 'false' && (
            <>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <GoABlock>
                  <h4 className="client-no-padding-no-margin">Reason of withdrawal</h4>
                </GoABlock>
                <GoAFormItem error={errors.reasonForWithdrawal?.message as unknown as string}>
                  <GoAInput
                    type="text"
                    onChange={onChangeHandler}
                    name={reasonForWithdrawal}
                    id={reasonForWithdrawal}
                    value={getValues(reasonForWithdrawal)}
                    width="824px"
                  />
                </GoAFormItem>
              </GoABlock>
            </>
          )}
          {receivedCredential === 'true' && (
            <>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <GoABlock>
                  <h4 className="client-no-padding-no-margin">Name of credential</h4>
                </GoABlock>
                <GoAFormItem error={errors.credentialName?.message as unknown as string}>
                  <GoAInput
                    type="text"
                    onChange={onChangeHandler}
                    name={credentialName}
                    id={credentialName}
                    value={getValues(credentialName)}
                    width="824px"
                  />
                </GoAFormItem>
              </GoABlock>
            </>
          )}
          {isAttendingTraining === 'false' && receivedCredential !== '' && (
            <>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Where did this education occur?</h4>
                <GoAFormItem error={errors[trainingLocation]?.message as unknown as string}>
                  <GoARadioGroup name={trainingLocation} onChange={onChangeHandler} value={getValues(trainingLocation)}>
                    {trainingLocationOptions}
                  </GoARadioGroup>
                </GoAFormItem>
              </GoABlock>
            </>
          )}
          {isAttendingTraining === 'false' &&
            (educationLocation === TrainingLocations.IN_CANADA_AND_OUTSIDE_ALBERTA ||
              educationLocation === TrainingLocations.OUTSIDE_CANADA) &&
            receivedCredential === 'true' && (
              <>
                <GoASpacer vSpacing="l" />
                <GoABlock direction="column">
                  <h4 className="client-no-padding-no-margin">
                    Is the credential recognized professionally in Alberta?
                  </h4>
                  <p className="font-smaller">
                    Not all credentials earned in Canada (outside of Alberta) are recognized for professional employment
                    by industries and employers in Alberta. Some professions that require provincial recognition include
                    Journeyman trades, certain healthcare providers, engineers etc.{' '}
                  </p>
                  <GoAFormItem error={errors.credentialRecognized?.message as unknown as string}>
                    <GoARadioGroup
                      name={credentialRecognized}
                      value={credRecognized}
                      onChange={onChangeHandler}
                      orientation="horizontal"
                    >
                      <GoARadioItem value="true" label="Yes" />
                      <GoARadioItem value="false" label="No" />
                    </GoARadioGroup>
                  </GoAFormItem>
                </GoABlock>
              </>
            )}
          {isAttendingTraining === 'false' &&
            educationLocation === TrainingLocations.OUTSIDE_CANADA &&
            receivedCredential === 'true' && (
              <>
                <GoASpacer vSpacing="l" />
                <GoABlock direction="column">
                  <h4 className="client-no-padding-no-margin">Has the credential been assessed?</h4>
                  <GoAFormItem error={errors.credentialAssessed?.message as unknown as string}>
                    <GoARadioGroup
                      name={credentialAssessed}
                      value={credAssessed}
                      onChange={onChangeHandler}
                      orientation="horizontal"
                    >
                      <GoARadioItem value="true" label="Yes" />
                      <GoARadioItem value="false" label="No" />
                    </GoARadioGroup>
                  </GoAFormItem>
                </GoABlock>
              </>
            )}
          {isAttendingTraining === 'false' &&
            educationLocation === TrainingLocations.OUTSIDE_CANADA &&
            receivedCredential === 'true' &&
            credAssessed === 'true' && (
              <>
                <GoASpacer vSpacing="l" />
                <GoABlock direction="column">
                  <GoABlock>
                    <h4 className="client-no-padding-no-margin">
                      Name of assessment agency or professional regulatory body
                    </h4>
                  </GoABlock>
                  <GoAFormItem error={errors.assessmentAgencyName?.message as unknown as string}>
                    <GoAInput
                      type="text"
                      onChange={onChangeHandler}
                      name={assessmentAgencyName}
                      id={assessmentAgencyName}
                      value={getValues(assessmentAgencyName)}
                      width="824px"
                    />
                  </GoAFormItem>
                </GoABlock>
                <GoASpacer vSpacing="l" />
                <GoABlock direction="column">
                  <h4 className="client-no-padding-no-margin">Date of assessment</h4>
                  <GoABlock>
                    <GoAFormItem error={errors.assessmentDate?.message as unknown as string}>
                      <GoAInput
                        type="date"
                        name={assessmentDate}
                        value={getValues(assessmentDate) ? toIsoFormat(getValues(assessmentDate)!) : undefined}
                        onChange={onChangeHandler}
                        min={toIsoFormat(subYears(new Date(), 50))}
                        max="9999-12-31"
                      />
                    </GoAFormItem>
                  </GoABlock>
                </GoABlock>
                <GoASpacer vSpacing="l" />
                <GoABlock direction="column">
                  <GoABlock>
                    <h4 className="client-no-padding-no-margin">Credential general equivalency in Canada</h4>
                  </GoABlock>
                  <GoAFormItem error={errors.credentialEquivalency?.message as unknown as string}>
                    <GoAInput
                      type="text"
                      onChange={onChangeHandler}
                      name={credentialEquivalency}
                      id={credentialEquivalency}
                      value={getValues(credentialEquivalency)}
                      width="824px"
                    />
                  </GoAFormItem>
                </GoABlock>
              </>
            )}
          <GoASpacer vSpacing="l" />
        </form>
        {canEditEducation && (
          <div className="modalfixed">
            <GoABlock>
              <div className="d-flex w-100">
                <div className="flex-grow-1">
                  {canHardDelete
                    ? education && (
                        <>
                          <GoAButton
                            type="tertiary"
                            variant="destructive"
                            leadingIcon="trash"
                            onClick={deleteEducationRecordHandler}
                          >
                            Delete Education
                          </GoAButton>
                          <div className="delete-employment-advice-hard">
                            Delete function will be disabled after 48 hours the record has been created.
                          </div>
                        </>
                      )
                    : education && (
                        <>
                          <GoAButton type="tertiary" leadingIcon="archive" onClick={cancelEducationClickHandler}>
                            Cancel Education
                          </GoAButton>
                          <div className="delete-employment-advice-hard">
                            A record can no longer be deleted after 48 hours it&apos;s been created.
                          </div>
                        </>
                      )}
                </div>

                <div>
                  <GoAButtonGroup alignment="end">
                    <GoAButton type="secondary" onClick={educationCancelHandler}>
                      <span>Cancel</span>
                    </GoAButton>
                    <GoAButton type="primary" onClick={handleSubmit(educationSubmitHandler)}>
                      <span>{education ? 'Save' : 'Add'}</span>
                    </GoAButton>
                  </GoAButtonGroup>
                </div>
              </div>
            </GoABlock>
          </div>
        )}
      </div>
    </GoAModal>
  );
});
