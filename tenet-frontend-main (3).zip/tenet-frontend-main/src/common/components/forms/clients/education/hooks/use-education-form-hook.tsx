/* eslint-disable @typescript-eslint/no-unused-vars */
import { ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { compareDesc, differenceInHours } from 'date-fns';
import { useStore } from '../../../../../../hooks/use-store.hook';
import {
  Education,
  LevelOfEducation,
  PersonClassifications,
  TrainingDeliveryMethods,
  TrainingLocations,
} from '../../../../../../types/client';
import { useModal } from '../../../../../../hooks/use-modal.hook';
import { getListItems } from '../../../../../../utils/list-items.util';
import {
  ClientEducationHistoryCancelModal,
  ClientEducationHistorySubmitModal,
} from '../../../../modals/education/client-education-modal';
import { ConfirmationModal } from '../../../../modals/confirmation.modal';
import useEducationChangeMessage from '../../../../clients/hooks/use-education-change-message.hooks';
import { isAlphanumeric } from '../../../../../../utils/validateText.util';
import { toIsoFormat } from '../../../../../../utils/date.util';

type EducationFormData = {
  levelOfEducation: LevelOfEducation;
  educationalInstitution: string;
  fieldOfStudy: string;
  personAttendingTraining: boolean;
  startDate: string;
  exactStartDate?: boolean;
  expectedEndDate?: string;
  exactEndDate?: boolean;
  trainingDeliveryMethod?: TrainingDeliveryMethods;
  personClassification?: PersonClassifications;
  totalHoursPerWeek?: number;
  trainingLocation?: TrainingLocations;
  trainingInterferesWithEmployment?: boolean;
  completionDate?: string;
  exactCompletionDate?: boolean;
  credentialReceived?: boolean;
  reasonForWithdrawal?: string;
  credentialName?: string;
  credentialRecognized?: boolean;
  credentialAssessed?: boolean;
  assessmentAgencyName?: string;
  assessmentDate?: string;
  credentialEquivalency?: string;
};

type FormFieldName =
  | 'levelOfEducation'
  | 'educationalInstitution'
  | 'fieldOfStudy'
  | 'personAttendingTraining'
  | 'startDate'
  | 'expectedEndDate'
  | 'exactStartDate'
  | 'exactEndDate'
  | 'trainingDeliveryMethod'
  | 'personClassification'
  | 'totalHoursPerWeek'
  | 'trainingLocation'
  | 'trainingInterferesWithEmployment'
  | 'completionDate'
  | 'exactCompletionDate'
  | 'credentialReceived'
  | 'reasonForWithdrawal'
  | 'credentialName'
  | 'credentialRecognized'
  | 'credentialAssessed'
  | 'assessmentAgencyName'
  | 'assessmentDate'
  | 'credentialEquivalency';

const useSubmitEducation = (clientId: string, education?: Education) => {
  const [startDateApproximate, setStartDateApproximate] = useState(false);
  const [endDateApproximate, setEndDateApproximate] = useState(false);
  const [isAttendingTraining, setIsAttendingTraining] = useState('');
  const [isTrainingInterferingWithEmployment, setTrainingInterferesWithEmployment] = useState('');
  const [completionApproximate, setCompletionApproximate] = useState(false);
  const [receivedCredential, setReceivedCredential] = useState('');
  const { hideModal } = useModal();
  const [educationLocation, setEducationLocation] = useState('');
  const [credRecognized, setCredRecognized] = useState('');
  const [credAssessed, setCredAssessed] = useState('');
  const [canHardDelete, setCanHardDelete] = useState(false);

  useEffect(() => {
    if (education) {
      setIsAttendingTraining(education.personAttendingTraining?.toString());
      setTrainingInterferesWithEmployment(education.trainingInterferesWithEmployment?.toString() ?? '');
      setStartDateApproximate(education.exactStartDate ?? false);
      setEndDateApproximate(education.exactEndDate ?? false);
      setCompletionApproximate(education.exactCompletionDate ?? false);
      setReceivedCredential(education.credentialReceived?.toString() ?? '');
      setEducationLocation(education.trainingLocation ?? '');
      setCredRecognized(education.credentialRecognized?.toString() ?? '');
      setCredAssessed(education.credentialAssessed?.toString() ?? '');
      setTrainingInterferesWithEmployment(education?.trainingInterferesWithEmployment?.toString() ?? '');

      const hoursAfterCreation = Math.abs(differenceInHours(education?.createdAt, new Date()));

      setCanHardDelete(hoursAfterCreation <= 48);
    }
  }, [education]);

  const {
    clientsStore: { selectedClient, setEducationHistory, deleteEducation, updateEducationHistory },
  } = useStore();
  const {
    getValues,
    register,
    reset,
    setValue,
    handleSubmit,
    formState: { errors },
    setError,
  } = useForm<EducationFormData>({
    defaultValues: {
      ...education,
      startDate: education?.startDate ? toIsoFormat(education?.startDate) : undefined,
      expectedEndDate: education?.expectedEndDate ? toIsoFormat(education?.expectedEndDate) : undefined,
      completionDate: education?.completionDate ? toIsoFormat(education.completionDate) : undefined,
      assessmentDate: education?.assessmentDate ? toIsoFormat(education.assessmentDate) : undefined,
    },
  });

  const { setMessage } = useEducationChangeMessage();

  const { name: levelOfEducation } = register('levelOfEducation', {
    required: { value: true, message: 'This field is required!' },
    min: 3,
  });
  const { name: educationalInstitution } = register('educationalInstitution', {
    required: { value: true, message: 'Educational institution is required' },
  });
  const { name: fieldOfStudy } = register('fieldOfStudy');

  const { name: personAttendingTraining } = register('personAttendingTraining', {
    required: { value: isAttendingTraining === '', message: 'This field is mandatory' },
  });

  const { name: trainingDeliveryMethod } = register('trainingDeliveryMethod', {
    required: { value: isAttendingTraining === 'true', message: 'Training delivery is required!' },
  });

  const { name: startDate } = register('startDate', {
    required: { value: !!isAttendingTraining, message: 'Start date is required!' },
  });

  const { name: expectedEndDate } = register('expectedEndDate', {
    required: { value: isAttendingTraining === 'true', message: 'Expected end date is required!' },
  });
  const { name: exactEndDate } = register('exactEndDate');
  const { name: exactStartDate } = register('exactStartDate');

  const { name: personClassification } = register('personClassification', {
    required: { value: isAttendingTraining === 'true', message: "Person's classification is required!" },
  });

  const { name: totalHoursPerWeek } = register('totalHoursPerWeek', {
    required: { value: isAttendingTraining === 'true', message: 'Total hours per week is required!' },
    pattern: { value: /^\d+(\.*\d{0,2})$/, message: 'Can only be a whole or two-decimal place number' },
    minLength: { value: 1, message: 'Total hours per week cannot be less than 1' },
    maxLength: { value: 168, message: 'Total hours per week cannot be greater than 168' },
  });

  const { name: trainingLocation } = register('trainingLocation', {
    required: {
      value: isAttendingTraining !== '' || (receivedCredential !== '' && educationLocation === ''),
      message: 'Training location is required!',
    },
  });

  const { name: trainingInterferesWithEmployment } = register('trainingInterferesWithEmployment', {
    required: {
      value: isAttendingTraining === 'true' && isTrainingInterferingWithEmployment === '',
      message: 'Training interfers with employment is required!',
    },
  });

  const { name: completionDate } = register('completionDate', {
    required: { value: isAttendingTraining === 'false', message: 'Completion/last attended date is required!' },
  });
  const { name: exactCompletionDate } = register('exactCompletionDate');

  const { name: credentialReceived } = register('credentialReceived', {
    required: {
      value: isAttendingTraining === 'false' && receivedCredential === '',
      message: 'Credential received is required!',
    },
  });

  const { name: reasonForWithdrawal } = register('reasonForWithdrawal', {
    required: { value: receivedCredential === 'false', message: 'Reason for withdrawal is required!' },
  });

  const { name: credentialName } = register('credentialName', {
    required: { value: receivedCredential === 'true', message: 'Name of credential is required!' },
  });

  const { name: credentialRecognized } = register('credentialRecognized', {
    required: {
      value:
        receivedCredential === 'true' &&
        educationLocation !== '' &&
        credRecognized === '' &&
        educationLocation === TrainingLocations.OUTSIDE_CANADA,
      message: 'Credential recognized field is required!',
    },
  });

  const { name: credentialAssessed } = register('credentialAssessed', {
    required: {
      value:
        receivedCredential === 'true' &&
        credRecognized !== '' &&
        credAssessed === '' &&
        educationLocation === TrainingLocations.OUTSIDE_CANADA,
      message: 'Credential assessed field is required!',
    },
  });

  const { name: assessmentAgencyName } = register('assessmentAgencyName', {
    required: {
      value:
        receivedCredential !== '' && educationLocation !== '' && credAssessed === 'true' && credRecognized === 'false',
      message: 'Assessment agency field is required!',
    },
  });

  const { name: assessmentDate } = register('assessmentDate', {
    required: {
      value:
        receivedCredential !== '' && educationLocation !== '' && credAssessed === 'true' && credRecognized === 'false',
      message: 'Assessment date field is required!',
    },
  });

  const { name: credentialEquivalency } = register('credentialEquivalency', {
    required: {
      value:
        receivedCredential !== '' && educationLocation !== '' && credAssessed === 'true' && credRecognized === 'false',
      message: 'Credential equivalency field is required!',
    },
  });

  const formFields = {
    levelOfEducation,
    educationalInstitution,
    fieldOfStudy,
    personAttendingTraining,
    startDate,
    exactStartDate,
    expectedEndDate,
    exactEndDate,
    trainingDeliveryMethod,
    personClassification,
    totalHoursPerWeek,
    trainingLocation,
    trainingInterferesWithEmployment,
    completionDate,
    exactCompletionDate,
    credentialReceived,
    reasonForWithdrawal,
    credentialName,
    credentialRecognized,
    credentialAssessed,
    assessmentAgencyName,
    assessmentDate,
    credentialEquivalency,
  };

  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const confirmText = useMemo(
    () =>
      education?.id ? (
        <p className="client-font-with-margin">
          {`Client’s ${education?.educationalInstitution} education has been changed. Do you want to save your changes?`}
        </p>
      ) : (
        <>
          <p className="client-font-with-margin">
            {`Add this education to client's record. You can delete the record within 48 hours. After that, you may still
          update the record.`}
          </p>
          <p className="client-font-with-margin">{`Click "cancel" to go back to editing, or proceed to add the record.`}</p>
        </>
      ),
    [education?.id, education?.educationalInstitution],
  );
  const heading = useMemo(
    () =>
      education?.id
        ? 'Education information changed'
        : `Add this education to ${selectedClient?.firstName ?? 'Homer'} ${selectedClient?.lastName ?? 'Homer'}'s record?`,
    [education?.id, selectedClient?.firstName, selectedClient?.lastName],
  );

  const hasInvalidFields = useCallback(() => {
    let invalid = false;

    const sDate = new Date(getValues(startDate));
    if (compareDesc(sDate, new Date()) === -1) {
      setError(startDate, {
        type: 'custom',
        message: 'The start date cannot be in the future',
      });
      invalid = true;
    }

    if (selectedClient?.dateOfBirth && compareDesc(sDate, new Date(selectedClient?.dateOfBirth)) === 1) {
      setError(startDate, {
        type: 'custom',
        message: 'The start date cannot be earlier than the Date of Birth',
      });
      invalid = true;
    }

    const rawDate = getValues(completionDate);
    const cDate = rawDate ? new Date(rawDate) : undefined;
    if (cDate && compareDesc(cDate, sDate) === 1) {
      setError(completionDate, {
        type: 'custom',
        message: 'The completion date cannot be earlier than the start date',
      });
      invalid = true;
    }
    if (isAttendingTraining === 'false' && cDate && compareDesc(cDate, new Date()) === -1) {
      setError(completionDate, {
        type: 'custom',
        message: 'The completion date cannot be in the future if the client is not currently attending training',
      });
      invalid = true;
    }

    const expectedRawDate = getValues(expectedEndDate);
    const expectedDate = expectedRawDate ? new Date(expectedRawDate) : undefined;
    if (isAttendingTraining === 'true' && expectedDate && compareDesc(expectedDate, new Date()) === 1) {
      setError(expectedEndDate, {
        type: 'custom',
        message: 'The expected end date cannot be in the past if the client is currently attending training',
      });
      invalid = true;
    }
    if (isAttendingTraining === 'false' && expectedDate && compareDesc(expectedDate, new Date()) === -1) {
      setError(expectedEndDate, {
        type: 'custom',
        message: 'The expected end date cannot be in the future if the client is not currently attending training',
      });
      invalid = true;
    }
    if (cDate && compareDesc(cDate, sDate) === 1) {
      setError(expectedEndDate, {
        type: 'custom',
        message: 'The expected end date cannot be earlier than the start date',
      });
      invalid = true;
    }

    return invalid;
  }, [
    completionDate,
    expectedEndDate,
    getValues,
    isAttendingTraining,
    selectedClient?.dateOfBirth,
    setError,
    startDate,
  ]);

  const educationSubmitHandler = useCallback(async () => {
    try {
      if (hasInvalidFields()) {
        return;
      }
      setModalVisible(true);
      setLoading(true);

      const course = getValues('fieldOfStudy');
      if (course && !isAlphanumeric(course)) {
        setError(fieldOfStudy, { type: 'custom', message: 'Field of study must only contain alphanumeric characters' });
        return;
      }

      const newEducationHist = {
        clientId: clientId ?? selectedClient?.id ?? '',
        levelOfEducation: getValues('levelOfEducation'),
        educationalInstitution: getValues('educationalInstitution'),
        fieldOfStudy: course ?? '',
        personAttendingTraining: getValues('personAttendingTraining'),
        startDate: new Date(getValues('startDate')),
        expectedEndDate: getValues('expectedEndDate') ? new Date(getValues('expectedEndDate')!) : undefined,
        exactStartDate: getValues('exactStartDate'),
        exactEndDate: getValues('exactEndDate'),
        trainingDeliveryMethod: getValues('trainingDeliveryMethod') || undefined,
        personClassification: getValues('personClassification') || undefined,
        totalHoursPerWeek: parseInt(getValues('totalHoursPerWeek')?.toString() ?? '0', 10) || undefined,
        trainingLocation: getValues('trainingLocation') || undefined,
        trainingInterferesWithEmployment: getValues('trainingInterferesWithEmployment'),
        completionDate: getValues('completionDate') ? new Date(getValues('completionDate')!) : undefined,
        exactCompletionDate: getValues('exactCompletionDate'),
        credentialReceived: getValues('credentialReceived'),
        reasonForWithdrawal: getValues('reasonForWithdrawal') ?? undefined,
        credentialName: getValues('credentialName'),
        credentialRecognized: getValues('credentialRecognized'),
        credentialAssessed: getValues('credentialAssessed'),
        assessmentAgencyName: getValues('assessmentAgencyName'),
        assessmentDate: getValues('assessmentDate') ? new Date(getValues('assessmentDate')!) : undefined,
        credentialEquivalency: getValues('credentialEquivalency'),
      };

      setModalContent(
        <ClientEducationHistorySubmitModal
          onDecline={() => {
            if (education?.id) {
              setModalVisible(false);
              setModalContent(null);
            } else {
              reset();
              hideModal();
            }
          }}
          onConfirm={async () => {
            if (education?.id) {
              await updateEducationHistory(clientId ?? selectedClient?.id ?? '', newEducationHist, education?.id ?? '');
            } else {
              await setEducationHistory(clientId ?? selectedClient?.id ?? '', newEducationHist);
            }

            if (education?.id) {
              setMessage(`${selectedClient?.firstName} ${selectedClient?.lastName}'s education has been updated.`);
            }
            setModalVisible(false);
            reset();
            hideModal();
          }}
          educationId={education?.id}
          confirmText={confirmText}
          heading={heading}
        />,
      );
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [
    clientId,
    confirmText,
    education?.id,
    fieldOfStudy,
    getValues,
    hasInvalidFields,
    heading,
    hideModal,
    reset,
    selectedClient?.firstName,
    selectedClient?.id,
    selectedClient?.lastName,
    setEducationHistory,
    setError,
    setMessage,
    updateEducationHistory,
  ]);

  const educationCancelHandler = useCallback(async () => {
    setModalVisible(true);
    setModalContent(
      <ClientEducationHistoryCancelModal
        onDecline={() => {
          setModalVisible(false);
          setIsAttendingTraining('');
          hideModal();
          reset();
        }}
        onConfirm={() => {
          setModalVisible(false);
        }}
      />,
    );
  }, [reset, hideModal]);

  const deleteEducationRecordHandler = useCallback(() => {
    setModalVisible(true);
    const deleteEducationRecord = async () => {
      try {
        setLoading(true);

        if (education?.id) {
          await deleteEducation(education.id);
        }
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error(e);
      } finally {
        setLoading(false);
        setModalVisible(false);
        hideModal();
      }
    };
    const description = `Are you sure you want to delete the client's ${education?.educationalInstitution} experience ? This will remove the employment record permanently.`;
    setModalContent(
      <ConfirmationModal
        onConfirm={deleteEducationRecord}
        onDecline={() => setModalVisible(false)}
        heading="Delete Education"
        description={description}
        loading={loading}
        confirmText="Delete"
        declineText="No, go back"
        isDelete
      />,
    );
  }, [deleteEducation, education?.educationalInstitution, education?.id, hideModal, loading]);

  const onChangeHandler = useCallback(
    (name: string, value: string | string[] | boolean | undefined) => {
      if (Array.isArray(value)) {
        setValue(name as FormFieldName, value.join(','));
      } else {
        setValue(name as FormFieldName, value);
        if (name === personAttendingTraining) {
          const attending = value === 'true';
          setValue(name as FormFieldName, attending);
          setIsAttendingTraining(value as unknown as string);
        }
        if (name === credentialReceived) {
          const received = value === 'true';
          setValue(name as FormFieldName, received);
          setReceivedCredential(value as unknown as string);
        }
        if (name === trainingLocation) {
          setEducationLocation(value as unknown as string);
        }
        if (name === credentialRecognized) {
          const recognized = value === 'true';
          setValue(name as FormFieldName, recognized);
          setCredRecognized(value as unknown as string);
        }
        if (name === credentialAssessed) {
          const assessed = value === 'true';
          setValue(name as FormFieldName, assessed);
          setCredAssessed(value as unknown as string);
        }
        if (name === trainingInterferesWithEmployment) {
          const interferes = value === 'true';
          setValue(name as FormFieldName, interferes);
          setTrainingInterferesWithEmployment(value as unknown as string);
        }
      }
    },
    [
      setValue,
      personAttendingTraining,
      credentialReceived,
      trainingLocation,
      credentialRecognized,
      credentialAssessed,
      trainingInterferesWithEmployment,
    ],
  );

  const educationLevelOptions = getListItems(LevelOfEducation, 'dropdown', true);

  const trainingMethodOptions = getListItems(TrainingDeliveryMethods, 'radio');

  const personClassificationOptions = getListItems(PersonClassifications, 'radio');

  const trainingLocationOptions = getListItems(TrainingLocations, 'radio');

  return {
    loading,
    formFields,
    getValues,
    educationSubmitHandler,
    educationCancelHandler,
    onChangeHandler,
    errors,
    modalContent,
    modalVisible,
    handleSubmit,
    isAttendingTraining,
    educationLevelOptions,
    trainingMethodOptions,
    startDateApproximate,
    setStartDateApproximate,
    endDateApproximate,
    setEndDateApproximate,
    personClassificationOptions,
    trainingLocationOptions,
    isTrainingInterferingWithEmployment,
    hideModal,
    completionDate,
    canHardDelete,
    setCompletionApproximate,
    completionApproximate,
    exactCompletionDate,
    receivedCredential,
    educationLocation,
    TrainingLocations,
    credRecognized,
    credAssessed,
    deleteEducationRecordHandler,
  };
};

export default useSubmitEducation;
