/* eslint-disable @typescript-eslint/no-unused-expressions */
import { isBefore } from 'date-fns';
import { useForm } from 'react-hook-form';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';

import { MockUploader, Upload } from '../../../../../../types/files';
import {
  CreateSupplementaryActivity,
  SupplementaryActivity,
  SupplementaryActivityType,
} from '../../../../../../types/service-plan';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { noteService } from '../../../../../../services/note.service';
import { fileService } from '../../../../../../services/clients/client-files.service';
import { Note } from '../../../../../../types/note';

import useFileNotValid from '../../../../../../utils/file.util';
import { InvalidFileUploadError } from '../../../../../../types/errors/invalid-file-upload.error';
import { toIsoFormat } from '../../../../../../utils/date.util';

type FormInputType = {
  activityType: SupplementaryActivityType;
  courseName?: string;
  supportItem?: string;
  competencyToDevelop?: string;
  description?: string;
  startDate?: string;
  endDate?: string;
  supportProvidedOn?: string;
  provider?: string;
  cost?: string;
  notes?: string;
  fileUpload?: File | string;
  employer?: string;
  jobTitle?: string;
  noc?: string;
};

type FormInputKeys =
  | 'activityType'
  | 'courseName'
  | 'supportItem'
  | 'competencyToDevelop'
  | 'description'
  | 'startDate'
  | 'endDate'
  | 'supportProvidedOn'
  | 'provider'
  | 'cost'
  | 'notes'
  | 'fileUpload'
  | 'employer'
  | 'jobTitle'
  | 'noc';

type Args = {
  activity?: SupplementaryActivity;
  uploadType: string;
  hideModal: () => void;
};

export const useSupplementaryActivityForm = ({ activity, uploadType, hideModal }: Args) => {
  const courseName: FormInputKeys = 'courseName';
  const supportItem: FormInputKeys = 'supportItem';
  const competencyToDevelop: FormInputKeys = 'competencyToDevelop';
  const description: FormInputKeys = 'description';
  const startDate: FormInputKeys = 'startDate';
  const supportProvidedOn: FormInputKeys = 'supportProvidedOn';
  const endDate: FormInputKeys = 'endDate';
  const provider: FormInputKeys = 'provider';
  const cost: FormInputKeys = 'cost';

  const [note, setNote] = useState<Note | undefined>();
  const [watchCost, setCost] = useState('');

  const {
    control,
    handleSubmit,
    register,
    unregister,
    setValue,
    getValues,
    reset,
    watch,
    setError,
    formState: { errors },
  } = useForm<FormInputType>({
    defaultValues: {
      activityType: activity?.activityType ?? SupplementaryActivityType.SHORT_COURSE,
      courseName: activity?.name,
      supportItem: activity?.supportItem,
      competencyToDevelop: activity?.competencyToDevelop,
      cost: activity?.cost?.toFixed(2),
      description: activity?.description,
      provider: activity?.provider,
      notes: note?.message,
      supportProvidedOn: activity?.supportProvidedOn ? toIsoFormat(new Date(activity.supportProvidedOn)) : undefined,
      startDate: activity?.startDate ? toIsoFormat(new Date(activity.startDate)) : undefined,
      endDate: activity?.endDate ? toIsoFormat(new Date(activity.endDate)) : undefined,
      employer: activity?.employer,
      jobTitle: activity?.jobTitle,
      noc: activity?.noc,
    },
  });

  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});
  const [isLoading, setIsLoading] = useState(false);
  const {
    servicePlanStore: { servicePlan },
    supplementaryActivityFormStore: { createActivity, updateActivity },
  } = useStore();
  const [uploadError, setUploadError] = useState<string | null>(null);

  const { name: activityType } = register('activityType', {
    required: {
      value: true,
      message: 'Activity type is required',
    },
  });

  const watchActivityType = watch(activityType);

  const { name: notes } = register('notes');
  const { name: fileUpload } = register('fileUpload');
  const { name: employer } = register('employer');
  const { name: jobTitle } = register('jobTitle');
  const { name: noc } = register('noc');

  const formFields = {
    activityType,
    courseName,
    competencyToDevelop,
    supportItem,
    supportProvidedOn,
    startDate,
    endDate,
    description,
    provider,
    cost,
    notes,
    fileUpload,
    employer,
    jobTitle,
    noc,
  };

  const registerCostField = useCallback(() => {
    register(cost, {
      required: {
        value: true,
        message: 'Cost is required',
      },
    });
  }, [register]);

  const registerDateFields = useCallback(() => {
    register(startDate, {
      required: {
        value: true,
        message: 'Start date is required',
      },
      validate: (value) => {
        const planStartDate = servicePlan?.startDate;
        if (planStartDate && value && isBefore(value, planStartDate)) {
          return 'The start date must not be earlier than service plan start date';
        }

        return true;
      },
    });
    register(endDate, {
      required: {
        value: true,
        message: 'End date is required',
      },
      validate: (value) => {
        const activityStartDate = getValues(startDate);
        if (activityStartDate && value && isBefore(value, activityStartDate)) {
          return 'The end date must not be earlier than the start date';
        }

        return true;
      },
    });
  }, [getValues, register, servicePlan?.startDate]);

  const registerSCFields = useCallback(() => {
    register(courseName, {
      required: {
        value: true,
        message: 'Course name is required',
      },
    });
    register(provider, {
      required: {
        value: true,
        message: 'Provider is required',
      },
    });
    registerDateFields();
    registerCostField();

    unregister([supportItem, competencyToDevelop, description, supportProvidedOn]);
  }, [register, registerCostField, registerDateFields, unregister]);
  const registerUWEFields = useCallback(() => {
    register(competencyToDevelop, {
      required: {
        value: true,
        message: 'Competency to develop is required',
      },
    });
    registerDateFields();

    unregister([courseName, supportItem, description, cost, provider, supportProvidedOn]);
  }, [register, registerDateFields, unregister]);
  const registerERSFields = useCallback(() => {
    register(supportItem, {
      required: {
        value: true,
        message: 'Support item is required',
      },
    });
    register(description, {
      required: {
        value: true,
        message: 'Description is required',
      },
    });
    register(supportProvidedOn, {
      required: {
        value: true,
        message: 'Support provided on is required',
      },
    });
    registerCostField();

    unregister([courseName, startDate, endDate, provider, competencyToDevelop]);
  }, [register, registerCostField, unregister]);

  const registerMap: Record<SupplementaryActivityType, () => void> = useMemo(
    () => ({
      [SupplementaryActivityType.EMPLOYMENT_READINESS_SUPPORT]: registerERSFields,
      [SupplementaryActivityType.SHORT_COURSE]: registerSCFields,
      [SupplementaryActivityType.UNPAID_WORK_EXPERIENCE]: registerUWEFields,
    }),
    [registerERSFields, registerSCFields, registerUWEFields],
  );

  const activityTypeWatch = watch(activityType);
  const activityTypeChecks = useMemo(
    () => ({
      isERS: activityTypeWatch === SupplementaryActivityType.EMPLOYMENT_READINESS_SUPPORT,
      isSC: activityTypeWatch === SupplementaryActivityType.SHORT_COURSE,
      isUWE: activityTypeWatch === SupplementaryActivityType.UNPAID_WORK_EXPERIENCE,
    }),
    [activityTypeWatch],
  );

  const [uploads, setUploads] = useState<Upload[]>([]);
  const [progressList, setProgressList] = useState<Record<string, number>>({});

  const onChangeHandler = useCallback(
    (name: string, value: string | SupplementaryActivityType | undefined) => {
      setValue(name as FormInputKeys, value, {
        shouldValidate: !['endDate', 'startDate', 'supportProvidedOn'].includes(name),
      });

      if (name === activityType) {
        registerMap[value as SupplementaryActivityType]();
      }
    },
    [activityType, registerMap, setValue],
  );

  const formatCurrency = useCallback(
    (name: string, value: string) => {
      const cad = (Math.round(parseFloat(value) * 100) / 100).toFixed(2);
      if (name === cost) {
        setValue(name, cad);
        setCost(cad);
      }
    },
    [setValue, cost],
  );

  const { fileNotValidHandler } = useFileNotValid();

  const uploadFile = useCallback(
    (file: File) => {
      try {
        fileNotValidHandler(file.name, file.type);
        const reader = new FileReader();

        reader.onload = (e: ProgressEvent<FileReader>) => {
          if (!e.target) return;
          const url = e.target.result;
          const uploader: MockUploader = {
            onprogress: (percent) => {
              setProgressList((old) => ({ ...old, [file.name]: percent }));
            },
          };

          setUploads((old) => [
            ...old,
            {
              file,
              uploader,
              fileType: uploadType,
              id: uuidv4(),
              createdAt: new Date().toISOString(),
              size: file.size,
              adspId: '',
            },
          ]);

          if (url) {
            uploader.upload?.(url);
          }
        };

        reader.readAsDataURL(file);
      } catch (e) {
        if (e instanceof InvalidFileUploadError) {
          setUploadError(e.message);
        }
      }
    },
    [fileNotValidHandler, uploadType],
  );

  const deleteFile = useCallback(
    async (file: Upload) => {
      setUploads((old) => old.filter((upload) => upload.id !== file.id));

      if (file.persisted) {
        await fileService.deleteFile(file.adspId);
      }
    },
    [setUploads],
  );

  const getActivityPayload = useCallback((): CreateSupplementaryActivity => {
    const rawCost = getValues(cost);
    const { supportProvidedOn: supportProvidedOnVal, startDate: startDateVal, endDate: endDateVal } = getValues();

    return {
      activityType: getValues(activityType),
      name: getValues(courseName),
      cost: rawCost ? Number.parseFloat(rawCost) : undefined,
      description: getValues(description),
      competencyToDevelop: getValues(competencyToDevelop),
      supportItem: getValues(supportItem),
      provider: getValues(provider),
      supportProvidedOn: supportProvidedOnVal ? new Date(supportProvidedOnVal) : undefined,
      startDate: startDateVal ? new Date(startDateVal) : undefined,
      endDate: endDateVal ? new Date(endDateVal) : undefined,
      employer: getValues(employer),
      jobTitle: getValues(jobTitle),
      noc: getValues(noc),
    };
  }, [activityType, employer, getValues, jobTitle, noc]);

  const persistNote = useCallback(
    async (savedActivity: SupplementaryActivity) => {
      const message = getValues(notes);

      if (message && note?.id) {
        await noteService.update(note.id, { message });
        return;
      }

      if (message && servicePlan?.clientId) {
        noteService.create({
          subject: 'Supplementary activities',
          message,
          recordIds: [savedActivity.id, savedActivity.servicePlanId, servicePlan.clientId],
        });
      }
    },
    [getValues, note?.id, notes, servicePlan?.clientId],
  );

  const createSupplementaryActivity = useCallback(async () => {
    const payload = getActivityPayload();

    try {
      setIsLoading(true);
      const result = await createActivity(payload);
      if (result.id && result.servicePlanId === servicePlan?.id) {
        await Promise.all([
          persistNote(result),
          uploads.length ? fileService.uploadFiles(result.id, uploads) : undefined,
        ]);
      }
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setIsLoading(false);
      hideModal();
    }
  }, [createActivity, getActivityPayload, hideModal, persistNote, requestErrorHandler, servicePlan?.id, uploads]);

  const updateSupplementaryActivity = useCallback(
    async (activityToUpdate: SupplementaryActivity) => {
      const payload = getActivityPayload();

      try {
        setIsLoading(true);
        const result = await updateActivity(activityToUpdate.id, payload);
        if (result.id && result.servicePlanId === servicePlan?.id) {
          await Promise.all([
            persistNote(result),
            uploads.length
              ? fileService.uploadFiles(
                  result.id,
                  uploads.filter((upload) => !upload.persisted),
                )
              : undefined,
          ]);
        }
      } catch (e) {
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
      } finally {
        setIsLoading(false);
        hideModal();
      }
    },
    [getActivityPayload, hideModal, persistNote, requestErrorHandler, servicePlan?.id, updateActivity, uploads],
  );

  const hasInvalidFields = useCallback(() => {
    let invalid = false;

    const wage = watchCost;
    if (!/^\d+(\.*\d{0,2})$/.test(wage) && watchActivityType !== SupplementaryActivityType.UNPAID_WORK_EXPERIENCE) {
      setError(cost, {
        type: 'custom',
        message: 'Can only be a whole or two-decimal place number',
      });
      invalid = true;
    }

    const nocCode = getValues(noc);
    if (
      nocCode &&
      !/^\d{5}$/.test(nocCode.substring(0, 5)) &&
      watchActivityType === SupplementaryActivityType.UNPAID_WORK_EXPERIENCE
    ) {
      setError(noc, {
        type: 'custom',
        message: 'NOC code must be a 5-digit number',
      });
      invalid = true;
    }

    return invalid;
  }, [getValues, noc, setError, watchActivityType, watchCost]);

  const submitBtnHandler = useCallback(async () => {
    if (hasInvalidFields()) {
      return false;
    }
    if (activity) {
      return updateSupplementaryActivity(activity);
    }

    return createSupplementaryActivity();
  }, [activity, createSupplementaryActivity, hasInvalidFields, updateSupplementaryActivity]);

  useEffect(() => {
    const typeToRegister = getValues(activityType);
    registerMap[typeToRegister]();

    if (activity?.id) {
      noteService
        .getByRecordId(activity.id)
        .then((data) => {
          if (data.length) {
            setNote(data[0]);
            setValue(notes, data[0].message);
          }
        })
        .catch(() => {});

      fileService.getFiles(activity.id).then((files) => {
        const uploaded: Upload[] = files.map((file) => ({
          id: file.id,
          file: new File([], file.fileName),
          uploader: { onprogress: () => {} },
          fileType: file.typeName,
          createdAt: file.adspCreatedAt,
          size: file.size,
          adspId: file.adspId,
          persisted: true,
        }));

        setUploads([...uploaded]);
      });
    }
  }, [activity?.id, activityType, getValues, notes, registerMap, registerSCFields, setValue]);

  useEffect(() => {
    if (activity?.cost) {
      setCost(activity.cost?.toFixed(2));
    }
  }, [activity?.cost]);

  const [loading, setLoading] = useState(false);

  const downloadFile = useCallback(
    (fileId: string, filename: string, filesize: number) => {
      try {
        setLoading(true);
        fileService.downloadFileByAdspId(fileId, filename, filesize);
      } catch (error) {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    },
    [requestErrorHandler],
  );

  const onSelectNocCode = useCallback(
    (suggestion: { value: string; label: string }) => {
      setValue(noc, `${suggestion.value} - ${suggestion.label}`, { shouldValidate: true });
    },
    [noc, setValue],
  );

  const setNocCodeField = useCallback(
    (name: string, value: string) => {
      setValue(noc as FormInputKeys, value.trim(), { shouldValidate: true });
    },
    [noc, setValue],
  );

  return {
    control,
    handleSubmit,
    formFields,
    errors,
    requestError,
    isLoading,
    setValue,
    onChangeHandler,
    getValues,
    watch,
    reset,
    uploadFile,
    progressList,
    uploads,
    activityTypeChecks,
    submitBtnHandler,
    deleteFile,
    uploadError,
    setUploadError,
    formatCurrency,
    watchCost,
    loading,
    downloadFile,
    onSelectNocCode,
    setNocCodeField,
    watchActivityType,
  };
};
