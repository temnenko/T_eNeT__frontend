import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoAFileUploadCard,
  GoAFileUploadInput,
  GoAFormItem,
  GoAInput,
  GoAModal,
  GoANotification,
  GoARadioGroup,
  GoARadioItem,
  GoASpacer,
  GoATextarea,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { subYears } from 'date-fns';

import { useCallback, useMemo } from 'react';
import {
  ServicePlanFileTypes,
  SupplementaryActivity,
  SupplementaryActivityType,
  supplementaryActivityTypeLabels,
} from '../../../../../types/service-plan';
import { useSupplementaryActivityForm } from './hooks/use-supplementary-activity-form.hook';
import { useModal } from '../../../../../hooks/use-modal.hook';
import { ConfirmationModal } from '../../../modals/confirmation.modal';
import useCancelActivity from './hooks/use-cancel-activity.hook';
import TenetFileUploadCard from './tenetFileUploadCard';
import { toIsoFormat } from '../../../../../utils/date.util';
import NocInput from '../../../app-noc-dropdown/app-noc-input';

type Props = {
  heading: string;
  btnLabel: string;
  activity: SupplementaryActivity | undefined;
};

const SupplementaryActivityForm = observer(({ heading, btnLabel, activity }: Props) => {
  const { showModal, hideModal } = useModal();
  const {
    handleSubmit,
    submitBtnHandler,
    formFields,
    errors,
    onChangeHandler,
    getValues,
    activityTypeChecks,
    uploadFile,
    progressList,
    uploads,
    deleteFile,
    isLoading,
    uploadError,
    setUploadError,
    formatCurrency,
    watchCost,
    downloadFile,
    onSelectNocCode,
    setNocCodeField,
    watchActivityType,
  } = useSupplementaryActivityForm({
    activity,
    uploadType: ServicePlanFileTypes.SERVICE_PLAN_ACTIVITY,
    hideModal,
  });
  const {
    activityType,
    courseName,
    supportItem,
    competencyToDevelop,
    cost,
    description,
    supportProvidedOn,
    endDate,
    startDate,
    provider,
    notes,
    fileUpload,
    employer,
    jobTitle,
    noc,
  } = formFields;
  const { isERS, isSC, isUWE } = activityTypeChecks;
  const { key, label } = useMemo(() => {
    if (isERS) {
      return { key: supportItem, label: 'Support item' };
    }
    if (isUWE) {
      return { key: competencyToDevelop, label: 'Competency to develop' };
    }

    return { key: courseName, label: 'Course name' };
  }, [competencyToDevelop, courseName, isERS, isUWE, supportItem]);

  const { cancelActivity } = useCancelActivity({
    activityId: activity?.id,
    hideModal,
  });
  const confirmActivityCancellation = useCallback(() => {
    if (activity?.id) {
      showModal(
        <ConfirmationModal
          heading="Cancel Activity"
          description="Cancel activity?"
          confirmText="Yes, cancel"
          declineText="No, go back"
          onDecline={hideModal}
          onConfirm={cancelActivity}
          size="sm"
          isDelete
        />,
      );
    }
  }, [activity?.id, cancelActivity, hideModal, showModal]);

  return (
    <GoAModal maxWidth="512px" open width="88px" transition="slow" heading={heading} onClose={hideModal}>
      <div className="relative">
        <form className="form-modal form-modal-no-margin">
          <GoABlock direction="column">
            <GoAFormItem label="Activity type">
              <GoARadioGroup
                name={activityType}
                testId={activityType}
                value={getValues(activityType)}
                onChange={onChangeHandler}
                disabled={!!activity}
              >
                <GoARadioItem
                  value={SupplementaryActivityType.SHORT_COURSE}
                  label={supplementaryActivityTypeLabels.SHORT_COURSE}
                />
                <GoARadioItem
                  value={SupplementaryActivityType.EMPLOYMENT_READINESS_SUPPORT}
                  label={supplementaryActivityTypeLabels.EMPLOYMENT_READINESS_SUPPORT}
                />
                <GoARadioItem
                  value={SupplementaryActivityType.UNPAID_WORK_EXPERIENCE}
                  label={supplementaryActivityTypeLabels.UNPAID_WORK_EXPERIENCE}
                />
              </GoARadioGroup>
            </GoAFormItem>
            <GoAFormItem label={label} error={errors[key]?.message}>
              <GoAInput
                type="text"
                name={key}
                id={key}
                value={getValues(key)}
                onChange={onChangeHandler}
                width="428px"
              />
            </GoAFormItem>
            {isERS && (
              <GoAFormItem label="Support provided on" error={errors.supportProvidedOn?.message}>
                <GoABlock>
                  <GoAInput
                    type="date"
                    onChange={onChangeHandler}
                    min={toIsoFormat(subYears(new Date(), 3))}
                    max="9999-12-31"
                    name={supportProvidedOn}
                    testId={supportProvidedOn}
                    value={getValues(supportProvidedOn) ? toIsoFormat(getValues(supportProvidedOn)!) : undefined}
                  />
                </GoABlock>
              </GoAFormItem>
            )}
            {isERS && (
              <GoAFormItem label="Description" error={errors.description?.message}>
                <GoATextarea
                  name={description}
                  id={description}
                  value={getValues(description)}
                  onChange={onChangeHandler}
                  width="404px"
                  rows={2}
                  maxCount={500}
                  countBy="character"
                />
              </GoAFormItem>
            )}
            {(isSC || isUWE) && (
              <>
                <GoAFormItem label="Start date" error={errors.startDate?.message}>
                  <GoABlock>
                    <GoAInput
                      type="date"
                      onChange={onChangeHandler}
                      min={toIsoFormat(subYears(new Date(), 4))}
                      max="9999-12-31"
                      name={startDate}
                      testId={startDate}
                      value={getValues(startDate) ? toIsoFormat(getValues(startDate)!) : undefined}
                    />
                  </GoABlock>
                </GoAFormItem>
                <GoAFormItem label="End date" error={errors.endDate?.message}>
                  <GoABlock>
                    <GoAInput
                      type="date"
                      onChange={onChangeHandler}
                      min={toIsoFormat(subYears(new Date(), 1))}
                      max="9999-12-31"
                      name={endDate}
                      testId={endDate}
                      value={getValues(endDate) ? toIsoFormat(getValues(endDate)!) : undefined}
                    />
                  </GoABlock>
                </GoAFormItem>
              </>
            )}
            {isSC && (
              <GoAFormItem label="Provider" error={errors.provider?.message}>
                <GoAInput
                  type="text"
                  name={provider}
                  id={provider}
                  value={getValues(provider)}
                  onChange={onChangeHandler}
                  width="428px"
                />
              </GoAFormItem>
            )}
            {(isERS || isSC) && (
              <GoAFormItem label="Cost" error={errors.cost?.message}>
                <GoAInput
                  type="number"
                  leadingContent="$"
                  name={cost}
                  id={cost}
                  value={watchCost}
                  onChange={onChangeHandler}
                  onBlur={formatCurrency}
                  width="200px"
                />
              </GoAFormItem>
            )}
            {watchActivityType === SupplementaryActivityType.UNPAID_WORK_EXPERIENCE && (
              <>
                <GoAFormItem label="Employer">
                  <GoAInput
                    type="text"
                    onChange={onChangeHandler}
                    name={employer}
                    id={employer}
                    value={getValues(employer) as string}
                    width="428px"
                  />
                </GoAFormItem>
                <GoAFormItem label="Job title">
                  <GoAInput
                    type="text"
                    onChange={onChangeHandler}
                    name={jobTitle}
                    id={jobTitle}
                    value={getValues(jobTitle) as string}
                    width="428px"
                  />
                </GoAFormItem>
                <GoABlock direction="column">
                  <h4 className="client-no-padding-no-margin">NOC</h4>
                  <NocInput
                    name={noc}
                    id={noc}
                    placeholder=""
                    width="428px"
                    value={getValues(noc) ?? ''}
                    onSelectNocCode={onSelectNocCode}
                    setNocCodeField={setNocCodeField}
                    errors={errors}
                  />
                </GoABlock>
              </>
            )}
            <GoAFormItem label="Notes" requirement="optional" error={errors.notes?.message}>
              <GoATextarea
                name={notes}
                id={notes}
                value={getValues(notes)}
                onChange={onChangeHandler}
                width="404px"
                rows={2}
                maxCount={500}
                countBy="character"
              />
            </GoAFormItem>
            <GoAFormItem label="Upload a file" requirement="optional">
              <GoAFileUploadInput testId={fileUpload} onSelectFile={uploadFile} variant="button" maxFileSize="10 Mb" />
              {uploads.map((upload) => {
                if (upload.adspId) {
                  return (
                    <TenetFileUploadCard
                      key={upload.file.name}
                      filename={upload.file.name}
                      size={upload.size}
                      modifiedDate={new Date(upload.createdAt)}
                      onDelete={() => deleteFile(upload)}
                      onDownload={() => downloadFile(upload.adspId, upload.file.name, upload.size)}
                    />
                  );
                }
                return (
                  <GoAFileUploadCard
                    key={upload.file.name}
                    filename={upload.file.name}
                    type={upload.file.type}
                    size={upload.file.size}
                    progress={progressList[upload.file.name]}
                    onDelete={() => deleteFile(upload)}
                    onCancel={() => deleteFile(upload)}
                  />
                );
              })}
            </GoAFormItem>
            {uploadError && (
              <>
                <GoASpacer vSpacing="l" />
                <GoANotification type="important" onDismiss={() => setUploadError(null)}>
                  {uploadError}
                </GoANotification>
                <GoASpacer vSpacing="s" />
              </>
            )}

            <GoASpacer vSpacing="xl" />
          </GoABlock>
        </form>
        <div className="modalfixed">
          <GoAButtonGroup alignment="start">
            <GoAButton disabled={isLoading} mr="4xl" type="submit" onClick={handleSubmit(submitBtnHandler)}>
              <span>{btnLabel}</span>
            </GoAButton>
            <GoAButton
              disabled={!activity || isLoading}
              leadingIcon="remove-circle"
              variant="destructive"
              type="tertiary"
              onClick={confirmActivityCancellation}
            >
              <span>Cancel activity</span>
            </GoAButton>
          </GoAButtonGroup>
        </div>
      </div>
    </GoAModal>
  );
});

export default SupplementaryActivityForm;
