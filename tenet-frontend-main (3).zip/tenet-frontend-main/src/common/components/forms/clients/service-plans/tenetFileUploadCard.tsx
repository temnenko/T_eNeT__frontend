import { GoABlock, GoAButton, GoAButtonGroup, GoAIcon } from '@abgov/react-components';
import { format } from 'date-fns';
import { observer } from 'mobx-react-lite';

export interface GoAFileUploadCardProps {
  filename: string;
  size: number;
  modifiedDate: Date;
  onDelete?: () => void;
  onDownload?: () => void;
}

const TenetFileUploadCard = observer(
  ({ filename, size, modifiedDate, onDelete, onDownload }: GoAFileUploadCardProps) => {
    return (
      <div className="tenet_upload_card">
        <GoABlock>
          <GoAIcon type="document-text" data-testid="icon" size="large" fillColor="blue" />
          <GoABlock direction="column" gap="none">
            <span>
              <GoAButton type="tertiary" onClick={onDownload}>
                {filename}
              </GoAButton>
            </span>
            <span>{`${size}KB`}</span>
            <span>{`Uploaded on ${format(modifiedDate, 'MMMM do, yyyy h:mm a')}`}</span>
          </GoABlock>
        </GoABlock>
        <GoAButtonGroup alignment="center">
          <GoAButton leadingIcon="trash" type="tertiary" onClick={onDelete}>
            Remove
          </GoAButton>
        </GoAButtonGroup>
      </div>
    );
  },
);

export default TenetFileUploadCard;
