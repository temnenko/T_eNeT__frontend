import { useCallback, useState } from 'react';

import { useStore } from '../../../../../../hooks/use-store.hook';
import { SupplementaryActivityOutcome } from '../../../../../../types/service-plan';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';

type Args = {
  activityId?: string;
  hideModal: () => void;
};

const useCancelActivity = ({ activityId, hideModal }: Args) => {
  const {
    supplementaryActivityFormStore: { updateActivity },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});

  const cancelActivity = useCallback(async () => {
    try {
      if (activityId) {
        await updateActivity(activityId, { outcome: SupplementaryActivityOutcome.CANCELLED });
      }
    } catch (error) {
      requestErrorHandler({
        error,
        setError: setRequestError,
      });
    } finally {
      hideModal();
    }
  }, [activityId, hideModal, requestErrorHandler, updateActivity]);

  return {
    cancelActivity,
    requestError,
  };
};

export default useCancelActivity;
