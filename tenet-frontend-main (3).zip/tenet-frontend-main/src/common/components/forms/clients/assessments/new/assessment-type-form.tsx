import {
  GoASpacer,
  GoAFormItem,
  GoAButton,
  GoABlock,
  GoARadioItem,
  GoARadioGroup,
  GoADropdown,
  GoADropdownItem,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import InlineLoadingIndicator from '../../../inline-loading-indicator';
import useSubmitAssessmentType from './hooks/use-submit-assessment-type.hook';
import { AssessmentType } from '../../../../../../types/assessment';
import { useCapitalizeFirstCharOfEveryWord } from '../../../../../../hooks/use-capitalize.hook';

export const AssessmentTypeForm = observer(() => {
  const {
    loading,
    formFields,
    getValues,
    assessmentTypeSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    agreementSummaries,
    canEditInProgressAssessment,
  } = useSubmitAssessmentType();

  const { assessmentType, programAssessedFor } = formFields;
  const capitalizeFirst = useCapitalizeFirstCharOfEveryWord();

  const renderItems = () => {
    return agreementSummaries.map(({ id, name, agreementNumber }) => {
      return <GoADropdownItem value={id} label={`${name} - ${agreementNumber}`} key={id} />;
    });
  };

  return (
    <form className="create-client-form">
      <div className="client-assessment-type">
        <GoAFormItem
          label="Assessment type"
          labelSize="regular"
          error={errors[assessmentType]?.message as unknown as string}
        >
          <GoARadioGroup
            name={assessmentType}
            value={getValues(assessmentType)}
            onChange={(name: string, value: string) => onChangeHandler(name, value as AssessmentType)}
          >
            <div>
              <input type="radio" className="asssessment-employability-p" disabled checked={false} />
              <span className="asssessment-employability-span">Employability Assessment</span>
            </div>
            <GoARadioItem
              value={AssessmentType.SERVICE_NEEDS_DETERMINATION}
              label={capitalizeFirst(AssessmentType.SERVICE_NEEDS_DETERMINATION)}
            />
          </GoARadioGroup>
        </GoAFormItem>

        <GoASpacer vSpacing="xl" />

        <GoABlock direction="column">
          <GoAFormItem
            label="Program assessed for"
            labelSize="regular"
            error={errors.programAssessedFor?.message as unknown as string}
          >
            <GoADropdown
              name={programAssessedFor}
              value={getValues(programAssessedFor)}
              multiselect={false}
              onChange={(name: string, value: string | string[]) => onChangeHandler(name, value as string)}
              width="100%"
            >
              <GoADropdownItem key="no-data" value="" label="- Select Agreement -" />

              {renderItems()}
            </GoADropdown>
          </GoAFormItem>
        </GoABlock>
      </div>

      <GoASpacer vSpacing="4xl" />

      {canEditInProgressAssessment && (
        <GoABlock>
          <GoAButton
            disabled={loading}
            type="submit"
            onClick={handleSubmit(assessmentTypeSubmitHandler)}
            trailingIcon={loading ? undefined : 'arrow-forward'}
          >
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span className="client-bold-600">Next:</span> Needs Identification
              </>
            )}
          </GoAButton>
        </GoABlock>
      )}

      <GoASpacer vSpacing="xl" />
    </form>
  );
});
