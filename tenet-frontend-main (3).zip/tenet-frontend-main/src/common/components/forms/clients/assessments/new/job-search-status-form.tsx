import { GoASpacer, GoAFormItem, GoAButton } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import InlineLoadingIndicator from '../../../inline-loading-indicator';
import useSubmitJobSearch from './hooks/use-submit-job-search.hook';
import RichTextEditor from '../../../../rich-text-editor/rich-text-editor';

export const JobSearchStatusForm = observer(() => {
  const {
    loading,
    formFields,
    control,
    handleSubmit,
    jobSearchActivitiesSubmitHandler,
    previousButtonHandler,
    errors,
    canEditInProgressAssessment,
  } = useSubmitJobSearch();

  const { jobSearchActivities, jobSearchCompetency, strengthsAndChallenges } = formFields;

  return (
    <form className="create-client-form">
      <GoAFormItem
        label="Job search activities"
        labelSize="regular"
        error={errors.jobSearchActivities?.message as unknown as string}
      >
        <span className="font-smaller">
          Explore job search activities to date, including other services and interventions accessed. If currently or
          previously involved with other programs, enter the name of program/provider, dates of involvement and results.
        </span>
        <GoASpacer vSpacing="s" />
        <RichTextEditor
          name={jobSearchActivities}
          control={control}
          placeholder={undefined}
          rules={{
            required: { value: true, message: 'This field is required!' },
            maxLength: {
              value: 1500,
              message: 'Must be less than 1500 characters',
            },
          }}
        />
      </GoAFormItem>

      <GoASpacer vSpacing="xl" />

      <GoAFormItem
        label="Job search competency"
        labelSize="regular"
        error={errors.jobSearchCompetency?.message as unknown as string}
      >
        <span className="font-smaller">
          Explore competency on all aspects of job search, including resume review, interview skills, employer contract,
          labour market knowledge, references, transferrable skills to employment goal.
        </span>
        <GoASpacer vSpacing="s" />
        <RichTextEditor
          name={jobSearchCompetency}
          control={control}
          placeholder={undefined}
          rules={{
            required: { value: true, message: 'This field is required!' },
            maxLength: {
              value: 1500,
              message: 'Must be less than 1500 characters',
            },
          }}
        />
      </GoAFormItem>

      <GoASpacer vSpacing="xl" />

      <GoAFormItem
        label="Strengths and challenges/barriers"
        labelSize="regular"
        error={errors.strengthsAndChallenges?.message as unknown as string}
      >
        <span className="font-smaller">
          Explore strengths, challenges and/or barriers encountered and support(s) needed to re-enter the labour market.
          For example, the client may has reliable child care in place but needs to update their criminal record check.
        </span>
        <GoASpacer vSpacing="s" />

        <RichTextEditor
          name={strengthsAndChallenges}
          control={control}
          placeholder={undefined}
          rules={{
            required: { value: true, message: 'This field is required!' },
            maxLength: {
              value: 1500,
              message: 'Must be less than 1500 characters',
            },
          }}
        />
      </GoAFormItem>

      <GoASpacer vSpacing="3xl" />

      {canEditInProgressAssessment && (
        <div className="row-space-between client-demographic-prev-next">
          <GoAButton disabled={loading} type="secondary" onClick={previousButtonHandler} leadingIcon="arrow-back">
            <span className="client-bold-600">Previous:</span> Employment Status
          </GoAButton>
          <GoAButton
            disabled={loading}
            type="submit"
            onClick={handleSubmit(jobSearchActivitiesSubmitHandler)}
            trailingIcon={loading ? undefined : 'arrow-forward'}
          >
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span className="client-bold-600">Next:</span> Service Recommendation
              </>
            )}
          </GoAButton>
        </div>
      )}

      <GoASpacer vSpacing="3xl" />
    </form>
  );
});
