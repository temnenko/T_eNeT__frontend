import { useCallback, useMemo } from 'react';
import { GoAIcon } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';

import { useStore } from '../../../../../../../hooks/use-store.hook';
import { Stepper } from '../../../../stepper';
import { TabsTextState } from '../../../../../../../types/client-forms';
import {
  AssessmentFormStepperKeys,
  assessmentFormStepperPaths,
  assessmentFormStepperTitles,
} from '../../../../../../../types/assessment-forms';
import useLoadAssessment from './use-load-assessment.hook';

const useFormSteppers = () => {
  const {
    authStore: { isAuthenticated },
    assessmentFormStepperStore: { steppers, active },
  } = useStore();
  const { type, need, employment, jobSearch, service, files, review } = steppers;
  const navigate = useNavigate();
  const { assessment } = useLoadAssessment();

  const clickHandler = useCallback(
    (key: AssessmentFormStepperKeys, path: string) => () => {
      const updatedPath = assessment?.id ? path.replace(':id?', assessment.id!) : path;

      // Do not move past the first assessment form until submitted
      if (assessment?.id) {
        active(key);
        navigate(updatedPath);
      }
    },
    [active, assessment?.id, navigate],
  );
  const getTabIcon = useCallback((tabState: TabsTextState) => {
    if (tabState === TabsTextState.ACTIVE) {
      return <GoAIcon type="pencil" theme="filled" size="small" />;
    }

    if (tabState === TabsTextState.DONE) {
      return <GoAIcon type="checkmark" theme="filled" size="small" />;
    }

    return '';
  }, []);

  const steppersProps = useMemo(
    () => [
      {
        text: assessmentFormStepperTitles.type,
        icon: getTabIcon(type.tabText),
        clickHandler: clickHandler(AssessmentFormStepperKeys.TYPE, assessmentFormStepperPaths.type),
        className: '',
        tabClassName: type.tab,
        textClassName: type.tabText,
      },
      {
        text: assessmentFormStepperTitles.need,
        icon: getTabIcon(need.tabText),
        clickHandler: clickHandler(AssessmentFormStepperKeys.NEED, assessmentFormStepperPaths.need),
        className: '',
        tabClassName: need.tab,
        textClassName: need.tabText,
      },
      {
        text: assessmentFormStepperTitles.employment,
        icon: getTabIcon(employment.tabText),
        clickHandler: clickHandler(AssessmentFormStepperKeys.EMPLOYMENT, assessmentFormStepperPaths.employment),
        className: '',
        tabClassName: employment.tab,
        textClassName: employment.tabText,
      },
      {
        text: assessmentFormStepperTitles.jobSearch,
        icon: getTabIcon(jobSearch.tabText),
        clickHandler: clickHandler(AssessmentFormStepperKeys.JOB_SEARCH, assessmentFormStepperPaths.jobSearch),
        className: '',
        tabClassName: jobSearch.tab,
        textClassName: jobSearch.tabText,
      },
      {
        text: assessmentFormStepperTitles.service,
        icon: getTabIcon(service.tabText),
        clickHandler: clickHandler(AssessmentFormStepperKeys.SERVICE, assessmentFormStepperPaths.service),
        className: '',
        tabClassName: service.tab,
        textClassName: service.tabText,
      },
      {
        text: assessmentFormStepperTitles.files,
        icon: getTabIcon(files.tabText),
        clickHandler: clickHandler(AssessmentFormStepperKeys.FILES, assessmentFormStepperPaths.files),
        className: '',
        tabClassName: files.tab,
        textClassName: files.tabText,
      },
      {
        text: assessmentFormStepperTitles.review,
        icon: getTabIcon(review.tabText),
        clickHandler: clickHandler(AssessmentFormStepperKeys.REVIEW, assessmentFormStepperPaths.review),
        className: '',
        tabClassName: review.tab,
        textClassName: review.tabText,
      },
    ],
    [
      getTabIcon,
      type.tabText,
      type.tab,
      clickHandler,
      need.tabText,
      need.tab,
      employment.tabText,
      employment.tab,
      jobSearch.tabText,
      jobSearch.tab,
      service.tabText,
      service.tab,
      files.tabText,
      files.tab,
      review.tabText,
      review.tab,
    ],
  );

  return useMemo(() => {
    if (isAuthenticated) {
      return steppersProps.map((val) => (
        <Stepper
          key={val.text}
          text={val.text}
          icon={val.icon}
          clickHandler={val.clickHandler}
          className={val.className}
          tabClassName={val.tabClassName}
          textClassName={val.textClassName}
        />
      ));
    }

    return '';
  }, [isAuthenticated, steppersProps]);
};

export default useFormSteppers;
