import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import useLoadAssessment from './use-load-assessment.hook';
import { Assessment } from '../../../../../../../types/assessment';
import { useStore } from '../../../../../../../hooks/use-store.hook';
import { useNavigateAssessmentStepper } from './use-navigate-assessment-stepper.hook';
import { AssessmentFormStepperKeys } from '../../../../../../../types/assessment-forms';

type NeedsIdentificationFormData = {
  workExperience: boolean;
  careerPlanning: boolean;
  educationAndTraining: boolean;
  jobSearchAssistance: boolean;
  careerAdvice: boolean;
  selfEmployment: boolean;
  laborMarketInformation: boolean;
  foreignCredentialRecognition: boolean;
};

type FormFieldName =
  | 'workExperience'
  | 'careerPlanning'
  | 'educationAndTraining'
  | 'jobSearchAssistance'
  | 'careerAdvice'
  | 'selfEmployment'
  | 'laborMarketInformation'
  | 'foreignCredentialRecognition';

const useSubmitNeedsIdentification = () => {
  const {
    assessmentFormStore: { assessmentWatch, watchAssessment, retrieveAssessment, updateAssessment },
    permissionStore: { canEditInProgressAssessment },
  } = useStore();

  const [errorFieldText, setErrorFieldText] = useState('');

  const { assessment } = useLoadAssessment();

  const [loading, setLoading] = useState(false);

  const { goToNextStep, goToPreviousStep, setActiveStep } = useNavigateAssessmentStepper();

  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    formState: { errors },
    reset,
  } = useForm<NeedsIdentificationFormData>({
    defaultValues: {
      workExperience: retrieveAssessment('workExperience') ?? assessment?.workExperience,
      careerPlanning: retrieveAssessment('careerPlanning') ?? assessment?.careerPlanning,
      educationAndTraining: retrieveAssessment('educationAndTraining') ?? assessment?.educationAndTraining,
      jobSearchAssistance: retrieveAssessment('jobSearchAssistance') ?? assessment?.jobSearchAssistance,
      careerAdvice: retrieveAssessment('careerAdvice') ?? assessment?.careerAdvice,
      selfEmployment: retrieveAssessment('selfEmployment') ?? assessment?.selfEmployment,
      laborMarketInformation: retrieveAssessment('laborMarketInformation') ?? assessment?.laborMarketInformation,
      foreignCredentialRecognition:
        retrieveAssessment('foreignCredentialRecognition') ?? assessment?.foreignCredentialRecognition,
    },
  });

  const { name: workExperience } = register('workExperience');
  const [watchWorkExperience, setWorkExperience] = useState<boolean | undefined>(undefined);

  const { name: careerPlanning } = register('careerPlanning');
  const [watchCareerPlanning, setCareerPlanning] = useState<boolean | undefined>(undefined);

  const { name: educationAndTraining } = register('educationAndTraining');
  const [watchEducationTraining, setEducationTraining] = useState<boolean | undefined>(undefined);

  const { name: jobSearchAssistance } = register('jobSearchAssistance');
  const [watchJobSearchAssistance, setJobSearchAssistance] = useState<boolean | undefined>(undefined);

  const { name: careerAdvice } = register('careerAdvice');
  const [watchCareerAdvice, setCareerAdvice] = useState<boolean | undefined>(undefined);

  const { name: selfEmployment } = register('selfEmployment');
  const [watchSelfEmployment, setSelfEmployment] = useState<boolean | undefined>(undefined);

  const { name: laborMarketInformation } = register('laborMarketInformation');
  const [watchLaborMarketInfo, setLaborMarketInfo] = useState<boolean | undefined>(undefined);

  const { name: foreignCredentialRecognition } = register('foreignCredentialRecognition');
  const [watchForeignCredential, setForeignCredential] = useState<boolean | undefined>(undefined);

  const formFields = {
    workExperience,
    careerPlanning,
    educationAndTraining,
    jobSearchAssistance,
    careerAdvice,
    selfEmployment,
    laborMarketInformation,
    foreignCredentialRecognition,
  };

  useEffect(() => {
    setActiveStep(AssessmentFormStepperKeys.NEED);
    if (assessmentWatch || assessment) {
      reset({
        workExperience: retrieveAssessment(workExperience) ?? assessment?.workExperience,
        careerPlanning: retrieveAssessment(careerPlanning) ?? assessment?.careerPlanning,
        educationAndTraining: retrieveAssessment(educationAndTraining) ?? assessment?.educationAndTraining,
        jobSearchAssistance: retrieveAssessment(jobSearchAssistance) ?? assessment?.jobSearchAssistance,
        careerAdvice: retrieveAssessment(careerAdvice) ?? assessment?.careerAdvice,
        selfEmployment: retrieveAssessment(selfEmployment) ?? assessment?.selfEmployment,
        laborMarketInformation: retrieveAssessment(laborMarketInformation) ?? assessment?.laborMarketInformation,
        foreignCredentialRecognition:
          retrieveAssessment(foreignCredentialRecognition) ?? assessment?.foreignCredentialRecognition,
      });
      setWorkExperience(retrieveAssessment(workExperience) ?? assessment?.workExperience);
      setCareerPlanning(retrieveAssessment(careerPlanning) ?? assessment?.careerPlanning);
      setEducationTraining(retrieveAssessment(educationAndTraining) ?? assessment?.educationAndTraining);
      setJobSearchAssistance(retrieveAssessment(jobSearchAssistance) ?? assessment?.jobSearchAssistance);
      setCareerAdvice(retrieveAssessment(careerAdvice) ?? assessment?.careerAdvice);
      setSelfEmployment(retrieveAssessment(selfEmployment) ?? assessment?.selfEmployment);
      setLaborMarketInfo(retrieveAssessment(laborMarketInformation) ?? assessment?.laborMarketInformation);
      setForeignCredential(
        retrieveAssessment(foreignCredentialRecognition) ?? assessment?.foreignCredentialRecognition,
      );
    }
  }, [
    assessment,
    assessmentWatch,
    careerAdvice,
    careerPlanning,
    educationAndTraining,
    foreignCredentialRecognition,
    getValues,
    jobSearchAssistance,
    laborMarketInformation,
    reset,
    retrieveAssessment,
    selfEmployment,
    setActiveStep,
    setValue,
    workExperience,
  ]);

  const needsIdentificationSubmitHandler = useCallback(async () => {
    const needsIdentification: Partial<Assessment> = {
      id: assessment!.id,
      clientId: assessment?.clientId,
      workExperience: watchWorkExperience,
      careerPlanning: watchCareerPlanning,
      educationAndTraining: watchEducationTraining,
      jobSearchAssistance: watchJobSearchAssistance,
      careerAdvice: watchCareerAdvice,
      selfEmployment: watchSelfEmployment,
      laborMarketInformation: watchLaborMarketInfo,
      foreignCredentialRecognition: watchForeignCredential,
    };
    const formEntries =
      watchWorkExperience ||
      watchCareerPlanning ||
      watchEducationTraining ||
      watchJobSearchAssistance ||
      watchCareerAdvice ||
      watchSelfEmployment ||
      watchLaborMarketInfo ||
      watchForeignCredential;

    if (!formEntries) {
      setErrorFieldText('At least one option must be selected');
      return;
    }
    setLoading(true);
    setErrorFieldText('');

    try {
      await updateAssessment(assessment!.id!, needsIdentification as Assessment);
      goToNextStep(assessment!.id!);
    } finally {
      setLoading(false);
    }
  }, [
    assessment,
    goToNextStep,
    updateAssessment,
    watchWorkExperience,
    watchCareerPlanning,
    watchEducationTraining,
    watchJobSearchAssistance,
    watchCareerAdvice,
    watchSelfEmployment,
    watchLaborMarketInfo,
    watchForeignCredential,
  ]);

  const onChangeHandler = useCallback(
    (name: string, value: boolean) => {
      setValue(name as FormFieldName, value);
      watchAssessment(name, value);
      if (name === workExperience) {
        setWorkExperience(value);
      }
      if (name === careerPlanning) {
        setCareerPlanning(value);
      }
      if (name === educationAndTraining) {
        setEducationTraining(value);
      }
      if (name === jobSearchAssistance) {
        setJobSearchAssistance(value);
      }
      if (name === careerAdvice) {
        setCareerAdvice(value);
      }
      if (name === selfEmployment) {
        setSelfEmployment(value);
      }
      if (name === laborMarketInformation) {
        setLaborMarketInfo(value);
      }
      if (name === foreignCredentialRecognition) {
        setForeignCredential(value);
      }
    },
    [
      setValue,
      setWorkExperience,
      watchAssessment,
      workExperience,
      careerPlanning,
      educationAndTraining,
      jobSearchAssistance,
      careerAdvice,
      selfEmployment,
      laborMarketInformation,
      foreignCredentialRecognition,
    ],
  );

  const previousButtonHandler = useCallback(() => {
    goToPreviousStep(assessment!.id!);
  }, [assessment, goToPreviousStep]);

  return {
    loading,
    formFields,
    getValues,
    needsIdentificationSubmitHandler,
    onChangeHandler,
    handleSubmit,
    previousButtonHandler,
    errors,
    assessment,
    errorFieldText,
    canEditInProgressAssessment,
  };
};

export default useSubmitNeedsIdentification;
