import { observer } from 'mobx-react-lite';

import useFormSteppers from './hooks/use-form-steppers.hook';

export const NewAssessmentFormsStepper = observer(() => {
  const steppers = useFormSteppers();

  return (
    <ul className="tabs" role="tablist">
      {steppers}
    </ul>
  );
});
