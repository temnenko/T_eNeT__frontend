import { observer } from 'mobx-react-lite';
import {
  GoASpacer,
  GoAButton,
  GoANotification,
  GoAFormItem,
  GoAFileUploadInput,
  GoATable,
} from '@abgov/react-components';
import { useEffect } from 'react';
import { AssessmentFormStepperKeys } from '../../../../../../types/assessment-forms';
import { useNavigateAssessmentStepper } from './hooks/use-navigate-assessment-stepper.hook';
import InlineLoadingIndicator from '../../../inline-loading-indicator';
import useSubmitAssessmentDocuments from './hooks/use-submit-assessment-files';
import { ClientFilesUploadRow } from '../../../client-files-upload-row';
import useSubmitAssessmentFileUploads from '../../../hooks/use-submit-assessment-file-uploads.hook';

export const AssessmentFilesUploadForm = observer(() => {
  const { setActiveStep } = useNavigateAssessmentStepper();
  const {
    submitHandler,
    loading,
    requestError,
    invalidUploadError,
    previousButtonClickHandler,
    assessment,
    downloadFile,
    canEditInProgressAssessment,
    canDeleteFiles,
  } = useSubmitAssessmentDocuments();
  const {
    uploads,
    progressList,
    deleteFile,
    uploadFile,
    onFileTypeChange,
    fileBeingDeleted,
    fileDeletedSuccessfully,
    setFileDeletedSuccessfully,
    uploadError,
    setUploadError,
  } = useSubmitAssessmentFileUploads();

  useEffect(() => {
    setActiveStep(AssessmentFormStepperKeys.FILES);
  }, [setActiveStep]);

  return (
    <div className="create-client-form">
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {uploadError && (
        <>
          <GoASpacer vSpacing="l" />
          <GoANotification type="important" onDismiss={() => setUploadError(null)}>
            {uploadError}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {assessment && (
        <form className="client-assessment-files">
          {canEditInProgressAssessment && (
            <GoAFormItem label="Assessment documents" requirement="optional">
              <GoAFileUploadInput onSelectFile={uploadFile} maxFileSize="10MB" />
            </GoAFormItem>
          )}

          <GoASpacer vSpacing="l" />
          {fileDeletedSuccessfully && (
            <GoANotification type="information" onDismiss={() => setFileDeletedSuccessfully(false)}>
              File deleted successfully
            </GoANotification>
          )}
          <GoATable>
            <thead>
              <tr>
                <th data-testid="clientCreationUploadedFiles">Files</th>
                <th data-testid="clientCreationFileType">Type</th>
                <th data-testid="clientCreationFilesDateAdded">Date added</th>
                <th data-testid="clientCreationFileSize">Size</th>
                <th>{}</th>
              </tr>
            </thead>
            <tbody data-testid="clientCreationUploadedFilesTableBody">
              <ClientFilesUploadRow
                uploads={uploads}
                progressList={progressList}
                deleteHandler={deleteFile}
                onFileTypeChange={onFileTypeChange}
                fileBeingDeleted={fileBeingDeleted}
                downloadFile={downloadFile}
                canDeleteFiles={canDeleteFiles}
                errorMessage={invalidUploadError?.message}
              />
            </tbody>
          </GoATable>
          <GoASpacer vSpacing="2xl" />
        </form>
      )}
      <GoASpacer vSpacing="l" />
      {canEditInProgressAssessment && (
        <div className="row-space-between client-demographic-prev-next">
          <GoAButton type="secondary" onClick={() => previousButtonClickHandler()} leadingIcon="arrow-back">
            <span className="client-bold-600">Back:</span> Service Recommendation
          </GoAButton>
          <GoAButton onClick={submitHandler} trailingIcon={loading ? undefined : 'arrow-forward'} disabled={loading}>
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span className="client-bold-600">Next:</span> Review
              </>
            )}
          </GoAButton>
        </div>
      )}

      <GoASpacer vSpacing="xl" />
    </div>
  );
});
