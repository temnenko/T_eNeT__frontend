/* eslint-disable react/no-array-index-key */
import { GoAButton, GoAContainer, GoAGrid, GoATable } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useAssessmentReview } from './hooks/use-assessment-review.hook';
import InlineLoadingIndicator from '../../../inline-loading-indicator';

const AssessmentReview = observer(() => {
  const {
    cards,
    previousButtonHandler,
    completeAssessmentHandler,
    modalContent,
    modalVisible,
    loading,
    files,
    canEditInProgressAssessment,
  } = useAssessmentReview();

  const actions = (navigateAction: () => void) => (
    <GoAButton type="tertiary" size="compact" onClick={navigateAction} disabled={false}>
      <span style={{ color: 'white' }}>Edit</span>
    </GoAButton>
  );

  return (
    <div className="client-review-overview">
      {modalVisible && modalContent}
      <GoAGrid gap="xl" minChildWidth="350px">
        {cards?.map((clientCard) => {
          return (
            <GoAContainer
              key={clientCard.title}
              heading={clientCard.title}
              accent="thick"
              actions={actions(clientCard.navigate)}
              padding="compact"
            >
              {clientCard.data.map((item) => (
                <GoAGrid minChildWidth="200px" gap="none" key={item.label}>
                  <div className="client-review-card-label">
                    <span className="color-interactive">{item.label}</span>
                  </div>
                  <div className="client-review-card-value">
                    <span className="client-bold-600">{item.value as string | JSX.Element}</span>
                  </div>
                </GoAGrid>
              ))}
            </GoAContainer>
          );
        })}
        <GoAContainer heading="Files" accent="thick" actions={actions(files.navigate)} padding="compact">
          <GoATable width="100%">
            <thead>
              <tr>
                <th className="review-filename" data-testid="review_filename">
                  Files
                </th>
                <th className="review-filetype" data-testid="review_filetype">
                  Type
                </th>
                <th className="review-dateadded" data-testid="review_dateHeader">
                  Date Added
                </th>
              </tr>
            </thead>
            <tbody>
              {files.data.length
                ? files.data.map((file) => {
                    return (
                      <tr key={`${file.filename}-${file.dateAdded}`}>
                        <td style={{ color: '#0070C4', fontWeight: '400', lineHeight: '28px', width: '40%' }}>
                          {file.filename}
                        </td>
                        <td style={{ width: '20%' }}>{file.filetype}</td>
                        <td style={{ width: '40%' }}>{file.dateAdded}</td>
                      </tr>
                    );
                  })
                : 'No files found'}
            </tbody>
          </GoATable>
        </GoAContainer>
        {canEditInProgressAssessment && (
          <div className="organization-form-buttons client-demographic-prev-next">
            <GoAButton type="secondary" onClick={previousButtonHandler} leadingIcon="arrow-back">
              <span className="client-bold-600">Previous:</span> Client files
            </GoAButton>
            <GoAButton type="primary" onClick={completeAssessmentHandler} disabled={false}>
              {loading ? (
                <InlineLoadingIndicator label="Saving changes..." />
              ) : (
                <>
                  <span className="client-bold-600">Next:</span> Complete Assessment
                </>
              )}
            </GoAButton>
          </div>
        )}
      </GoAGrid>
    </div>
  );
});

export default AssessmentReview;
