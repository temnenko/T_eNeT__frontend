import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import useLoadAssessment from './use-load-assessment.hook';
import { Assessment, AssessmentType, CreateAssessment } from '../../../../../../../types/assessment';
import { useStore } from '../../../../../../../hooks/use-store.hook';
import { useNavigateAssessmentStepper } from './use-navigate-assessment-stepper.hook';
import { AssessmentFormStepperKeys } from '../../../../../../../types/assessment-forms';
import useLoadAgreementDropdownItems from './use-load-agreement-dropdown-items.hook';
import { AgreementSummary } from '../../../../../../../types/agreement';

type AssessmentTypeData = {
  assessmentType: AssessmentType;
  programAssessedFor: string;
};

type FormFieldName = 'assessmentType' | 'programAssessedFor';

const useSubmitAssessmentType = () => {
  const {
    clientsStore: { selectedClient },
    assessmentFormStore: { watchAssessment, retrieveAssessment, createAssessment, updateAssessment },
    permissionStore: { canEditInProgressAssessment },
    userStore: { organizationId },
  } = useStore();

  const { assessment } = useLoadAssessment();

  const { agreementDropdownItems } = useLoadAgreementDropdownItems(organizationId);

  const { goToNextStep, setActiveStep } = useNavigateAssessmentStepper();

  const [agreementSummaries, setAgreementSummaries] = useState<AgreementSummary[]>([]);

  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    formState: { errors },
    reset,
  } = useForm<AssessmentTypeData>({
    defaultValues: {
      assessmentType: retrieveAssessment('assessmentType') ?? assessment?.assessmentType,
      programAssessedFor: retrieveAssessment('programAssessedFor') ?? assessment?.agreementId,
    },
  });

  const { name: assessmentType } = register('assessmentType', { required: 'Please select an assessment type' });
  const { name: programAssessedFor } = register('programAssessedFor', {
    required: { value: true, message: 'Please select a program agreement' },
  });

  const formFields = {
    assessmentType,
    programAssessedFor,
  };

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setActiveStep(AssessmentFormStepperKeys.TYPE);
    if (agreementDropdownItems.length > 0) {
      setAgreementSummaries(agreementDropdownItems);
    }
    reset({
      assessmentType: retrieveAssessment(assessmentType) ?? assessment?.assessmentType,
      programAssessedFor: retrieveAssessment('programAssessedFor') ?? assessment?.agreementId,
    });
  }, [agreementDropdownItems, assessment, assessmentType, reset, retrieveAssessment, setActiveStep, setValue]);

  const assessmentTypeSubmitHandler = useCallback(async () => {
    const assessmentTypeData: CreateAssessment = {
      assessmentType: getValues('assessmentType') as AssessmentType,
      clientId: assessment?.clientId || selectedClient!.id,
      agreementId: getValues(programAssessedFor),
    };
    setLoading(true);
    let id = assessment?.id;
    try {
      if (id) {
        await updateAssessment(id, assessmentTypeData as Assessment);
      } else {
        const created = await createAssessment(assessmentTypeData as Assessment);
        id = created!.id;
      }
      goToNextStep(id);
    } catch (error) {
      setLoading(false);
      return;
    } finally {
      setLoading(false);
    }
  }, [
    getValues,
    assessment?.clientId,
    assessment?.id,
    selectedClient,
    programAssessedFor,
    goToNextStep,
    updateAssessment,
    createAssessment,
  ]);

  const onChangeHandler = useCallback(
    (name: string, value: AssessmentType | string) => {
      setValue(name as FormFieldName, value);
      watchAssessment(name, value);
    },
    [setValue, watchAssessment],
  );

  return {
    loading,
    formFields,
    getValues,
    assessmentTypeSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    assessment,
    agreementSummaries,
    canEditInProgressAssessment,
  };
};

export default useSubmitAssessmentType;
