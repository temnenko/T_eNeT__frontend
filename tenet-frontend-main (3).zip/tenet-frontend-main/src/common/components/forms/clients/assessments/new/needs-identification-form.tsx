import { GoASpacer, GoAFormItem, GoAButton, GoACheckbox, GoANotification } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useSubmitNeedsIdentification from './hooks/use-submit-needs-identification';
import InlineLoadingIndicator from '../../../inline-loading-indicator';

export const NeedsIdentificationForm = observer(() => {
  const {
    loading,
    formFields,
    getValues,
    onChangeHandler,
    handleSubmit,
    needsIdentificationSubmitHandler,
    previousButtonHandler,
    errorFieldText,
    canEditInProgressAssessment,
  } = useSubmitNeedsIdentification();

  const {
    workExperience,
    careerPlanning,
    educationAndTraining,
    jobSearchAssistance,
    careerAdvice,
    selfEmployment,
    laborMarketInformation,
    foreignCredentialRecognition,
  } = formFields;

  return (
    <form className="create-client-form">
      <GoAFormItem label="Select all that apply">
        <span className="font-smaller">
          If the client is not seeking one of the services below, this may not be the right program for them.
        </span>
        <GoASpacer vSpacing="l" />
        <GoACheckbox
          name={workExperience}
          onChange={onChangeHandler}
          checked={getValues(workExperience)}
          value={getValues(workExperience)}
        >
          Work experience
        </GoACheckbox>
        <GoACheckbox
          name={careerPlanning}
          value={getValues(careerPlanning)}
          onChange={onChangeHandler}
          checked={getValues(careerPlanning)}
        >
          Career planning
        </GoACheckbox>
        <GoACheckbox
          name={educationAndTraining}
          value={getValues(educationAndTraining)}
          onChange={onChangeHandler}
          checked={getValues(educationAndTraining)}
        >
          Education and training
        </GoACheckbox>
        <GoACheckbox
          name={jobSearchAssistance}
          value={getValues(jobSearchAssistance)}
          onChange={onChangeHandler}
          checked={getValues(jobSearchAssistance)}
        >
          Job search assistance
        </GoACheckbox>
        <GoACheckbox
          name={careerAdvice}
          value={getValues(careerAdvice)}
          onChange={onChangeHandler}
          checked={getValues(careerAdvice)}
        >
          Career advice
        </GoACheckbox>
        <GoACheckbox
          name={selfEmployment}
          value={getValues(selfEmployment)}
          onChange={onChangeHandler}
          checked={getValues(selfEmployment)}
        >
          Self employment
        </GoACheckbox>
        <GoACheckbox
          name={laborMarketInformation}
          value={getValues(laborMarketInformation)}
          onChange={onChangeHandler}
          checked={getValues(laborMarketInformation)}
        >
          Labour market information
        </GoACheckbox>
        <GoACheckbox
          name={foreignCredentialRecognition}
          value={getValues(foreignCredentialRecognition)}
          onChange={onChangeHandler}
          checked={getValues(foreignCredentialRecognition)}
        >
          Foreign Credential Recognition
        </GoACheckbox>
      </GoAFormItem>
      <GoASpacer vSpacing="m" />
      {errorFieldText && (
        <>
          <GoANotification type="emergency" onDismiss={() => {}}>
            {errorFieldText}
          </GoANotification>
          <GoASpacer vSpacing="s" />{' '}
        </>
      )}

      <GoASpacer vSpacing="3xl" />

      {canEditInProgressAssessment && (
        <div className="row-space-between">
          <GoAButton disabled={loading} type="secondary" onClick={previousButtonHandler} leadingIcon="arrow-back">
            <span className="client-bold-600">Previous:</span> Assessment Type
          </GoAButton>
          <GoAButton
            disabled={loading}
            type="submit"
            onClick={handleSubmit(needsIdentificationSubmitHandler)}
            trailingIcon={loading ? undefined : 'arrow-forward'}
          >
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span className="client-bold-600">Next:</span> Employment Status
              </>
            )}
          </GoAButton>
        </div>
      )}

      <GoASpacer vSpacing="3xl" />
    </form>
  );
});
