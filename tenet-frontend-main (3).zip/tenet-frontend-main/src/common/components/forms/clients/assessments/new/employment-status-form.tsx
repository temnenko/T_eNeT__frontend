import { GoASpacer, GoAFormItem, GoAButton, GoADropdown, GoADropdownItem } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import InlineLoadingIndicator from '../../../inline-loading-indicator';
import useSubmitEmploymentStatus from './hooks/use-submit-employment-status.hook';
import { EmploymentStatusTypes, LMDAIntakeTypes } from '../../../../../../types/assessment-forms';
import RichTextEditor from '../../../../rich-text-editor/rich-text-editor';

export const EmploymentStatusForm = observer(() => {
  const {
    loading,
    formFields,
    control,
    getValues,
    onChangeHandler,
    handleSubmit,
    submitHandler,
    errors,
    previousButtonHandler,
    canEditInProgressAssessment,
  } = useSubmitEmploymentStatus();

  const { financialResources, employmentGoal, employmentStatus, lmdaIntakeType } = formFields;

  return (
    <form className="create-client-form">
      <GoAFormItem label="Employment status at intake" error={errors[employmentStatus]?.message as unknown as string}>
        <GoADropdown name="employmentStatus" onChange={onChangeHandler} value={getValues(employmentStatus)}>
          <GoADropdownItem value="" name="selectEmployment" label="-- Select --" />
          <GoADropdownItem value={EmploymentStatusTypes.UNEMPLOYED} name="unemployed" label="Unemployed" />
          <GoADropdownItem value={EmploymentStatusTypes.EMPLOYED} name="employed" label="Employed" />
          <GoADropdownItem value={EmploymentStatusTypes.SELF_EMPLOYED} name="Self-employed" label="Self-Employed" />
        </GoADropdown>
      </GoAFormItem>
      <GoASpacer vSpacing="s" />
      <GoAFormItem
        label="LMDA verification result at intake"
        error={errors[lmdaIntakeType]?.message as unknown as string}
      >
        <GoADropdown name="lmdaIntakeType" onChange={onChangeHandler} value={getValues(lmdaIntakeType)}>
          <GoADropdownItem value="" name="selectLmdaIntake" label="-- Select --" />
          <GoADropdownItem
            value={LMDAIntakeTypes.ELIGIBLE_FORMER_CLAIMANT}
            name="formerClaimant"
            label="Eligible - Former Claimant"
          />
          <GoADropdownItem
            value={LMDAIntakeTypes.ELIGIBLE_PREMIMUMS_PAID}
            name="premiumsPaid"
            label="Eligible - Premimums Paid"
          />
          <GoADropdownItem
            value={LMDAIntakeTypes.ELIGIBLE_ACTIVE_CLAIM}
            name="activeClaim"
            label="Eligible - Active Claim"
          />
          <GoADropdownItem value={LMDAIntakeTypes.INELIGIBLE} name="ineligible" label="Ineligible" />
        </GoADropdown>
      </GoAFormItem>
      <GoASpacer vSpacing="s" />
      <GoAFormItem
        label="Financial resources and support"
        error={errors[financialResources]?.message as unknown as string}
      >
        <span className="font-smaller">
          Note any current financial resources and support, such as EI, social assistance, available to applicant and
          immediate family. For instance, client’s spouse may be working full time.
        </span>
        <RichTextEditor
          name="financialResources"
          control={control}
          placeholder={undefined}
          rules={{
            required: { value: true, message: 'This field is required!' },
            maxLength: {
              value: 1500,
              message: 'Must be less than 1500 characters',
            },
            validate: (value) => {
              const alphaLen = value.match(/[a-zA-Z]/g)?.length ?? 0;
              if (alphaLen < 20) {
                return 'Must contain more than 20 alphabetic characters';
              }
              return true;
            },
          }}
        />
      </GoAFormItem>
      <GoASpacer vSpacing="m" />
      <GoAFormItem
        label="Primary employment goal or job target"
        error={errors[employmentGoal]?.message as unknown as string}
      >
        <span className="font-smaller">
          Note any details about job target as well as skills and abilities. For instance, is the client willing to work
          away from home or move? Is the job target in a particular industry?
        </span>
        <br />
        <RichTextEditor
          name="employmentGoal"
          control={control}
          placeholder={undefined}
          rules={{
            required: { value: true, message: 'Employment goal is required!' },
          }}
        />
      </GoAFormItem>

      <GoASpacer vSpacing="3xl" />

      {canEditInProgressAssessment && (
        <div className="row-space-between client-demographic-prev-next">
          <GoAButton disabled={loading} type="secondary" onClick={previousButtonHandler} leadingIcon="arrow-back">
            <span className="client-bold-600">Previous:</span> Needs identification
          </GoAButton>
          <GoAButton
            disabled={loading}
            type="submit"
            onClick={handleSubmit(submitHandler)}
            trailingIcon={loading ? undefined : 'arrow-forward'}
          >
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span className="client-bold-600">Next:</span> Job search status
              </>
            )}
          </GoAButton>
        </div>
      )}

      <GoASpacer vSpacing="3xl" />
    </form>
  );
});
