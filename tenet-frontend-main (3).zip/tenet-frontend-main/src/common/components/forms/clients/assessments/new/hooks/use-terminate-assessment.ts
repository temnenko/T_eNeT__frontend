import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../../../../../hooks/use-store.hook';
import { Assessment, AssessmentStatus, UpdateAssessment } from '../../../../../../../types/assessment';
import useLoadAssessment from './use-load-assessment.hook';

type TerminateArgs = {
  status: AssessmentStatus.CLIENT_DECLINED | AssessmentStatus.PROVIDER_CANCELLED;
};

const useTerminateAssessment = () => {
  const {
    assessmentFormStore: { updateAssessment },
    clientsStore: { selectedClient },
    permissionStore: { canEditInProgressAssessment },
  } = useStore();
  const { assessment } = useLoadAssessment();

  const clientId = assessment?.clientId || selectedClient?.id;

  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);

  const terminateAssessment = useCallback(
    async (args: TerminateArgs) => {
      try {
        setLoading(true);

        const update: UpdateAssessment = {
          status: args.status,
          assessmentDate: new Date(),
        };
        await updateAssessment(assessment!.id, update as Assessment);
        navigate(`/clients/${clientId}/all-assessments`);
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error(e);
      } finally {
        setLoading(false);
      }
    },
    [assessment, clientId, navigate, updateAssessment],
  );

  return {
    disabled: !assessment?.id,
    loading,
    terminateAssessment,
    canEditInProgressAssessment,
  };
};

export default useTerminateAssessment;
