import { useCallback, useEffect, useState } from 'react';
import { useStore } from '../../../../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../../../../hooks/use-request-error-handler.hook';
import { InvalidFileUploadError } from '../../../../../../../types/errors/invalid-file-upload.error';
import { AssessmentFormStepperKeys } from '../../../../../../../types/assessment-forms';
import useLoadAssessment from './use-load-assessment.hook';
import { useNavigateAssessmentStepper } from './use-navigate-assessment-stepper.hook';
import { RequestError } from '../../../../../../../types/errors/errors';
import { fileService } from '../../../../../../../services/clients/client-files.service';

const useSubmitAssessmentDocuments = () => {
  const { assessment } = useLoadAssessment();

  const {
    assessmentFilesStore: { getAssementDocuments, documents, newUploads },
    permissionStore: { canEditInProgressAssessment, canDeleteInProgressAssessmentFile },
  } = useStore();

  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [invalidUploadError, setInvalidUploadError] = useState<InvalidFileUploadError | null>(null);
  const { goToNextStep, goToPreviousStep, setActiveStep } = useNavigateAssessmentStepper();

  useEffect(() => {
    const call = async (assessmentId: string) => {
      await getAssementDocuments(assessmentId);
    };
    if (assessment) {
      call(assessment.id);
    }
  }, [assessment, getAssementDocuments]);

  const submitHandler = async () => {
    try {
      setInvalidUploadError(null);
      setLoading(true);
      if (newUploads.length && newUploads.some((f) => !f.fileType)) {
        throw new InvalidFileUploadError('Select a file type');
      }
      goToNextStep(assessment!.id);
    } catch (error) {
      if (error instanceof InvalidFileUploadError) {
        setInvalidUploadError(error);
      } else {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
        // eslint-disable-next-line no-console
        console.error(error);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setActiveStep(AssessmentFormStepperKeys.FILES);
  }, [setActiveStep]);

  const previousButtonClickHandler = useCallback(() => {
    goToPreviousStep(assessment!.id);
  }, [goToPreviousStep, assessment]);

  const downloadFile = useCallback(
    (fileId: string, filename: string, filesize: number) => {
      try {
        setLoading(true);
        fileService.downloadFileByAdspId(fileId, filename, filesize);
      } catch (error) {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    },
    [requestErrorHandler],
  );

  return {
    submitHandler,
    loading,
    requestError,
    invalidUploadError,
    setInvalidUploadError,
    previousButtonClickHandler,
    getAssementDocuments,
    assessment,
    documents,
    downloadFile,
    canEditInProgressAssessment,
    canDeleteFiles: canDeleteInProgressAssessmentFile,
  };
};

export default useSubmitAssessmentDocuments;
