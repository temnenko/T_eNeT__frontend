/* eslint-disable no-nested-ternary */
import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';

import useLoadAssessment from './use-load-assessment.hook';
import { Assessment } from '../../../../../../../types/assessment';
import { useStore } from '../../../../../../../hooks/use-store.hook';
import { AssessmentFormStepperKeys, ServiceRecommendationTypes } from '../../../../../../../types/assessment-forms';
import { useNavigateAssessmentStepper } from './use-navigate-assessment-stepper.hook';
import { toIsoFormat } from '../../../../../../../utils/date.util';

type FormFieldName =
  | 'serviceRecommendation'
  | 'readyWillingAble'
  | 'approved'
  | 'laborMarketDestined'
  | 'approvedAt'
  | 'reviewRequested'
  | 'assessmentDate'
  | 'agreementDate';

type ServiceRecommendationData = {
  serviceRecommendation: string;
  readyWillingAble: ServiceRecommendationTypes;
  approved: ServiceRecommendationTypes;
  laborMarketDestined: ServiceRecommendationTypes;
  approvedAt: Date;
  reviewRequested: ServiceRecommendationTypes;
  assessmentDate: string | undefined;
  agreementDate: string | undefined;
};

const useSubmitServiceRecommendation = (assessmentId?: string) => {
  const {
    assessmentFormStore: { assessmentWatch, watchAssessment, retrieveAssessment, updateAssessment },
    permissionStore: { canEditInProgressAssessment },
  } = useStore();

  const { assessment } = useLoadAssessment(assessmentId);

  const { goToNextStep, setActiveStep, goToPreviousStep } = useNavigateAssessmentStepper();

  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    reset,
    watch,
    control,
    formState: { errors },
  } = useForm<ServiceRecommendationData>({
    defaultValues: {
      serviceRecommendation: retrieveAssessment('serviceRecommendation') ?? assessment?.serviceRecommendation,
      approvedAt: retrieveAssessment('approvedAt') ?? assessment?.approvedAt,
    },
  });

  useEffect(() => {
    setActiveStep(AssessmentFormStepperKeys.SERVICE);
    if (assessmentWatch || assessment) {
      reset({
        serviceRecommendation: retrieveAssessment('serviceRecommendation') ?? assessment?.serviceRecommendation,
        readyWillingAble:
          retrieveAssessment('readyWillingAble') ??
          (assessment?.readyWillingAble !== undefined
            ? assessment?.readyWillingAble
              ? ServiceRecommendationTypes.YES
              : ServiceRecommendationTypes.NO
            : undefined),
        approved:
          retrieveAssessment('approved') ??
          (assessment?.approved !== undefined
            ? assessment?.approved
              ? ServiceRecommendationTypes.YES
              : ServiceRecommendationTypes.NO
            : undefined),
        laborMarketDestined:
          retrieveAssessment('laborMarketDestined') ??
          (assessment?.laborMarketDestined !== undefined
            ? assessment?.laborMarketDestined
              ? ServiceRecommendationTypes.YES
              : ServiceRecommendationTypes.NO
            : undefined),
        reviewRequested:
          retrieveAssessment('reviewRequested') ??
          (assessment?.reviewRequested !== undefined
            ? assessment?.reviewRequested
              ? ServiceRecommendationTypes.YES
              : ServiceRecommendationTypes.NO
            : undefined),
        assessmentDate: retrieveAssessment('assessmentDate')
          ? retrieveAssessment('assessmentDate')
          : assessment?.assessmentDate
            ? toIsoFormat(assessment?.assessmentDate)
            : undefined,
        agreementDate: retrieveAssessment('agreementDate')
          ? retrieveAssessment('agreementDate')
          : assessment?.agreementDate
            ? toIsoFormat(assessment?.agreementDate)
            : undefined,
      });
    }
  }, [assessment, assessmentWatch, reset, retrieveAssessment, setActiveStep]);

  const { name: serviceRecommendation } = register('serviceRecommendation', {
    required: { value: true, message: 'Service recommendation is required!' },
  });

  const { name: readyWillingAble } = register('readyWillingAble', {
    required: { value: true, message: 'Ready willing able is required!' },
  });

  const { name: approved } = register('approved', {
    required: { value: true, message: 'Approval is required!' },
  });

  const { name: laborMarketDestined } = register('laborMarketDestined', {
    required: { value: true, message: 'Labour market destined is required!' },
  });

  const approvedValue = watch(approved);
  const { name: assessmentDate } = register('assessmentDate', {
    required: {
      value: true,
      message: 'Assessment date is required!',
    },
  });
  const { name: reviewRequested } = register('reviewRequested', {
    required: { value: approvedValue === ServiceRecommendationTypes.NO, message: 'Review requested is required' },
  });
  const { name: agreementDate } = register('agreementDate', {
    required: {
      value: approvedValue === ServiceRecommendationTypes.YES,
      message: 'Agreement date is required!',
    },
  });

  const formFields = {
    serviceRecommendation,
    readyWillingAble,
    approved,
    laborMarketDestined,
    reviewRequested,
    assessmentDate,
    agreementDate,
  };

  const reviewRequestedValue = watch('reviewRequested');

  const [loading, setLoading] = useState(false);

  const serviceRecommendationSubmitHandler = useCallback(async () => {
    const serviceRecommendationData = {
      serviceRecommendation: getValues(serviceRecommendation),
      readyWillingAble:
        getValues(readyWillingAble) === undefined
          ? undefined
          : getValues(readyWillingAble) === ServiceRecommendationTypes.YES,
      laborMarketDestined:
        getValues(laborMarketDestined) === undefined
          ? undefined
          : getValues(laborMarketDestined) === ServiceRecommendationTypes.YES,
      approved: getValues(approved) === undefined ? undefined : getValues(approved) === ServiceRecommendationTypes.YES,
      reviewRequested:
        getValues(reviewRequested) === undefined
          ? undefined
          : getValues(reviewRequested) === ServiceRecommendationTypes.YES,
      assessmentDate: getValues('assessmentDate') ? new Date(getValues('assessmentDate')!).toISOString() : undefined,
      approvedAt: getValues(approved) === ServiceRecommendationTypes.YES ? new Date().toISOString() : undefined,
      agreementDate: getValues('agreementDate') ? new Date(getValues('agreementDate')!).toISOString() : undefined,
    };
    setLoading(true);
    await updateAssessment(assessment!.id!, serviceRecommendationData as Assessment).finally(() => setLoading(false));
    goToNextStep(assessment!.id);
  }, [
    approved,
    assessment,
    getValues,
    goToNextStep,
    laborMarketDestined,
    readyWillingAble,
    reviewRequested,
    serviceRecommendation,
    updateAssessment,
  ]);

  const onChangeHandler = useCallback(
    (name: string, value: string | boolean | string[] | Date | undefined) => {
      if (Array.isArray(value)) {
        setValue(name as FormFieldName, value.join(','));
        watchAssessment(name, value.join(','));
      } else {
        setValue(name as FormFieldName, value as string);
        watchAssessment(name, value);
      }
    },
    [setValue, watchAssessment],
  );

  const onRadioButtonChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value);
      watchAssessment(name, value);
    },
    [setValue, watchAssessment],
  );

  const previousButtonClickHandler = useCallback(() => {
    goToPreviousStep(assessment!.id);
  }, [assessment, goToPreviousStep]);

  return {
    loading,
    formFields,
    getValues,
    serviceRecommendationSubmitHandler,
    onChangeHandler,
    handleSubmit,
    control,
    errors,
    assessment,
    onRadioButtonChangeHandler,
    previousButtonClickHandler,
    reviewRequestedValue,
    approvedValue,
    canEditInProgressAssessment,
  };
};

export default useSubmitServiceRecommendation;
