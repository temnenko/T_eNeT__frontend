import {
  GoASpacer,
  GoAFormItem,
  GoAButton,
  GoABlock,
  GoARadioItem,
  GoARadioGroup,
  GoACallout,
  GoAInput,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { subYears } from 'date-fns';
import InlineLoadingIndicator from '../../../inline-loading-indicator';
import useSubmitServiceRecommendation from './hooks/use-service-recommendation.hook';
import { ServiceRecommendationTypes } from '../../../../../../types/assessment-forms';
import { toIsoFormat } from '../../../../../../utils/date.util';
import RichTextEditor from '../../../../rich-text-editor/rich-text-editor';

interface Props {
  assessmentId?: string;
}

export const ServiceRecommendationForm = observer(({ assessmentId }: Props) => {
  const {
    loading,
    formFields,
    control,
    getValues,
    serviceRecommendationSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    onRadioButtonChangeHandler,
    previousButtonClickHandler,
    reviewRequestedValue,
    approvedValue,
    canEditInProgressAssessment,
  } = useSubmitServiceRecommendation(assessmentId);

  const {
    serviceRecommendation,
    readyWillingAble,
    approved,
    laborMarketDestined,
    reviewRequested,
    assessmentDate,
    agreementDate,
  } = formFields;

  return (
    <form className="create-client-form">
      <GoABlock direction="column">
        <GoAFormItem label="Labour market destined" error={errors.laborMarketDestined?.message as unknown as string}>
          <GoARadioGroup
            name={laborMarketDestined}
            value={getValues(laborMarketDestined)}
            onChange={onRadioButtonChangeHandler}
            orientation="vertical"
          >
            <GoARadioItem value={ServiceRecommendationTypes.YES} label="Yes" />
            <GoARadioItem value={ServiceRecommendationTypes.NO} label="No" />
          </GoARadioGroup>
        </GoAFormItem>
      </GoABlock>
      <GoASpacer vSpacing="m" />
      <GoABlock direction="column">
        <GoAFormItem
          label="Provider determined applicant Ready Willing Able?"
          error={errors.readyWillingAble?.message as unknown as string}
        >
          <GoARadioGroup
            name={readyWillingAble}
            value={getValues(readyWillingAble)}
            onChange={onRadioButtonChangeHandler}
            orientation="vertical"
          >
            <GoARadioItem value={ServiceRecommendationTypes.YES} label="Yes" />
            <GoARadioItem value={ServiceRecommendationTypes.NO} label="No" />
          </GoARadioGroup>
        </GoAFormItem>
      </GoABlock>
      <GoASpacer vSpacing="m" />
      <GoABlock direction="column">
        <GoAFormItem label="Service Recommendation" error={errors.serviceRecommendation?.message as unknown as string}>
          <p>
            If suitable, record recommended service components and rationale for suitability. If not suitable, record
            alternatives explored or recommended, including the agency, provider/program, or community supports
            discussed and referred to.{' '}
          </p>
          <RichTextEditor
            control={control}
            name={serviceRecommendation}
            placeholder={undefined}
            rules={{
              required: { value: true, message: 'Service recommendation is required!' },
            }}
          />
        </GoAFormItem>
      </GoABlock>
      <GoASpacer vSpacing="l" />
      <GoABlock direction="column">
        <GoAFormItem
          label="Assessors’s recommendation for services"
          error={errors.approved?.message as unknown as string}
        >
          <GoASpacer vSpacing="m" />
          <GoARadioGroup
            name={approved}
            value={getValues(approved)}
            onChange={onRadioButtonChangeHandler}
            orientation="vertical"
          >
            <GoARadioItem value={ServiceRecommendationTypes.YES} label="Approved" />
            <GoARadioItem value={ServiceRecommendationTypes.NO} label="Declined" />
          </GoARadioGroup>
        </GoAFormItem>
      </GoABlock>
      <GoASpacer vSpacing="l" />
      {approvedValue === ServiceRecommendationTypes.YES && (
        <div className="assessment-participant">
          <p>Participant Agreement</p>
          <p>
            This is to confirm that applicant has been informed of program intent, objectives and expectations of
            participation. The applicant has agreed to actively participate in the program and will advise service
            manager of any change in circumstance that may impact their ongoing eligibility or ability to successfully
            complete the program.
          </p>
          <GoAFormItem error={errors[agreementDate]?.message as unknown as string}>
            <GoAInput
              type="date"
              onChange={onChangeHandler}
              name={agreementDate}
              value={getValues(agreementDate) ? toIsoFormat(getValues(agreementDate)!) : undefined}
              min={toIsoFormat(subYears(new Date(), 50))}
              max="9999-12-31"
            />
          </GoAFormItem>
          <GoASpacer vSpacing="l" />
        </div>
      )}
      <GoAFormItem error={errors[assessmentDate]?.message as unknown as string} label="The client was assessed on">
        <GoAInput
          type="date"
          onChange={onChangeHandler}
          name={assessmentDate}
          value={getValues(assessmentDate) ? toIsoFormat(getValues(assessmentDate)!) : undefined}
          min={toIsoFormat(subYears(new Date(), 50))}
          max="9999-12-31"
        />
      </GoAFormItem>
      {approvedValue === ServiceRecommendationTypes.NO && (
        <>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <GoAFormItem
              label="Applicant was advised of their right to review this decision and would like to:"
              error={errors.reviewRequested?.message as unknown as string}
            >
              <GoARadioGroup
                name={reviewRequested}
                value={getValues(reviewRequested)}
                onChange={onRadioButtonChangeHandler}
                orientation="vertical"
              >
                <GoARadioItem value={ServiceRecommendationTypes.YES} label="Decline the review" />
                <GoARadioItem value={ServiceRecommendationTypes.NO} label="Request to review" />
              </GoARadioGroup>
            </GoAFormItem>
          </GoABlock>
        </>
      )}
      <GoASpacer vSpacing="l" />
      {reviewRequestedValue === ServiceRecommendationTypes.NO && approvedValue === ServiceRecommendationTypes.NO && (
        <div className="width-416-px">
          <GoACallout type="important" size="medium">
            Please follow your organization’s review procedure after submitting this form and record the review
            decision.
          </GoACallout>
        </div>
      )}

      <GoASpacer vSpacing="3xl" />

      {canEditInProgressAssessment && (
        <div className="row-space-between client-demographic-prev-next">
          <GoAButton disabled={loading} type="secondary" onClick={previousButtonClickHandler} leadingIcon="arrow-back">
            <span className="client-bold-600">Previous:</span>Job search status
          </GoAButton>
          <GoAButton
            disabled={loading}
            type="submit"
            onClick={handleSubmit(serviceRecommendationSubmitHandler)}
            trailingIcon={loading ? undefined : 'arrow-forward'}
          >
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span className="client-bold-600">Next:</span> Client files
              </>
            )}
          </GoAButton>
        </div>
      )}

      <GoASpacer vSpacing="3xl" />
    </form>
  );
});
