import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useStore } from '../../../../../../../hooks/use-store.hook';
import useLoadAssessment from './use-load-assessment.hook';
import { useNavigateAssessmentStepper } from './use-navigate-assessment-stepper.hook';
import {
  AssessmentFormStepperKeys,
  EmploymentStatusTypes,
  LMDAIntakeTypes,
} from '../../../../../../../types/assessment-forms';
import { Assessment, UpdateAssessment } from '../../../../../../../types/assessment';
import { getEnumValue } from '../../../../../../../utils/enums.util';

type FormFieldName = 'financialResources' | 'employmentGoal';

type EmploymentStatusData = {
  financialResources: string;
  employmentGoal: string;
  employmentStatus: string;
  lmdaIntakeType: string;
};
const useSubmitEmploymentStatus = () => {
  const {
    assessmentFormStore: { watchAssessment, retrieveAssessment, updateAssessment },
    permissionStore: { canEditInProgressAssessment },
  } = useStore();
  const { assessment } = useLoadAssessment();
  const { goToNextStep, setActiveStep, goToPreviousStep } = useNavigateAssessmentStepper();

  const {
    getValues,
    handleSubmit,
    control,
    register,
    setValue,
    reset,
    formState: { errors },
    setError,
  } = useForm<EmploymentStatusData>({
    defaultValues: {
      financialResources: retrieveAssessment('financialResources') ?? assessment?.financialResources,
      employmentGoal: retrieveAssessment('employmentGoal') ?? assessment?.employmentGoal,
      employmentStatus: retrieveAssessment('employmentStatus') ?? assessment?.employmentStatus,
      lmdaIntakeType: retrieveAssessment('lmdaIntakeType') ?? assessment?.lmdaIntakeType,
    },
  });

  const [loading, setLoading] = useState(false);

  const { name: financialResources } = register('financialResources', {
    required: { value: true, message: 'This field is required!' },
    maxLength: {
      value: 1500,
      message: 'Must be less than 1500 characters',
    },
    validate: (value) => {
      const alphaLen = value.match(/[a-zA-Z]/g)?.length ?? 0;
      if (alphaLen < 20) {
        return 'Must contain more than 20 alphabetic characters';
      }
      return true;
    },
  });

  const { name: employmentGoal } = register('employmentGoal', {
    required: { value: true, message: 'Employment goal is required!' },
  });

  const { name: employmentStatus } = register('employmentStatus', {
    required: { value: true, message: 'Employment status is required!' },
  });

  const { name: lmdaIntakeType } = register('lmdaIntakeType', {
    required: { value: true, message: 'Lmda intake type is required!' },
  });

  const formFields = {
    financialResources,
    employmentGoal,
    employmentStatus,
    lmdaIntakeType,
  };

  useEffect(() => {
    setActiveStep(AssessmentFormStepperKeys.EMPLOYMENT);
    reset({
      financialResources: retrieveAssessment(financialResources) ?? assessment?.financialResources,
      employmentGoal: retrieveAssessment(employmentGoal) ?? assessment?.employmentGoal,
      employmentStatus: retrieveAssessment(employmentStatus) ?? assessment?.employmentStatus,
      lmdaIntakeType: retrieveAssessment(lmdaIntakeType) ?? assessment?.lmdaIntakeType,
    });
  }, [
    assessment,
    employmentGoal,
    employmentStatus,
    financialResources,
    lmdaIntakeType,
    reset,
    retrieveAssessment,
    setActiveStep,
  ]);

  const hasInvalidFields = useCallback(() => {
    let invalid = false;

    const finResource = getValues(financialResources);
    if (finResource?.length) {
      const alphaLen = finResource.match(/[a-zA-Z]/g)?.length ?? 0;
      if (alphaLen < 20) {
        setError(financialResources, { type: 'custom', message: 'Must contain more than 20 alphabetic characters' });
        invalid = true;
      }
    }
    return invalid;
  }, [financialResources, getValues, setError]);

  const submitHandler = useCallback(async () => {
    const continueSave = async () => {
      try {
        if (hasInvalidFields()) {
          return;
        }

        setLoading(true);

        const args: UpdateAssessment = {
          financialResources: getValues('financialResources'),
          employmentGoal: getValues('employmentGoal'),
          employmentStatus: getEnumValue(EmploymentStatusTypes, getValues('employmentStatus')),
          lmdaIntakeType: getEnumValue(LMDAIntakeTypes, getValues('lmdaIntakeType')),
        };
        await updateAssessment(assessment!.id!, args as Assessment);
        goToNextStep(assessment!.id);
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    continueSave();
  }, [assessment, getValues, goToNextStep, hasInvalidFields, updateAssessment]);

  const onChangeHandler = useCallback(
    (name: string, value: string | string[]) => {
      if (typeof value === 'string') {
        setValue(name as FormFieldName, value);
        watchAssessment(name, value);
      }
    },
    [setValue, watchAssessment],
  );

  const previousButtonHandler = useCallback(() => {
    goToPreviousStep(assessment!.id);
  }, [assessment, goToPreviousStep]);

  return {
    loading,
    control,
    submitHandler,
    handleSubmit,
    errors,
    getValues,
    onChangeHandler,
    formFields,
    previousButtonHandler,
    canEditInProgressAssessment,
  };
};

export default useSubmitEmploymentStatus;
