/* eslint-disable no-nested-ternary */
import { ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format, parseISO } from 'date-fns';
import { useStore } from '../../../../../../../hooks/use-store.hook';
import { useNavigateAssessmentStepper } from './use-navigate-assessment-stepper.hook';
import { AssessmentFormStepperKeys, EmploymentStatusLabels } from '../../../../../../../types/assessment-forms';
import { ClientAssessmentServicePlanModal } from '../../../../../modals/client-assessment-service-plan-modal';
import { getEnumValue } from '../../../../../../../utils/enums.util';
import { toIsoFormat } from '../../../../../../../utils/date.util';
import RichText from '../../../../../rich-text-editor/rich-text';

export const useAssessmentReview = () => {
  const {
    assessmentFormStore: { assessmentNeedsString, assessment, completeAssessment, resetAssessment },
    clientsStore: { selectedClient },
    assessmentFilesStore: { documents, getAssementDocuments, uploadAssessmentDocuments },
    permissionStore: { canCreateNewServicePlanForClient, canEditInProgressAssessment },
  } = useStore();
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);
  const [loading, setLoading] = useState(false);

  const clientId = assessment?.clientId || selectedClient?.id;
  const navigate = useNavigate();

  const { goToPreviousStep, setActiveStep, jumpToStep } = useNavigateAssessmentStepper();

  useEffect(() => {
    setActiveStep(AssessmentFormStepperKeys.REVIEW);
    if (assessment) {
      getAssementDocuments(assessment?.id);
    }
  }, [setActiveStep, getAssementDocuments, assessment]);

  const previousButtonHandler = useCallback(() => {
    goToPreviousStep(assessment!.id);
  }, [assessment, goToPreviousStep]);

  const finalizeAssessment = useCallback(async () => {
    await uploadAssessmentDocuments(assessment!.id);
    await completeAssessment(assessment!.id);
    setModalVisible(false);
    setModalContent(null);
    resetAssessment();
  }, [assessment, completeAssessment, resetAssessment, uploadAssessmentDocuments]);

  const completeAssessmentHandler = useCallback(async () => {
    try {
      if (canCreateNewServicePlanForClient) {
        setModalVisible(true);
        setLoading(true);

        setModalContent(
          <ClientAssessmentServicePlanModal
            onDecline={async () => {
              await finalizeAssessment();
              navigate(`/clients/${clientId}/service-plans?origin=assessment`);
            }}
            onConfirm={async () => {
              await finalizeAssessment();
              navigate(`/clients/${clientId}/service-plans/transition-to-employment?origin=assessment`);
            }}
          />,
        );
      } else {
        await finalizeAssessment();
        navigate(`/clients/${clientId}/service-plans`);
      }
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [canCreateNewServicePlanForClient, clientId, finalizeAssessment, navigate]);

  return useMemo(() => {
    const cards = [
      {
        title: 'Assessment Type',
        navigate: () => jumpToStep(AssessmentFormStepperKeys.TYPE, assessment!.id),
        data: [
          {
            label: 'Assessment type',
            value: assessment?.assessmentType,
          },
        ],
      },
      {
        title: 'Needs Identification',
        navigate: () => jumpToStep(AssessmentFormStepperKeys.NEED, assessment!.id),
        data: [
          {
            label: 'Needs',
            value: <RichText html={assessmentNeedsString} />,
          },
        ],
      },
      {
        title: 'Employment Status',
        navigate: () => jumpToStep(AssessmentFormStepperKeys.EMPLOYMENT, assessment!.id),
        data: [
          {
            label: 'Employment status at intake',
            value: getEnumValue(EmploymentStatusLabels, assessment?.employmentStatus),
          },
          {
            label: 'LMDA intake type',
            value: assessment?.lmdaIntakeType?.replaceAll('_', ' '),
          },
          {
            label: 'Primary source of income',
            value: <RichText html={assessment?.financialResources ?? ''} />,
          },
          {
            label: 'Goals and competency',
            value: <RichText html={assessment?.employmentGoal ?? ''} />,
          },
        ],
      },
      {
        title: 'Job Search Status',
        navigate: () => jumpToStep(AssessmentFormStepperKeys.JOB_SEARCH, assessment!.id),
        data: [
          {
            label: 'Job search activities',
            value: <RichText html={assessment?.jobSearchActivities ?? ''} />,
          },
          {
            label: 'Job search competency',
            value: <RichText html={assessment?.jobSearchCompetency ?? ''} />,
          },
          {
            label: 'Strengths and challenges/barriers',
            value: <RichText html={assessment?.strengthsAndBarriers ?? ''} />,
          },
        ],
      },
      {
        title: 'Service recommendation',
        navigate: () => jumpToStep(AssessmentFormStepperKeys.SERVICE, assessment!.id),
        data: [
          {
            label: 'Program',
            value: assessment?.agreementName,
          },
          {
            label: 'Labor market destined',
            value:
              assessment?.laborMarketDestined === true
                ? 'Yes'
                : assessment?.laborMarketDestined === false
                  ? 'No'
                  : 'Unspecified',
          },
          {
            label: 'RWA',
            value:
              assessment?.readyWillingAble === true
                ? 'Yes'
                : assessment?.readyWillingAble === false
                  ? 'No'
                  : 'Unspecified',
          },
          {
            label: 'Recommendation',
            value: <RichText html={assessment?.serviceRecommendation?.replaceAll('_', ' ') ?? ''} />,
          },
          {
            label: 'Assessor decision',
            value: assessment?.approved === true ? 'Approved' : 'Declined',
          },
          {
            label: 'Agreement Date',
            value: assessment?.agreementDate ? toIsoFormat(assessment?.agreementDate.toString()) : '',
          },
          {
            label: 'Assessment Date',
            value: assessment?.assessmentDate ? toIsoFormat(assessment?.assessmentDate.toString()) : '',
          },
        ],
      },
    ];
    const files = {
      title: 'Files',
      navigate: () => jumpToStep(AssessmentFormStepperKeys.FILES, assessment!.id),
      data: documents?.map((fileUpload) => {
        return {
          filename: fileUpload.fileName,
          filetype: fileUpload.typeName,
          dateAdded: format(parseISO(fileUpload.adspCreatedAt), 'MMM do, yyyy h:mm a'),
        };
      }),
    };
    return {
      cards,
      assessment,
      previousButtonHandler,
      completeAssessmentHandler,
      modalContent,
      modalVisible,
      loading,
      files,
      canEditInProgressAssessment,
    };
  }, [
    assessment,
    assessmentNeedsString,
    documents,
    previousButtonHandler,
    completeAssessmentHandler,
    modalContent,
    modalVisible,
    loading,
    canEditInProgressAssessment,
    jumpToStep,
  ]);
};
