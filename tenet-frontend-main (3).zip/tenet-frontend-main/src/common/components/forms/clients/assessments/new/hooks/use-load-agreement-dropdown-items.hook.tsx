import { useEffect } from 'react';
import { useStore } from '../../../../../../../hooks/use-store.hook';

const useLoadAgreementDropdownItems = (organizationId?: string) => {
  const {
    organizationStore: { completedAgreementsSummary, getOrganizationCompletedAgreements },
  } = useStore();

  useEffect(() => {
    const fetchAssessmentSummaries = async () => {
      if (completedAgreementsSummary.length === 0 && organizationId) {
        await getOrganizationCompletedAgreements(organizationId);
      }
    };
    fetchAssessmentSummaries();
  }, [completedAgreementsSummary.length, getOrganizationCompletedAgreements, organizationId]);

  return {
    agreementDropdownItems: completedAgreementsSummary,
  };
};

export default useLoadAgreementDropdownItems;
