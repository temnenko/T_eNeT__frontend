import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import useLoadAssessment from './use-load-assessment.hook';
import { Assessment } from '../../../../../../../types/assessment';
import { useStore } from '../../../../../../../hooks/use-store.hook';
import { useNavigateAssessmentStepper } from './use-navigate-assessment-stepper.hook';
import { AssessmentFormStepperKeys } from '../../../../../../../types/assessment-forms';

type JobSearchStatusFormData = {
  jobSearchActivities: string;
  jobSearchCompetency: string;
  strengthsAndChallenges: string;
};

type FormFieldName = 'jobSearchActivities' | 'jobSearchCompetency' | 'strengthsAndChallenges';

const useSubmitJobSearch = () => {
  const {
    assessmentFormStore: { watchAssessment, retrieveAssessment, updateAssessment },
    permissionStore: { canEditInProgressAssessment },
  } = useStore();

  const { assessment } = useLoadAssessment();

  const [loading, setLoading] = useState(false);

  const { goToNextStep, goToPreviousStep, setActiveStep } = useNavigateAssessmentStepper();

  const {
    getValues,
    control,
    handleSubmit,
    register,
    setValue,
    reset,
    formState: { errors },
    setError,
  } = useForm<JobSearchStatusFormData>({
    defaultValues: {
      jobSearchActivities: retrieveAssessment('jobSearchActivities') ?? assessment?.jobSearchActivities,
      jobSearchCompetency: retrieveAssessment('jobSearchCompetency') ?? assessment?.jobSearchCompetency,
      strengthsAndChallenges: retrieveAssessment('strengthsAndChallenges') ?? assessment?.strengthsAndBarriers,
    },
  });

  const { name: jobSearchActivities } = register('jobSearchActivities', {
    required: { value: true, message: 'This field is required!' },
    maxLength: {
      value: 1500,
      message: 'Must be less than 1500 characters',
    },
  });
  const { name: jobSearchCompetency } = register('jobSearchCompetency', {
    required: { value: true, message: 'This field is required!' },
    maxLength: {
      value: 1500,
      message: 'Must be less than 1500 characters',
    },
  });
  const { name: strengthsAndChallenges } = register('strengthsAndChallenges', {
    required: { value: true, message: 'This field is required!' },
    maxLength: {
      value: 1500,
      message: 'Must be less than 1500 characters',
    },
  });

  const formFields = {
    jobSearchActivities,
    jobSearchCompetency,
    strengthsAndChallenges,
  };

  const hasInvalidFields = useCallback(() => {
    let invalid = false;

    const jobSearch = getValues(jobSearchActivities);
    if (jobSearch?.length) {
      const alphaLen = jobSearch.match(/[a-zA-Z]/g)?.length ?? 0;
      if (alphaLen < 20) {
        setError(jobSearchActivities, { type: 'custom', message: 'Must contain more than 20 alphabetic characters' });
        invalid = true;
      }
    }

    const jobCompetency = getValues(jobSearchCompetency);
    if (jobCompetency?.length) {
      const alphaLen = jobCompetency.match(/[a-zA-Z]/g)?.length ?? 0;
      if (alphaLen < 20) {
        setError(jobSearchCompetency, { type: 'custom', message: 'Must contain more than 20 alphabetic characters' });
        invalid = true;
      }
    }

    const strength = getValues(strengthsAndChallenges);
    if (strength?.length) {
      const alphaLen = strength.match(/[a-zA-Z]/g)?.length ?? 0;
      if (alphaLen < 20) {
        setError(strengthsAndChallenges, {
          type: 'custom',
          message: 'Must contain more than 20 alphabetic characters',
        });
        invalid = true;
      }
    }
    return invalid;
  }, [getValues, jobSearchActivities, setError, jobSearchCompetency, strengthsAndChallenges]);

  const jobSearchActivitiesSubmitHandler = useCallback(async () => {
    const jobSearchActivitiesData: Partial<Assessment> = {
      jobSearchActivities: getValues('jobSearchActivities'),
      jobSearchCompetency: getValues('jobSearchCompetency'),
      strengthsAndBarriers: getValues('strengthsAndChallenges'),
      id: assessment?.id,
    };
    if (hasInvalidFields()) {
      return;
    }

    setLoading(true);
    try {
      await updateAssessment(assessment!.id, jobSearchActivitiesData as Assessment);
      goToNextStep(assessment!.id);
    } finally {
      setLoading(false);
    }
  }, [assessment, getValues, goToNextStep, hasInvalidFields, updateAssessment]);

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value);
      watchAssessment(name, value);
    },
    [setValue, watchAssessment],
  );

  const previousButtonHandler = useCallback(() => {
    goToPreviousStep(assessment!.id);
  }, [assessment, goToPreviousStep]);

  useEffect(() => {
    setActiveStep(AssessmentFormStepperKeys.JOB_SEARCH);
    reset({
      jobSearchActivities: retrieveAssessment(jobSearchActivities) ?? assessment?.jobSearchActivities,
      jobSearchCompetency: retrieveAssessment(jobSearchCompetency) ?? assessment?.jobSearchCompetency,
      strengthsAndChallenges: retrieveAssessment(strengthsAndChallenges) ?? assessment?.strengthsAndBarriers,
    });
  }, [
    assessment,
    jobSearchActivities,
    jobSearchCompetency,
    reset,
    retrieveAssessment,
    setActiveStep,
    strengthsAndChallenges,
  ]);

  return {
    loading,
    formFields,
    getValues,
    control,
    jobSearchActivitiesSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    assessment,
    previousButtonHandler,
    canEditInProgressAssessment,
  };
};

export default useSubmitJobSearch;
