import { GoABlock, GoAButton, GoAPopover } from '@abgov/react-components';
import useTerminateAssessment from './hooks/use-terminate-assessment';
import InlineLoadingIndicator from '../../../inline-loading-indicator';
import { AssessmentStatus } from '../../../../../../types/assessment';

export function TerminateAssessment() {
  const { disabled, loading, terminateAssessment, canEditInProgressAssessment } = useTerminateAssessment();

  if (!canEditInProgressAssessment) {
    return null;
  }
  return (
    <GoAPopover
      target={
        <GoAButton type="secondary" disabled={disabled} size="compact" trailingIcon="chevron-down">
          {loading ? <InlineLoadingIndicator label="Terminating" /> : 'End assessment'}
        </GoAButton>
      }
    >
      <GoABlock direction="column" gap="l">
        <GoAButton
          type="tertiary"
          size="compact"
          onClick={() => terminateAssessment({ status: AssessmentStatus.CLIENT_DECLINED })}
        >
          Client decline
        </GoAButton>
        <GoAButton
          type="tertiary"
          size="compact"
          onClick={() => terminateAssessment({ status: AssessmentStatus.PROVIDER_CANCELLED })}
        >
          Cancel
        </GoAButton>
      </GoABlock>
    </GoAPopover>
  );
}
