import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../../../../../hooks/use-store.hook';
import { AssessmentFormStepperKeys, assessmentFormStepperPaths } from '../../../../../../../types/assessment-forms';

export const useNavigateAssessmentStepper = () => {
  const navigate = useNavigate();
  const { assessmentFormStepperStore } = useStore();

  const setActiveStep = useCallback(
    (stepKey: AssessmentFormStepperKeys) => {
      assessmentFormStepperStore.setActiveStep(stepKey);
    },
    [assessmentFormStepperStore],
  );

  const goToNextStep = useCallback(
    (assessmentId: string) => {
      const nextStepKey = assessmentFormStepperStore.next();
      if (nextStepKey) {
        let nextStepPath = assessmentFormStepperPaths[nextStepKey];
        nextStepPath = nextStepPath.replace(':id', assessmentId);
        navigate(nextStepPath);
      }
    },
    [assessmentFormStepperStore, navigate],
  );

  const goToPreviousStep = useCallback(
    (assessmentId: string) => {
      const previousStepKey = assessmentFormStepperStore.previous();
      if (previousStepKey) {
        let previousStepPath = assessmentFormStepperPaths[previousStepKey];
        previousStepPath = previousStepPath.replace(':id', assessmentId);
        navigate(previousStepPath);
      }
    },
    [assessmentFormStepperStore, navigate],
  );

  const jumpToStep = useCallback(
    (stepKey: AssessmentFormStepperKeys, assessmentId: string) => {
      let stepPath = assessmentFormStepperPaths[stepKey];
      stepPath = stepPath.replace(':id', assessmentId);
      navigate(stepPath);
    },
    [navigate],
  );

  return { goToNextStep, goToPreviousStep, setActiveStep, jumpToStep };
};
