import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from '../../../../../../../hooks/use-store.hook';

const useLoadAssessment = (selectedAssessmentId?: string) => {
  const { id } = useParams<{ id: string }>();
  const {
    assessmentFormStore: { assessment, loadAssessment },
  } = useStore();

  useEffect(() => {
    const activeAssessmentId = id ?? selectedAssessmentId;

    const fetchAssessment = async () => {
      if (activeAssessmentId) {
        await loadAssessment(activeAssessmentId);
      }
    };
    fetchAssessment();
  }, [id, loadAssessment, selectedAssessmentId]);

  return {
    assessment,
    isLoading: !assessment,
  };
};

export default useLoadAssessment;
