import { useCallback, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useStore } from '../../../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';
import { noteService } from '../../../../../../services/note.service';

type NoteFormData = {
  subject: string;
  message: string;
};

type FormFieldKeys = 'subject' | 'message';

const useCreateNoteForm = () => {
  const {
    clientsStore: { selectedClient },
    servicePlanStore: { getServicePlanNotes },
  } = useStore();
  const [loading, setLoading] = useState(false);
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});

  const {
    control,
    handleSubmit,
    register,
    setValue,
    getValues,
    reset,
    watch,
    formState: { errors },
  } = useForm<NoteFormData>();

  const { name: subject } = register('subject', {
    required: {
      value: true,
      message: 'Subject is required',
    },
  });

  const { name: message } = register('message', {
    required: {
      value: true,
      message: 'Note is required',
    },
  });

  const formFields = {
    subject,
    message,
  };

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldKeys, value, { shouldValidate: true });
    },
    [setValue],
  );

  const createNote = useCallback(async () => {
    try {
      setLoading(true);

      if (selectedClient?.id) {
        await noteService.create({
          subject: getValues(subject),
          message: getValues(message),
          recordIds: [selectedClient.id],
        });

        reset();
      }
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      await getServicePlanNotes(selectedClient!.id);
      setLoading(false);
    }
  }, [getServicePlanNotes, getValues, message, requestErrorHandler, reset, selectedClient, subject]);

  return {
    control,
    getValues,
    watch,
    loading,
    errors,
    requestError,
    formFields,
    onChangeHandler,
    createNote,
    handleSubmit,
  };
};

export default useCreateNoteForm;
