import { GoABlock, GoAButton, GoAFormItem, GoAInput } from '@abgov/react-components';
import useCreateNoteForm from './hooks/use-create-note-form.hook';
import RichTextEditor from '../../../rich-text-editor/rich-text-editor';

export function CreateNoteForm() {
  const { formFields, errors, getValues, onChangeHandler, createNote, handleSubmit, control, loading } =
    useCreateNoteForm();
  const { subject, message } = formFields;

  return (
    <form>
      <GoABlock direction="column">
        <GoAFormItem label="Subject" error={errors.subject?.message}>
          <GoAInput
            type="text"
            name={subject}
            id={subject}
            value={getValues(subject)}
            onChange={onChangeHandler}
            width="624px"
          />
        </GoAFormItem>
        <GoAFormItem label="Note" error={errors.message?.message}>
          <RichTextEditor
            name={message}
            control={control}
            placeholder={undefined}
            rules={{ required: 'Message is required' }}
          />
        </GoAFormItem>
        <GoAButton disabled={loading} type="submit" onClick={handleSubmit(createNote)} mb="4">
          <span>Post</span>
        </GoAButton>
      </GoABlock>
    </form>
  );
}
