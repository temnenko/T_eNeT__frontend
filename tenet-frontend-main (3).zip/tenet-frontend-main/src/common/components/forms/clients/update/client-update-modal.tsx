import { GoAModal } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  title: string;
  hideModal: () => void;
}

export const ClientUpdateModal = observer(({ children, title, hideModal }: Props) => {
  return (
    <GoAModal maxWidth="1000px" open width="888px" transition="slow" heading={title} onClose={hideModal}>
      {children}
    </GoAModal>
  );
});
