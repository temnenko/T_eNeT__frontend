import { useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { AddressType, ClientAddressRecord, ContactStatus } from '../../../../../types/client';
import { useStore } from '../../../../../hooks/use-store.hook';
import useFetchSelectedClient from '../../../../../hooks/use-fetch-selected-client.hook';
import useValidateContactForm from '../validations/use-validate-contact-form.hook';
import { CanadaPostAddressFullAddress } from '../../../../../services/canada-post.service';
import { toIsoFormat } from '../../../../../utils/date.util';

type ResidentialFields = {
  residentialStreetAddress: string;
  residentialUnit: string;
  residentialCity: string;
  residentialProvince: string;
  residentialPostalCode: string;
  residentialCountry: string;
  residentialAddressEffectiveBy: string;
};

type FormFieldName =
  | 'mailingStreetAddress'
  | 'mailingUnit'
  | 'mailingCity'
  | 'mailingProvince'
  | 'mailingPostalCode'
  | 'mailingCountry'
  | 'mailingAddressEffectiveBy'
  | 'residentialStreetAddress'
  | 'residentialUnit'
  | 'residentialCity'
  | 'residentialProvince'
  | 'residentialPostalCode'
  | 'residentialCountry'
  | 'residentialAddressEffectiveBy';

type FormFieldsType = {
  mailingStreetAddress: string;
  mailingUnit: string;
  mailingCity: string;
  mailingProvince: string;
  mailingPostalCode: string;
  mailingCountry: string;
  mailingAddressEffectiveBy?: string;
  residentialStreetAddress: string;
  residentialUnit: string;
  residentialCity: string;
  residentialProvince: string;
  residentialPostalCode: string;
  residentialCountry: string;
  residentialAddressEffectiveBy?: string;
};

type EmailPhoneField = {
  id: string;
  value: string;
};

export type PhoneField = {
  id: string;
  phoneNumber: string;
};

export type EmailField = {
  id: string;
  emailAddress: string;
};

export type AllContactFormData = {
  mailingStreetAddress: string;
  mailingUnit: string;
  mailingCity: string;
  mailingProvince: string;
  mailingPostalCode: string;
  mailingCountry: string;
  mailingAddressEffectiveBy?: string;
  residentialStreetAddress: string;
  residentialUnit: string;
  residentialCity: string;
  residentialProvince: string;
  residentialPostalCode: string;
  residentialCountry: string;
  residentialAddressEffectiveBy?: string;
  phones: PhoneField[];
  emails: EmailField[];
};

const useUpdateClientContactDetails = () => {
  const { client } = useFetchSelectedClient();

  const {
    clientsStore: { saveClientContactDetails, saveClientAddresses },
  } = useStore();

  const {
    getValues,
    handleSubmit,
    register,
    unregister,
    reset,
    setValue,
    watch,
    formState: { errors },
    control,
  } = useForm<AllContactFormData>({
    mode: 'onChange',
    defaultValues: {
      mailingStreetAddress: '',
      mailingUnit: '',
      mailingCity: '',
      mailingProvince: '',
      mailingPostalCode: '',
      mailingCountry: '',
      mailingAddressEffectiveBy: undefined,
      residentialStreetAddress: '',
      residentialUnit: '',
      residentialCity: '',
      residentialProvince: '',
      residentialPostalCode: '',
      residentialCountry: '',
      residentialAddressEffectiveBy: undefined,
      phones: [],
      emails: [],
    },
  });

  const { validateStreetAddress, validateCity, validateCountry, validateProvince, validatePostalCode } =
    useValidateContactForm();

  const { name: mailingStreetAddress } = register('mailingStreetAddress', {
    required: { value: true, message: 'Mailing street address required' },
    validate: validateStreetAddress,
  });

  const { name: mailingCity } = register('mailingCity', {
    required: { value: true, message: 'Mailing city/town required' },
    validate: validateCity,
  });

  const { name: mailingUnit } = register('mailingUnit');

  const { name: mailingProvince } = register('mailingProvince', {
    required: { value: true, message: 'Mailing province required' },
    validate: validateProvince,
  });

  const { name: mailingPostalCode } = register('mailingPostalCode', {
    required: { value: true, message: 'Mailing postal code required' },
    validate: (value) => validatePostalCode(value, watch('mailingProvince'), watch('mailingCountry')),
  });

  const { name: mailingCountry } = register('mailingCountry', {
    required: { value: true, message: 'Mailing country required' },
    validate: validateCountry,
  });

  const { name: mailingAddressEffectiveBy } = register('mailingAddressEffectiveBy', {
    required: { value: true, message: 'Mailing address effective date required' },
  });

  const [phoneFields, setPhoneFields] = useState<EmailPhoneField[]>([]);
  const [emailFields, setEmailFields] = useState<EmailPhoneField[]>([]);
  const [isEmailDisabled, setIsEmailDisabled] = useState(false);
  const [isSameAsMailingAddress, setIsSameAsMailingAddress] = useState(true);
  const [isOverride, setIsOverride] = useState(false);
  const [formFields, setFormFields] = useState<FormFieldsType>({
    mailingStreetAddress: '',
    mailingUnit: '',
    mailingCity: '',
    mailingProvince: '',
    mailingPostalCode: '',
    mailingCountry: '',
    mailingAddressEffectiveBy: '',
    residentialStreetAddress: '',
    residentialUnit: '',
    residentialCity: '',
    residentialProvince: '',
    residentialPostalCode: '',
    residentialCountry: '',
    residentialAddressEffectiveBy: '',
  });

  const unregisterResidentialFields = useCallback(() => {
    unregister('residentialStreetAddress');
    unregister('residentialCity');
    unregister('residentialUnit');
    unregister('residentialProvince');
    unregister('residentialPostalCode');
    unregister('residentialCountry');
    unregister('residentialAddressEffectiveBy');
  }, [unregister]);

  const registerResidentialFields = useCallback(() => {
    const residentialFields: ResidentialFields = {
      residentialStreetAddress: register('residentialStreetAddress', {
        required: { value: true, message: 'Residential street address required' },
      }).name,
      residentialCity: register('residentialCity', {
        required: { value: true, message: 'Residential city/town required' },
      }).name,
      residentialUnit: register('residentialUnit').name,
      residentialProvince: register('residentialProvince', {
        required: { value: true, message: 'Residential province required' },
      }).name,
      residentialPostalCode: register('residentialPostalCode', {
        required: { value: true, message: 'Residential postal code required' },
      }).name,
      residentialCountry: register('residentialCountry', {
        required: { value: true, message: 'Residential country required' },
      }).name,
      residentialAddressEffectiveBy: register('residentialAddressEffectiveBy', {
        required: { value: true, message: 'Residential address effective date required' },
      }).name,
    };

    return residentialFields;
  }, [register]);

  const setAddressFormFields = useCallback(
    (
      residentialFields: ResidentialFields = {
        residentialStreetAddress: '',
        residentialUnit: '',
        residentialCity: '',
        residentialProvince: '',
        residentialPostalCode: '',
        residentialCountry: '',
        residentialAddressEffectiveBy: '',
      },
    ) => {
      setFormFields({
        ...formFields,
        ...residentialFields,
      });
    },
    [formFields, setFormFields],
  );

  const handleToggleSameAsMailingAddress = (name: string, value: string) => {
    setIsOverride(true);
    setIsSameAsMailingAddress(value === '1');

    // if Yes: Unregister residential fields
    if (value === '1') {
      unregisterResidentialFields();
      setAddressFormFields();
    } else {
      const residentialFields = registerResidentialFields();
      setAddressFormFields(residentialFields);
    }
  };

  // populate address fields initially
  useEffect(() => {
    if (isOverride) {
      return;
    }
    if (client?.addresses?.length) {
      const mailingAddress = client.addresses.find(
        (address) => address.addressType === AddressType.MAILING || address.addressType === AddressType.BOTH,
      );
      const residentialAddress = client.addresses.find(
        (address) => address.addressType === AddressType.RESIDENTIAL || address.addressType === AddressType.BOTH,
      );

      setIsSameAsMailingAddress(mailingAddress?.addressType === AddressType.BOTH);

      const mailingAddressEffectiveByValue = mailingAddress?.effectiveDate
        ? toIsoFormat(new Date(mailingAddress.effectiveDate))
        : undefined;

      // eslint-disable-next-line no-nested-ternary
      const residentialAddressEffectiveByValue = isSameAsMailingAddress
        ? mailingAddressEffectiveByValue
        : residentialAddress?.effectiveDate
          ? toIsoFormat(new Date(residentialAddress.effectiveDate))
          : undefined;

      const initialValues = {
        mailingStreetAddress: mailingAddress?.street || '',
        mailingUnit: mailingAddress?.unit || '',
        mailingCity: mailingAddress?.city || '',
        mailingProvince: mailingAddress?.province || '',
        mailingPostalCode: mailingAddress?.postalCode || '',
        mailingCountry: mailingAddress?.countryCode || '',
        mailingAddressEffectiveBy: mailingAddressEffectiveByValue,
        residentialStreetAddress: isSameAsMailingAddress
          ? mailingAddress?.street || ''
          : residentialAddress?.street || '',
        residentialUnit: isSameAsMailingAddress ? mailingAddress?.unit : residentialAddress?.unit || '',
        residentialCity: isSameAsMailingAddress ? mailingAddress?.city : residentialAddress?.city || '',
        residentialProvince: isSameAsMailingAddress ? mailingAddress?.province : residentialAddress?.province || '',
        residentialPostalCode: isSameAsMailingAddress
          ? mailingAddress?.postalCode
          : residentialAddress?.postalCode || '',
        residentialCountry: isSameAsMailingAddress
          ? mailingAddress?.countryCode
          : residentialAddress?.countryCode || '',
        residentialAddressEffectiveBy: residentialAddressEffectiveByValue,
      };

      reset(initialValues);
    }

    if (isSameAsMailingAddress) {
      unregisterResidentialFields();
      setFormFields({
        mailingStreetAddress,
        mailingUnit,
        mailingCity,
        mailingProvince,
        mailingPostalCode,
        mailingCountry,
        mailingAddressEffectiveBy,
        residentialStreetAddress: '',
        residentialUnit: '',
        residentialCity: '',
        residentialProvince: '',
        residentialPostalCode: '',
        residentialCountry: '',
        residentialAddressEffectiveBy: '',
      });
    } else {
      const residentialFormFields = registerResidentialFields();

      setAddressFormFields(residentialFormFields);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client?.addresses, isSameAsMailingAddress]);

  // populate phones and emails fields initially
  useEffect(() => {
    if (client && client.phones) {
      const phoneFieldData = client.phones.map((phone, index) => ({
        id: String(index),
        value: phone.phoneNumber,
      }));
      setPhoneFields(phoneFieldData);

      client.phones.forEach((phone, index) => {
        setValue(`phone[${index}]` as keyof AllContactFormData, phone.phoneNumber);
      });
    } else {
      setPhoneFields([]);
    }

    if (client?.emailAddresses && client?.emailAddresses.length > 0) {
      const emailFieldData = client.emailAddresses.map((email, index) => ({
        id: String(index),
        value: email.emailAddress,
      }));

      setEmailFields(emailFieldData);
      client.emailAddresses.forEach((email, index) => {
        setValue(`email[${index}]` as keyof AllContactFormData, email.emailAddress);
      });
    } else {
      setEmailFields([]);
    }
  }, [client, setValue]);

  const onChangeHandler = useCallback(
    (name: string, value: string | undefined) => {
      setValue(name as FormFieldName, value);
    },
    [setValue],
  );

  const onBlurHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value.trim(), { shouldValidate: true });
    },
    [setValue],
  );

  const submit = useCallback(async () => {
    try {
      const mailingAddress = {
        street: getValues('mailingStreetAddress'),
        unit: getValues('mailingUnit') || '',
        city: getValues('mailingCity'),
        province: getValues('mailingProvince'),
        postalCode: getValues('mailingPostalCode'),
        countryCode: getValues('mailingCountry'),
        effectiveDate: getValues('mailingAddressEffectiveBy')
          ? new Date(getValues('mailingAddressEffectiveBy')!).toISOString()
          : undefined,
        addressType: AddressType.MAILING,
      };

      const addressesToSave: ClientAddressRecord[] = [];

      if (isSameAsMailingAddress) {
        mailingAddress.addressType = AddressType.BOTH;
        addressesToSave.push(mailingAddress);
      } else {
        const residentialAddress = {
          street: getValues('residentialStreetAddress'),
          unit: getValues('residentialUnit') || '',
          city: getValues('residentialCity'),
          province: getValues('residentialProvince'),
          postalCode: getValues('residentialPostalCode'),
          countryCode: getValues('residentialCountry'),
          effectiveDate: getValues('residentialAddressEffectiveBy')
            ? new Date(getValues('residentialAddressEffectiveBy')!).toISOString()
            : undefined,
          addressType: AddressType.RESIDENTIAL,
        };
        addressesToSave.push(mailingAddress, residentialAddress);
      }
      const updatedPhoneNumbers = phoneFields.map((field) => {
        return { phoneNumber: field.value, status: ContactStatus.ACTIVE };
      });
      const updatedEmailAddresses = emailFields.map((field) => {
        return { emailAddress: field.value, status: ContactStatus.ACTIVE };
      });

      await Promise.all([
        saveClientAddresses(addressesToSave),
        saveClientContactDetails(updatedEmailAddresses, updatedPhoneNumbers),
      ]);

      reset();
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
    }
  }, [
    getValues,
    isSameAsMailingAddress,
    phoneFields,
    emailFields,
    saveClientContactDetails,
    saveClientAddresses,
    reset,
  ]);

  const isCheckboxDisabled = useMemo(() => {
    return emailFields.some((field) => field.value.trim() !== '');
  }, [emailFields]);

  const handleCheckboxChange = useCallback(() => {
    if (!isCheckboxDisabled) {
      setIsEmailDisabled((prev) => !prev);
      setEmailFields([]);
    }
  }, [isCheckboxDisabled]);

  const handleAddPhoneField = useCallback(() => {
    setPhoneFields((prev) => [...prev, { id: String(prev.length), value: '' }]);
  }, []);

  const handleRemovePhoneField = useCallback((id: string) => {
    setPhoneFields((prev) => prev.filter((field) => field.id !== id));
  }, []);

  const handleRemoveEmailField = useCallback((id: string) => {
    setEmailFields((prev) => prev.filter((field) => field.id !== id));
  }, []);

  const handleAddEmailField = useCallback(() => {
    setEmailFields((prev) => [...prev, { id: String(prev.length), value: '' }]);
  }, []);

  const handlePhoneChange = useCallback((id: string, value: string) => {
    setPhoneFields((prev) => prev.map((field) => (field.id === id ? { ...field, value } : field)));
  }, []);

  const handleEmailChange = useCallback((id: string, value: string) => {
    setEmailFields((prev) => prev.map((field) => (field.id === id ? { ...field, value } : field)));
  }, []);

  const onSelectAddress = useCallback(
    (addressData: CanadaPostAddressFullAddress, addressType: AddressType) => {
      const addressValue =
        !addressData.BuildingNumber || !addressData.Street
          ? addressData.Line1
          : `${addressData.BuildingNumber} ${addressData.Street}`;

      if (addressType === AddressType.MAILING) {
        setValue('mailingStreetAddress', addressValue, {
          shouldValidate: true,
        });
        setValue('mailingUnit', addressData.SubBuilding, { shouldValidate: true });
        setValue('mailingCity', addressData.City, { shouldValidate: true });
        setValue('mailingProvince', addressData.Province, { shouldValidate: true });
        setValue('mailingPostalCode', addressData.PostalCode, { shouldValidate: true });
        setValue('mailingCountry', addressData.CountryName, { shouldValidate: true });
      } else if (addressType === AddressType.RESIDENTIAL) {
        setValue('residentialStreetAddress', addressValue, {
          shouldValidate: true,
        });
        setValue('residentialUnit', addressData.SubBuilding, { shouldValidate: true });
        setValue('residentialCity', addressData.City, { shouldValidate: true });
        setValue('residentialProvince', addressData.Province, { shouldValidate: true });
        setValue('residentialPostalCode', addressData.PostalCode, { shouldValidate: true });
        setValue('residentialCountry', addressData.CountryName, { shouldValidate: true });
      }
    },
    [setValue],
  );

  const setAddressStreetField = useCallback(
    (name: string, value: string) => {
      setValue(name as keyof AllContactFormData, value);
    },
    [setValue],
  );

  return {
    formFields,
    getValues,
    onChangeHandler,
    handleSubmit,
    errors,
    isSameAsMailingAddress,
    register,
    unregister,
    reset,
    handleToggleSameAsMailingAddress,
    setIsSameAsMailingAddress,
    phoneFields,
    emailFields,
    control,
    handlePhoneChange,
    isEmailDisabled,
    isCheckboxDisabled,
    handleAddPhoneField,
    handleAddEmailField,
    handleEmailChange,
    handleCheckboxChange,
    submit,
    handleRemovePhoneField,
    handleRemoveEmailField,
    onBlurHandler,
    onSelectAddress,
    setAddressStreetField,
  };
};

export default useUpdateClientContactDetails;
