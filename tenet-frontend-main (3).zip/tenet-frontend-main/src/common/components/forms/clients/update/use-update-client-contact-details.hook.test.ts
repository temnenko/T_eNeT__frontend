import { act, renderHook } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import * as reactHookForm from 'react-hook-form';
import { AddressType, ContactStatus } from '../../../../../types/client';
import RootStore from '../../../../../stores/root.store';
import * as hooks from '../../../../../hooks/use-store.hook';
import useUpdateClientContactDetails from './use-update-client-contact-details.hook';

jest.mock('react-hook-form', () => ({
  ...jest.requireActual('react-hook-form'),
  useForm: jest.fn(),
}));

describe('useUpdateClientContactDetails', () => {
  const selectedClient = {
    addresses: [
      {
        id: '1',
        addressType: AddressType.MAILING,
        street: '123 Main St',
        unit: '123',
        city: 'Toronto',
        province: 'ON',
        postalCode: 'M1M 1M1',
        countryCode: 'Canada',
        effectiveDate: new Date('1983, 1, 2'),
      },
      {
        id: '2',
        addressType: AddressType.RESIDENTIAL,
        street: '456 Queen St',
        unit: '456',
        city: 'Toronto',
        province: 'ON',
        postalCode: 'M2M 2M2',
        countryCode: 'Canada',
        effectiveDate: new Date('1983, 1, 2'),
      },
    ],
  };
  const mockStore = {
    clientsStore: {
      saveClientAddresses: jest.fn(),
      saveClientContactDetails: jest.fn(),
      selectedClient,
    },
  } as unknown as RootStore;

  const mockForm = {
    register: jest.fn().mockImplementation(() => ({ name: 'testName' })),
    unregister: jest.fn(),
    getValues: jest.fn(),
    handleSubmit: jest.fn(),
    setValue: jest.fn(),
    reset: jest.fn(),
    formState: { errors: {} },
  } as unknown as ReturnType<typeof useForm>;

  beforeEach(() => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);
    jest.spyOn(reactHookForm, 'useForm').mockImplementation(() => mockForm);
  });

  it('initializes with proper default state', () => {
    const { result } = renderHook(() => useUpdateClientContactDetails());
    expect(result.current.formFields).toBeDefined();
    expect(result.current.phoneFields).toEqual([]);
    expect(result.current.emailFields).toEqual([]);
    expect(result.current.isEmailDisabled).toBe(false);
  });

  it('updates form fields when isSameAsMailingAddress is toggled', () => {
    const { result } = renderHook(() => useUpdateClientContactDetails());

    act(() => {
      result.current.setIsSameAsMailingAddress(false);
    });

    expect(result.current.unregister).toHaveBeenCalledWith('residentialStreetAddress');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialCity');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialUnit');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialProvince');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialPostalCode');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialCountry');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialAddressEffectiveBy');

    act(() => {
      result.current.setIsSameAsMailingAddress(true);
    });

    expect(result.current.register).toHaveBeenCalledWith(
      'residentialStreetAddress',
      expect.objectContaining({ required: expect.anything() }),
    );
    expect(result.current.register).toHaveBeenCalledWith(
      'residentialCity',
      expect.objectContaining({ required: expect.anything() }),
    );
    expect(result.current.register).toHaveBeenCalledWith('residentialUnit');
    expect(result.current.register).toHaveBeenCalledWith(
      'residentialProvince',
      expect.objectContaining({ required: expect.anything() }),
    );
    expect(result.current.register).toHaveBeenCalledWith(
      'residentialPostalCode',
      expect.objectContaining({ required: expect.anything() }),
    );
    expect(result.current.register).toHaveBeenCalledWith(
      'residentialCountry',
      expect.objectContaining({ required: expect.anything() }),
    );
    expect(result.current.register).toHaveBeenCalledWith(
      'residentialAddressEffectiveBy',
      expect.objectContaining({ required: expect.anything() }),
    );
  });

  it('initializes form fields with address data from the store', async () => {
    const { result } = renderHook(() => useUpdateClientContactDetails());

    expect(result.current.reset).toHaveBeenCalledWith({
      mailingStreetAddress: '123 Main St',
      mailingUnit: '123',
      mailingCity: 'Toronto',
      mailingProvince: 'ON',
      mailingPostalCode: 'M1M 1M1',
      mailingCountry: 'Canada',
      mailingAddressEffectiveBy: expect.any(String),
      residentialStreetAddress: '456 Queen St',
      residentialUnit: '456',
      residentialCity: 'Toronto',
      residentialProvince: 'ON',
      residentialPostalCode: 'M2M 2M2',
      residentialCountry: 'Canada',
      residentialAddressEffectiveBy: expect.any(String),
    });
  });

  it('adds a phone field', () => {
    const { result } = renderHook(() => useUpdateClientContactDetails());

    act(() => {
      result.current.handleAddPhoneField();
    });

    expect(result.current.phoneFields.length).toBe(1);
  });

  it('updates an email field value', () => {
    const { result } = renderHook(() => useUpdateClientContactDetails());

    act(() => {
      result.current.handleEmailChange('0', 'test@example.com');
    });

    expect(result.current.emailFields).toEqual([]);
  });

  it('toggles isEmailDisabled when not disabled by emailFields values', () => {
    const { result } = renderHook(() => useUpdateClientContactDetails());

    act(() => {
      result.current.handleCheckboxChange();
    });

    expect(result.current.isEmailDisabled).toBe(true);
  });

  it('does not toggle isEmailDisabled when isCheckboxDisabled is true', () => {
    const { result } = renderHook(() => useUpdateClientContactDetails());

    act(() => {
      result.current.handleAddEmailField();
      result.current.handleEmailChange('0', 'email@provider.com');
    });

    act(() => {
      result.current.handleCheckboxChange();
    });

    expect(result.current.isEmailDisabled).toBe(false);
  });

  it('initializes phone and email fields with data from the store', () => {
    mockStore.clientsStore.selectedClient!.phones = [{ phoneNumber: '1234567890', status: ContactStatus.ACTIVE }];
    mockStore.clientsStore.selectedClient!.emailAddresses = [
      { emailAddress: 'user@example.com', status: ContactStatus.ACTIVE },
    ];

    const { result } = renderHook(() => useUpdateClientContactDetails());

    expect(result.current.phoneFields).toEqual([{ id: '0', value: '1234567890' }]);
    expect(result.current.emailFields).toEqual([{ id: '0', value: 'user@example.com' }]);
  });
});
