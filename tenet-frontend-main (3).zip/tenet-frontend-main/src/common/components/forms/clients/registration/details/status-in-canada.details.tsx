import { GoADetails } from '@abgov/react-components';

export function StatusInCanadaDetails() {
  return (
    <GoADetails heading="How each status in Canada is defined?" mt="0">
      <p>
        Canadian Citizen: a person who is Canadian by birth either born in Canada or born outside of Canada to a
        Canadian citizen who was themselves either born in Canada or granted citizenship; or has applied for a grant of
        citizenship and has received Canadian citizenship (naturalization). If the applicant was born in Canada, the
        effective date of their status is their Date of Birth.
      </p>
      <p>
        Permanent resident: a person who has been given permanent resident status by immigrating to Canada but is not a
        Canadian citizen.
      </p>
      <p>
        Protected person: a person whom the immigration and Refugee Board of Canada has determined to be a convention
        refugee or in need of protection in Canada, or a person who has had a positive pre-removal risk assessment in
        most cases.
      </p>
      <p>
        Refugee claimant: a person who has applied for refugee protection status in Canada and is awaiting a decision
        from the immigration and Refugee Board of Canada.
      </p>
      <p>
        Temporary resident: a foreign national who is lawfully authorized to remain in Canada for a short period,
        including students, foreign workers and visitors, such as tourists.
      </p>
    </GoADetails>
  );
}
