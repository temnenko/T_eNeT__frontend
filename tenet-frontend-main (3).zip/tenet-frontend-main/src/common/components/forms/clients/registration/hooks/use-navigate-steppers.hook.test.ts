import * as reactRouterDom from 'react-router-dom';
import { act, renderHook } from '@testing-library/react';
import { reveal } from 'jest-auto-stub';
import * as hooks from '../../../../../../hooks/use-store.hook';
import { useNavigateStepper } from './use-navigate-steppers.hook';
import { ClientFormStepperKeys, clientFormStepperPaths } from '../../../../../../types/client-forms';
import RootStore from '../../../../../../stores/root.store';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}));

describe('useNavigateStepper', () => {
  const mockNavigate = jest.fn();
  const mockStore = {
    clientFormStepperStore: {
      setActiveStep: jest.fn(),
      next: jest.fn(),
      previous: jest.fn(),
    },
  } as unknown as RootStore;

  beforeEach(() => {
    jest.spyOn(reactRouterDom, 'useNavigate').mockImplementation(() => mockNavigate);
    jest.spyOn(hooks, 'useStore').mockReturnValue(mockStore);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should navigate to the next step and update store correctly', () => {
    const clientId = '123';
    const nextStepKey = ClientFormStepperKeys.CONSENT;
    const nextStepPath = clientFormStepperPaths[nextStepKey].replace(':clientId', clientId);

    reveal(mockStore.clientFormStepperStore).next.mockImplementation(() => nextStepKey);

    const { result } = renderHook(() => useNavigateStepper());

    act(() => {
      result.current.goToNextStep(clientId);
    });

    expect(mockStore.clientFormStepperStore.next).toHaveBeenCalled();
    expect(mockNavigate).toHaveBeenCalledWith(nextStepPath);
  });

  it('should navigate to the previous step and update store correctly', () => {
    const clientId = '123';
    const previousStepKey = ClientFormStepperKeys.FACTORS;
    const previousStepPath = clientFormStepperPaths[previousStepKey].replace(':clientId', clientId);

    reveal(mockStore.clientFormStepperStore).previous.mockImplementation(() => previousStepKey);

    const { result } = renderHook(() => useNavigateStepper());

    act(() => {
      result.current.goToPreviousStep(clientId);
    });

    expect(mockStore.clientFormStepperStore.previous).toHaveBeenCalled();
    expect(mockNavigate).toHaveBeenCalledWith(previousStepPath);
  });

  it('should set the active step in the store', () => {
    const stepKey = ClientFormStepperKeys.FACTORS;

    const { result } = renderHook(() => useNavigateStepper());

    act(() => {
      result.current.setActiveStep(stepKey);
    });

    expect(mockStore.clientFormStepperStore.setActiveStep).toHaveBeenCalledWith(stepKey);
  });

  it('should not navigate if there is no next or previous step', () => {
    reveal(mockStore.clientFormStepperStore).next.mockImplementation(() => undefined);
    reveal(mockStore.clientFormStepperStore).previous.mockImplementation(() => undefined);

    const { result } = renderHook(() => useNavigateStepper());

    act(() => {
      result.current.goToNextStep('123');
    });

    expect(mockStore.clientFormStepperStore.next).toHaveBeenCalled();
    expect(mockNavigate).not.toHaveBeenCalled();

    act(() => {
      result.current.goToPreviousStep('123');
    });

    expect(mockStore.clientFormStepperStore.previous).toHaveBeenCalled();
    expect(mockNavigate).not.toHaveBeenCalled();
  });
});
