/* eslint-disable no-nested-ternary */
import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { AddressType, ClientAddressRecord } from '../../../../../../types/client';
import { useNavigateStepper } from './use-navigate-steppers.hook';
import useLoadClient from './use-load-client';
import { ClientFormStepperKeys } from '../../../../../../types/client-forms';
import useValidateContactForm from '../../validations/use-validate-contact-form.hook';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { CanadaPostAddressFullAddress } from '../../../../../../services/canada-post.service';
import useSaveContactInfo from './use-save-contact-info.hook';
import { RequestError } from '../../../../../../types/errors/errors';

export type ResidentialFields = {
  residentialStreetAddress: string;
  residentialUnit: string;
  residentialCity: string;
  residentialProvince: string;
  residentialPostalCode: string;
  residentialCountry: string;
};

export type AddressesFormData = {
  mailingStreetAddress: string;
  mailingUnit?: string;
  mailingCity: string;
  mailingProvince: string;
  mailingPostalCode: string;
  mailingCountry: string;

  residentialStreetAddress: string;
  residentialUnit?: string;
  residentialCity: string;
  residentialProvince: string;
  residentialPostalCode: string;
  residentialCountry: string;

  // for dynamic phone and email fields
  [key: string]: string | undefined;
};

export type FormFieldName =
  | 'mailingStreetAddress'
  | 'mailingUnit'
  | 'mailingCity'
  | 'mailingProvince'
  | 'mailingPostalCode'
  | 'mailingCountry'
  | 'residentialStreetAddress'
  | 'residentialUnit'
  | 'residentialCity'
  | 'residentialProvince'
  | 'residentialPostalCode'
  | 'residentialCountry';

export type FormFieldsType = {
  mailingStreetAddress: string;
  mailingUnit: string;
  mailingCity: string;
  mailingProvince: string;
  mailingPostalCode: string;
  mailingCountry: string;
  residentialStreetAddress: string;
  residentialUnit: string;
  residentialCity: string;
  residentialProvince: string;
  residentialPostalCode: string;
  residentialCountry: string;
};

const useSaveAddresses = () => {
  const {
    clientFormStore: { clientWatch, retrieveClient, watchClient, saveClientAddresses, saveClientContactDetails },
    permissionStore: { canEditClientInProgress },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();

  const { client } = useLoadClient();

  const { goToPreviousStep, setActiveStep, goToNextStep } = useNavigateStepper();

  const {
    getValues,
    handleSubmit,
    register,
    unregister,
    reset,
    setValue,
    watch,
    control,
    formState: { errors },
  } = useForm<AddressesFormData>({
    mode: 'all',
  });

  const {
    phoneFields,
    emailFields,
    isEmailDisabled,
    isPhoneDisabled,
    isValidEmail,
    setPhoneFields,
    setEmailFields,
    handleAddPhoneField,
    handleAddEmailField,
    handlePhoneChange,
    handleEmailChange,
    handleCheckboxChange,
    handleNoPhonesCheckboxChange,
    getPhonesAndEmails,
    handleRemovePhoneField,
    handleRemoveEmailField,
  } = useSaveContactInfo(unregister, watchClient);

  const { validateStreetAddress, validateCity, validateCountry, validateProvince, validatePostalCode } =
    useValidateContactForm();

  const { name: mailingStreetAddress } = register('mailingStreetAddress', {
    required: { value: true, message: 'Mailing street address required' },
    validate: {
      value: (value) => {
        return validateStreetAddress(value);
      },
    },
  });

  const { name: mailingCity } = register('mailingCity', {
    required: { value: true, message: 'Mailing city/town required' },
    validate: (value) => {
      return validateCity(value);
    },
  });

  const { name: mailingUnit } = register('mailingUnit');

  const { name: mailingProvince } = register('mailingProvince', {
    required: { value: true, message: 'Mailing province required' },
    validate: (value) => {
      return validateProvince(value);
    },
  });

  const { name: mailingCountry } = register('mailingCountry', {
    required: { value: true, message: 'Mailing country required' },
    validate: (value) => {
      return validateCountry(value);
    },
  });

  const { name: mailingPostalCode } = register('mailingPostalCode', {
    required: { value: true, message: 'Mailing postal code required' },
    validate: (value) => {
      return validatePostalCode(value, watch(mailingProvince), watch(mailingCountry));
    },
  });

  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [isSameAsMailingAddress, setIsSameAsMailingAddress] = useState(true);
  const [isOverride, setIsOverride] = useState(false);
  const [formFields, setFormFields] = useState<FormFieldsType>({
    mailingStreetAddress: '',
    mailingUnit: '',
    mailingCity: '',
    mailingProvince: '',
    mailingPostalCode: '',
    mailingCountry: '',
    residentialStreetAddress: '',
    residentialUnit: '',
    residentialCity: '',
    residentialProvince: '',
    residentialPostalCode: '',
    residentialCountry: '',
  });

  const unregisterResidentialFields = useCallback(() => {
    unregister('residentialStreetAddress');
    unregister('residentialCity');
    unregister('residentialUnit');
    unregister('residentialProvince');
    unregister('residentialPostalCode');
    unregister('residentialCountry');
  }, [unregister]);

  const registerResidentialFields = useCallback(() => {
    const residentialFields: ResidentialFields = {
      residentialStreetAddress: register('residentialStreetAddress', {
        required: { value: true, message: 'Residential street address required' },
        validate: (value) => {
          return validateStreetAddress(value);
        },
      }).name,
      residentialCity: register('residentialCity', {
        required: { value: true, message: 'Residential city/town required' },
        validate: (value) => {
          return validateCity(value);
        },
      }).name,
      residentialUnit: register('residentialUnit').name,
      residentialProvince: register('residentialProvince', {
        required: { value: true, message: 'Residential province required' },
        validate: (value) => {
          return validateProvince(value);
        },
      }).name,
      residentialPostalCode: register('residentialPostalCode', {
        required: { value: true, message: 'Residential postal code required' },
        validate: (value) => {
          return validatePostalCode(value, watch('residentialProvince'), watch('residentialCountry'));
        },
      }).name,
      residentialCountry: register('residentialCountry', {
        required: { value: true, message: 'Residential country required' },
        validate: (value) => {
          return validateCountry(value);
        },
      }).name,
    };

    return residentialFields;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [register]);

  const setAddressFormFields = useCallback(
    (
      residentialFields: ResidentialFields = {
        residentialStreetAddress: '',
        residentialUnit: '',
        residentialCity: '',
        residentialProvince: '',
        residentialPostalCode: '',
        residentialCountry: '',
      },
    ) => {
      setFormFields({
        ...formFields,
        ...residentialFields,
      });
    },
    [formFields, setFormFields],
  );

  const handleToggleSameAsMailingAddress = (name: string, value: string) => {
    setIsOverride(true);
    setIsSameAsMailingAddress(value === '1');
    watchClient('isSameAsMailingAddress', value === '1');

    // if Yes: Unregister residential fields
    if (value === '1') {
      unregisterResidentialFields();
      setAddressFormFields();
    } else {
      const residentialFields = registerResidentialFields();
      setAddressFormFields(residentialFields);
    }
  };

  useEffect(() => {
    setActiveStep(ClientFormStepperKeys.CONTACT);
    if (retrieveClient('phoneFields')) {
      setPhoneFields(retrieveClient('phoneFields'));
    } else if (client?.phones && client?.phones.length > 0) {
      client.phones.forEach((phone, index) => {
        setValue(`phone-${index}`, phone.phoneNumber);
      });

      const phoneFieldData = client.phones.map((phone, index) => ({
        id: String(index),
        value: phone.phoneNumber,
      }));
      setPhoneFields(phoneFieldData);
    } else {
      setPhoneFields([{ id: '0', value: '' }]);
    }
    if (retrieveClient('emailFields')) {
      setEmailFields(retrieveClient('emailFields'));
    } else if (client?.emailAddresses && client?.emailAddresses.length > 0) {
      client.emailAddresses.forEach((email, index) => {
        setValue(`email-${index}`, email.emailAddress);
      });

      const emailFieldData = client.emailAddresses.map((email, index) => ({
        id: String(index),
        value: email.emailAddress,
      }));
      setEmailFields(emailFieldData);
    } else {
      setEmailFields([{ id: '0', value: '' }]);
    }

    if (isOverride) {
      return;
    }
    if (clientWatch || client?.addresses?.length) {
      const mailingAddress = client?.addresses.find(
        (address) => address.addressType === AddressType.MAILING || address.addressType === AddressType.BOTH,
      );
      const residentialAddress = client?.addresses.find(
        (address) => address.addressType === AddressType.RESIDENTIAL || address.addressType === AddressType.BOTH,
      );
      const noAddresses = !mailingAddress && !residentialAddress;

      setIsSameAsMailingAddress(
        retrieveClient('isSameAsMailingAddress') ?? (mailingAddress?.addressType === AddressType.BOTH || noAddresses),
      );

      reset({
        mailingStreetAddress: retrieveClient(mailingStreetAddress) ?? (mailingAddress?.street || ''),
        mailingUnit: retrieveClient(mailingUnit) ?? (mailingAddress?.unit || ''),
        mailingCity: retrieveClient(mailingCity) ?? (mailingAddress?.city || ''),
        mailingProvince: retrieveClient(mailingProvince) ?? (mailingAddress?.province || ''),
        mailingPostalCode: retrieveClient(mailingPostalCode) ?? (mailingAddress?.postalCode || ''),
        mailingCountry: retrieveClient(mailingCountry) ?? (mailingAddress?.countryCode || ''),
        residentialStreetAddress: isSameAsMailingAddress
          ? (retrieveClient(mailingStreetAddress) ?? (mailingAddress?.street || ''))
          : (retrieveClient('residentialStreetAddress') ?? (residentialAddress?.street || '')),
        residentialUnit: isSameAsMailingAddress
          ? (retrieveClient(mailingUnit) ?? mailingAddress?.unit)
          : (retrieveClient('residentialUnit') ?? (residentialAddress?.unit || '')),
        residentialCity: isSameAsMailingAddress
          ? (retrieveClient(mailingCity) ?? mailingAddress?.city)
          : (retrieveClient('residentialCity') ?? (residentialAddress?.city || '')),
        residentialProvince: isSameAsMailingAddress
          ? (retrieveClient(mailingProvince) ?? mailingAddress?.province)
          : (retrieveClient('residentialProvince') ?? (residentialAddress?.province || '')),
        residentialPostalCode: isSameAsMailingAddress
          ? (retrieveClient(mailingPostalCode) ?? mailingAddress?.postalCode)
          : (retrieveClient('residentialPostalCode') ?? (residentialAddress?.postalCode || '')),
        residentialCountry: isSameAsMailingAddress
          ? (retrieveClient(mailingCountry) ?? mailingAddress?.countryCode)
          : (retrieveClient('residentialCountry') ?? (residentialAddress?.countryCode || '')),
      });
    }

    if (isSameAsMailingAddress) {
      unregisterResidentialFields();
      setFormFields({
        mailingStreetAddress,
        mailingUnit,
        mailingCity,
        mailingProvince,
        mailingPostalCode,
        mailingCountry,
        residentialStreetAddress: '',
        residentialUnit: '',
        residentialCity: '',
        residentialProvince: '',
        residentialPostalCode: '',
        residentialCountry: '',
      });
    } else {
      const residentialFormFields = registerResidentialFields();

      setAddressFormFields(residentialFormFields);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client?.addresses, client?.phones, client?.emailAddresses, isSameAsMailingAddress]);

  const clientAddressesSaveHandler = useCallback(async () => {
    try {
      setRequestError({});
      setLoading(true);
      const mailingAddress = {
        street: getValues('mailingStreetAddress'),
        unit: getValues('mailingUnit') || '',
        city: getValues('mailingCity'),
        province: getValues('mailingProvince'),
        postalCode: getValues('mailingPostalCode'),
        countryCode: getValues('mailingCountry'),
        addressType: AddressType.MAILING,
      };

      const addressesToSave: ClientAddressRecord[] = [];

      if (isSameAsMailingAddress) {
        mailingAddress.addressType = AddressType.BOTH;
        addressesToSave.push(mailingAddress);
      } else {
        const residentialAddress = {
          street: getValues('residentialStreetAddress'),
          unit: getValues('residentialUnit') || '',
          city: getValues('residentialCity'),
          province: getValues('residentialProvince'),
          postalCode: getValues('residentialPostalCode'),
          countryCode: getValues('residentialCountry'),
          addressType: AddressType.RESIDENTIAL,
        };
        addressesToSave.push(mailingAddress, residentialAddress);
      }
      const { emails, phones } = getPhonesAndEmails();

      await Promise.all([saveClientAddresses(addressesToSave), saveClientContactDetails(emails, phones)]);
      reset();
      goToNextStep(client!.id);
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [
    getValues,
    isSameAsMailingAddress,
    getPhonesAndEmails,
    saveClientAddresses,
    saveClientContactDetails,
    reset,
    goToNextStep,
    client,
    requestErrorHandler,
  ]);

  const previousButtonClickHandler = useCallback(() => {
    goToPreviousStep(client!.id);
  }, [client, goToPreviousStep]);

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      const processedValue = typeof value === 'string' ? value.trim() : value;
      setValue(name as FormFieldName, processedValue);
      watchClient(name, processedValue);
    },
    [setValue, watchClient],
  );

  const onBlurHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value.trim(), { shouldValidate: true });
      watchClient(name, value);
    },
    [setValue, watchClient],
  );

  const setAddressStreetField = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value);
      watchClient(name, value);
    },
    [setValue, watchClient],
  );

  const onSelectAddress = useCallback(
    (addressData: CanadaPostAddressFullAddress, addressType: AddressType) => {
      const addressValue =
        !addressData.BuildingNumber || !addressData.Street
          ? addressData.Line1
          : `${addressData.BuildingNumber} ${addressData.Street}`;

      if (addressType === AddressType.MAILING) {
        setValue('mailingStreetAddress', addressValue, {
          shouldValidate: true,
        });
        setValue('mailingUnit', addressData.SubBuilding, { shouldValidate: true });
        setValue('mailingCity', addressData.City, { shouldValidate: true });
        setValue('mailingProvince', addressData.Province, { shouldValidate: true });
        setValue('mailingPostalCode', addressData.PostalCode, { shouldValidate: true });
        setValue('mailingCountry', addressData.CountryName, { shouldValidate: true });
        watchClient('mailingStreetAddress', `${addressData.BuildingNumber} ${addressData.Street}`);
        watchClient('mailingUnit', addressData.SubBuilding);
        watchClient('mailingCity', addressData.City);
        watchClient('mailingProvince', addressData.Province);
        watchClient('mailingPostalCode', addressData.PostalCode);
        watchClient('mailingCountry', addressData.CountryName);
      } else if (addressType === AddressType.RESIDENTIAL) {
        setValue('residentialStreetAddress', addressValue, {
          shouldValidate: true,
        });
        setValue('residentialUnit', addressData.SubBuilding, { shouldValidate: true });
        setValue('residentialCity', addressData.City, { shouldValidate: true });
        setValue('residentialProvince', addressData.Province, { shouldValidate: true });
        setValue('residentialPostalCode', addressData.PostalCode, { shouldValidate: true });
        setValue('residentialCountry', addressData.CountryName, { shouldValidate: true });
        watchClient('residentialStreetAddress', `${addressData.BuildingNumber} ${addressData.Street}`);
        watchClient('residentialUnit', addressData.SubBuilding);
        watchClient('residentialCity', addressData.City);
        watchClient('residentialProvince', addressData.Province);
        watchClient('residentialPostalCode', addressData.PostalCode);
        watchClient('residentialCountry', addressData.CountryName);
      }
    },
    [setValue, watchClient],
  );

  return {
    loading,
    requestError,
    formFields,
    control,
    getValues,
    watch,
    clientAddressesSaveHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    isSameAsMailingAddress,
    register,
    unregister,
    reset,
    previousButtonClickHandler,
    handleToggleSameAsMailingAddress,
    setIsSameAsMailingAddress,
    onBlurHandler,
    onSelectAddress,
    setAddressStreetField,
    phoneFields,
    emailFields,
    isEmailDisabled,
    isPhoneDisabled,
    isValidEmail,
    handleAddPhoneField,
    handleAddEmailField,
    handlePhoneChange,
    handleEmailChange,
    handleCheckboxChange,
    handleNoPhonesCheckboxChange,
    handleRemovePhoneField,
    handleRemoveEmailField,
    canEditClientInProgress,
    client,
  };
};

export default useSaveAddresses;
