import { observer } from 'mobx-react-lite';

import { GoAButton, GoANotification, GoASpacer } from '@abgov/react-components';
import { ClientFilesUploadForm as ClientFilesUploadFormContainer } from '../../client-files-upload-form';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import useSubmitClientRegistrationDocuments from '../../../clients/hooks/use-submit-client-registration-documents';

export const ClientFilesUploadForm = observer(() => {
  const {
    submitHandler,
    loading,
    requestError,
    invalidUploadError,
    previousButtonClickHandler,
    client,
    downloadFile,
    canEditClientInProgress,
    canUploadClientFiles,
  } = useSubmitClientRegistrationDocuments();
  return (
    <div className="create-client-form">
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {client && canEditClientInProgress(client) && (
        <ClientFilesUploadFormContainer
          formItemLabel="Client documents"
          downloadFile={downloadFile}
          canUploadClientFiles={canUploadClientFiles(client)}
          invalidUploadError={invalidUploadError}
        />
      )}
      <GoASpacer vSpacing="m" />
      {client && canEditClientInProgress(client) && (
        <div className="row-space-between client-demographic-prev-next">
          <GoAButton type="secondary" onClick={() => previousButtonClickHandler()} leadingIcon="arrow-back">
            <span className="client-bold-600">Previous:</span> Client consent
          </GoAButton>
          <GoAButton onClick={submitHandler} trailingIcon={loading ? undefined : 'arrow-forward'} disabled={loading}>
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span className="client-bold-600">Next:</span> Review
              </>
            )}
          </GoAButton>
        </div>
      )}

      <GoASpacer vSpacing="xl" />
    </div>
  );
});
