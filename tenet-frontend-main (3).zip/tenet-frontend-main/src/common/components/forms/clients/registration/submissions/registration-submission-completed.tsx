import { GoABlock, GoAButton, GoAIcon, GoASpacer } from '@abgov/react-components';
import { useNavigate, useParams } from 'react-router-dom';

export default function RegistrationSubmissionCompleted() {
  const { clientId } = useParams();
  const navigate = useNavigate();

  return (
    <GoABlock direction="column" gap="2xs" alignment="center">
      <GoASpacer vSpacing="2xl" />
      <span className="circle-175">
        <GoAIcon type="checkmark" size="xlarge" />
      </span>
      <GoASpacer vSpacing="xl" />
      <center>
        {`The registration is complete and a request for LMDA Verification has been submitted. You can check and manage
        verification results on the client's "LMDA" page.`}
      </center>
      <GoASpacer vSpacing="2xl" />
      <GoAButton
        size="compact"
        onClick={() => navigate(`/clients/${clientId}/overview`)}
      >{`Go to client's profile`}</GoAButton>
      <GoASpacer vSpacing="2xl" />
    </GoABlock>
  );
}
