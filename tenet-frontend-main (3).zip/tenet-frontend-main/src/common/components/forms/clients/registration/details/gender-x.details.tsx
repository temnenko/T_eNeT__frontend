import { GoADetails } from '@abgov/react-components';

export function GenderXDetails() {
  return (
    <GoADetails heading="What is Gender X?" mt="0">
      <p>
        {`Gender X is used when an individual who does not identify as male or female, or identifies as non-binary in
        terms of their gender identity and who has chosen to self-identify as "X".`}
      </p>
    </GoADetails>
  );
}
