import { useMemo } from 'react';

import useSubmitFileUploads from '../../../hooks/use-submit-file-uploads.hook';

export const useClientRegistrationFiles = () => {
  const { uploads } = useSubmitFileUploads();

  return useMemo(() => {
    const fileobjects = {
      title: 'Files',
      data: uploads.map((fileUpload) => {
        return {
          filename: fileUpload.file.name,
          filetype: fileUpload.file.type,
          dateAdded: fileUpload.file.lastModified,
        };
      }),
    };
    return fileobjects;
  }, [uploads]);
};
