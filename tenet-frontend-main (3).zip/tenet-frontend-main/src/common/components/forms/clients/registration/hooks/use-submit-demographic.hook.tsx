/* eslint-disable no-nested-ternary */
import { ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';
import { differenceInDays, subDays, subYears, differenceInHours } from 'date-fns';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { useNavigateStepper } from './use-navigate-steppers.hook';
import useLoadClient from './use-load-client';
import { ClientFormStepperKeys } from '../../../../../../types/client-forms';
import { Demographic, ImmigrationStatus } from '../../../../../../types/client';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';
import { toIsoFormat } from '../../../../../../utils/date.util';

type DemographicFormData = {
  statusInCanada: ImmigrationStatus;
  statusEffectiveDate: string | undefined;
  gender: string;
  maritalStatus: string;
  numberOfDependents: number;
};

type FormFieldName = 'statusInCanada' | 'statusEffectiveDate' | 'gender' | 'maritalStatus' | 'numberOfDependents';

const useSubmitDemographic = (
  isUpdate: boolean,
  hideModal?: () => void,
  clientId?: string,
  setClientUpdated?: (value: string) => void,
) => {
  const [dependents, setDependents] = useState<number | undefined>();
  const { goToNextStep, goToPreviousStep, setActiveStep } = useNavigateStepper();
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const {
    clientFormStore: { clientWatch, watchClient, retrieveClient, saveClientDemographics },
    clientsStore: { getClientById },
    permissionStore: { canEditClientInProgress },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();

  const { client } = useLoadClient(clientId);

  const {
    getValues,
    handleSubmit,
    register,
    reset,
    setValue,
    formState: { errors },
    watch,
  } = useForm<DemographicFormData>({
    defaultValues: {
      statusInCanada: retrieveClient('statusInCanada') ?? client?.demographic?.statusInCanada,
      statusEffectiveDate: retrieveClient('statusEffectiveDate')
        ? retrieveClient('statusEffectiveDate')
        : client?.demographic?.statusEffectiveDate
          ? toIsoFormat(new Date(client?.demographic?.statusEffectiveDate))
          : undefined,
      gender: retrieveClient('gender') ?? client?.demographic?.gender,
      maritalStatus: retrieveClient('maritalStatus') ?? client?.demographic?.maritalStatus,
      numberOfDependents: retrieveClient('numberOfDependents') ?? client?.demographic?.numberOfDependents,
    },
  });

  const { name: statusInCanada } = register('statusInCanada', {
    required: { value: true, message: 'Immigration status in Canada is required!' },
    min: 3,
  });
  const watchStatusInCanada = watch(statusInCanada);

  const minimumStatusEffectiveDate = useMemo(() => {
    if (client?.dateOfBirth) {
      return new Date(client.dateOfBirth);
    }
    return subDays(subYears(new Date(), 50), 1);
  }, [client?.dateOfBirth]);

  const { name: statusEffectiveDate } = register('statusEffectiveDate', {
    required: { value: true, message: 'Immigration status effective date is required!' },
    validate: (value) => {
      if (value && client?.dateOfBirth) {
        if (differenceInDays(client?.dateOfBirth, value) > 0) {
          return `The date must not be earlier than the applicant's DOB.`;
        }
      }
      if (value && differenceInHours(value, new Date()) > 0) {
        return 'The date must not be in the future';
      }
      return true;
    },
  });
  const { name: gender } = register('gender', {
    required: { value: true, message: 'Gender identity required!' },
  });
  const { name: maritalStatus } = register('maritalStatus', {
    required: { value: true, message: 'Marital status required' },
    min: 3,
  });
  const { name: numberOfDependents } = register('numberOfDependents', {
    required: { value: true, message: 'Number of dependents required!' },
    validate: (value) => {
      return value < 0 ? 'number of dependants must not be less than 0' : true;
    },
  });

  const formFields = {
    statusInCanada,
    statusEffectiveDate,
    gender,
    maritalStatus,
    numberOfDependents,
  };

  useEffect(() => {
    setActiveStep(ClientFormStepperKeys.DEMOGRAPHICS);
    if (clientWatch || client?.demographic) {
      setValue(numberOfDependents, client?.demographic?.numberOfDependents ?? retrieveClient(numberOfDependents));
      setDependents(client?.demographic?.numberOfDependents ?? retrieveClient(numberOfDependents));

      setValue(statusInCanada, client?.demographic?.statusInCanada ?? retrieveClient(statusInCanada));
      const minStatusDate = client?.demographic?.statusEffectiveDate
        ? toIsoFormat(new Date(client?.demographic?.statusEffectiveDate))
        : client?.demographic?.statusInCanada === ImmigrationStatus.CANADIAN_CITIZEN && client?.dateOfBirth
          ? toIsoFormat(new Date(client?.dateOfBirth))
          : undefined;
      setValue(statusEffectiveDate, minStatusDate ?? retrieveClient(statusEffectiveDate) ?? undefined);
      setValue(gender, client?.demographic?.gender ?? retrieveClient(gender));
      setValue(maritalStatus, client?.demographic?.maritalStatus ?? retrieveClient(maritalStatus));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client?.demographic]);

  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  const clientSubmitHandler = useCallback(async () => {
    const continueSave = async () => {
      try {
        setRequestError({});
        setLoading(true);

        const clientDemographicData: Demographic = {
          statusInCanada: getValues('statusInCanada'),
          statusEffectiveDate: getValues('statusEffectiveDate')
            ? new Date(getValues('statusEffectiveDate')!).toISOString()
            : undefined,
          maritalStatus: getValues('maritalStatus'),
          numberOfDependents: dependents ?? 0,
          gender: getValues('gender'),
          id: client!.demographic?.id ?? undefined,
        };

        await saveClientDemographics(clientDemographicData);

        if (!isUpdate) {
          goToNextStep(client!.id);
        }

        if (isUpdate) {
          getClientById(client!.id);
          if (typeof setClientUpdated === 'function') {
            setClientUpdated('demographics');
          }
          if (typeof hideModal === 'function') {
            hideModal();
          }
        }

        reset();
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error(e);
        setModalVisible(false);
        setModalContent(null);
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    };
    if (isUpdate) {
      setModalVisible(true);
      setModalContent(
        <GoAModal heading="Demographic information changed" maxWidth="500px" open>
          <p className="client-font-with-margin">
            Client’s demographic information has been changed. Do you want to save your changes?
          </p>
          <GoAButtonGroup alignment="end" mt="l">
            <GoAButton
              type="secondary"
              variant="destructive"
              onClick={() => {
                setModalContent(null);
                setModalVisible(false);
                setDependents(0);
                setValue(statusEffectiveDate, toIsoFormat(new Date()));
                if (typeof hideModal === 'function') {
                  hideModal();
                }
              }}
            >
              Cancel
            </GoAButton>
            <GoAButton onClick={continueSave}>Yes, save changes</GoAButton>
          </GoAButtonGroup>
        </GoAModal>,
      );
    } else {
      continueSave();
    }
  }, [
    isUpdate,
    getValues,
    dependents,
    client,
    saveClientDemographics,
    reset,
    goToNextStep,
    getClientById,
    setClientUpdated,
    hideModal,
    requestErrorHandler,
    setValue,
    statusEffectiveDate,
  ]);

  const previousButtonClickHandler = useCallback(() => {
    goToPreviousStep(client!.id);
  }, [client, goToPreviousStep]);

  const onChangeHandler = useCallback(
    (name: string, value: string | undefined) => {
      setValue(name as FormFieldName, value);
      watchClient(name, value);
      if (name === numberOfDependents) {
        setDependents(value ? +value : 0);
        watchClient(name, value ? +value : 0);
      }
    },
    [numberOfDependents, setValue, watchClient],
  );

  return {
    loading,
    requestError,
    formFields,
    getValues,
    clientSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    dependents,
    previousButtonClickHandler,
    client,
    modalContent,
    modalVisible,
    hideModal,
    canEditClientInProgress,
    watchStatusInCanada,
    minimumStatusEffectiveDate,
  };
};

export default useSubmitDemographic;
