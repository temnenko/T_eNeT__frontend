import { GoADetails } from '@abgov/react-components';

export function IndigenousTypeDetails() {
  return (
    <GoADetails heading="How do we define different indigenous types?" mt="0">
      <p>Status: First Nations persons with registered status under the Indian Act.</p>
      <p>
        Non-status: people who identify themselves as Indians but who are not entitled to registration on the Indian
        Register pursuant to the Indian Act.
      </p>
      <p>
        Métis: while there is no legal or legislative definition of Métis, they are recognized as one of three
        Indigenous/Aboriginal peoples under section 35 of the Constitution Act, 1982.
      </p>
      <p>
        Inuit: the Inuit peoples are recognized as Indigenous peoples who primarily inhabit the northern regions of
        Canada.
      </p>
    </GoADetails>
  );
}
