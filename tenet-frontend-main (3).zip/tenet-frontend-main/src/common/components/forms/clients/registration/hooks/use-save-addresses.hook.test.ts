import { act, renderHook } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import * as reactHookForm from 'react-hook-form';
import useSaveContactDetails from './use-save-addresses.hook';
import RootStore from '../../../../../../stores/root.store';
import * as hooks from '../../../../../../hooks/use-store.hook';
import * as stepperNavigationHook from './use-navigate-steppers.hook';
import { AddressType } from '../../../../../../types/client';

jest.mock('react-hook-form', () => ({
  ...jest.requireActual('react-hook-form'),
  useForm: jest.fn(),
}));

describe('useSaveAddresses', () => {
  const client = {
    addresses: [
      {
        id: '1',
        addressType: AddressType.MAILING,
        street: '123 Main St',
        unit: '123',
        city: 'Toronto',
        province: 'ON',
        postalCode: 'M1M 1M1',
        countryCode: 'Canada',
        effectiveDate: new Date('1983, 1, 2'),
      },
      {
        id: '2',
        addressType: AddressType.RESIDENTIAL,
        street: '456 Queen St',
        unit: '456',
        city: 'Toronto',
        province: 'ON',
        postalCode: 'M2M 2M2',
        countryCode: 'Canada',
        effectiveDate: new Date('1983, 1, 2'),
      },
    ],
  };
  const mockStore = {
    clientFormStore: {
      saveClientAddresses: jest.fn(),
      client,
      clientWatch: {},
      retrieveClient: jest.fn(),
      watchClient: jest.fn(),
      loadClient: jest.fn(),
    },
    clientFormStepperStore: { setCompletedSteps: jest.fn() },
    clientsStore: {
      selectedClient: { id: 'mock-id', firstName: 'Simpson', lastName: 'Jay' },
    },
    permissionStore: { isSuperAdmin: false },
    userStore: { role: 'SUPER_ADMIN' },
  } as unknown as RootStore;

  const mockForm = {
    register: jest.fn().mockImplementation(() => ({ name: 'testName' })),
    unregister: jest.fn(),
    getValues: jest.fn(),
    handleSubmit: jest.fn(),
    setValue: jest.fn(),
    reset: jest.fn(),
    formState: { errors: {} },
  } as unknown as ReturnType<typeof useForm>;

  const mockStepperNavigationHook = {
    goToNextStep: jest.fn(),
    goToPreviousStep: jest.fn(),
    setActiveStep: jest.fn(),
    jumpToStep: jest.fn(),
  };

  beforeEach(() => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);
    jest.spyOn(reactHookForm, 'useForm').mockImplementation(() => mockForm);
    jest.spyOn(stepperNavigationHook, 'useNavigateStepper').mockImplementation(() => mockStepperNavigationHook);
  });

  it('initializes with proper default state', () => {
    const { result } = renderHook(() => useSaveContactDetails());
    expect(result.current.loading).toBe(false);
    expect(result.current.formFields).toBeDefined();
  });

  it('updates form fields when isSameAsMailingAddress is toggled', () => {
    const { result } = renderHook(() => useSaveContactDetails());

    act(() => {
      result.current.setIsSameAsMailingAddress(false);
    });

    expect(result.current.unregister).toHaveBeenCalledWith('residentialStreetAddress');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialCity');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialUnit');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialProvince');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialPostalCode');
    expect(result.current.unregister).toHaveBeenCalledWith('residentialCountry');

    act(() => {
      result.current.setIsSameAsMailingAddress(true);
    });

    expect(result.current.register).toHaveBeenCalledWith(
      'residentialStreetAddress',
      expect.objectContaining({ required: expect.anything() }),
    );
    expect(result.current.register).toHaveBeenCalledWith(
      'residentialCity',
      expect.objectContaining({ required: expect.anything() }),
    );
    expect(result.current.register).toHaveBeenCalledWith('residentialUnit');
    expect(result.current.register).toHaveBeenCalledWith(
      'residentialProvince',
      expect.objectContaining({ required: expect.anything() }),
    );
    expect(result.current.register).toHaveBeenCalledWith(
      'residentialPostalCode',
      expect.objectContaining({ required: expect.anything() }),
    );
    expect(result.current.register).toHaveBeenCalledWith(
      'residentialCountry',
      expect.objectContaining({ required: expect.anything() }),
    );
  });

  it('initializes form fields with address data from the store', async () => {
    const { result } = renderHook(() => useSaveContactDetails());

    expect(result.current.reset).toHaveBeenCalledWith({
      mailingStreetAddress: '123 Main St',
      mailingUnit: '123',
      mailingCity: 'Toronto',
      mailingProvince: 'ON',
      mailingPostalCode: 'M1M 1M1',
      mailingCountry: 'Canada',
      residentialStreetAddress: '456 Queen St',
      residentialUnit: '456',
      residentialCity: 'Toronto',
      residentialProvince: 'ON',
      residentialPostalCode: 'M2M 2M2',
      residentialCountry: 'Canada',
    });
  });
});
