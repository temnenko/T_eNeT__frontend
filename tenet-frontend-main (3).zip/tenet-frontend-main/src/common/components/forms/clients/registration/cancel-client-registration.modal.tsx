import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';

type Props = {
  onConfirm: () => void;
  onDecline: () => void;
};

export default function CancelClientRegistrationModal({ onConfirm, onDecline }: Props) {
  return (
    <GoAModal heading="Cancel registration" transition="slow" maxWidth="500px" open>
      <p className="client-font-with-margin">
        {`Your data isn't saved yet. Exiting now will remove any record from the system. `}
      </p>
      <p className="client-font-with-margin">
        Complete all required fields in the first section (Personal Details) to save your progress.
      </p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton leadingIcon="trash" type="secondary" variant="destructive" onClick={onDecline}>
          Cancel
        </GoAButton>
        <GoAButton type="primary" onClick={onConfirm}>
          Continue registration
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
