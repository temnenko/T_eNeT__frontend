import {
  GoABlock,
  GoASpacer,
  GoAFormItem,
  GoARadioGroup,
  GoARadioItem,
  GoAButton,
  GoAInput,
  GoAIconButton,
  GoANotification,
  GoACallout,
  GoAButtonGroup,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { addYears } from 'date-fns';
import useSubmitDemographic from './hooks/use-submit-demographic.hook';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import { StatusInCanadaDetails } from './details/status-in-canada.details';
import { GenderXDetails } from './details/gender-x.details';
import { ImmigrationStatus } from '../../../../../types/client';
import { toIsoFormat } from '../../../../../utils/date.util';

interface Props {
  isUpdate?: boolean;
  clientId?: string;
  setClientUpdated?: (value: string) => void;
  hideModal?: () => void;
}

export const DemographicForm = observer(({ isUpdate, clientId, setClientUpdated, hideModal }: Props) => {
  const {
    loading,
    requestError,
    formFields,
    clientSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    dependents,
    previousButtonClickHandler,
    modalContent,
    modalVisible,
    getValues,
    canEditClientInProgress,
    client,
    minimumStatusEffectiveDate,
  } = useSubmitDemographic(!!isUpdate, hideModal, clientId, setClientUpdated);

  const { statusInCanada, statusEffectiveDate, gender, maritalStatus, numberOfDependents } = formFields;

  return (
    <>
      {modalVisible && modalContent}
      <form className="create-client-form">
        <GoABlock direction="column">
          <h4 className="client-no-padding-no-margin">{`Applicant's status in Canada`}</h4>
          <GoAFormItem error={errors[statusInCanada]?.message as unknown as string}>
            <GoARadioGroup name={statusInCanada} onChange={onChangeHandler} value={getValues(statusInCanada) ?? ''}>
              <GoARadioItem value={ImmigrationStatus.CANADIAN_CITIZEN} label="Canadian Citizen" />
              <GoARadioItem value={ImmigrationStatus.PERMANENT_RESIDENT} label="Permanent Resident" />
              <GoARadioItem value={ImmigrationStatus.PROTECTED_PERSON} label="Protected Person" />
              <GoARadioItem value={ImmigrationStatus.REFUGEE_CLAIMANT} label="Refugee Claimant" />
              <GoARadioItem value={ImmigrationStatus.TEMPORARY_RESIDENT} label="Temporary Resident" />
            </GoARadioGroup>
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="l" />
        <GoABlock direction="column" gap="s">
          <h4 className="client-no-padding-no-margin">Status effective date</h4>
          <div className={!statusEffectiveDate ? 'field-interactive-error' : ''}>
            <GoAFormItem error={errors[statusEffectiveDate]?.message as unknown as string}>
              <GoAInput
                type="date"
                onChange={onChangeHandler}
                name={statusEffectiveDate}
                value={getValues(statusEffectiveDate) ? toIsoFormat(getValues(statusEffectiveDate)!) : undefined}
                min={toIsoFormat(minimumStatusEffectiveDate)}
                max={toIsoFormat(addYears(new Date(), 5))}
              />
              <GoASpacer vSpacing="xs" />
              <p className="statusEffectiveDate_helpertext">
                Applicants born in Canada; status in Canada will be <strong>Canadian citizen</strong>, status effective
                date will be <strong>Date Of Birth</strong>.
              </p>
              <StatusInCanadaDetails />
            </GoAFormItem>
          </div>
        </GoABlock>
        <GoASpacer vSpacing="xl" />
        <GoASpacer vSpacing="l" />
        <GoABlock direction="column">
          <h4 className="client-no-padding-no-margin">{`Applicant's gender identity`}</h4>
          <GoAFormItem error={errors[gender]?.message as unknown as string}>
            <GoARadioGroup name={gender} value={getValues(gender) ?? ''} onChange={onChangeHandler}>
              <GoARadioItem value="FEMALE" label="Female" />
              <GoARadioItem value="MALE" label="Male" />
              <GoARadioItem value="GENDER_X" label="Gender X" />
              <GoARadioItem value="PREFER_NOT_TO_REPORT" label="Prefer not to report" />
            </GoARadioGroup>
            <GenderXDetails />
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="l" />
        <GoABlock direction="column">
          <h4 className="client-no-padding-no-margin">{`Applicant's marital status in Canada`}</h4>
          <GoAFormItem error={errors[maritalStatus]?.message as unknown as string}>
            <GoARadioGroup name={maritalStatus} value={getValues(maritalStatus) ?? ''} onChange={onChangeHandler}>
              <GoARadioItem value="SINGLE" label="Single" />
              <GoARadioItem value="MARRIED_OR_EQUIVALENT" label="Married or equivalent" />
              <GoARadioItem value="PREFER_NOT_TO_REPORT" label="Prefer not to report" />
            </GoARadioGroup>
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="l" />
        <GoABlock direction="column">
          <h4 className="client-no-padding-no-margin">Number of dependants:</h4>
          <GoAFormItem error={errors[numberOfDependents]?.message as unknown as string}>
            <div className="client-demographic-btn-flex">
              <GoABlock direction="column">
                <GoABlock>
                  <GoAIconButton
                    icon="remove"
                    size="medium"
                    onClick={() => {
                      if (dependents) {
                        onChangeHandler(numberOfDependents, (dependents - 1).toString());
                      }
                    }}
                  />
                  <GoAInput
                    onChange={(name: string, value: string): void => {
                      onChangeHandler(name, value);
                    }}
                    name={numberOfDependents}
                    type="text"
                    id="numberOfDependents"
                    width="71px"
                    value={dependents?.toString()}
                  />
                  <GoAIconButton
                    icon="add"
                    size="medium"
                    onClick={() => {
                      onChangeHandler(numberOfDependents, ((!dependents ? 0 : dependents) + 1).toString());
                    }}
                  />
                </GoABlock>
                {dependents! >= 20 ? (
                  <GoACallout type="important">Whoa, there is a lot of dependants!</GoACallout>
                ) : undefined}
              </GoABlock>
            </div>
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="xl" />
        {requestError?.message && (
          <>
            <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
              {requestError.message}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
        {client &&
          canEditClientInProgress(client) &&
          (!isUpdate ? (
            <div className="client-demographic-prev-next">
              <GoAButton type="secondary" onClick={previousButtonClickHandler} leadingIcon="arrow-back">
                <span>Previous:</span> Personal Details
              </GoAButton>
              <GoAButton
                type="primary"
                onClick={handleSubmit(clientSubmitHandler)}
                trailingIcon={loading ? undefined : 'arrow-forward'}
                disabled={loading}
              >
                {loading ? (
                  <InlineLoadingIndicator label="Saving changes..." />
                ) : (
                  <>
                    <span>Next:</span> Contact Information
                  </>
                )}
              </GoAButton>
            </div>
          ) : (
            <GoAButtonGroup alignment="end">
              <GoAButton type="secondary" onClick={hideModal}>
                Cancel
              </GoAButton>
              <GoAButton onClick={handleSubmit(clientSubmitHandler)}>Save</GoAButton>
            </GoAButtonGroup>
          ))}

        <GoASpacer vSpacing="2xl" />
      </form>
    </>
  );
});
