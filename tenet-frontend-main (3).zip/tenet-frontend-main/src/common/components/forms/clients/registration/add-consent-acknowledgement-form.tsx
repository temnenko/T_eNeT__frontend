import { GoAButton, GoANotification, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import useSubmitConsentAcknowledgement from './hooks/use-submit-consent-acknowledgement.hook';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import { ConsentAcknowledgementForm } from '../consent-acknowledgement-form';

export const AddConsentAcknowledgementForm = observer(() => {
  const {
    loading,
    requestError,
    addSubmitHandler,
    handleSubmit,
    errors,
    onChangeHandler,
    previousButtonClickHandler,
    getValues,
    canEditClientInProgress,
    client,
  } = useSubmitConsentAcknowledgement();

  return (
    <form className="create-client-form">
      <ConsentAcknowledgementForm errors={errors} onChangeHandler={onChangeHandler} getValues={getValues} />
      <GoASpacer vSpacing="xl" />
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {client && canEditClientInProgress(client) && (
        <div className="row-space-between client-demographic-prev-next">
          <GoAButton
            disabled={loading}
            type="secondary"
            onClick={() => previousButtonClickHandler()}
            leadingIcon="arrow-back"
          >
            <span className="client-bold-600">Previous:</span> Factors
          </GoAButton>
          <GoAButton
            disabled={loading}
            type="submit"
            onClick={handleSubmit(addSubmitHandler)}
            trailingIcon={loading ? undefined : 'arrow-forward'}
          >
            {loading ? (
              <InlineLoadingIndicator label="Saving changes..." />
            ) : (
              <>
                <span className="client-bold-600">Next:</span> Client files
              </>
            )}
          </GoAButton>
        </div>
      )}

      <GoASpacer vSpacing="2xl" />
    </form>
  );
});
