/* eslint-disable @typescript-eslint/no-unused-expressions */
import { ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import lunhCheck from 'luhn-js';
import { useForm } from 'react-hook-form';
import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';
import { compareDesc, differenceInYears } from 'date-fns';
import useLoadClient from './use-load-client';
import { CreateClientArgs, Language, NameType, SinRecord } from '../../../../../../types/client';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { useNavigateStepper } from './use-navigate-steppers.hook';
import { ClientFormStepperKeys } from '../../../../../../types/client-forms';
import { getEnumValue } from '../../../../../../utils/enums.util';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';
import { toIsoFormat } from '../../../../../../utils/date.util';

type PersonalDetailsFormData = {
  language: Language;
  firstName: string;
  middleName?: string;
  lastName: string;
  nameType?: string;
  prevFirstName?: string;
  prevMiddleName?: string;
  prevLastName?: string;
  dateOfBirth: string;
  sin: string;
  sinExpiryDate?: string;
  workPermitExpiryDate?: string;
  isOpenWorkPermit: boolean;
};

type FormFieldName =
  | 'language'
  | 'firstName'
  | 'middleName'
  | 'lastName'
  | 'nameType'
  | 'prevFirstName'
  | 'prevMiddleName'
  | 'prevLastName'
  | 'sin'
  | 'isOpenWorkPermit'
  | 'sinExpiryDate'
  | 'workPermitExpiryDate'
  | 'dateOfBirth';

const useSubmitPersonalDetails = (
  isModal: boolean,
  hideModal?: () => void,
  clientId?: string,
  setClientUpdated?: (value: string) => void,
) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const {
    clientFormStore: { clientWatch, watchClient, retrieveClient, createClient, updateClient },
    permissionStore: { canEditClientInProgress, canCreateNewClient },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();

  const { goToNextStep, setActiveStep } = useNavigateStepper();

  const { client } = useLoadClient(clientId);

  const {
    getValues,
    handleSubmit,
    register,
    reset,
    setValue,
    setError,
    formState: { errors },
    clearErrors,
    watch,
  } = useForm<PersonalDetailsFormData>();

  const { name: firstName } = register('firstName', {
    required: { value: true, message: 'Legal first name is required.' },
    pattern: {
      value: /^[\p{L}](?:[.'-]?[\p{L}])*$/u,
      message: 'Name can only begin with an alphabet or accented character',
    },
    min: 3,
  });
  const { name: language } = register('language', {
    required: { value: true, message: 'Preferred official language is required.' },
  });
  const { name: middleName } = register('middleName', {
    pattern: {
      value: /^[\p{L}](?:[.'-]?[\p{L}])*$/u,
      message: 'Name can only begin with an alphabet or accented character',
    },
    min: 3,
  });
  const { name: lastName } = register('lastName', {
    required: { value: true, message: 'Legal last name is required.' },
    pattern: {
      value: /^[\p{L}](?:[.'-]?[\p{L}])*$/u,
      message: 'Name can only begin with an alphabet or accented character',
    },
    min: 3,
  });
  const { name: nameType } = register('nameType');

  const { name: prevFirstName } = register('prevFirstName', {
    pattern: {
      value: /^[\p{L}](?:[.'-]?[\p{L}])*$/u,
      message: 'Name can only begin with an alphabet or accented character',
    },
    min: 3,
  });
  const { name: prevMiddleName } = register('prevMiddleName', {
    pattern: {
      value: /^[\p{L}](?:[.'-]?[\p{L}])*$/u,
      message: 'Name can only begin with an alphabet or accented character',
    },
    min: 3,
  });
  const { name: prevLastName } = register('prevLastName', {
    pattern: {
      value: /^[\p{L}](?:[.'-]?[\p{L}])*$/u,
      message: 'Name can only begin with an alphabet or accented character',
    },
    min: 3,
  });
  const { name: dateOfBirth } = register('dateOfBirth', {
    required: { value: true, message: 'Date of Birth is required.' },
    validate: (value) => {
      if (compareDesc(new Date(value), Date.now()) <= 0) {
        return 'The date of birth cannot be in the future';
      }
      if (differenceInYears(Date.now(), new Date(value)) <= 16) {
        return 'The applicant cannot be below 16 years of age';
      }
      return true;
    },
  });
  const { name: sin } = register('sin', {
    required: { value: true, message: 'The Social Insurance Number is required.' },
    minLength: { value: 9, message: 'The Social Insurance Number field can only contain 9 numbers (no spaces)' },
    maxLength: { value: 9, message: 'The Social Insurance Number field can only contain 9 numbers (no spaces)' },
    pattern: {
      value: /[0-9]{9}/,
      message: 'SIN Number can only contain numbers',
    },
    validate: (value) => {
      if (value.indexOf('0') === 0) {
        return 'The Social Insurance Number cannot begin with zero';
      }
      if (!lunhCheck.isValid(value)) {
        return 'The Social Insurance Number is not valid';
      }
      return true;
    },
  });
  const sinWatch = watch(sin);
  const isTempSin = useMemo(() => sinWatch?.trim().charAt(0) === '9', [sinWatch]);

  const { name: sinExpiryDate } = register('sinExpiryDate');

  const { name: isOpenWorkPermit } = register('isOpenWorkPermit');
  const hasOpenWorkPermit = watch(isOpenWorkPermit);

  const { name: workPermitExpiryDate } = register('workPermitExpiryDate', {
    validate: (value) => {
      if (!value && !hasOpenWorkPermit && isTempSin) {
        return 'The work permit expiry date is required';
      }
      return true;
    },
  });

  const formFields = {
    language,
    firstName,
    middleName,
    lastName,
    prevFirstName,
    prevMiddleName,
    prevLastName,
    dateOfBirth,
    sin,
    isOpenWorkPermit,
    nameType,
    sinExpiryDate,
    workPermitExpiryDate,
  };

  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  useEffect(() => {
    setActiveStep(ClientFormStepperKeys.PERSONAL);
    if (clientWatch || client) {
      const sinPosition = (client?.sinRecords?.length ?? 1) - 1;
      const savedSinExpiryDate = client?.sinRecords[sinPosition]?.sinExpiryDate;
      reset({
        language: retrieveClient(language) ?? client?.language,
        firstName: retrieveClient(firstName) ?? client?.firstName,
        middleName: retrieveClient(middleName) ?? client?.middleName ?? '',
        lastName: retrieveClient(lastName) ?? client?.lastName,
        dateOfBirth:
          retrieveClient(dateOfBirth) ?? (client?.dateOfBirth ? toIsoFormat(new Date(client.dateOfBirth)) : undefined),
        sin: retrieveClient(sin) ?? client?.sinRecords[sinPosition]?.sinNumber,
        sinExpiryDate:
          retrieveClient(sinExpiryDate) ?? (savedSinExpiryDate ? toIsoFormat(new Date(savedSinExpiryDate)) : undefined),
        workPermitExpiryDate:
          retrieveClient(workPermitExpiryDate) ??
          (client?.sinRecords[sinPosition]?.workPermitExpiryDate
            ? toIsoFormat(new Date(client.sinRecords[sinPosition]!.workPermitExpiryDate ?? ''))
            : undefined),
        prevFirstName: retrieveClient(prevFirstName) ?? client?.previousName?.firstName ?? '',
        prevMiddleName: retrieveClient(prevMiddleName) ?? client?.previousName?.middleName ?? '',
        prevLastName: retrieveClient(prevLastName) ?? client?.previousName?.lastName ?? '',
        nameType: retrieveClient(nameType) ?? client?.previousName?.type,
        isOpenWorkPermit: retrieveClient(isOpenWorkPermit),
      });
    }
  }, [
    client,
    clientWatch,
    client?.id,
    dateOfBirth,
    firstName,
    language,
    lastName,
    middleName,
    nameType,
    prevFirstName,
    prevLastName,
    prevMiddleName,
    reset,
    retrieveClient,
    setActiveStep,
    setValue,
    sin,
    sinExpiryDate,
    workPermitExpiryDate,
    isOpenWorkPermit,
  ]);

  const hasInvalidFields = useCallback(
    (_dateOfBirth: string): boolean => {
      let foundInvalidField = false;

      if (compareDesc(new Date(_dateOfBirth), Date.now()) <= 0) {
        setError('dateOfBirth', { message: 'The date of birth cannot be in the future' });
        foundInvalidField = true;
      } else if (differenceInYears(Date.now(), new Date(_dateOfBirth)) < 18) {
        setError('dateOfBirth', { message: 'The applicant cannot be below 18 years of age' });
        foundInvalidField = true;
      }

      const isEmptySinExpiryDate = !getValues('sinExpiryDate');

      if (isTempSin && isEmptySinExpiryDate) {
        setError('sinExpiryDate', { message: 'The SIN expiry date is required' });
        foundInvalidField = true;
      }
      return foundInvalidField;
    },
    [getValues, isTempSin, setError],
  );

  const clientSubmitHandler = useCallback(async () => {
    const continueSave = async () => {
      try {
        if (hasInvalidFields(getValues(dateOfBirth))) {
          return;
        }

        setLoading(true);

        const sinRecord: Omit<SinRecord, 'id'> = {
          sinNumber: getValues('sin'),
          sinExpiryDate: getValues('sinExpiryDate') ? new Date(getValues('sinExpiryDate')!).toISOString() : undefined,
          workPermitExpiryDate: getValues('workPermitExpiryDate')
            ? new Date(getValues('workPermitExpiryDate')!).toISOString()
            : undefined,
        };

        const clientData: CreateClientArgs = {
          firstName: getValues('firstName'),
          lastName: getValues('lastName'),
          middleName: getValues('middleName'),
          dateOfBirth: new Date(getValues(dateOfBirth)).toISOString(),
          sinRecords: [sinRecord],
          language: getEnumValue(Language, getValues('language'))!,
          creationCompleted: false,
        };

        if (getValues(nameType)) {
          clientData.previousName = {
            firstName: getValues(prevFirstName),
            middleName: getValues(prevMiddleName),
            lastName: getValues(prevLastName),
            type: getEnumValue(NameType, getValues(nameType)),
          };
        }

        // clients are only created in a stepper, not a modal
        if (!isModal) {
          if (!client) {
            const createdClient = await createClient(clientData);
            goToNextStep(createdClient.id);
          } else {
            await updateClient(clientData);
            goToNextStep(client.id);
          }
        } else {
          await updateClient(clientData);
          setClientUpdated!('personal details');
          reset();
          hideModal!();
        }
        reset();
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error(e);
        setModalVisible(false);
        setModalContent(null);
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    };
    if (isModal) {
      setModalVisible(true);
      setModalContent(
        <GoAModal heading="Personal details changed" maxWidth="500px" open>
          <p className="client-font-with-margin">
            Client’s personal details information has been changed. Do you want to save your changes?
          </p>
          <GoAButtonGroup alignment="end" mt="l">
            <GoAButton
              type="secondary"
              variant="destructive"
              onClick={() => {
                setModalContent(null);
                setModalVisible(false);
                reset();
                if (typeof hideModal === 'function') {
                  hideModal();
                }
              }}
            >
              Cancel
            </GoAButton>
            <GoAButton onClick={continueSave}>Yes, save changes</GoAButton>
          </GoAButtonGroup>
        </GoAModal>,
      );
    } else {
      continueSave();
    }
  }, [
    client,
    createClient,
    dateOfBirth,
    getValues,
    goToNextStep,
    hasInvalidFields,
    hideModal,
    isModal,
    nameType,
    prevFirstName,
    prevLastName,
    prevMiddleName,
    requestErrorHandler,
    reset,
    setClientUpdated,
    updateClient,
  ]);

  const onChangeHandler = useCallback(
    (name: string, value: string | NameType | boolean | undefined) => {
      watchClient(name, value);

      setValue(name as FormFieldName, value, {
        shouldValidate: !['dateOfBirth', 'sinExpiryDate', 'workPermitExpiryDate'].includes(name),
      });

      if (name === 'isOpenWorkPermit') {
        const openWorkPermit = getValues(isOpenWorkPermit);
        if (!openWorkPermit) {
          setValue('workPermitExpiryDate', undefined);
        }
        watchClient(name, openWorkPermit);
      }

      if (sinWatch) {
        const sanitizedValue = sinWatch.replace(/\s+/g, '');
        if (sinWatch !== sanitizedValue) {
          setValue(sin, sanitizedValue, { shouldValidate: true });
        }
      }
    },
    [getValues, isOpenWorkPermit, setValue, sin, sinWatch, watchClient],
  );

  const onNameTypeChangeHandler = useCallback(
    (name: string, value: string | string[]) => {
      setValue(name as FormFieldName, value as NameType);
      watchClient(name, value);
    },
    [setValue, watchClient],
  );

  const validateSIN = useCallback(
    (name: string, value: string) => {
      const pattern = {
        value: /[0-9]{9}/,
        message: 'SIN Number can only contain numbers',
      };
      if (value.length > 0) {
        if (value.indexOf('0') === 0) {
          setError(sin, { type: 'custom', message: 'The Social Insurance Number cannot begin with zero' });
        } else if (!pattern.value.test(value)) {
          setError(sin, { type: 'custom', message: pattern.message });
        } else if (value.length < 9 || value.length > 9) {
          setError(sin, {
            type: 'custom',
            message: 'The Social Insurance Number field can only contain 9 numbers (no spaces)',
          });
        } else if (!lunhCheck.isValid(value)) {
          setError(sin, { type: 'custom', message: 'The Social Insurance Number is not valid' });
        } else {
          clearErrors(sin);
        }
      } else {
        setError(sin, { type: 'custom', message: 'The Social Insurance Number is required.' });
      }
    },
    [clearErrors, setError, sin],
  );

  return {
    loading,
    requestError,
    formFields,
    getValues,
    clientSubmitHandler,
    onChangeHandler,
    handleSubmit,
    isTempSin,
    errors,
    onNameTypeChangeHandler,
    modalContent,
    modalVisible,
    hasOpenWorkPermit,
    validateSIN,
    canEditClientInProgress,
    client,
    canCreateNewClient,
  };
};

export default useSubmitPersonalDetails;
