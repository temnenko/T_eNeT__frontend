import { GoABlock, GoAButton, GoAContainer, GoAGrid, GoASpacer, GoATable } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useClientRegistrationReview } from './hooks/use-client-review-cards.hook';
import ClientRegistrationReviewCard from './client-registration-review-card';
import useCompleteClientRegistration from './hooks/use-submit-for-lmda-verification.hook';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import UserErrorCallout from '../../../user-error-callout/user-error-callout';
import SystemErrorCallout from '../../../system-error-callout/system-error-callout';
import { ClientFormStepperKeys } from '../../../../../types/client-forms';
import { useNavigateStepper } from './hooks/use-navigate-steppers.hook';
import useActionButton from '../../../../../hooks/use-action-button.hook';

const ClientRegistrationReview = observer(() => {
  const { cards, documents, client, canEditClientInProgress } = useClientRegistrationReview();
  const { error, loading, submitHandler } = useCompleteClientRegistration();
  const { jumpToStep } = useNavigateStepper();

  return (
    <div className="client-review-overview">
      {error?.isUserError && <UserErrorCallout message={error?.message} />}
      {error?.isSystemError && <SystemErrorCallout />}
      <GoAGrid gap="xl" minChildWidth="350px">
        {cards?.map((clientCard) => {
          return (
            <ClientRegistrationReviewCard
              key={clientCard.title}
              title={clientCard.title}
              data={clientCard.data}
              additionalData={clientCard.additionalData}
              editDisabled={loading}
              action={clientCard.navigate}
            />
          );
        })}
        <GoAContainer
          heading="Files"
          accent="thick"
          actions={useActionButton(() => jumpToStep(ClientFormStepperKeys.FILES, client!.id))}
          padding="compact"
        >
          <GoATable width="100%">
            <thead>
              <tr>
                <th className="review-filename" data-testid="review_filename">
                  Files
                </th>
                <th className="review-filetype" data-testid="review_filetype">
                  Type
                </th>
                <th className="review-dateadded" data-testid="review_dateHeader">
                  Date Added
                </th>
              </tr>
            </thead>
            <tbody>
              {documents &&
                documents.map((file) => {
                  return (
                    <tr key={`${file.fileName}-${file.createdAt}`}>
                      <td style={{ color: '#0070C4', fontWeight: '400', lineHeight: '28px', width: '40%' }}>
                        {file.fileName}
                      </td>
                      <td style={{ width: '20%' }}>{file.typeName}</td>
                      <td style={{ width: '40%' }}>{file.adspCreatedAt?.substring(0, 10)}</td>
                    </tr>
                  );
                })}
            </tbody>
          </GoATable>
        </GoAContainer>
        <GoASpacer vSpacing="m" />
        {client && canEditClientInProgress(client) && (
          <GoABlock gap="m">
            <GoAButton type="primary" onClick={submitHandler} disabled={loading}>
              {loading ? (
                <InlineLoadingIndicator label="Submitting for LMDA verification..." />
              ) : (
                <>Complete Registration</>
              )}
            </GoAButton>
          </GoABlock>
        )}
      </GoAGrid>
    </div>
  );
});

export default ClientRegistrationReview;
