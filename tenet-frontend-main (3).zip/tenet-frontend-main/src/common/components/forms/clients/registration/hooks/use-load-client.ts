/* eslint-disable @typescript-eslint/no-unused-expressions */
import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from '../../../../../../hooks/use-store.hook';

const useLoadClient = (selectedClientId?: string) => {
  const { clientId } = useParams<{ clientId: string }>();
  const {
    clientFormStore: { client, loadClient },
    clientFormStepperStore: { setCompletedSteps },
  } = useStore();

  useEffect(() => {
    const activeClient = clientId ?? selectedClientId;
    if (activeClient && (!client || client.id !== activeClient)) {
      loadClient(activeClient).then((data) => setCompletedSteps(data));
    }
  }, [client, client?.id, clientId, loadClient, selectedClientId, setCompletedSteps]);

  return {
    client,
    isLoading: !client,
  };
};

export default useLoadClient;
