import { ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';

import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';
import { useNavigateStepper } from './use-navigate-steppers.hook';
import useLoadClient from './use-load-client';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { ClientFormStepperKeys, FactorValues, IndigenousTypes } from '../../../../../../types/client-forms';
import { getEnumValue } from '../../../../../../utils/enums.util';
import { Factors, FactorsOptions } from '../../../../../../types/client';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';

type FactorsFormData = {
  disability: string;
  indigenous: string;
  indigenousType: string;
  immigrant: string;
  yearOfLanding: string;
  visibleMinority: string;
};

type FormFieldName = 'disability' | 'indigenous' | 'indigenousType' | 'immigrant' | 'yearOfLanding' | 'visibleMinority';

const useSubmitFactors = (
  isUpdate: boolean,
  hideModal?: () => void,
  clientId?: string,
  setClientUpdated?: (value: string) => void,
) => {
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);
  const {
    clientFormStore: { clientWatch, watchClient, retrieveClient, updateClient },
    clientsStore: { getClientById },
    permissionStore: { canEditClientInProgress },
  } = useStore();

  const { goToNextStep, goToPreviousStep, setActiveStep } = useNavigateStepper();

  const { client, isLoading } = useLoadClient(clientId);

  const {
    getValues,
    handleSubmit,
    register,
    reset,
    setValue,
    setError,
    formState: { errors },
    watch,
  } = useForm<FactorsFormData>({
    defaultValues: {
      disability: retrieveClient('disability') ?? client?.factors?.disability,
      indigenous: retrieveClient('indigenous') ?? client?.factors?.indigenous,
      indigenousType: retrieveClient('indigenousType') ?? client?.factors?.indigenousType,
      immigrant: retrieveClient('immigrant') ?? client?.factors?.immigrant,
      yearOfLanding: retrieveClient('yearOfLanding') ?? client?.factors?.yearOfLanding,
      visibleMinority: retrieveClient('visibleMinority') ?? client?.factors?.visibleMinority,
    },
  });
  const requestErrorHandler = useRequestErrorHandler();

  useEffect(() => {
    setActiveStep(ClientFormStepperKeys.FACTORS);
    if (!isLoading && (clientWatch || client?.factors)) {
      const { factors } = client!;
      reset({
        disability: factors?.disability ?? retrieveClient('disability'),
        indigenous: factors?.indigenous ?? retrieveClient('indigenous'),
        indigenousType: factors?.indigenousType ?? retrieveClient('indigenousType'),
        immigrant: retrieveClient('immigrant') ?? factors?.immigrant,
        yearOfLanding: factors?.yearOfLanding ?? retrieveClient('yearOfLanding'),
        visibleMinority: factors?.visibleMinority ?? retrieveClient('visibleMinority'),
      });
      // setIsImmigrant(factors?.immigrant?.toUpperCase() === FactorsOptions.YES);
    }
  }, [client, clientWatch, isLoading, reset, retrieveClient, setActiveStep]);

  const { name: disability } = register('disability', {
    required: { value: true, message: 'Disability required' },
  });
  const { name: indigenous } = register('indigenous', {
    required: { value: true, message: 'Indigenous required' },
  });

  const indigenousWatch = watch(indigenous);
  const isIndigenous = useMemo(() => indigenousWatch === FactorValues.YES, [indigenousWatch]);

  const { name: indigenousType } = register('indigenousType', {
    required: { value: isIndigenous, message: 'Indigenous type required' },
  });
  const { name: immigrant } = register('immigrant', {
    required: { value: true, message: 'Immigrant required' },
  });
  const immigrantWatch = watch(immigrant);
  const isImmigrant = useMemo(() => immigrantWatch === FactorValues.YES, [immigrantWatch]);

  const { name: yearOfLanding } = register('yearOfLanding', {
    required: { value: isImmigrant, message: 'Year of landing required' },
  });
  const { name: visibleMinority } = register('visibleMinority', {
    required: { value: true, message: 'Visible minority required' },
  });

  const formFields = {
    disability,
    indigenous,
    indigenousType,
    immigrant,
    yearOfLanding,
    visibleMinority,
  };

  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  /* const checkImmigrant = useCallback(
    () => (getValues('immigrant') === FactorsOptions.YES ? setIsImmigrant(true) : setIsImmigrant(false)),
    [getValues],
  ); */

  const hasInvalidYearOfLand = useCallback((): boolean => {
    const value = Number.parseInt(getValues('yearOfLanding')?.trim() ?? '0', 10);
    const thisYear = new Date().getUTCFullYear();

    if (isImmigrant && value <= 0) {
      setError('yearOfLanding', { message: 'The year of landing is required.' });
      return true;
    }
    if (isImmigrant && value > thisYear) {
      setError('yearOfLanding', { message: 'The year of landing cannot be in the future.' });
      return true;
    }

    return false;
  }, [getValues, isImmigrant, setError]);

  const factorsSubmitHandler = useCallback(async () => {
    const continueSave = async () => {
      try {
        if (hasInvalidYearOfLand()) {
          return;
        }

        setRequestError({});
        setLoading(true);

        const clientFactorsData: Factors = {
          disability: getEnumValue(FactorsOptions, getValues('disability'))!,
          indigenous: getEnumValue(FactorsOptions, getValues('indigenous'))!,
          indigenousType: getEnumValue(IndigenousTypes, getValues('indigenousType'))!,
          immigrant: getEnumValue(FactorsOptions, getValues('immigrant'))!,
          yearOfLanding: getValues('yearOfLanding'),
          visibleMinority: getEnumValue(FactorsOptions, getValues('visibleMinority'))!,
        };

        await updateClient({ factors: clientFactorsData });

        if (!isUpdate) {
          goToNextStep(client!.id!);
        }

        if (isUpdate) {
          getClientById(client!.id!);
          if (typeof setClientUpdated === 'function') {
            setClientUpdated('factors');
          }
          if (typeof hideModal === 'function') {
            hideModal();
          }
        }

        reset();
      } catch (e) {
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
        // eslint-disable-next-line no-console
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    if (isUpdate) {
      setModalVisible(true);
      setModalContent(
        <GoAModal heading="Factors changed" maxWidth="500px" open>
          <p className="client-font-with-margin">
            Client’s self declared factor(s) has been changed. Do you want to save your changes?
          </p>
          <GoAButtonGroup alignment="end" mt="l">
            <GoAButton
              type="secondary"
              variant="destructive"
              onClick={() => {
                setModalContent(null);
                setModalVisible(false);
                if (typeof hideModal === 'function') {
                  hideModal();
                }
              }}
            >
              Cancel
            </GoAButton>
            <GoAButton onClick={continueSave}>Yes, save changes</GoAButton>
          </GoAButtonGroup>
        </GoAModal>,
      );
    } else {
      continueSave();
    }
  }, [
    client,
    getClientById,
    getValues,
    goToNextStep,
    hasInvalidYearOfLand,
    hideModal,
    isUpdate,
    requestErrorHandler,
    reset,
    setClientUpdated,
    updateClient,
  ]);

  const previousButtonClickHandler = useCallback(() => {
    goToPreviousStep(client!.id!);
  }, [client, goToPreviousStep]);

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value);
      watchClient(name, value);

      /* if (name === 'immigrant') {
        checkImmigrant();
      } */
    },
    [/* checkImmigrant,  */ setValue, watchClient],
  );

  return {
    loading,
    isImmigrant,
    requestError,
    formFields,
    getValues,
    factorsSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    previousButtonClickHandler,
    modalVisible,
    modalContent,
    isIndigenous,
    canEditClientInProgress,
    client,
  };
};

export default useSubmitFactors;
