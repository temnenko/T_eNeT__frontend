import { useCallback, useEffect, useMemo } from 'react';

import { format } from 'date-fns';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { AddressType } from '../../../../../../types/client';
import { humanizeNameType } from '../../../../../../utils/humanize.util';
import { useNavigateStepper } from './use-navigate-steppers.hook';
import { ClientFormStepperKeys } from '../../../../../../types/client-forms';
import { toIsoDate } from '../../../../../../utils/date.util';

export const useClientRegistrationReview = () => {
  const {
    clientFormStore: { client },
    clientFilesStore: { getClientDocuments, documents },
    permissionStore: { canEditClientInProgress },
  } = useStore();

  const { jumpToStep } = useNavigateStepper();

  useEffect(() => {
    const call = async (clientId: string) => {
      await getClientDocuments(clientId);
    };
    if (client) {
      call(client.id);
    }
  }, [client, getClientDocuments]);

  const createPersonalDetailsData = useCallback(() => {
    const sinPosition = (client?.sinRecords?.length ?? 1) - 1;
    const previousName = client?.previousName;

    let otherName = previousName
      ? `${previousName.firstName} ${previousName.middleName ?? ''} ${previousName.lastName ?? ''}`
      : '';
    if (otherName.trim()) {
      otherName = previousName ? `${otherName} - (${humanizeNameType(previousName.type!)})` : '';
    }

    const workPermitExpiryDate = client?.sinRecords[sinPosition]?.workPermitExpiryDate;

    const data = [
      {
        label: 'Other names',
        value: otherName.trim(),
      },
      {
        label: 'First name',
        value: client?.firstName,
      },
      {
        label: 'Middle name',
        value: client?.middleName,
      },
      {
        label: 'Last name',
        value: client?.lastName,
      },
      {
        label: 'DOB',
        value: client?.dateOfBirth ? format(toIsoDate(client.dateOfBirth), 'dd MMM yyyy') : '',
      },
      {
        label: 'SIN',
        value: client?.sinRecords[sinPosition]?.sinNumber,
      },
    ];

    if (client?.sinRecords?.[sinPosition]?.sinExpiryDate) {
      data.push({
        label: 'SIN expiry date',
        value: format(toIsoDate(client.sinRecords[sinPosition].sinExpiryDate!), 'dd MMM yyyy'),
      });
    }

    if (client?.sinRecords?.[sinPosition]?.sinNumber.startsWith('9')) {
      data.push({
        label: 'Work permit expiry date',
        value: workPermitExpiryDate ? format(toIsoDate(workPermitExpiryDate), 'dd MMM yyyy') : 'No open work permit',
      });
    }
    return data.filter((entry) => entry);
  }, [
    client?.dateOfBirth,
    client?.firstName,
    client?.lastName,
    client?.middleName,
    client?.previousName,
    client?.sinRecords,
  ]);

  return useMemo(() => {
    const demographic = client?.demographic;
    const factors = client?.factors;
    const addresses = client?.addresses;
    const phones = client?.phones;

    const cards = [
      {
        title: 'Personal detail',
        data: createPersonalDetailsData(),
        navigate: () => jumpToStep(ClientFormStepperKeys.PERSONAL, client!.id),
      },
      {
        title: 'Demographic',
        data: [
          {
            label: 'Status',
            value: demographic?.statusInCanada?.replaceAll('_', ' '),
          },
          {
            label: 'Effective date',
            value: demographic?.statusEffectiveDate
              ? format(toIsoDate(demographic.statusEffectiveDate), 'dd MMM yyyy')
              : '',
          },
          {
            label: 'Gender',
            value: demographic?.gender,
          },
          {
            label: 'Marital status',
            value: demographic?.maritalStatus.replaceAll('_', ' '),
          },
          {
            label: 'Dependents',
            value: demographic?.numberOfDependents.toString(),
          },
        ],
        navigate: () => jumpToStep(ClientFormStepperKeys.DEMOGRAPHICS, client!.id),
      },
      {
        title: 'Contact Information',
        data: [
          {
            label: 'Address',
            value: addresses ? addresses[0]?.street : '',
          },
          {
            label: 'City',
            value: addresses ? addresses[0]?.city : '',
          },
          {
            label: 'Province',
            value: addresses ? addresses[0]?.province : '',
          },
          {
            label: 'Postal Code',
            value: addresses ? addresses[0]?.postalCode : '',
          },
          {
            label: 'Residential address the same?',
            value: addresses && client?.addresses[0]?.addressType === AddressType.BOTH ? 'Yes' : 'No',
          },
          {
            label: 'Phone',
            value: phones && phones[0]?.phoneNumber,
          },
          {
            label: 'Email',
            value: client?.emailAddresses && client?.emailAddresses[0]?.emailAddress,
          },
        ],
        navigate: () => jumpToStep(ClientFormStepperKeys.CONTACT, client!.id),
      },
      {
        title: 'Factors',
        data: [
          {
            label: 'Disability',
            value: factors?.disability,
          },
          {
            label: 'Indigenous',
            value: factors?.indigenous,
          },
          {
            label: 'Immigrant',
            value: factors?.immigrant,
          },
          {
            label: 'Visible Minority',
            value: factors?.visibleMinority,
          },
        ],
        additionalData: [
          {
            label: 'Year of landing',
            value: factors?.yearOfLanding ?? 'NA',
          },
        ],
        navigate: () => jumpToStep(ClientFormStepperKeys.FACTORS, client!.id),
      },
    ];
    return { cards, documents, client, canEditClientInProgress };
  }, [client, createPersonalDetailsData, documents, canEditClientInProgress, jumpToStep]);
};
