import { useCallback, useMemo } from 'react';
import { GoAIcon } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';

import { useStore } from '../../../../../../hooks/use-store.hook';
import { Stepper } from '../../../stepper';
import {
  ClientFormStepperKeys,
  TabsTextState,
  clientFormStepperPaths,
  clientFormStepperTitles,
} from '../../../../../../types/client-forms';
import useLoadClient from './use-load-client';

const useSteppers = () => {
  const {
    authStore: { isAuthenticated },
    clientFormStepperStore: { steppers, active },
  } = useStore();
  const { personal, demographics, contact, factors, consent, files, review } = steppers;
  const navigate = useNavigate();
  const { client } = useLoadClient();

  const clickHandler = useCallback(
    (key: ClientFormStepperKeys, path: string) => () => {
      const updatedPath = client?.id ? path.replace(':clientId?', client.id!) : path;
      if (client?.id) {
        active(key);
        navigate(updatedPath);
      }
    },
    [active, client?.id, navigate],
  );
  const getTabIcon = useCallback((tabState: TabsTextState) => {
    if (tabState === TabsTextState.ACTIVE) {
      return <GoAIcon type="pencil" theme="filled" size="small" />;
    }

    if (tabState === TabsTextState.DONE) {
      return <GoAIcon type="checkmark" theme="filled" size="small" />;
    }

    return '';
  }, []);

  const steppersProps = useMemo(
    () => [
      {
        text: clientFormStepperTitles.personal,
        icon: getTabIcon(personal.tabText),
        clickHandler: clickHandler(ClientFormStepperKeys.PERSONAL, clientFormStepperPaths.personal),
        className: '',
        tabClassName: personal.tab,
        textClassName: personal.tabText,
      },
      {
        text: clientFormStepperTitles.demographics,
        icon: getTabIcon(demographics.tabText),
        clickHandler: clickHandler(ClientFormStepperKeys.DEMOGRAPHICS, clientFormStepperPaths.demographics),
        className: '',
        tabClassName: demographics.tab,
        textClassName: demographics.tabText,
      },
      {
        text: clientFormStepperTitles.contact,
        icon: getTabIcon(contact.tabText),
        clickHandler: clickHandler(ClientFormStepperKeys.CONTACT, clientFormStepperPaths.contact),
        className: '',
        tabClassName: contact.tab,
        textClassName: contact.tabText,
      },
      {
        text: clientFormStepperTitles.factors,
        icon: getTabIcon(factors.tabText),
        clickHandler: clickHandler(ClientFormStepperKeys.FACTORS, clientFormStepperPaths.factors),
        className: '',
        tabClassName: factors.tab,
        textClassName: factors.tabText,
      },
      {
        text: clientFormStepperTitles.consent,
        icon: getTabIcon(consent.tabText),
        clickHandler: clickHandler(ClientFormStepperKeys.CONSENT, clientFormStepperPaths.consent),
        className: '',
        tabClassName: consent.tab,
        textClassName: consent.tabText,
      },
      {
        text: clientFormStepperTitles.files,
        icon: getTabIcon(files.tabText),
        clickHandler: clickHandler(ClientFormStepperKeys.FILES, clientFormStepperPaths.files),
        className: '',
        tabClassName: files.tab,
        textClassName: files.tabText,
      },
      {
        text: clientFormStepperTitles.review,
        icon: getTabIcon(review.tabText),
        clickHandler: clickHandler(ClientFormStepperKeys.REVIEW, clientFormStepperPaths.review),
        className: '',
        tabClassName: review.tab,
        textClassName: review.tabText,
      },
    ],
    [
      clickHandler,
      contact.tab,
      contact.tabText,
      demographics.tab,
      demographics.tabText,
      factors.tab,
      factors.tabText,
      consent.tab,
      consent.tabText,
      files.tab,
      files.tabText,
      getTabIcon,
      personal.tab,
      personal.tabText,
      review.tab,
      review.tabText,
    ],
  );

  return useMemo(() => {
    if (isAuthenticated) {
      return steppersProps.map((val) => (
        <Stepper
          key={val.text}
          text={val.text}
          icon={val.icon}
          clickHandler={val.clickHandler}
          className={val.className}
          tabClassName={val.tabClassName}
          textClassName={val.textClassName}
        />
      ));
    }

    return '';
  }, [isAuthenticated, steppersProps]);
};

export default useSteppers;
