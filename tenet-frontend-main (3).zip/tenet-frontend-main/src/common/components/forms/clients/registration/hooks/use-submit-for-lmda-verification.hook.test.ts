import '@testing-library/jest-dom';
import { renderHook } from '@testing-library/react';
import RootStore from '../../../../../../stores/root.store';
import * as hooks from '../../../../../../hooks/use-store.hook';
import useCompleteClientRegistration from './use-submit-for-lmda-verification.hook';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}));

describe('useCompleteClientRegistration', () => {
  const mockStore = {
    clientFormStore: {
      id: 'test-client-id',
      updateClient: jest.fn(),
      loadClient: jest.fn(),
    },
    clientFormStepperStore: { setCompletedSteps: jest.fn() },
    clientsStore: {
      selectedClient: { id: 'mock-id', firstName: 'Simpson', lastName: 'Jay' },
    },
    clientFilesStore: { uploadClientDocuments: jest.fn() },
  } as unknown as RootStore;

  beforeEach(() => {
    jest.spyOn(hooks, 'useStore').mockReturnValue(mockStore);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('should return correct value types', () => {
    const { result } = renderHook(() => useCompleteClientRegistration());

    expect(result.current.submitHandler).toBeInstanceOf(Function);
    expect(result.current.loading).toBeFalsy();
  });
});
