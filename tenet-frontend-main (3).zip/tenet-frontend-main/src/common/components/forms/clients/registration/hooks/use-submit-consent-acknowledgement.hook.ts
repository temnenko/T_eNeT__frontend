/* eslint-disable no-nested-ternary */
import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';

import { useStore } from '../../../../../../hooks/use-store.hook';
import { useNavigateStepper } from './use-navigate-steppers.hook';
import useLoadClient from './use-load-client';
import { ClientFormStepperKeys } from '../../../../../../types/client-forms';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';
import { toIsoFormat } from '../../../../../../utils/date.util';

export type ConsentFormData = {
  foipConsentedAt?: string;
  wcbAcknowledgedAt?: string;
};

type FormFieldName = 'foipConsentedAt' | 'wcbAcknowledgedAt';

const useSubmitConsentAcknowledgement = (clientId?: string) => {
  const {
    clientFormStore: { watchClient, retrieveClient, updateClient },
    clientsStore: { selectedClient },
    permissionStore: { canEditClientInProgress },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();

  const { goToNextStep, goToPreviousStep, setActiveStep } = useNavigateStepper();

  const { client } = useLoadClient(clientId) ?? { client: selectedClient };

  const {
    getValues,
    handleSubmit,
    register,
    reset,
    setValue,
    formState: { errors },
  } = useForm<ConsentFormData>({
    defaultValues: {
      foipConsentedAt: client?.foipConsentedAt
        ? toIsoFormat(client.foipConsentedAt)
        : retrieveClient('foipConsentedAt'),
      wcbAcknowledgedAt: client?.wcbAcknowledgedAt
        ? toIsoFormat(client.wcbAcknowledgedAt)
        : retrieveClient('wcbAcknowledgedAt'),
    },
  });

  const { name: foipConsentedAt } = register('foipConsentedAt', {
    required: { value: true, message: 'FOIP consent date required.' },
  });
  const { name: wcbAcknowledgedAt } = register('wcbAcknowledgedAt', {
    required: { value: true, message: 'WCB acknowledged date required.' },
  });

  const formFields = {
    foipConsentedAt,
    wcbAcknowledgedAt,
  };

  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  useEffect(() => {
    setActiveStep(ClientFormStepperKeys.CONSENT);
    reset({
      foipConsentedAt: client?.foipConsentedAt
        ? toIsoFormat(new Date(client.foipConsentedAt))
        : retrieveClient(foipConsentedAt),
      wcbAcknowledgedAt: client?.wcbAcknowledgedAt
        ? toIsoFormat(new Date(client.wcbAcknowledgedAt))
        : retrieveClient(wcbAcknowledgedAt),
    });
  }, [client, foipConsentedAt, reset, retrieveClient, setActiveStep, setValue, wcbAcknowledgedAt]);

  const addSubmitHandler = useCallback(async () => {
    const { foipConsentedAt: consentedAt, wcbAcknowledgedAt: acknowledgedAt } = getValues();

    try {
      setRequestError({});
      setLoading(true);

      await updateClient({
        foipConsentedAt: consentedAt ? new Date(consentedAt).toISOString() : undefined,
        wcbAcknowledgedAt: acknowledgedAt ? new Date(acknowledgedAt).toISOString() : undefined,
      });

      reset();
      goToNextStep(client!.id);
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [updateClient, getValues, reset, goToNextStep, client, requestErrorHandler]);

  const useUpdateSubmitHandler = (closeModal: () => void) =>
    useCallback(async () => {
      const { foipConsentedAt: consentedAt, wcbAcknowledgedAt: acknowledgedAt } = getValues();

      try {
        setRequestError({});
        setLoading(true);

        await updateClient(
          {
            foipConsentedAt: consentedAt ? new Date(consentedAt).toISOString() : undefined,
            wcbAcknowledgedAt: acknowledgedAt ? new Date(acknowledgedAt).toISOString() : undefined,
          },
          selectedClient?.id,
        );
      } catch (e) {
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
        // eslint-disable-next-line no-console
        console.error(e);
      } finally {
        setLoading(false);
        closeModal();
      }
    }, [closeModal]);

  const previousButtonClickHandler = useCallback(() => {
    goToPreviousStep(client!.id);
  }, [client, goToPreviousStep]);

  const onChangeHandler = useCallback(
    (name: string, value: string | undefined) => {
      setValue(name as FormFieldName, value);
      watchClient(name, value);
    },
    [setValue, watchClient],
  );

  return {
    loading,
    requestError,
    formFields,
    getValues,
    addSubmitHandler,
    onChangeHandler,
    handleSubmit,
    previousButtonClickHandler,
    errors,
    client,
    useUpdateSubmitHandler,
    canEditClientInProgress,
  };
};

export default useSubmitConsentAcknowledgement;
