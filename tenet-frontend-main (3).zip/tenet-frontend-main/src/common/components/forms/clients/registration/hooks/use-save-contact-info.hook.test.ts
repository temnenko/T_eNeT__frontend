/* eslint-disable prettier/prettier */
import { act, renderHook } from '@testing-library/react';
import { useForm } from 'react-hook-form';
import * as reactHookForm from 'react-hook-form';
import useSaveEmailPhone from './use-save-contact-info.hook';
import * as stepperNavigationHook from './use-navigate-steppers.hook';

jest.mock('react-hook-form', () => ({
  ...jest.requireActual('react-hook-form'),
  useForm: jest.fn(),
}));

describe('useSaveContactInfo', () => {
  const mockForm = {
    register: jest.fn().mockImplementation(() => ({ name: 'testName' })),
    unregister: jest.fn(),
    getValues: jest.fn(),
    handleSubmit: jest.fn(),
    setValue: jest.fn(),
    reset: jest.fn(),
    formState: { errors: {} },
  } as unknown as ReturnType<typeof useForm>;

  const mockStepperNavigationHook = {
    goToNextStep: jest.fn(),
    goToPreviousStep: jest.fn(),
    setActiveStep: jest.fn(),
    jumpToStep: jest.fn(),
  };

  beforeEach(() => {
    jest.spyOn(reactHookForm, 'useForm').mockImplementation(() => mockForm);
    jest.spyOn(stepperNavigationHook, 'useNavigateStepper').mockImplementation(() => mockStepperNavigationHook);
  });

  it('initializes with default state', () => {
    const { result } = renderHook(() => useSaveEmailPhone(mockForm.unregister, () => {}));

    expect(result.current.phoneFields).toEqual([{ id: '0', value: '' }]);
    expect(result.current.emailFields).toEqual([{ id: '0', value: '' }]);
    expect(result.current.isEmailDisabled).toBe(false);
  });

  it('adds a phone field', () => {
    const { result } = renderHook(() => useSaveEmailPhone(mockForm.unregister, () => {}));

    act(() => {
      result.current.handleAddPhoneField();
    });

    expect(result.current.phoneFields.length).toBe(2);
  });

  it('adds an email field', () => {
    const { result } = renderHook(() => useSaveEmailPhone(mockForm.unregister, () => {}));

    act(() => {
      result.current.handleAddEmailField();
    });

    expect(result.current.emailFields.length).toBe(2);
  });

  it('updates a phone field value', () => {
    const { result } = renderHook(() => useSaveEmailPhone(mockForm.unregister, () => {}));

    act(() => {
      result.current.handlePhoneChange('0', '1234567890');
    });

    expect(result.current.phoneFields).toEqual([{ id: '0', value: '1234567890' }]);
  });

  it('updates an email field value', () => {
    const { result } = renderHook(() => useSaveEmailPhone(mockForm.unregister, () => {}));

    act(() => {
      result.current.handleEmailChange('0', 'test@example.com');
    });

    expect(result.current.emailFields).toEqual([{ id: '0', value: 'test@example.com' }]);
  });

  it('toggles isEmailDisabled when not disabled by emailFields values', () => {
    const { result } = renderHook(() => useSaveEmailPhone(mockForm.unregister, () => {}));

    act(() => {
      result.current.handleCheckboxChange('testCheck', true);
    });

    expect(result.current.isEmailDisabled).toBe(true);
  });

  it('does not toggle isEmailDisabled when isCheckboxDisabled is true', () => {
    const { result } = renderHook(() => useSaveEmailPhone(mockForm.unregister, () => {}));

    // Manually simulate a state where isCheckboxDisabled should be true
    act(() => {
      result.current.handleEmailChange('0', 'test@example.com');
    });

    act(() => {
      result.current.handleCheckboxChange('testCheck', false);
    });

    expect(result.current.isEmailDisabled).toBe(false); // Assumes initial state is false and remains unchanged
  });

  it('submits phone and email fields', () => {
    const { result } = renderHook(() => useSaveEmailPhone(mockForm.unregister, () => {}));

    act(() => {
      result.current.handleAddPhoneField();
      result.current.handlePhoneChange('0', '1234567890');
      result.current.handlePhoneChange('1', '0987654321');
      result.current.handleAddEmailField();
      result.current.handleEmailChange('0', 'test@example.com');
      result.current.handleEmailChange('1', 'example@test.com');
    });

    act(() => {
      result.current.getPhonesAndEmails();
    });
  });
});
