import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { useStore } from '../../../../../../hooks/use-store.hook';
import useLoadClient from './use-load-client';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';

const useCompleteClientRegistration = () => {
  const {
    clientFormStore: { updateClient },
    clientFilesStore: { uploadClientDocuments },
  } = useStore();
  const navigate = useNavigate();
  const requestErrorHandler = useRequestErrorHandler();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<RequestError>({});

  const { client } = useLoadClient();

  const submitHandler = useCallback(async () => {
    try {
      setError({});
      setLoading(true);

      if (client && client.id) {
        await uploadClientDocuments(client!.id);
        await updateClient({
          creationCompleted: true,
        });

        navigate(`/clients/${client.id}/overview`);
      }
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError,
      });
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [client, navigate, requestErrorHandler, updateClient, uploadClientDocuments]);

  return {
    loading,
    error,
    submitHandler,
  };
};

export default useCompleteClientRegistration;
