/* eslint-disable no-nested-ternary */
import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoACheckbox,
  GoADropdown,
  GoADropdownItem,
  GoAFormItem,
  GoAGrid,
  GoAInput,
  GoANotification,
  GoARadioGroup,
  GoARadioItem,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { subYears } from 'date-fns';

import useSubmitPersonalDetails from './hooks/use-submit-personal-details.hook';
import { Language } from '../../../../../types/client';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import { toIsoFormat } from '../../../../../utils/date.util';

interface Props {
  isModal?: boolean;
  clientId?: string;
  setClientUpdated?: (value: string) => void;
  hideModal?: () => void;
}

export const PersonalDetailsForm = observer(({ isModal, clientId, setClientUpdated, hideModal }: Props) => {
  const {
    loading,
    requestError,
    formFields,
    getValues,
    clientSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    onNameTypeChangeHandler,
    modalContent,
    modalVisible,
    isTempSin,
    hasOpenWorkPermit,
    validateSIN,
    canEditClientInProgress,
    canCreateNewClient,
    client,
  } = useSubmitPersonalDetails(!!isModal, hideModal, clientId, setClientUpdated);
  const {
    language,
    firstName,
    middleName,
    lastName,
    nameType,
    prevFirstName,
    prevMiddleName,
    prevLastName,
    sin,
    isOpenWorkPermit,
    sinExpiryDate,
    workPermitExpiryDate,
    dateOfBirth,
  } = formFields;

  const nextButton = (
    <GoAButton
      disabled={loading}
      type="submit"
      onClick={handleSubmit(clientSubmitHandler)}
      trailingIcon={loading ? undefined : 'arrow-forward'}
    >
      {loading ? (
        <InlineLoadingIndicator label="Saving changes..." />
      ) : (
        <>
          <span className="client-bold-600">Next:</span> Demographics
        </>
      )}
    </GoAButton>
  );

  return (
    <>
      {modalVisible && modalContent}
      <form className="create-client-form">
        <GoABlock direction="column">
          <h4 className="client-no-padding-no-margin">{`Applicant's preferred official language:`}</h4>
          <span>
            {`This information is required to meet the federal government's requirements under the Official Languages Act.
            It is mandatory that this data be reported for all LMTA participants.`}
          </span>
          <GoAFormItem error={errors[language]?.message as unknown as string}>
            <GoARadioGroup name={language} value={getValues(language)} onChange={onChangeHandler}>
              <GoARadioItem value={Language.EN} label="English" />
              <GoARadioItem value={Language.FR} label="French" />
              <GoARadioItem value={Language.BOTH} label="Both" />
            </GoARadioGroup>
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="l" />
        <GoABlock direction="column" gap="xs">
          <h4 className="client-no-padding-no-margin">{`Applicant's legal name`}</h4>
          <span>{`The applicant's full name as shown on their legal documents such as driver's license, passport etc.`}</span>
          <GoAGrid minChildWidth="167px">
            <GoAFormItem label="First name" error={errors[firstName]?.message as unknown as string}>
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={firstName}
                id={firstName}
                value={getValues(firstName)}
                width="167px"
              />
            </GoAFormItem>
            <GoAFormItem
              label="Middle name"
              requirement="optional"
              error={errors[middleName]?.message as unknown as string}
            >
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={middleName}
                id={middleName}
                value={getValues(middleName)}
                width="167px"
              />
            </GoAFormItem>
            <GoAFormItem label="Last name" error={errors[lastName]?.message as unknown as string}>
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={lastName}
                id={lastName}
                value={getValues(lastName)}
                width="167px"
              />
            </GoAFormItem>
          </GoAGrid>
        </GoABlock>
        <GoASpacer vSpacing="l" />
        <GoABlock direction="column" gap="xs">
          <GoABlock gap="xs">
            <h4 className="client-no-padding-no-margin">Has the applicant used any other name?</h4>
            <span className="client-small-faint-text">(optional)</span>
          </GoABlock>
          <span>{`The applicant's alias, nickname, previously married, etc. Full name as shown on their legal documents such as driver's license, passport etc.`}</span>
          <GoAGrid minChildWidth="161px">
            <GoAFormItem label="Name type">
              <GoADropdown
                name={nameType}
                onChange={onNameTypeChangeHandler}
                width="161px"
                value={getValues(nameType)}
                relative
              >
                <GoADropdownItem value="" label="--Select--" />
                <GoADropdownItem value="PREFERRED_NAME" label="Preferred name" />
                <GoADropdownItem value="MAIDEN_NAME" label="Maiden name" />
                <GoADropdownItem value="PREVIOUS_NAME" label="Previous name" />
                <GoADropdownItem value="ALIAS" label="Alias" />
              </GoADropdown>
            </GoAFormItem>
            <GoAFormItem label="First name" error={errors[prevFirstName]?.message as unknown as string}>
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={prevFirstName}
                id={prevFirstName}
                value={getValues(prevFirstName)}
                width="161px"
              />
            </GoAFormItem>
            <GoAFormItem label="Middle name" error={errors[prevMiddleName]?.message as unknown as string}>
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={prevMiddleName}
                id={prevMiddleName}
                value={getValues(prevMiddleName)}
                width="161px"
              />
            </GoAFormItem>
            <GoAFormItem label="Last name" error={errors[prevLastName]?.message as unknown as string}>
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={prevLastName}
                id={prevLastName}
                value={getValues(prevLastName)}
                width="161px"
              />
            </GoAFormItem>
          </GoAGrid>
        </GoABlock>
        <GoASpacer vSpacing="l" />
        <GoABlock direction="column">
          <h4 className="client-no-padding-no-margin">{`Applicant's Date of Birth (DOB)`}</h4>
          <GoAFormItem error={errors[dateOfBirth]?.message as unknown as string}>
            <GoABlock>
              <GoAInput
                type="date"
                onChange={onChangeHandler}
                min={toIsoFormat(subYears(new Date(), 100))}
                max={toIsoFormat(new Date())}
                name={dateOfBirth}
                value={getValues(dateOfBirth) ? toIsoFormat(getValues(dateOfBirth)!) : undefined}
              />
            </GoABlock>
          </GoAFormItem>
        </GoABlock>
        <GoASpacer vSpacing="l" />
        <GoAFormItem
          label={`Applicant's Social Insurance Number (SIN)`}
          error={errors[sin]?.message as unknown as string}
        >
          <GoAInput
            type="text"
            onChange={onChangeHandler}
            name={sin}
            id={sin}
            value={getValues(sin)}
            width="398px"
            onBlur={validateSIN}
            onKeyPress={onChangeHandler}
          />
        </GoAFormItem>
        {isTempSin && (
          <>
            <GoASpacer vSpacing="l" />
            <GoAFormItem label="SIN Expiry date" error={errors[sinExpiryDate]?.message as unknown as string}>
              <GoAInput
                type="date"
                onChange={onChangeHandler}
                name={sinExpiryDate}
                value={getValues(sinExpiryDate) ? toIsoFormat(getValues(sinExpiryDate)!) : undefined}
                min="0000-01-01"
                max="9999-12-31"
              />
            </GoAFormItem>
            <GoASpacer vSpacing="l" />
            {!hasOpenWorkPermit && (
              <GoAFormItem
                label="Open work permit expiry date"
                error={errors[workPermitExpiryDate]?.message as unknown as string}
              >
                <GoAInput
                  type="date"
                  onChange={onChangeHandler}
                  name={workPermitExpiryDate}
                  value={getValues(workPermitExpiryDate) ? toIsoFormat(getValues(workPermitExpiryDate)!) : undefined}
                  min="0000-01-01"
                  max="9999-12-31"
                />
              </GoAFormItem>
            )}
            <GoASpacer vSpacing="s" />
            <GoACheckbox
              name={isOpenWorkPermit}
              text="Applicant does not have an open work permit"
              onChange={onChangeHandler}
              checked={getValues(isOpenWorkPermit)}
            />
          </>
        )}
        <GoASpacer vSpacing="xl" />
        {requestError?.message && (
          <>
            <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
              {requestError.message}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
        {isModal ? (
          <GoAButtonGroup alignment="end">
            <GoAButton type="secondary" onClick={hideModal}>
              Cancel
            </GoAButton>
            <GoAButton onClick={handleSubmit(clientSubmitHandler)}>Save</GoAButton>
          </GoAButtonGroup>
        ) : client ? (
          canEditClientInProgress(client) && nextButton
        ) : (
          canCreateNewClient && nextButton
        )}
        <GoASpacer vSpacing="2xl" />
      </form>
    </>
  );
});

export default PersonalDetailsForm;
