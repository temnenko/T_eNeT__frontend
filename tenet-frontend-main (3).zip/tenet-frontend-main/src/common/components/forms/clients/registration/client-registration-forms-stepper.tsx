import { observer } from 'mobx-react-lite';

import useSteppers from './hooks/use-steppers.hook';

export const ClientRegistrationFormsStepper = observer(() => {
  const steppers = useSteppers();

  return (
    <ul className="tabs" role="tablist">
      {steppers}
    </ul>
  );
});
