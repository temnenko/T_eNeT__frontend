import {
  GoABlock,
  GoAButton,
  GoACallout,
  GoACheckbox,
  GoAFormItem,
  GoAIconButton,
  GoAInput,
  GoANotification,
  GoARadioGroup,
  GoARadioItem,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useSaveAddresses from '../hooks/use-save-addresses.hook';
import { AddressFields, AddressOnChangeHandler } from '../../../fields/address-fields';
import InlineLoadingIndicator from '../../../inline-loading-indicator';
import { AddressType } from '../../../../../../types/client';
import { useFormatPhoneInput } from '../../../../../../hooks/use-format-phone-input.hook';
import { isPhoneNumberComplete } from '../../../../../../utils/phone.util';

export const ContactDetailsForm = observer(() => {
  const {
    loading,
    requestError,
    register,
    clientAddressesSaveHandler,
    handleSubmit,
    formFields,
    getValues: rawGetValues,
    watch,
    errors,
    onChangeHandler,
    isSameAsMailingAddress,
    previousButtonClickHandler,
    handleToggleSameAsMailingAddress,
    onBlurHandler,
    onSelectAddress,
    setAddressStreetField,
    phoneFields,
    emailFields,
    isValidEmail,
    handleAddPhoneField,
    handleAddEmailField,
    handlePhoneChange,
    handleEmailChange,
    handleCheckboxChange,
    handleNoPhonesCheckboxChange,
    handleRemovePhoneField,
    handleRemoveEmailField,
    canEditClientInProgress,
    client,
  } = useSaveAddresses();
  const formatPhoneInput = useFormatPhoneInput();

  const getValues = (name: string): string => {
    const value = rawGetValues(name);
    return value ? value.toString() : '';
  };

  return (
    <form className="client-contact-form">
      <GoABlock direction="column">
        <div className="address-section-heading">Mailing address</div>
        <AddressFields
          fields={{
            streetAddress: formFields.mailingStreetAddress,
            unit: formFields.mailingUnit,
            city: formFields.mailingCity,
            province: formFields.mailingProvince,
            postalCode: formFields.mailingPostalCode,
            country: formFields.mailingCountry,
            addressType: AddressType.MAILING,
          }}
          onChangeHandler={onChangeHandler as AddressOnChangeHandler}
          getValues={getValues}
          errors={errors}
          onBlurHandler={onBlurHandler}
          onSelectAddress={onSelectAddress}
          setAddressStreetField={setAddressStreetField}
        />
        <GoASpacer vSpacing="m" />
        <div className="address-section-heading">Residential address</div>
        <GoAFormItem label="Is the residential address the same as mailing address?" labelSize="regular">
          <GoARadioGroup
            name="sameAsMailingAddress"
            value={isSameAsMailingAddress ? '1' : '2'}
            onChange={handleToggleSameAsMailingAddress}
          >
            <GoARadioItem value="1" label="Yes" />
            <GoARadioItem value="2" label="No" />
          </GoARadioGroup>
        </GoAFormItem>
        {!isSameAsMailingAddress && (
          <AddressFields
            fields={{
              streetAddress: formFields.residentialStreetAddress,
              unit: formFields.residentialUnit,
              city: formFields.residentialCity,
              province: formFields.residentialProvince,
              postalCode: formFields.residentialPostalCode,
              country: formFields.residentialCountry,
              addressType: AddressType.RESIDENTIAL,
            }}
            onChangeHandler={onChangeHandler as AddressOnChangeHandler}
            getValues={getValues}
            errors={errors}
            onBlurHandler={onBlurHandler}
            onSelectAddress={onSelectAddress}
            setAddressStreetField={setAddressStreetField}
          />
        )}
        <GoASpacer vSpacing="m" />
        <div className="address-section-heading">Phone Number</div>
        {phoneFields.length === 0 && (
          <GoACallout type="information">
            phone number is an essential contract method for people looking for work. Discuss at assessment.
          </GoACallout>
        )}
        {phoneFields.map((field, index) => {
          const { name } = register(`phone-${field.id}`, {
            value: formatPhoneInput(field.value),
            required: 'If the applicant does not have a phone number, please indicate',
            pattern: {
              value: /^\(?\d{3}\)?([\s])?\d{3}([-])?\d{4}$/,
              message: 'Invalid Canadian phone number',
            },
          });
          return (
            <GoAFormItem key={field.id} label="Applicant's phone number" error={errors && errors[name]?.message}>
              <div className="d-flex">
                <GoAInput
                  type="tel"
                  name={name}
                  value={formatPhoneInput(watch(name))}
                  onChange={(_name, val) => {
                    handlePhoneChange(field.id, val);
                    onChangeHandler(_name, val);
                  }}
                  leadingContent="+1"
                  trailingIcon={isPhoneNumberComplete(field.value) ? 'checkmark-done' : undefined}
                />
                {!!index && (
                  <GoAIconButton
                    variant="color"
                    size="medium"
                    icon="trash"
                    onClick={() => handleRemovePhoneField(field.id)}
                  />
                )}
              </div>
            </GoAFormItem>
          );
        })}
        <GoAButton type="tertiary" leadingIcon="add" onClick={handleAddPhoneField} disabled={phoneFields.length >= 3}>
          Add another phone number
        </GoAButton>

        <GoAFormItem>
          <GoACheckbox
            name="no-phone"
            text="Check this box if the applicant doesn't have a phone number"
            onChange={handleNoPhonesCheckboxChange}
            checked={phoneFields.length === 0}
            disabled={phoneFields.length === 0}
          />
        </GoAFormItem>

        <GoASpacer vSpacing="m" />
        <div className="address-section-heading">Email</div>
        {emailFields.map((field, index) => {
          const { name } = register(`email-${field.id}`, {
            value: field.value,
            required: 'If the applicant does not have an email address, please indicate',
            pattern: {
              value: /^[^\s@<>&]+@[^\s@<>&]+\.[^\s@<>&]+$/,
              message: 'The Email Address does not conform to the email address format standards',
            },
            maxLength: { value: 255, message: 'Email address must be less than 255 characters' },
            minLength: { value: 6, message: 'Email address must be at least 6 characters' },
          });
          return (
            <GoAFormItem key={field.id} label="Applicant's email address" error={errors[name]?.message}>
              <div className="d-flex">
                <GoAInput
                  type="email"
                  onChange={(_name, val) => {
                    handleEmailChange(field.id, val);
                    onChangeHandler(_name, val);
                  }}
                  value={getValues(name)}
                  name={name}
                  trailingIcon={isValidEmail(field.value) ? 'checkmark-done' : undefined}
                />
                {!!index && (
                  <GoAIconButton
                    variant="color"
                    size="medium"
                    icon="trash"
                    onClick={() => handleRemoveEmailField(field.id)}
                  />
                )}
              </div>
            </GoAFormItem>
          );
        })}
        <GoAButton type="tertiary" leadingIcon="add" onClick={handleAddEmailField} disabled={emailFields.length >= 3}>
          Add another email
        </GoAButton>
        <GoAFormItem>
          <GoACheckbox
            name="no-email"
            text="Check this box if the applicant doesn't have an email"
            onChange={handleCheckboxChange}
            checked={emailFields.length === 0}
            disabled={emailFields.length === 0}
          />
        </GoAFormItem>
        <GoASpacer vSpacing="l" />
      </GoABlock>
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {client && canEditClientInProgress(client) && (
        <GoABlock>
          <div className="contact-details-form-buttons client-demographic-prev-next">
            <GoAButton
              type="secondary"
              leadingIcon="arrow-back"
              disabled={loading}
              onClick={() => {
                previousButtonClickHandler();
              }}
            >
              <span>Previous:</span> Demographic
            </GoAButton>
            <GoAButton
              type="submit"
              disabled={loading}
              onClick={handleSubmit(clientAddressesSaveHandler)}
              trailingIcon="arrow-forward"
            >
              {loading ? (
                <InlineLoadingIndicator label="Saving changes..." />
              ) : (
                <>
                  <span className="client-bold-600">Next:</span> Factors
                </>
              )}
            </GoAButton>
          </div>
        </GoABlock>
      )}

      <GoASpacer vSpacing="2xl" />
    </form>
  );
});

export default ContactDetailsForm;
