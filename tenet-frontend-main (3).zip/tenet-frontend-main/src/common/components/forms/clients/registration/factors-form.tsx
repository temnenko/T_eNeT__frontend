import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoACallout,
  GoAFormItem,
  GoAInput,
  GoANotification,
  GoARadioGroup,
  GoARadioItem,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import useSubmitFactors from './hooks/use-submit-factors.hook';
import { FactorValues, IndigenousTypes } from '../../../../../types/client-forms';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import { IndigenousTypeDetails } from './details/indigenous-type.details';

interface Props {
  isUpdate?: boolean;
  clientId?: string;
  setClientUpdated?: (value: string) => void;
  hideModal?: () => void;
}

export const FactorsForm = observer(({ isUpdate, clientId, setClientUpdated, hideModal }: Props) => {
  const {
    requestError,
    loading,
    isImmigrant,
    formFields,
    getValues,
    factorsSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    previousButtonClickHandler,
    modalVisible,
    modalContent,
    isIndigenous,
    canEditClientInProgress,
    client,
  } = useSubmitFactors(!!isUpdate, hideModal, clientId, setClientUpdated);
  const { disability, indigenous, indigenousType, immigrant, yearOfLanding, visibleMinority } = formFields;

  return (
    <>
      {modalVisible && modalContent}
      <div className={isUpdate ? 'relative' : ''}>
        <form className={isUpdate ? 'form-modal form-modal-margin' : 'create-client-form'}>
          <GoACallout type="information" size="medium" heading="Self-declared responses">
            <span>
              {`The following questions collect the applicant's self-declared response indicating how they identify with
            their disability, indigenous, immigration and visible minority status.`}
            </span>
          </GoACallout>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Does the applicant identify as a person with a disability?</h4>
            <span>
              A disability refers to a physical mental sensory, intellectual or learning impairment which, in
              interaction with various barriers, may hinder labour market participant. Individuals may self identify as
              a person with a disability. No medical evidence is required.
            </span>
            <GoAFormItem error={errors[disability]?.message as unknown as string}>
              <GoARadioGroup name={disability} value={getValues(disability)} onChange={onChangeHandler}>
                <GoARadioItem value={FactorValues.YES} label="Yes" />
                <GoARadioItem value={FactorValues.NO} label="No" />
                <GoARadioItem value={FactorValues.PREFER_NOT_TO_REPORT} label="Prefer not to report" />
              </GoARadioGroup>
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Does the applicant identify as being Indigenous?</h4>
            <span>
              Indigenous identity refers to whether a person reports being an Indigenous person that is First Nation
              (North American Indian), Métis, or Inuk (Inuit) and/or being a Registered or Treaty and/or being a member
              of a First Nation or Indian Band.
            </span>
            <GoAFormItem error={errors[indigenous]?.message as unknown as string}>
              <GoARadioGroup name={indigenous} value={getValues(indigenous)} onChange={onChangeHandler}>
                <GoARadioItem value={FactorValues.YES} label="Yes" />
                <GoARadioItem value={FactorValues.NO} label="No" />
                <GoARadioItem value={FactorValues.PREFER_NOT_TO_REPORT} label="Prefer not to report" />
              </GoARadioGroup>
            </GoAFormItem>
          </GoABlock>
          {isIndigenous && (
            <>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Indigenous type:</h4>
                <GoAFormItem error={errors[indigenousType]?.message as unknown as string}>
                  <GoARadioGroup name={indigenousType} value={getValues(indigenousType)} onChange={onChangeHandler}>
                    <GoARadioItem value={IndigenousTypes.STATUS} label="Status" />
                    <GoARadioItem value={IndigenousTypes.NON_STATUS} label="Non-Status" />
                    <GoARadioItem value={IndigenousTypes.METIS} label="Métis" />
                    <GoARadioItem value={IndigenousTypes.INUIT} label="Inuit" />
                  </GoARadioGroup>
                  <IndigenousTypeDetails />
                </GoAFormItem>
              </GoABlock>
            </>
          )}
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Does the applicant identify as being an immigrant?</h4>
            <span>
              An immigrant is a person, who is or has been a landed immigrant in Canada (i.e. permanent resident). A
              landed immigrant is a person who has been granted the right to live in Canada permanently by immigration
              authorities.
            </span>
            <GoAFormItem error={errors[immigrant]?.message as unknown as string}>
              <GoARadioGroup name={immigrant} value={getValues(immigrant)} onChange={onChangeHandler}>
                <GoARadioItem value={FactorValues.YES} label="Yes" />
                <GoARadioItem value={FactorValues.NO} label="No" />
              </GoARadioGroup>
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          {isImmigrant && (
            <>
              <GoABlock direction="column">
                <h4 className="client-no-padding-no-margin">Year of landing</h4>
                <span>
                  The year in which the final interview with an immigration officer occurred at either the port of entry
                  or a local IRCC office within Canada, during which an applicant becomes a permanent resident.
                  Approximate year is acceptable.
                </span>
                <GoAFormItem error={errors[yearOfLanding]?.message as unknown as string}>
                  <GoAInput
                    type="number"
                    onChange={onChangeHandler}
                    name={yearOfLanding}
                    id={yearOfLanding}
                    value={getValues(yearOfLanding)}
                    width="315px"
                    placeholder="YYYY"
                    max={new Date().getUTCFullYear()}
                    maxLength={4}
                  />
                </GoAFormItem>
              </GoABlock>
              <GoASpacer vSpacing="l" />
            </>
          )}
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">
              Does the applicant consider themselves to be a visible minority?
            </h4>
            <span>
              A visible minority refers to whether a person self-identifies as belonging to a visible minority group as
              defined by the Employment Equity Act. The LMTA performance measurement defines visible minorities as
              persons, other than Indigenous, who are non-Caucasian.
            </span>
            <GoAFormItem error={errors[visibleMinority]?.message as unknown as string}>
              <GoARadioGroup name={visibleMinority} value={getValues(visibleMinority)} onChange={onChangeHandler}>
                <GoARadioItem value={FactorValues.YES} label="Yes" />
                <GoARadioItem value={FactorValues.NO} label="No" />
                <GoARadioItem value={FactorValues.PREFER_NOT_TO_REPORT} label="Prefer not to report" />
              </GoARadioGroup>
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="xl" />
          {requestError?.message && (
            <>
              <GoANotification type="emergency">{requestError.message}</GoANotification>
              <GoASpacer vSpacing="s" />
            </>
          )}
          {client && canEditClientInProgress(client) && (
            <div>
              {isUpdate ? (
                <GoAButtonGroup alignment="end">
                  <GoAButton type="secondary" onClick={hideModal}>
                    Cancel
                  </GoAButton>
                  <GoAButton onClick={handleSubmit(factorsSubmitHandler)}>Save</GoAButton>
                </GoAButtonGroup>
              ) : (
                <div className="row-space-between client-demographic-prev-next">
                  <GoAButton
                    disabled={loading}
                    type="secondary"
                    onClick={() => previousButtonClickHandler()}
                    leadingIcon="arrow-back"
                  >
                    <span className="client-bold-600">Previous:</span> Contact information
                  </GoAButton>
                  <GoAButton
                    disabled={loading}
                    type="submit"
                    onClick={handleSubmit(factorsSubmitHandler)}
                    trailingIcon={loading ? undefined : 'arrow-forward'}
                  >
                    {loading ? (
                      <InlineLoadingIndicator label="Saving changes..." />
                    ) : (
                      <>
                        <span className="client-bold-600">Next:</span> Client consent
                      </>
                    )}
                  </GoAButton>
                </div>
              )}
            </div>
          )}
          <GoASpacer vSpacing="2xl" />
        </form>
      </div>
    </>
  );
});

export default FactorsForm;
