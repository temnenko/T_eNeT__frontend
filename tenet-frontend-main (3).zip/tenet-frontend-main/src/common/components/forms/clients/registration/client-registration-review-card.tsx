import { GoABlock, GoAContainer, GoAGrid } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useActionButton from '../../../../../hooks/use-action-button.hook';

type Props = {
  title: string;
  data: {
    label: string;
    value?: string;
  }[];
  additionalData?: {
    label: string;
    value?: string;
  }[];
  editDisabled: boolean;
  action: () => void;
};

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const ClientRegistrationReviewCard = observer(({ title, data, additionalData = [], editDisabled, action }: Props) => {
  const actions = useActionButton(action);
  return (
    <div className="client-review-card">
      <GoAContainer heading={title} accent="thick" actions={actions} padding="compact">
        <GoABlock direction="column">
          {data &&
            data.map((entry) => {
              if (entry.label === 'Immigrant' && title === 'Factors' && additionalData?.length) {
                return (
                  <GoAGrid minChildWidth="300px" key={entry.label} gap="none">
                    <GoAGrid minChildWidth="150px" gap="none">
                      <div className="client-review-card-label">
                        <span className="color-interactive" key={entry.label}>
                          {entry.label}
                        </span>
                      </div>
                      <div className="client-review-card-value">
                        <span className="client-bold-600" key={entry.value}>
                          {entry.value}
                        </span>
                      </div>
                    </GoAGrid>
                    <GoAGrid minChildWidth="150px" gap="none">
                      <div className="client-review-card-label-yol">
                        <span className="color-interactive" key={additionalData[0]?.label}>
                          {additionalData[0]?.label}
                        </span>
                      </div>
                      <div>
                        <span className="client-bold-600" key={additionalData[0]?.value}>
                          {additionalData[0]?.value}
                        </span>
                      </div>
                    </GoAGrid>
                  </GoAGrid>
                );
              }
              return (
                <GoAGrid minChildWidth="150px" key={entry.label} gap="none">
                  <div className="client-review-card-label">
                    <span className="color-interactive">{entry.label}</span>
                  </div>
                  <div className="client-review-card-value">
                    <span className="client-bold-600">{entry.value}</span>
                  </div>
                </GoAGrid>
              );
            })}
        </GoABlock>
      </GoAContainer>
    </div>
  );
});

export default ClientRegistrationReviewCard;
