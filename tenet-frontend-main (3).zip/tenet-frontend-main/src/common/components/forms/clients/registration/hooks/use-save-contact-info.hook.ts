import { useState, useCallback } from 'react';
import { ContactStatus } from '../../../../../../types/client';

type EmailPhoneField = {
  id: string;
  value: string;
};
type Unregister = (args: string | string[]) => void;

const useSaveContactInfo = (unregister: Unregister, watchClient: <T>(field: string, value: T) => void) => {
  const [phoneFields, setPhoneFields] = useState<EmailPhoneField[]>([{ id: '0', value: '' }]);
  const [emailFields, setEmailFields] = useState<EmailPhoneField[]>([{ id: '0', value: '' }]);
  const [isEmailDisabled, setIsEmailDisabled] = useState(false);
  const [isPhoneDisabled, setIsPhoneDisabled] = useState(false);

  const handleCheckboxChange = useCallback(
    (_: string, checked: boolean) => {
      if (checked) {
        setIsEmailDisabled(true);
        emailFields.forEach(({ id }) => unregister(`email-${id}`));
        setEmailFields([]);

        watchClient('emailFields', []);
      } else {
        setIsEmailDisabled(false);
        setEmailFields([{ id: '0', value: '' }]);

        watchClient('emailFields', [{ id: '0', value: '' }]);
      }
    },
    [emailFields, unregister, watchClient],
  );

  const handleNoPhonesCheckboxChange = useCallback(
    (_: string, checked: boolean) => {
      if (checked) {
        setIsPhoneDisabled(true);
        phoneFields.forEach(({ id }) => unregister(`phone-${id}`));
        setPhoneFields([]);
        watchClient('phoneFields', []);
      } else {
        setIsPhoneDisabled(false);
        setPhoneFields([{ id: '0', value: '' }]);
        watchClient('phoneFields', [{ id: '0', value: '' }]);
      }
    },
    [phoneFields, unregister, watchClient],
  );

  const handleAddPhoneField = useCallback(() => {
    if (phoneFields.length < 3) {
      setPhoneFields((prev) => [...prev, { id: String(prev.length), value: '' }]);

      watchClient('phoneFields', phoneFields);
    }
  }, [phoneFields, watchClient]);

  const handleAddEmailField = useCallback(() => {
    if (emailFields.length < 3) {
      setEmailFields((prev) => [...prev, { id: String(prev.length), value: '' }]);

      watchClient('emailFields', emailFields);
    }
  }, [emailFields, watchClient]);

  const handlePhoneChange = useCallback(
    (id: string, value: string) => {
      setPhoneFields((prev) => prev.map((field) => (field.id === id ? { ...field, value } : field)));

      watchClient('phoneFields', phoneFields);
    },
    [phoneFields, watchClient],
  );

  const handleEmailChange = useCallback(
    (id: string, value: string) => {
      setEmailFields((prev) => prev.map((field) => (field.id === id ? { ...field, value } : field)));

      watchClient('emailFields', emailFields);
    },
    [emailFields, watchClient],
  );

  const handleRemovePhoneField = useCallback(
    (id: string) => {
      setPhoneFields((prev) => prev.filter((field) => field.id !== id));
      unregister(`phone-${id}`);

      watchClient(
        'phoneFields',
        phoneFields.filter((field) => field.id !== id),
      );
    },
    [phoneFields, unregister, watchClient],
  );

  const handleRemoveEmailField = useCallback(
    (id: string) => {
      setEmailFields((prev) => prev.filter((field) => field.id !== id));
      unregister(`email-${id}`);

      watchClient(
        'emailFields',
        emailFields.filter((field) => field.id !== id),
      );
    },
    [emailFields, unregister, watchClient],
  );

  const getPhonesAndEmails = useCallback(() => {
    const updatedPhoneNumbers = phoneFields.map((field) => {
      return { phoneNumber: field.value?.replace(/\D/g, '')?.trim(), status: ContactStatus.ACTIVE };
    });
    const updatedEmailAddresses = emailFields.map((field) => {
      return { emailAddress: field.value, status: ContactStatus.ACTIVE };
    });

    return {
      emails: updatedEmailAddresses,
      phones: updatedPhoneNumbers,
    };
  }, [emailFields, phoneFields]);

  const isValidEmail = useCallback((value: string) => {
    return /^[^\s@<>&]+@[^\s@<>&]+\.[^\s@<>&]+$/.test(value);
  }, []);

  return {
    phoneFields,
    emailFields,
    isEmailDisabled,
    isPhoneDisabled,
    isValidEmail,
    setPhoneFields,
    setEmailFields,
    handleAddPhoneField,
    handleAddEmailField,
    handlePhoneChange,
    handleEmailChange,
    handleCheckboxChange,
    handleNoPhonesCheckboxChange,
    getPhonesAndEmails,
    handleRemovePhoneField,
    handleRemoveEmailField,
  };
};

export default useSaveContactInfo;
