import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { ClientFormStepperKeys, clientFormStepperPaths } from '../../../../../../types/client-forms';

export const useNavigateStepper = () => {
  const navigate = useNavigate();
  const { clientFormStepperStore } = useStore();

  const setActiveStep = useCallback(
    (stepKey: ClientFormStepperKeys) => {
      clientFormStepperStore.setActiveStep(stepKey);
    },
    [clientFormStepperStore],
  );

  const goToNextStep = useCallback(
    (clientId: string) => {
      const nextStepKey = clientFormStepperStore.next();
      if (nextStepKey) {
        let nextStepPath = clientFormStepperPaths[nextStepKey];
        nextStepPath = nextStepPath.replace(':clientId', clientId);
        navigate(nextStepPath);
      }
    },
    [clientFormStepperStore, navigate],
  );

  const goToPreviousStep = useCallback(
    (clientId: string) => {
      const previousStepKey = clientFormStepperStore.previous();
      if (previousStepKey) {
        let previousStepPath = clientFormStepperPaths[previousStepKey];
        previousStepPath = previousStepPath.replace(':clientId', clientId);
        navigate(previousStepPath);
      }
    },
    [clientFormStepperStore, navigate],
  );

  const jumpToStep = useCallback(
    (stepKey: ClientFormStepperKeys, clientId: string) => {
      let stepPath = clientFormStepperPaths[stepKey];
      stepPath = stepPath.replace(':clientId', clientId);
      navigate(stepPath);
    },
    [navigate],
  );

  return { goToNextStep, goToPreviousStep, setActiveStep, jumpToStep };
};
