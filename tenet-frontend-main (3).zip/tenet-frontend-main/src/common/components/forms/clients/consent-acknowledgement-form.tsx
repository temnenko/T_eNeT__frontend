import { GoABlock, GoAButton, GoAFormItem, GoAInput, GoASpacer, GoAText } from '@abgov/react-components';
import { FieldErrors, UseFormGetValues } from 'react-hook-form';

import { ConsentFormData } from './registration/hooks/use-submit-consent-acknowledgement.hook';
import { toIsoFormat } from '../../../../utils/date.util';

type Props = {
  errors: FieldErrors<ConsentFormData>;
  onChangeHandler: (name: string, value: string | undefined) => void;
  getValues: UseFormGetValues<ConsentFormData>;
};

export function ConsentAcknowledgementForm({ errors, onChangeHandler, getValues }: Props) {
  return (
    <>
      <GoABlock direction="column">
        <GoAText maxWidth="598px" size="heading-m" mt="m" mb="m">
          Record of client agreement to personal information collection notice.
        </GoAText>
        <GoAText maxWidth="598px" size="body-m" mb="m">
          The following FOIP Collection Notice has been provided to and discussed with the applicant:
        </GoAText>
        <GoAText maxWidth="598px" size="body-m">
          “The personal information collected is for the purpose of registration and determining eligibility for
          government-funded training and employment programs in Alberta. Personal information is collected throughout
          the application process including the Training and Employment Services Request form.
        </GoAText>
        <GoAText maxWidth="598px" size="body-m">
          If you are deemed eligible, the personal information provided will be used and disclosed in the application
          process, for ongoing eligibility verification, the delivery of programs, benefits or services and to assess
          and evaluate the effectiveness of programs and services offered by the Government of Alberta.
        </GoAText>
        <GoAText maxWidth="598px" size="body-m">
          This collection is authorized by section 33(c) of the Freedom of Information and Protection of Privacy Act.”
        </GoAText>
        <GoAText maxWidth="598px" size="heading-s" mt="m" mb="s">
          The applicant has been provided with contact information should they have questions about the collection of
          personal information.
        </GoAText>
        <GoAText maxWidth="598px" size="body-m">
          Contact the Training and Employment Program Specialist:
        </GoAText>
        <GoAText maxWidth="624px" size="body-m">
          Email:{' '}
          <GoAButton
            type="tertiary"
            onClick={() => {
              window.location.href = 'mailto:JET.ProgramSpecialist@gov.ab.ca';
            }}
          >
            JET.ProgramSpecialist@gov.ab.ca
          </GoAButton>
        </GoAText>
        <GoAText maxWidth="624px" size="body-m" mb="m">
          Address: Training and Employment Services, 2nd Floor, 9925 109 St NW, Edmonton, AB T5J 3M9
        </GoAText>
        <GoAFormItem label="Consent given on" error={errors.foipConsentedAt?.message as unknown as string}>
          <GoABlock gap="s">
            <GoAInput
              type="date"
              onChange={onChangeHandler}
              name="foipConsentedAt"
              value={getValues('foipConsentedAt') ? toIsoFormat(getValues('foipConsentedAt')!) : undefined}
              min="0000-01-01"
              max="9999-12-31"
            />
            <GoAButton onClick={() => onChangeHandler('foipConsentedAt', toIsoFormat(new Date()))} type="tertiary">
              Today
            </GoAButton>
          </GoABlock>
        </GoAFormItem>
      </GoABlock>
      <GoASpacer vSpacing="l" />
      <GoABlock direction="column">
        <h4 className="client-no-padding-no-margin">WCB acknowledgement</h4>
        <span>
          {`The applicant understands that while they are registered and attending an employment and training program
          funded by the Government of Alberta (GOA), they are deemed to be a worker of the GOA for the sole purpose of
          receiving workers' compensation benefits under the Workers' Compensation Act.`}
        </span>
        <span>
          {`If injured in an accident, they will be entitled to claim workers' compensation benefits and have resigned
          their right to take legal action against the GOA, any other employer or worker covered by the Workers'
          Compensation Act.`}
        </span>
        <span>
          {`They further understand that they are not deemed a worker of the GOA while they are engaged in homework,
          study, or e-learning when outside of the training provider's institution/facility.`}
        </span>
        <GoAFormItem label="WCB acknowledged on" error={errors.wcbAcknowledgedAt?.message as unknown as string}>
          <GoABlock gap="s">
            <GoAInput
              type="date"
              onChange={onChangeHandler}
              name="wcbAcknowledgedAt"
              value={getValues('wcbAcknowledgedAt') ? toIsoFormat(getValues('wcbAcknowledgedAt')!) : undefined}
              min="0000-01-01"
              max="9999-12-31"
            />
            <GoAButton onClick={() => onChangeHandler('wcbAcknowledgedAt', toIsoFormat(new Date()))} type="tertiary">
              Today
            </GoAButton>
          </GoABlock>
        </GoAFormItem>
      </GoABlock>
    </>
  );
}
