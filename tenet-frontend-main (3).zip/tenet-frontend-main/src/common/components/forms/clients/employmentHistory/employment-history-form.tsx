import {
  GoABlock,
  GoASpacer,
  GoAFormItem,
  GoARadioGroup,
  GoARadioItem,
  GoAButton,
  GoAInput,
  GoAButtonGroup,
  GoADropdownItem,
  GoADropdown,
  GoACheckbox,
  GoAModal,
  GoADivider,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { subYears } from 'date-fns';
import useSubmitEmploymentHistory from './hooks/use-employment-history-hook';
import { Employment, WageFrequencies } from '../../../../../types/client';
import useCapitalize from '../../../../../hooks/use-capitalize.hook';
import NocInput from '../../../app-noc-dropdown/app-noc-input';
import { toIsoFormat } from '../../../../../utils/date.util';

interface Props {
  clientId: string;
  employment?: Employment;
  serviceplanId?: string;
  canEditEmployment?: boolean;
}

export const EmploymentForm = observer(({ clientId, employment, serviceplanId, canEditEmployment }: Props) => {
  const {
    formFields,
    getValues,
    employmentSubmitHandler,
    employmentCancelHandler,
    cancelEmploymentClickHandler,
    deleteEmploymentyRecordHandler,
    onChangeHandler,
    errors,
    startDateApproximate,
    endDateApproximate,
    setStartDateApproximate,
    setEndDateApproximate,
    hideModal,
    modalContent,
    modalVisible,
    handleSubmit,
    setCurrentEmployment,
    isCurrentEmployment,
    setExperienceOutsideOfCanada,
    isExperienceOutsideOfCanada,
    canHardDelete,
    reasonForLeavingItems,
    onSelectNocCode,
    setNocCodeField,
    formatCurrency,
    watchWage,
    employmentId,
  } = useSubmitEmploymentHistory(clientId, employment, serviceplanId);
  const capitalize = useCapitalize();

  const {
    jobTitle,
    noc,
    employerName,
    experienceOutsideOfCanada,
    selfEmployed,
    startDate,
    endDate,
    reasonForLeaving,
    numberOfHourPerWeek,
    wageCents,
    wageFrequency,
    currentEmployment,
  } = formFields;

  const title = `${employment ? 'Edit' : 'Add'} Employment`;

  return (
    <GoAModal maxWidth="1000px" open width="88px" transition="slow" heading={title} onClose={hideModal}>
      {modalVisible && modalContent}
      <div>
        <form className="create-client-form">
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Job Title</h4>
            <GoAFormItem error={errors.jobTitle?.message as unknown as string}>
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={jobTitle}
                id={jobTitle}
                value={getValues(jobTitle) as string}
                width="824px"
              />
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">NOC</h4>
            <NocInput
              name={noc}
              id={noc}
              placeholder=""
              width="824px"
              value={getValues(noc)}
              onSelectNocCode={onSelectNocCode}
              setNocCodeField={setNocCodeField}
              errors={errors}
            />
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Employer</h4>
            <GoAFormItem error={errors.employerName?.message as unknown as string}>
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={employerName}
                id={employerName}
                value={getValues(employerName) as string}
                width="824px"
              />
            </GoAFormItem>
            <GoASpacer vSpacing="s" />
            <GoACheckbox
              name={experienceOutsideOfCanada}
              text="This experience is outside of Canada."
              onChange={(name: string, checked: boolean) => {
                setExperienceOutsideOfCanada(checked);
                onChangeHandler(name, checked);
              }}
              checked={getValues(experienceOutsideOfCanada) ?? isExperienceOutsideOfCanada}
              value={getValues('experienceOutsideOfCanada')}
            />
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Is this self employed</h4>
            <GoAFormItem>
              <GoARadioGroup name={selfEmployed} value={getValues(selfEmployed) ? '1' : '0'} onChange={onChangeHandler}>
                <GoARadioItem value="1" label="Yes" />
                <GoARadioItem value="0" label="No" />
              </GoARadioGroup>
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">Start date</h4>
            <GoABlock>
              <GoAFormItem error={errors.startDate?.message as unknown as string}>
                <GoAInput
                  type="date"
                  name={startDate}
                  value={getValues(startDate) ? toIsoFormat(getValues(startDate)!) : undefined}
                  onChange={onChangeHandler}
                  min={toIsoFormat(subYears(new Date(), 50))}
                  max="9999-12-31"
                />
              </GoAFormItem>
              <GoASpacer hSpacing="xs" />
              <GoACheckbox
                name="exactStartDate"
                text="This date is approximate."
                onChange={(name: string, checked: boolean) => {
                  setStartDateApproximate(checked);
                  onChangeHandler(name, checked);
                }}
                value={getValues('exactStartDate')}
                checked={getValues('exactStartDate') ?? startDateApproximate}
              />
            </GoABlock>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <h4 className="client-no-padding-no-margin">End date</h4>
            <GoABlock>
              <GoAFormItem error={errors.endDate?.message as unknown as string}>
                <GoAInput
                  type="date"
                  name={endDate}
                  value={getValues(endDate) ? toIsoFormat(getValues(endDate)!) : undefined}
                  onChange={onChangeHandler}
                  min={toIsoFormat(subYears(new Date(), 50))}
                  max="9999-12-31"
                  disabled={isCurrentEmployment}
                />
              </GoAFormItem>
              <GoASpacer hSpacing="xs" />
              <GoACheckbox
                name="exactEndDate"
                text="This date is approximate."
                onChange={(name: string, checked: boolean) => {
                  setEndDateApproximate(checked);
                  onChangeHandler(name, checked);
                }}
                value={getValues('exactEndDate')}
                checked={getValues('exactEndDate') ?? endDateApproximate}
                disabled={isCurrentEmployment}
              />
            </GoABlock>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock>
            <GoAFormItem error={errors.currentEmployment?.message as unknown as string}>
              <GoACheckbox
                name={currentEmployment}
                text="The client currently works here"
                onChange={(name: string, checked: boolean) => {
                  setCurrentEmployment(checked);
                  onChangeHandler(name, checked);
                }}
                checked={getValues(currentEmployment) ?? isCurrentEmployment}
                value={getValues('currentEmployment') ?? isCurrentEmployment}
              />
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <div className="client-no-padding-no-margin-div">
              <h4 className="client-no-padding-no-margin">Reason for leaving</h4>
              <GoAFormItem>
                <GoADropdown
                  name={reasonForLeaving}
                  value={getValues(reasonForLeaving)}
                  onChange={onChangeHandler}
                  relative
                  disabled={isCurrentEmployment}
                >
                  {reasonForLeavingItems}
                </GoADropdown>
              </GoAFormItem>
            </div>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock direction="column">
            <GoABlock>
              <h4 className="client-no-padding-no-margin">{`Average hours per week `}</h4>
            </GoABlock>
            <GoAFormItem error={errors[numberOfHourPerWeek]?.message as unknown as string}>
              <GoAInput
                type="text"
                onChange={onChangeHandler}
                name={numberOfHourPerWeek}
                value={getValues(numberOfHourPerWeek)?.toString()}
              />
            </GoAFormItem>
          </GoABlock>
          <GoASpacer vSpacing="l" />
          <GoABlock>
            <GoABlock direction="column">
              <GoABlock>
                <h4 className="client-no-padding-no-margin">Wage</h4>
                <span className="font-smaller">(in Canadian dollars)</span>
              </GoABlock>
              <GoAFormItem error={errors[wageCents]?.message as unknown as string}>
                <GoAInput
                  type="number"
                  onChange={onChangeHandler}
                  name={wageCents}
                  value={watchWage?.toString()}
                  width="80%"
                  leadingContent="$"
                  onBlur={formatCurrency}
                />
              </GoAFormItem>
            </GoABlock>
            <GoABlock direction="column">
              <h4 className="client-no-padding-no-margin">Frequency</h4>
              <GoAFormItem error={errors[wageFrequency]?.message as unknown as string}>
                <GoADropdown name={wageFrequency} value={getValues(wageFrequency)} onChange={onChangeHandler} relative>
                  {Object.keys(WageFrequencies).map((item) => (
                    <GoADropdownItem key={item} value={item} label={capitalize(item.replaceAll('_', '-'))} />
                  ))}
                </GoADropdown>
              </GoAFormItem>
            </GoABlock>
          </GoABlock>

          <GoASpacer vSpacing="l" />
          <GoADivider />
          <GoASpacer vSpacing="l" />

          {canEditEmployment && (
            <GoABlock>
              <div className="d-flex w-100">
                <div className="flex-grow-1">
                  {canHardDelete ? (
                    <>
                      <GoAButton
                        type="tertiary"
                        variant="destructive"
                        leadingIcon="trash"
                        onClick={deleteEmploymentyRecordHandler}
                      >
                        Delete Employment
                      </GoAButton>
                      <div className="delete-employment-advice-hard">
                        Delete function will be disabled after 48 hours the record has been created.
                      </div>
                    </>
                  ) : (
                    <>
                      <GoAButton type="tertiary" leadingIcon="archive" onClick={cancelEmploymentClickHandler}>
                        Cancel Employment
                      </GoAButton>
                      <div className="delete-employment-advice-hard">
                        A record can no longer be deleted after 48 hours it&apos;s been created.
                      </div>
                    </>
                  )}
                </div>

                <div>
                  <GoAButtonGroup alignment="end">
                    <GoAButton type="secondary" onClick={employmentCancelHandler}>
                      <span>Cancel</span>
                    </GoAButton>
                    <GoAButton type="primary" onClick={handleSubmit(employmentSubmitHandler)}>
                      <span>{employmentId ? 'Save' : 'Add'}</span>
                    </GoAButton>
                  </GoAButtonGroup>
                </div>
              </div>
            </GoABlock>
          )}
        </form>
      </div>
    </GoAModal>
  );
});
