import { useCallback, useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { EmploymentRow } from '../../../../clients/employments/employment-row';

const useEmploymentHistory = () => {
  const { id: clientId } = useParams<{ id: string }>();
  const {
    clientsStore: {
      employmentHistory,
      getClientEmploymentHistory,
      selectedClient,
      currentEmploymentListPosition,
      getEmploymentListSize,
    },
    permissionStore: { canEditEmployment },
  } = useStore();
  const [expandedRecordId, setExpandedRecordId] = useState<string>();
  const [archived, setArchived] = useState(false);
  const toggleShowCancelledEmployment = useCallback(() => setArchived(!archived), [archived]);

  const toggleExpansion = useCallback(
    (id: string) => {
      if (id === expandedRecordId) {
        setExpandedRecordId(undefined);
      } else {
        setExpandedRecordId(id);
      }
    },
    [expandedRecordId],
  );

  const employmentRows = useMemo(() => {
    return employmentHistory?.map((employment) => (
      <EmploymentRow
        key={employment.id}
        employment={employment}
        expandedRecordId={expandedRecordId}
        toggleExpansion={toggleExpansion}
        canEditEmployment={canEditEmployment}
      />
    ));
  }, [canEditEmployment, employmentHistory, expandedRecordId, toggleExpansion]);

  useEffect(() => {
    const clientToUse = clientId || selectedClient?.id;
    if (clientToUse) {
      getClientEmploymentHistory(clientToUse, archived);
    }
  }, [
    archived,
    clientId,
    getClientEmploymentHistory,
    currentEmploymentListPosition,
    getEmploymentListSize,
    selectedClient?.id,
  ]);

  return useMemo(() => {
    return { employmentHistory, clientId, archived, toggleShowCancelledEmployment, employmentRows, canEditEmployment };
  }, [archived, canEditEmployment, clientId, employmentHistory, employmentRows, toggleShowCancelledEmployment]);
};

export default useEmploymentHistory;
