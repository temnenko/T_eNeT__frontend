import { ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { compareDesc } from 'date-fns';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { useModal } from '../../../../../../hooks/use-modal.hook';
import {
  ClientEmploymentHistoryCancelModal,
  ClientEmploymentHistorySubmitModal,
} from '../../../../modals/client-employment-history-modal';
import { Employment, ReasonsForLeaving, WageFrequencies } from '../../../../../../types/client';
import CancelEmploymentRecordModal from '../../../../modals/employments/cancel-employment-record.modal';
import { ConfirmationModal } from '../../../../modals/confirmation.modal';
import { getListItems } from '../../../../../../utils/list-items.util';
import { isAlphanumeric, twoOrMoreAlphabets } from '../../../../../../utils/validateText.util';
import { toIsoFormat } from '../../../../../../utils/date.util';

type EmploymentFormData = {
  jobTitle: string;
  noc: string;
  employerName: string;
  experienceOutsideOfCanada?: boolean;
  selfEmployed: boolean;
  startDate: string;
  exactStartDate?: boolean;
  currentEmployment?: boolean;
  endDate?: string;
  exactEndDate?: boolean;
  reasonForLeaving?: ReasonsForLeaving;
  numberOfHourPerWeek: number;
  wageCents: string;
  wageFrequency: WageFrequencies;
};

type FormFieldName =
  | 'jobTitle'
  | 'noc'
  | 'employerName'
  | 'experienceOutsideOfCanada'
  | 'selfEmployed'
  | 'startDate'
  | 'endDate'
  | 'reasonForLeaving'
  | 'numberOfHourPerWeek'
  | 'wageCents'
  | 'wageFrequency'
  | 'currentEmployment'
  | 'exactEndDate'
  | 'exactStartDate';

const useSubmitEmploymentHistory = (clientId: string, employment?: Employment, serviceplanId?: string) => {
  const [startDateApproximate, setStartDateApproximate] = useState(false);
  const [endDateApproximate, setEndDateApproximate] = useState(false);
  const [isCurrentEmployment, setCurrentEmployment] = useState(false);
  const [isExperienceOutsideOfCanada, setExperienceOutsideOfCanada] = useState(false);
  const [watchWage, setWage] = useState('');

  useEffect(() => {
    if (employment) {
      setExperienceOutsideOfCanada(!!employment.experienceOutsideOfCanada);
      setCurrentEmployment(!!employment.currentEmployment);
      setStartDateApproximate(!!employment.exactStartDate);
      setEndDateApproximate(!!employment.exactEndDate);
      setWage(employment.wageCents?.toFixed(2));
    }
  }, [employment]);

  const { hideModal } = useModal();

  const {
    clientsStore: { selectedClient, setEmploymentHistory, archiveEmployment, deleteEmployment },
    servicePlanStore: { setServicePlanEmploymentId },
  } = useStore();
  const {
    getValues,
    register,
    reset,
    setValue,
    handleSubmit,
    formState: { errors },
    setError,
  } = useForm<EmploymentFormData>({
    defaultValues: {
      ...employment,
      wageCents: employment?.wageCents ? employment?.wageCents?.toFixed(2) : undefined,
      startDate: employment?.startDate ? toIsoFormat(employment?.startDate) : undefined,
      endDate: employment?.endDate ? toIsoFormat(employment?.endDate) : undefined,
    },
  });

  const { name: jobTitle } = register('jobTitle', {
    required: { value: true, message: 'Job title is required!' },
    min: 3,
  });
  const { name: noc } = register('noc', {
    required: { value: true, message: 'NOC is required' },
  });
  const { name: employerName } = register('employerName', {
    required: { value: true, message: 'Employer is required!' },
    pattern: {
      value: /^[\p{L}]+([ .'\-_?!;:"()&|/@+=~%#$,><^*÷•\\]*[\p{L}]+)*[ .'\-_?!;:"()&|/@+=~%#$,><^*÷•\\]*$/u,
      message: 'Name can only begin with an alphabet or accented character',
    },
  });

  const { name: experienceOutsideOfCanada } = register('experienceOutsideOfCanada');
  const { name: selfEmployed } = register('selfEmployed');
  const { name: startDate } = register('startDate', {
    required: { value: true, message: 'Start date is required!' },
  });
  const { name: endDate } = register('endDate', {
    required: { value: !isCurrentEmployment, message: 'End date is required!' },
  });
  const { name: reasonForLeaving } = register('reasonForLeaving');
  const { name: numberOfHourPerWeek } = register('numberOfHourPerWeek', {
    required: { value: true, message: 'Average hour per week is required!' },
    pattern: {
      value: /^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/,
      message: 'Please enter a valid number',
    },
  });
  const { name: wageCents } = register('wageCents', {
    required: { value: true, message: 'Wage is required!' },
  });
  const { name: wageFrequency } = register('wageFrequency', {
    required: { value: true, message: 'Wage frequency is required!' },
  });
  const { name: currentEmployment } = register('currentEmployment');
  const { name: exactEndDate } = register('exactEndDate');
  const { name: exactStartDate } = register('exactStartDate');

  useEffect(() => {
    setStartDateApproximate(getValues('exactStartDate') ?? false);
    setEndDateApproximate(getValues('exactEndDate') ?? false);
  }, [exactStartDate, exactEndDate, getValues]);

  const formFields = {
    jobTitle,
    noc,
    employerName,
    experienceOutsideOfCanada,
    selfEmployed,
    startDate,
    endDate,
    reasonForLeaving,
    numberOfHourPerWeek,
    wageCents,
    wageFrequency,
    currentEmployment,
    exactStartDate,
    exactEndDate,
  };

  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const employmentCancelHandler = useCallback(async () => {
    setModalVisible(true);
    setModalContent(
      <ClientEmploymentHistoryCancelModal
        onDecline={() => {
          setModalVisible(false);
          hideModal();
          reset();
        }}
        onConfirm={() => {
          setModalVisible(false);
        }}
      />,
    );
  }, [reset, hideModal]);

  const archiveEmploymentRecord = useCallback(async () => {
    try {
      setLoading(true);

      if (employment?.id) {
        await archiveEmployment(employment.id, true);
      }
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
      setModalVisible(false);
      hideModal();
    }
  }, [archiveEmployment, employment?.id, hideModal]);

  const deleteEmploymentRecord = useCallback(async () => {
    try {
      setLoading(true);

      if (employment?.id) {
        await deleteEmployment(employment.id);
        if (selectedClient?.id) {
          await setServicePlanEmploymentId(selectedClient?.id, '');
        }
      }
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
      setModalVisible(false);
      hideModal();
    }
  }, [deleteEmployment, employment?.id, hideModal, selectedClient?.id, setServicePlanEmploymentId]);

  const hasInvalidFields = useCallback(() => {
    let invalid = false;

    const sDate = new Date(getValues(startDate));
    if (selectedClient?.dateOfBirth && compareDesc(sDate, new Date(selectedClient?.dateOfBirth)) === 1) {
      setError(startDate, {
        type: 'custom',
        message: 'The start date cannot be earlier than the date of birth provided earlier in the registration process',
      });
      invalid = true;
    }

    const eRawDate = getValues(endDate);
    const eDate = eRawDate ? new Date(eRawDate) : undefined;

    if (eDate && compareDesc(eDate, sDate) === 1) {
      setError(endDate, { type: 'custom', message: 'The end date cannot be earlier than the start date' });
      invalid = true;
    }

    const jTitle = getValues(jobTitle).trim();
    if (!isAlphanumeric(jTitle) || !twoOrMoreAlphabets(jTitle) || jTitle.length < 2 || jTitle.length >= 100) {
      setError(jobTitle, { type: 'custom', message: 'Please enter a valid job title' });
      invalid = true;
    }

    const hours = getValues(numberOfHourPerWeek);
    if (hours >= 168) {
      setError(numberOfHourPerWeek, {
        type: 'custom',
        message: 'Please enter a number below 169',
      });
      invalid = true;
    }

    const nocCode = getValues(noc);
    if (!/^\d{5}$/.test(nocCode.substring(0, 5))) {
      setError(noc, {
        type: 'custom',
        message: 'NOC code must be a 5-digit number.',
      });
      invalid = true;
    }

    const wage = watchWage;
    if (!/^\d+(\.*\d{0,2})$/.test(wage)) {
      setError(wageCents, {
        type: 'custom',
        message: 'Can only be a whole or two-decimal place number',
      });
      invalid = true;
    }

    return invalid;
  }, [
    endDate,
    getValues,
    jobTitle,
    noc,
    numberOfHourPerWeek,
    selectedClient?.dateOfBirth,
    setError,
    startDate,
    wageCents,
    watchWage,
  ]);

  const employmentSubmitHandler = useCallback(async () => {
    try {
      setModalVisible(true);
      setLoading(true);

      if (hasInvalidFields()) {
        return;
      }

      const newEmploymentHist = {
        clientId: clientId ?? selectedClient?.id ?? '',
        jobTitle: getValues('jobTitle'),
        noc: getValues('noc'),
        employerName: getValues('employerName'),
        experienceOutsideOfCanada: getValues('experienceOutsideOfCanada'),
        selfEmployed: !!getValues('selfEmployed'),
        startDate: new Date(getValues('startDate')),
        endDate: getValues('endDate') ? new Date(getValues('endDate')!) : undefined,
        reasonForLeaving: getValues('reasonForLeaving') as ReasonsForLeaving,
        numberOfHourPerWeek: +getValues('numberOfHourPerWeek'),
        wageCents: parseFloat(getValues('wageCents')),
        wageFrequency: getValues('wageFrequency').toUpperCase() as WageFrequencies,
        currentEmployment: getValues('currentEmployment'),
        exactStartDate: getValues('exactStartDate'),
        exactEndDate: getValues('exactEndDate'),
      };

      setModalContent(
        <ClientEmploymentHistorySubmitModal
          firstName={selectedClient?.firstName ?? 'Homer'}
          lastName={selectedClient?.lastName ?? 'Simpson'}
          onDecline={() => {
            reset();
            hideModal();
          }}
          onConfirm={async () => {
            setEmploymentHistory(
              clientId ?? selectedClient?.id ?? '',
              newEmploymentHist,
              employment?.id ?? '',
              serviceplanId,
            );
            setModalVisible(false);
            hideModal();
          }}
        />,
      );

      reset();
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [
    clientId,
    employment?.id,
    getValues,
    hasInvalidFields,
    hideModal,
    reset,
    selectedClient?.firstName,
    selectedClient?.id,
    selectedClient?.lastName,
    serviceplanId,
    setEmploymentHistory,
  ]);

  const clientFirstName = useMemo(() => selectedClient?.firstName ?? 'Homer', [selectedClient]);
  const clientLastName = useMemo(() => selectedClient?.lastName ?? 'Simpson', [selectedClient]);

  const cancelEmploymentClickHandler = useCallback(() => {
    setModalVisible(true);
    setModalContent(
      <CancelEmploymentRecordModal
        onConfirm={archiveEmploymentRecord}
        onDecline={() => setModalVisible(false)}
        firstName={clientFirstName}
        lastName={clientLastName}
        loading={loading}
      />,
    );
  }, [archiveEmploymentRecord, clientFirstName, clientLastName, loading]);

  const deleteEmploymentyRecordHandler = () => {
    setModalVisible(true);
    const description = `Are you sure you want to delete the client's ${employment?.employerName} experience ? This will remove the employment record permanently.`;
    setModalContent(
      <ConfirmationModal
        onConfirm={deleteEmploymentRecord}
        onDecline={() => setModalVisible(false)}
        heading="Delete Employment"
        description={description}
        loading={loading}
        confirmText="Delete"
        declineText="No, go back"
        isDelete
      />,
    );
  };

  const onChangeHandler = useCallback(
    (name: string, value: string | string[] | boolean | number | undefined) => {
      if (Array.isArray(value)) {
        setValue(name as FormFieldName, value.join(','));
      } else if (name === noc) {
        setValue(name, (value as string)?.trim());
      } else {
        setValue(name as FormFieldName, value);
      }
    },
    [noc, setValue],
  );

  const formatCurrency = useCallback(
    (name: string, value: string) => {
      const cad = (Math.round(parseFloat(value) * 100) / 100).toFixed(2);
      if (name === wageCents) {
        setValue(name, cad);
        setWage(cad);
      }
    },
    [setValue, wageCents],
  );

  const onSelectNocCode = useCallback(
    (suggestion: { value: string; label: string }) => {
      setValue(noc, `${suggestion.value} - ${suggestion.label}`, { shouldValidate: true });
    },
    [noc, setValue],
  );

  const setNocCodeField = useCallback(
    (name: string, value: string) => {
      setValue(noc as FormFieldName, value.trim(), { shouldValidate: true });
    },
    [noc, setValue],
  );

  const canHardDelete = useMemo(() => {
    if (employment?.canHardDelete) {
      return employment?.canHardDelete;
    }
    return false;
  }, [employment]);

  const reasonForLeavingItems = getListItems(ReasonsForLeaving, 'dropdown', true);

  return {
    loading,
    formFields,
    getValues,
    employmentSubmitHandler,
    employmentCancelHandler,
    cancelEmploymentClickHandler,
    deleteEmploymentyRecordHandler,
    deleteEmploymentRecord,
    onChangeHandler,
    errors,
    startDateApproximate,
    setStartDateApproximate,
    endDateApproximate,
    setEndDateApproximate,
    hideModal,
    modalContent,
    modalVisible,
    handleSubmit,
    setCurrentEmployment,
    isCurrentEmployment,
    setExperienceOutsideOfCanada,
    isExperienceOutsideOfCanada,
    canHardDelete,
    reasonForLeavingItems,
    onSelectNocCode,
    setNocCodeField,
    formatCurrency,
    watchWage,
    employmentId: employment?.id,
  };
};

export default useSubmitEmploymentHistory;
