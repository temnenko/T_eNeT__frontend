import { observer } from 'mobx-react-lite';
import { useStore } from '../../../../hooks/use-store.hook';
import { StepperFormHeader } from '../../stepper-form/stepper-form-header';
import { agreementFormsStepperTitles } from '../../../../types/agreement-forms';

export const NewAgreementHeader = observer(() => {
  const {
    agreementFormStepperStore: { currentlyActive },
  } = useStore();

  return (
    <StepperFormHeader
      headingText="Create Agreement"
      currentlyActive={currentlyActive}
      formStepperTitles={agreementFormsStepperTitles}
    />
  );
});
