import { useMemo, useCallback } from 'react';
import { GoABlock, GoAButton, GoAFormItem, GoANotification, GoASpacer, GoAText } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import AutocompleteInput from '../../../../auto-complete-input';
import useAgreementDeliveryLocation from '../hooks/use-agreement-delivery-location.hook';
import InlineLoadingIndicator from '../../../inline-loading-indicator';
import { useNavigateAgreementStepper } from '../hooks/use-navigate-agreement-stepper.hook';
import LocationCard from './location-card';
import { LocationFormModal } from './location-form.modal';
import { useModal } from '../../../../../../hooks/use-modal.hook';

const AgreementDeliveryLocationsForm = observer(() => {
  const { showModal, hideModal } = useModal();
  const { goToNextStep, goToPreviousStep } = useNavigateAgreementStepper();
  const {
    requestError,
    loading,
    selectedLocations,
    locationSearch,
    locationData,
    filteredLocations,
    onSelectLocation,
    setSearchableField,
    onErrorDismiss,
    editLocationHandler,
    removeLocationHandler,
    nextButtonClickHandler,
  } = useAgreementDeliveryLocation({ goToNextStep, goToPreviousStep, hideModal });
  const isLocations = useMemo(() => !!locationData.length, [locationData.length]);
  const helpText = useMemo(
    () => (isLocations ? 'Search a location with name or address.' : 'No existing locations found'),
    [isLocations],
  );
  const errorMessage = useMemo(() => requestError?.message, [requestError?.message]);
  const addNewLocationHandler = useCallback(() => {
    showModal(<LocationFormModal hideModal={hideModal} submitLabel={undefined} />);
  }, [hideModal, showModal]);

  return (
    <div className="agreement-form">
      <GoAFormItem label="Select each location where the agreement will be delivered." helpText={helpText} mb="3">
        <GoAText mb="2">
          You can select from existing office locations that have been added to this organization.
        </GoAText>
        <GoAText mb="4">
          If you don’t see the location you are looking for upon searching, you will then be prompted to add a new
          location.
        </GoAText>
        <AutocompleteInput
          name="locationSearch"
          id="locationSearch"
          placeholder=""
          width="100%"
          onSelectAddress={undefined}
          onSelectUser={undefined}
          onSelectSuggestion={onSelectLocation}
          value={locationSearch}
          subType=""
          setField={setSearchableField}
          addAction={addNewLocationHandler}
          addLabel="Add a delivery location"
          suggestionData={filteredLocations}
        />
      </GoAFormItem>
      {selectedLocations.map((loc, pos) => (
        <LocationCard
          key={loc.id}
          location={loc}
          onRemoveHandler={() => removeLocationHandler({ id: loc.id, pos })}
          onEditHandler={
            loc.canEdit
              ? () => {
                  addNewLocationHandler();
                  editLocationHandler(pos);
                }
              : undefined
          }
        />
      ))}
      <GoASpacer vSpacing="xl" />
      {!!errorMessage && (
        <>
          <GoANotification type="emergency" onDismiss={onErrorDismiss}>
            {errorMessage}
          </GoANotification>
          <GoASpacer vSpacing="xs" />
        </>
      )}
      <GoABlock mb="s" direction="column" alignment="end">
        <GoAButton disabled={loading} onClick={nextButtonClickHandler} trailingIcon="arrow-forward">
          {loading ? (
            <InlineLoadingIndicator label="Saving changes..." />
          ) : (
            <>
              <span className="client-bold-600">Next:</span> Contact group
            </>
          )}
        </GoAButton>
      </GoABlock>
    </div>
  );
});

export default AgreementDeliveryLocationsForm;
