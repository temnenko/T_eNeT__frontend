import { observer } from 'mobx-react-lite';

import { GoAButton, GoANotification, GoASpacer } from '@abgov/react-components';
import InlineLoadingIndicator from '../../../inline-loading-indicator';
import useAgreementDocuments from '../hooks/use-agreement-documents.hook';
import { AgreementFilesUploadForm } from './agreement-documents-upload.form';

export const AgreementDocuments = observer(() => {
  const { submitHandler, loading, requestError, invalidUploadError, previousButtonClickHandler, agreement } =
    useAgreementDocuments();
  return (
    <div className="create-client-form">
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {agreement && (
        <AgreementFilesUploadForm invalidUploadError={invalidUploadError} formItemLabel="Agreement documents" />
      )}
      <GoASpacer vSpacing="m" />
      <div className="row-space-between client-demographic-prev-next">
        <GoAButton type="secondary" onClick={() => previousButtonClickHandler()} leadingIcon="arrow-back">
          <span className="client-bold-600">Previous:</span> Contact Group
        </GoAButton>
        <GoAButton onClick={submitHandler} trailingIcon={loading ? undefined : 'arrow-forward'} disabled={loading}>
          {loading ? (
            <InlineLoadingIndicator label="Saving changes..." />
          ) : (
            <>
              <span className="client-bold-600">Next:</span> Review
            </>
          )}
        </GoAButton>
      </div>
      <GoASpacer vSpacing="xl" />
    </div>
  );
});
