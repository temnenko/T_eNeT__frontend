/* eslint-disable consistent-return */
import { GoAModal } from '@abgov/react-components';

import { NewLocationForm } from './new-location.form';
import { LocationFormArgs } from '../hooks/use-agreement-location-form.hook';

type Props = LocationFormArgs & {
  submitLabel: string | undefined;
};

export function LocationFormModal({ hideModal, submitLabel }: Props) {
  return (
    <GoAModal maxWidth="784px" open width="88px" transition="slow" heading="Add a location" onClose={hideModal}>
      <div className="agreement-form">
        <NewLocationForm hideModal={hideModal} submitLabel={submitLabel} />
      </div>
    </GoAModal>
  );
}
