/* eslint-disable @typescript-eslint/no-unused-expressions */
import { useForm } from 'react-hook-form';
import { useCallback, useEffect, useState } from 'react';

import { useStore } from '../../../../../../hooks/use-store.hook';
import { Contact, CreateContact } from '../../../../../../types/organization';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';

type FormFieldName = 'name' | 'role' | 'phoneNumber' | 'extension' | 'emailAddress' | 'note' | 'agreementSignatory';

export type AgreementContactFormArgs = {
  hideModal?: () => void;
  selectedContact?: Contact;
};

type AgreementContactFormData = {
  name: string;
  role: string;
  phoneNumber: string;
  extension: string;
  emailAddress: string;
  note: string;
  agreementSignatory: boolean;
};

const useAgreementContactForm = ({ hideModal, selectedContact }: AgreementContactFormArgs) => {
  const {
    agreementFormsStore: {
      agreement,
      editContactId,
      selectedContacts,
      setEditContactId,
      setSelectedContacts,
      createAndConnectContacts,
      updateContact,
    },
    agreementStore: { selectedAgreement, getAgreementById },
    organizationStore: { selectedOrganization },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<AgreementContactFormData>();

  const loadContact = useCallback(async () => {
    if (selectedContact || typeof editContactId === 'number') {
      const contact = selectedContact ?? selectedContacts[editContactId!];

      setValue('name', contact.name);
      setValue('role', contact.role);
      setValue('phoneNumber', contact.phoneNumber);
      setValue('extension', contact.extension || '');
      setValue('emailAddress', contact.emailAddress);
      setValue('note', contact.note || '');
      setValue('agreementSignatory', contact.agreementSignatory);
    }
  }, [editContactId, selectedContact, selectedContacts, setValue]);

  const { name: contactName } = register('name', {
    required: { value: true, message: 'Name is required' },
    pattern: { value: /^[a-zA-Z\s]*$/, message: 'Name must contain only letters and spaces' },
  });

  const { name: agreementSignatory } = register('agreementSignatory');

  const { name: role } = register('role', {
    required: { value: true, message: 'Job title is required' },
    pattern: { value: /^[a-zA-Z\s]*$/, message: 'Job title must contain only letters and spaces' },
  });
  const { name: phoneNumber } = register('phoneNumber', {
    required: { value: true, message: 'Phone number is required' },
    pattern: {
      value: /^\(?\d{3}\)?([\s])?\d{3}([-])?\d{4}$/,
      message: 'Invalid Canadian phone number',
    },
  });
  const { name: extension } = register('extension', {
    pattern: { value: /^[0-9]*$/, message: 'Extension must contain only numbers' },
  });
  const { name: emailAddress } = register('emailAddress', {
    required: { value: true, message: 'Email address is required' },
    pattern: {
      value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
      message: 'Invalid email address',
    },
  });
  const { name: note } = register('note');

  const formData = {
    contactName,
    role,
    phoneNumber,
    extension,
    emailAddress,
    note,
    agreementSignatory,
  };

  const onChangeHandler = useCallback(
    (name: string, value: string | string[]) => {
      setValue(name as FormFieldName, value as string);
    },
    [setValue],
  );

  const onCheckboxChangeHandler = useCallback(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    (name: string, checked: boolean, value: string) => {
      setValue(name as FormFieldName, checked);
    },
    [setValue],
  );

  const agreementContactSubmitHandler = useCallback(async () => {
    const contact: CreateContact = {
      name: getValues('name')?.trim(),
      role: getValues('role')?.trim(),
      phoneNumber: getValues('phoneNumber')?.replace(/\D/g, '').trim(),
      extension: getValues('extension')?.trim(),
      emailAddress: getValues('emailAddress')?.trim()?.toLowerCase(),
      note: getValues('note')?.trim(),
      agreementSignatory: getValues('agreementSignatory'),
    };

    try {
      setRequestError({});
      setLoading(true);

      const organizationId = !hideModal ? selectedAgreement!.organizationId : agreement!.organizationId;
      const isEditId = typeof editContactId === 'number' || !!selectedContact;
      const result = isEditId
        ? await updateContact(selectedContact?.id ?? selectedContacts[editContactId!].id!, contact)
        : await createAndConnectContacts(selectedOrganization?.id ?? organizationId, [contact]);

      if (isEditId && !selectedContact) {
        const updated = [...selectedContacts];
        updated.splice(editContactId!, 1, { ...result, canEdit: true });
        setSelectedContacts([...updated]);
      } else if (!selectedContact) {
        setSelectedContacts([...selectedContacts, { ...result, canEdit: true }]);
      }

      setEditContactId(undefined);
      reset();
      hideModal && hideModal();
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setLoading(false);

      selectedContact && selectedAgreement && (await getAgreementById(selectedAgreement?.id));
    }

    reset();
  }, [
    agreement,
    createAndConnectContacts,
    editContactId,
    getAgreementById,
    getValues,
    hideModal,
    requestErrorHandler,
    reset,
    selectedAgreement,
    selectedContact,
    selectedContacts,
    selectedOrganization,
    setEditContactId,
    setSelectedContacts,
    updateContact,
  ]);

  useEffect(() => {
    loadContact();
  }, [editContactId, loadContact]);

  return {
    formData,
    loading,
    requestError,
    onChangeHandler,
    errors,
    handleSubmit,
    agreementContactSubmitHandler,
    getValues,
    watch,
    onCheckboxChangeHandler,
  };
};

export default useAgreementContactForm;
