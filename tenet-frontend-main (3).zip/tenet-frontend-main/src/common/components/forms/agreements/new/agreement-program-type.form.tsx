import {
  GoASpacer,
  GoAFormItem,
  GoAButton,
  GoARadioItem,
  GoARadioGroup,
  GoAButtonGroup,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import useSubmitAgreementType from './hooks/use-agreement-program-type.hook';
import { AgreementProgramType, AgreementProgramTypeAbbr } from '../../../../../types/agreement';

export const AgreementProgramTypeForm = observer(() => {
  const {
    loading,
    formFields,
    getValues,
    agreementProgramTypeSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    getListItems,
    capitalizeFirst,
  } = useSubmitAgreementType();

  const { agreementProgramType } = formFields;

  return (
    <form className="agreement-form">
      <GoAFormItem
        label="Program type"
        labelSize="regular"
        error={errors[agreementProgramType]?.message as unknown as string}
      >
        <GoARadioGroup
          name={agreementProgramType}
          value={getValues(agreementProgramType)}
          onChange={(name: string, value: string) => onChangeHandler(name, value as AgreementProgramType)}
        >
          <GoASpacer vSpacing="xs" />
          <GoARadioItem
            value={AgreementProgramType.TRANSITION_TO_EMPLOYMENT}
            label={`${capitalizeFirst(AgreementProgramType.TRANSITION_TO_EMPLOYMENT.toLowerCase()).replaceAll('To', 'to')} (${AgreementProgramTypeAbbr.TRANSITION_TO_EMPLOYMENT})`}
          />
          {getListItems(AgreementProgramType, AgreementProgramTypeAbbr)}
        </GoARadioGroup>
      </GoAFormItem>

      <GoASpacer vSpacing="xl" />

      <GoAButtonGroup alignment="end">
        <GoAButton
          disabled={loading}
          type="submit"
          onClick={handleSubmit(agreementProgramTypeSubmitHandler)}
          trailingIcon={loading ? undefined : 'arrow-forward'}
        >
          {loading ? (
            <InlineLoadingIndicator label="Saving changes..." />
          ) : (
            <>
              <span className="client-bold-600">Next:</span> Agreement details
            </>
          )}
        </GoAButton>
      </GoAButtonGroup>
      <GoASpacer vSpacing="s" />
    </form>
  );
});
