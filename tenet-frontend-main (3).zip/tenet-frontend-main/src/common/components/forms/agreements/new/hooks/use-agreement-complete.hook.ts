import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';

export const useCompleteAgreement = () => {
  const {
    agreementFormsStore: { agreement, completeAgreement },
    organizationStore: { selectedOrganization },
  } = useStore();

  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [validationMsg, setValidationMsg] = useState<string>('');

  const requestErrorHandler = useRequestErrorHandler();

  const creationCompleteHandler = useCallback(async () => {
    try {
      setLoading(true);
      if (agreement?.id) {
        const completed = await completeAgreement(agreement?.id);
        if (agreement?.creationCompleted || completed) {
          setValidationMsg('');
          if (agreement?.id) {
            navigate(`/agreements/${agreement?.id}`);
          } else {
            navigate(`/organizations/${selectedOrganization?.id}/agreements`);
          }
        } else {
          const msg =
            'Looks like there’s missing information. Please review the following sections and ensure all required fields are filled out. Once completed, feel free to submit again';
          setValidationMsg(msg);
        }
      }
    } catch (error) {
      setLoading(false);
      requestErrorHandler({
        error,
        setError: setRequestError,
      });
    } finally {
      setLoading(false);
    }
  }, [
    agreement?.creationCompleted,
    agreement?.id,
    completeAgreement,
    navigate,
    requestErrorHandler,
    selectedOrganization?.id,
  ]);

  return {
    loading,
    creationCompleteHandler,
    requestError,
    validationMsg,
    detailsCompleted: agreement?.name,
    locationsCompleted: agreement?.locations?.length,
    programTypeCompleted: agreement?.programType,
    contactCompleted: agreement?.contacts?.length,
    setValidationMsg,
    agreementCreationCompleted: agreement?.creationCompleted,
  };
};
