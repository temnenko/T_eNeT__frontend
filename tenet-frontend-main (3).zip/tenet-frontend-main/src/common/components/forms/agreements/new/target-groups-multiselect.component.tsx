type TargetGroupsMultiSelectProps = {
  options: string[];
  selected: string[];
  onChange: (selected: string[]) => void;
};

export function TargetGroupsMultiSelect({ options, selected, onChange }: TargetGroupsMultiSelectProps) {
  const handleCheckboxChange = (value: string) => {
    if (selected.includes(value)) {
      onChange(selected.filter((item) => item !== value));
    } else {
      onChange([...selected, value]);
    }
  };

  return (
    <div>
      {options.map((option) => (
        <div key={option}>
          <input
            type="checkbox"
            id={`checkbox-${option}`}
            value={option}
            checked={selected.includes(option)}
            onChange={() => handleCheckboxChange(option)}
          />
          <label htmlFor={`checkbox-${option}`}>{option}</label>
        </div>
      ))}
    </div>
  );
}
