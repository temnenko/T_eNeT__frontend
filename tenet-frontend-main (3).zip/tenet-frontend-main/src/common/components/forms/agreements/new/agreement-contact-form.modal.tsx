/* eslint-disable consistent-return */
import { GoAModal } from '@abgov/react-components';

import { AgreementContactFormArgs } from './hooks/use-agreement-contact-form.hook';
import { NewContactForm } from './new-contact.form';

type Props = AgreementContactFormArgs & {
  submitLabel: string | undefined;
};

export function AgreementContactFormModal({ hideModal, submitLabel }: Props) {
  return (
    <GoAModal maxWidth="784px" open width="88px" transition="slow" heading="Add a contact person" onClose={hideModal}>
      <div className="agreement-form">
        <NewContactForm hideModal={hideModal} submitLabel={submitLabel} />
      </div>
    </GoAModal>
  );
}
