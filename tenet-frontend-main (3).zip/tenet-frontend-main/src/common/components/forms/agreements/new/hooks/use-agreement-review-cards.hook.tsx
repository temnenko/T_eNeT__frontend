import { useMemo } from 'react';

import { format } from 'date-fns';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { languageReadable } from '../../../../../../types/client';
import { useNavigateAgreementStepper } from './use-navigate-agreement-stepper.hook';
import { AgreementFormsStepperKeys } from '../../../../../../types/agreement-forms';
import { AgreementProgramType, AgreementProgramTypeAbbr } from '../../../../../../types/agreement';
import { toIsoDate } from '../../../../../../utils/date.util';

export const useAgreementReviewCards = () => {
  const {
    agreementFormsStore: { agreement },
    agreementFilesStore: { documents },
  } = useStore();

  const { jumpToStep } = useNavigateAgreementStepper();

  return useMemo(() => {
    const programType = agreement?.programType;

    const cards = [
      {
        title: 'Program type',
        data: [
          {
            label: 'Operating name',
            value: (programType
              ? `${AgreementProgramType[programType]}  (${AgreementProgramTypeAbbr[programType]})`
              : ''
            ).replaceAll('_', ' '),
          },
        ],
        navigate: () => jumpToStep(AgreementFormsStepperKeys.PROGRAM_TYPE, agreement!.id),
      },
      {
        title: 'Agreement Details',
        data: [
          {
            label: 'Official language',
            value: agreement?.serviceLanguage ? languageReadable[agreement?.serviceLanguage] : 'English',
          },
          {
            label: 'Agreement name',
            value: agreement?.name,
          },
          {
            label: 'Agreement number',
            value: agreement?.agreementNumber,
          },
          {
            label: 'Intervention credential',
            value: agreement?.interventionCredential?.replaceAll('_', ''),
          },
          {
            label: 'Agreement start date',
            value: agreement?.startDate ? format(toIsoDate(agreement?.startDate), 'MMMM dd, yyyy') : '',
          },
          {
            label: 'Last intake date',
            value: agreement?.lastIntakeDate ? format(toIsoDate(agreement?.lastIntakeDate), 'MMMM dd, yyyy') : '',
          },
          {
            label: 'Agreement end date',
            value: agreement?.endDate ? format(toIsoDate(agreement?.endDate), 'MMMM dd, yyyy') : '',
          },
          {
            label: 'Expected length',
            value: agreement?.activeInterventionLength,
          },
          {
            label: 'Amendment option',
            value: agreement?.amendmentOption?.replaceAll('_', ' '),
          },
          {
            label: 'Max participants',
            value: agreement?.participantsMaxNumber,
          },
          {
            label: 'Target LMDA/WDA split',
            value: agreement?.targetLmdaWdaSplit,
          },
          {
            label: 'Target groups',
            value: agreement?.targetGroups.join(', '),
          },
          {
            label: 'Target sector',
            value: agreement?.targetSectors?.length
              ? agreement?.targetSectors?.join(', ')
              : 'General - No industry specified',
          },
          {
            label: 'Economic region',
            value: agreement?.economicRegions.join(', '),
          },
          {
            label: 'Communities served',
            value: agreement?.communitiesServed.join(', '),
          },
        ],
        navigate: () => jumpToStep(AgreementFormsStepperKeys.AGREEMENT_DETAILS, agreement!.id),
      },
    ];
    const locationCards = [
      {
        title: 'Delivery locations',
        data: agreement?.locations?.map((location) => {
          let address = `${location.street}, ${location.city} ${location.province} ${location.postalCode}`;
          if (location?.unit) {
            address = `${location.unit} - ${address}`;
          }
          return {
            address,
            phone: location.phoneNumber,
            email: location.email,
            name: location.name,
          };
        }),
        navigate: () => jumpToStep(AgreementFormsStepperKeys.DELIVERY_LOCATIONS, agreement!.id),
      },
    ];

    const contactCards = [
      {
        title: 'Contact group',
        data: agreement?.contacts?.map((contact) => {
          return {
            name: contact.name,
            title: contact.role,
            phone: contact.phoneNumber,
            extension: contact.extension,
            email: contact.emailAddress,
            isSignatory: contact.agreementSignatory,
            note: contact.note,
          };
        }),
        navigate: () => jumpToStep(AgreementFormsStepperKeys.CONTACT_GROUP, agreement!.id),
      },
    ];
    return { cards, agreement, locationCards, contactCards, documents };
  }, [agreement, documents, jumpToStep]);
};
