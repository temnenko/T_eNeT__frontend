import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from '../../../../../../hooks/use-store.hook';

const useLoadAgreement = (selectedAgreementId?: string, mode: 'forms' | 'profile' = 'forms') => {
  const { id: routeAgreementId } = useParams<{ id: string }>();
  const {
    agreementFormsStore: { agreement, getById },
    agreementStore: { selectedAgreement, getAgreementById },
  } = useStore();

  useEffect(() => {
    const activeAgreementId = routeAgreementId || selectedAgreementId;

    const fetchAgreementForCreate = async () => {
      if (activeAgreementId) {
        if (agreement?.id === activeAgreementId) {
          return;
        }
        await getById(activeAgreementId);
      }
    };

    const fetchAgreementForProfile = async () => {
      if (activeAgreementId) {
        if (selectedAgreement?.id === activeAgreementId) {
          return;
        }
        await getAgreementById(activeAgreementId);
      }
    };

    if (mode === 'forms') {
      fetchAgreementForCreate();
    } else {
      fetchAgreementForProfile();
    }
  }, [routeAgreementId, selectedAgreementId, agreement, getById, mode, selectedAgreement?.id, getAgreementById]);

  return {
    agreement: mode === 'forms' ? agreement : selectedAgreement,
  };
};

export default useLoadAgreement;
