import { GoABlock, GoAButton, GoAFormItem, GoAInput, GoASpacer } from '@abgov/react-components';

import { observer } from 'mobx-react-lite';
import { AddressFields } from '../../../fields/address-fields';
import { useFormatPhoneInput } from '../../../../../../hooks/use-format-phone-input.hook';
import useAgreementLocationForm, { LocationFormArgs } from '../hooks/use-agreement-location-form.hook';

export const NewLocationForm = observer(
  ({
    hideModal,
    submitLabel,
  }: LocationFormArgs & {
    submitLabel: string | undefined;
  }) => {
    const formatPhoneInput = useFormatPhoneInput();
    const {
      formFields,
      errors,
      loading,
      watch,
      onChangeHandler,
      setSearchableField,
      onSelectAddress,
      handleSubmit,
      deliveryLocationSaveHandler,
      getValues,
      onBlurHandler,
    } = useAgreementLocationForm({
      hideModal,
    });
    const {
      locationName,
      streetAddress,
      unit,
      city,
      province,
      postalCode,
      country,
      phoneNumber,
      emailAddress,
      addressType,
    } = formFields;

    return (
      <form>
        <GoAFormItem label="Location name" error={errors[locationName]?.message as unknown as string}>
          <GoAInput
            type="text"
            onChange={onChangeHandler}
            name={locationName}
            id={locationName}
            value={getValues(locationName)}
            width="42rem"
          />
        </GoAFormItem>
        <AddressFields
          fields={{
            streetAddress,
            unit,
            city,
            province,
            postalCode,
            country,
            addressType,
          }}
          onChangeHandler={onChangeHandler}
          getValues={watch}
          errors={errors}
          onBlurHandler={onBlurHandler}
          onSelectAddress={onSelectAddress}
          setAddressStreetField={setSearchableField}
        />
        <GoAFormItem
          requirement="optional"
          label="Phone number"
          error={errors[phoneNumber]?.message as unknown as string}
        >
          <GoAInput
            leadingContent="+1"
            type="tel"
            onChange={onChangeHandler}
            name={phoneNumber}
            id={phoneNumber}
            value={formatPhoneInput(watch(phoneNumber))}
            width="15.69rem"
          />
        </GoAFormItem>
        <GoAFormItem requirement="optional" label="Email" error={errors[emailAddress]?.message as unknown as string}>
          <GoAInput
            type="email"
            onChange={onChangeHandler}
            name={emailAddress}
            id={emailAddress}
            value={watch(emailAddress)}
            width="15.69rem"
          />
        </GoAFormItem>
        <GoASpacer vSpacing="m" />
        <GoABlock>
          <GoASpacer hSpacing="fill" />
          <GoAButton type="secondary" disabled={loading} onClick={handleSubmit(deliveryLocationSaveHandler)}>
            {submitLabel ?? 'Save and select location'}
          </GoAButton>
        </GoABlock>
      </form>
    );
  },
);
