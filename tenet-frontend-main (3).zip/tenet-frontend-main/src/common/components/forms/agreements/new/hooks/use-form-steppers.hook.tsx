import { useCallback, useMemo } from 'react';
import { GoAIcon } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../../../../hooks/use-store.hook';
import useLoadAgreement from './use-load-agreement.hook';
import {
  AgreementFormsStepperKeys,
  agreementFormsStepperPaths,
  agreementFormsStepperTitles,
} from '../../../../../../types/agreement-forms';
import { TabsTextState } from '../../../../../../stores/agreement-form-stepper.store';
import { Stepper } from '../../../stepper';

const useFormSteppers = () => {
  const {
    authStore: { isAuthenticated },
    agreementFormStepperStore: { steppers, active },
  } = useStore();
  const { programType, agreementDetails, deliveryLocations, contactGroup, documents, review } = steppers;
  const navigate = useNavigate();
  const { agreement } = useLoadAgreement();

  const clickHandler = useCallback(
    (key: AgreementFormsStepperKeys, path: string) => () => {
      const updatedPath = agreement?.id ? path.replace(':id?', agreement.id!) : path;

      // Do not move past the first agreement form until submitted
      if (agreement?.id) {
        active(key);
        navigate(updatedPath);
      }
    },
    [active, agreement?.id, navigate],
  );
  const getTabIcon = useCallback((tabState: TabsTextState) => {
    if (tabState === TabsTextState.ACTIVE) {
      return <GoAIcon type="pencil" theme="filled" size="small" />;
    }

    if (tabState === TabsTextState.DONE) {
      return <GoAIcon type="checkmark" theme="filled" size="small" />;
    }

    return '';
  }, []);

  const steppersProps = useMemo(
    () => [
      {
        text: agreementFormsStepperTitles.programType,
        icon: getTabIcon(programType.tabText),
        clickHandler: clickHandler(AgreementFormsStepperKeys.PROGRAM_TYPE, agreementFormsStepperPaths.programType),
        className: '',
        tabClassName: programType.tab,
        textClassName: programType.tabText,
      },
      {
        text: agreementFormsStepperTitles.agreementDetails,
        icon: getTabIcon(agreementDetails.tabText),
        clickHandler: clickHandler(
          AgreementFormsStepperKeys.AGREEMENT_DETAILS,
          agreementFormsStepperPaths.agreementDetails,
        ),
        className: '',
        tabClassName: agreementDetails.tab,
        textClassName: agreementDetails.tabText,
      },
      {
        text: agreementFormsStepperTitles.deliveryLocations,
        icon: getTabIcon(deliveryLocations.tabText),
        clickHandler: clickHandler(
          AgreementFormsStepperKeys.DELIVERY_LOCATIONS,
          agreementFormsStepperPaths.deliveryLocations,
        ),
        className: '',
        tabClassName: deliveryLocations.tab,
        textClassName: deliveryLocations.tabText,
      },
      {
        text: agreementFormsStepperTitles.contactGroup,
        icon: getTabIcon(contactGroup.tabText),
        clickHandler: clickHandler(AgreementFormsStepperKeys.CONTACT_GROUP, agreementFormsStepperPaths.contactGroup),
        className: '',
        tabClassName: contactGroup.tab,
        textClassName: contactGroup.tabText,
      },
      {
        text: agreementFormsStepperTitles.documents,
        icon: getTabIcon(documents.tabText),
        clickHandler: clickHandler(AgreementFormsStepperKeys.DOCUMENTS, agreementFormsStepperPaths.documents),
        className: '',
        tabClassName: documents.tab,
        textClassName: documents.tabText,
      },
      {
        text: agreementFormsStepperTitles.review,
        icon: getTabIcon(review.tabText),
        clickHandler: clickHandler(AgreementFormsStepperKeys.REVIEW, agreementFormsStepperPaths.review),
        className: '',
        tabClassName: review.tab,
        textClassName: review.tabText,
      },
    ],
    [
      getTabIcon,
      programType.tabText,
      programType.tab,
      clickHandler,
      agreementDetails.tabText,
      agreementDetails.tab,
      deliveryLocations.tabText,
      deliveryLocations.tab,
      contactGroup.tabText,
      contactGroup.tab,
      documents.tabText,
      documents.tab,
      review.tabText,
      review.tab,
    ],
  );

  return useMemo(() => {
    if (isAuthenticated) {
      return steppersProps.map((val) => (
        <Stepper
          key={val.text}
          text={val.text}
          icon={val.icon}
          clickHandler={val.clickHandler}
          className={val.className}
          tabClassName={val.tabClassName}
          textClassName={val.textClassName}
        />
      ));
    }

    return '';
  }, [isAuthenticated, steppersProps]);
};

export default useFormSteppers;
