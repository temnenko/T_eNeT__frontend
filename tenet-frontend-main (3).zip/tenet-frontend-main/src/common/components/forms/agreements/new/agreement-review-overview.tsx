import {
  GoAButton,
  GoAButtonGroup,
  GoACallout,
  GoAContainer,
  GoAGrid,
  GoAIconButton,
  GoANotification,
  GoASpacer,
  GoATable,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import AgreementReviewCard, { ContactReviewCard, LocationReviewCard } from './agreement-review-cards';
import InlineLoadingIndicator from '../../inline-loading-indicator';
import { AgreementFormsStepperKeys } from '../../../../../types/agreement-forms';
import { useNavigateAgreementStepper } from './hooks/use-navigate-agreement-stepper.hook';
import useActionButton from '../../../../../hooks/use-action-button.hook';
import { useAgreementReviewCards } from './hooks/use-agreement-review-cards.hook';
import { useCompleteAgreement } from './hooks/use-agreement-complete.hook';

const AgreementReview = observer(() => {
  const { cards, agreement, locationCards, contactCards, documents } = useAgreementReviewCards();
  const { jumpToStep } = useNavigateAgreementStepper();
  const {
    creationCompleteHandler,
    loading,
    requestError,
    validationMsg,
    detailsCompleted,
    locationsCompleted,
    programTypeCompleted,
    contactCompleted,
    setValidationMsg,
    agreementCreationCompleted,
  } = useCompleteAgreement();

  return (
    <div className="client-review-overview">
      {validationMsg && !agreementCreationCompleted && (
        <GoACallout type="emergency">
          <>
            <div className="agreement-review-message">
              <h3>Missing information</h3>
              <span>
                <GoAIconButton onClick={() => setValidationMsg('')} icon="close" />
              </span>
            </div>
            <p>{validationMsg}</p>
            <ul>
              {!programTypeCompleted && <li>Program type</li>}
              {!detailsCompleted && <li>Agreement Details</li>}
              {!locationsCompleted && <li>Delivery locations</li>}
              {!contactCompleted && <li>Contact group</li>}
            </ul>
          </>
        </GoACallout>
      )}
      <GoAGrid gap="xl" minChildWidth="350px">
        {cards?.map((aCard) => {
          return (
            <AgreementReviewCard key={aCard.title} title={aCard.title} data={aCard.data} action={aCard.navigate} />
          );
        })}
        {locationCards?.map((aCard) => {
          return <LocationReviewCard key={aCard.title} title={aCard.title} data={aCard.data} action={aCard.navigate} />;
        })}
        {contactCards?.map((aCard) => {
          return <ContactReviewCard key={aCard.title} title={aCard.title} data={aCard.data} action={aCard.navigate} />;
        })}
        <GoAContainer
          heading="Files"
          accent="thick"
          actions={useActionButton(() => jumpToStep(AgreementFormsStepperKeys.DOCUMENTS, agreement!.id))}
          padding="compact"
        >
          <GoATable width="100%">
            <thead>
              <tr>
                <th className="review-filename" data-testid="review_filename">
                  Files
                </th>
                <th className="review-filetype" data-testid="review_filetype">
                  Type
                </th>
                <th className="review-dateadded" data-testid="review_dateHeader">
                  Date Added
                </th>
              </tr>
            </thead>
            <tbody>
              {documents &&
                documents.map((file) => {
                  return (
                    <tr key={`${file.fileName}-${file.createdAt}`}>
                      <td style={{ color: '#0070C4', fontWeight: '400', lineHeight: '28px', width: '40%' }}>
                        {file.fileName}
                      </td>
                      <td style={{ width: '20%' }}>{file.typeName}</td>
                      <td style={{ width: '40%' }}>{file.adspCreatedAt?.substring(0, 10)}</td>
                    </tr>
                  );
                })}
            </tbody>
          </GoATable>
        </GoAContainer>
        <GoASpacer vSpacing="xl" />
        {requestError?.message && (
          <>
            <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
              {requestError.message}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
        <GoASpacer vSpacing="m" />
        <GoAButtonGroup alignment="end">
          <GoAButton type="primary" onClick={creationCompleteHandler} disabled={loading} trailingIcon="arrow-forward">
            {loading ? <InlineLoadingIndicator label="Submitting agreement..." /> : <>Complete</>}
          </GoAButton>
        </GoAButtonGroup>
      </GoAGrid>
    </div>
  );
});

export default AgreementReview;
