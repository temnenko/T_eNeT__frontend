import { useCallback } from 'react';
import { GoABlock, GoAButton, GoAFormItem, GoANotification, GoASpacer, GoAText } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import useAgreementContactGroups from './hooks/use-agreement-contact-groups.hook';
import AutocompleteInput from '../../../auto-complete-input';
import AgreementContactCard from './agreement-contact-card';
import { useModal } from '../../../../../hooks/use-modal.hook';
import { AgreementContactFormModal } from './agreement-contact-form.modal';

interface Props {
  isModal?: boolean;
  hideModal?: () => void;
}

export const AgreementContactGroups = observer(({ isModal, hideModal }: Props) => {
  const { showModal, hideModal: hideFormModal } = useModal();
  const {
    selectedContacts,
    filteredContacts,
    modalContent,
    modalVisible,
    onSelectContact,
    setSearchableField,
    contactSearch,
    nextButtonHandler,
    editContactHandler,
    removeContact,
    makeModalVisible,
    hideVisibleModal,
    noContactsError,
    doneButtonHandler,
  } = useAgreementContactGroups({ hideModal, isModal });

  const addNewContactHandler = useCallback(() => {
    if (!isModal) {
      showModal(<AgreementContactFormModal hideModal={hideFormModal} submitLabel={undefined} />);
    } else {
      makeModalVisible(<AgreementContactFormModal hideModal={hideVisibleModal} submitLabel={undefined} />);
    }
  }, [hideFormModal, hideVisibleModal, isModal, makeModalVisible, showModal]);

  const renderNavigationButton = useCallback(() => {
    return (
      <GoABlock direction="column" alignment="end">
        <GoAButton type="primary" onClick={nextButtonHandler} trailingIcon="arrow-forward">
          Next: Documents
        </GoAButton>
      </GoABlock>
    );
  }, [nextButtonHandler]);

  const renderDoneButton = useCallback(() => {
    return (
      <GoABlock direction="column" alignment="end">
        <GoAButton type="secondary" onClick={doneButtonHandler} trailingIcon="arrow-forward">
          Done
        </GoAButton>
      </GoABlock>
    );
  }, [doneButtonHandler]);

  return (
    <div className="agreement-form">
      {modalVisible && modalContent}
      {noContactsError && (
        <GoANotification type="emergency" ariaLive="assertive">
          At least one contact group is required for the agreement
        </GoANotification>
      )}
      <GoAFormItem
        label="Search and select contacts to add to your agreement."
        mt="s"
        helpText="If there are multiple contacts, you can search and select multiple times."
        mb="3"
      >
        <GoAText mb="2">
          You can select existing contacts that have been added to other agreements with this organization.
        </GoAText>
        <GoAText mb="4">
          If you don’t see the contact person you are looking for upon searching, you will then be prompted to add a new
          contact.
        </GoAText>
        <AutocompleteInput
          name="contactSearch"
          id="contactSearch"
          placeholder=""
          width="100%"
          onSelectAddress={undefined}
          onSelectUser={undefined}
          onSelectSuggestion={onSelectContact}
          value={contactSearch}
          subType=""
          setField={setSearchableField}
          addAction={addNewContactHandler}
          addLabel="Add a contact"
          suggestionData={filteredContacts}
        />
      </GoAFormItem>

      {selectedContacts.map((contact, pos) => (
        <AgreementContactCard
          key={contact.id!}
          contact={contact}
          onRemoveHandler={() => removeContact({ id: contact.id!, pos })}
          onEditHandler={
            contact.canEdit
              ? () => {
                  addNewContactHandler();
                  editContactHandler(pos);
                }
              : undefined
          }
        />
      ))}
      <GoASpacer vSpacing="m" />

      {!isModal && renderNavigationButton()}

      {isModal && renderDoneButton()}

      <GoASpacer vSpacing="m" />
    </div>
  );
});
