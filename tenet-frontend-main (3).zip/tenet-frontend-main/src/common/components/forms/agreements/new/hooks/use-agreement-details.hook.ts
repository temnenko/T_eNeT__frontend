import { useForm } from 'react-hook-form';
import { useCallback, useEffect, useState } from 'react';

import useLoadAgreement from './use-load-agreement.hook';
import { useNavigateAgreementStepper } from './use-navigate-agreement-stepper.hook';
import { AgreementFormsStepperKeys } from '../../../../../../types/agreement-forms';
import {
  Agreement,
  AgreementTargetGroups,
  InterventionCredential,
  UpdateAgreement,
} from '../../../../../../types/agreement';
import { economicRegionLabels, EconomicRegions } from '../../../../../../types/core';
import { SelectionType } from '../../../../multiselect/use-multiselect.hook';
import { communitiesData } from '../lists/communities.data';
import { industryData } from '../lists/industry.data';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { toIsoFormat } from '../../../../../../utils/date.util';

type FormFieldName =
  | 'serviceLanguage'
  | 'name'
  | 'agreementNumber'
  | 'startDate'
  | 'lastIntakeDate'
  | 'endDate'
  | 'activeInterventionLength'
  | 'amendmentOption'
  | 'participantsMaxNumber'
  | 'targetLmdaWdaSplit'
  | 'targetGroups'
  | 'targetSector'
  | 'economicRegions'
  | 'communitiesServed'
  | 'participantsMaxNumber'
  | 'specifyOther'
  | 'interventionCredential';

export type AgreementFormData = {
  serviceLanguage?: string;
  name: string;
  language?: string;
  agreementName?: string;
  agreementNumber?: string;
  startDate?: string;
  lastIntakeDate?: string;
  endDate?: string;
  activeInterventionLength?: number;
  amendmentOption?: string;
  participantsMaxNumber?: number;
  targetLmdaWdaSplit?: string;
  targetGroups?: AgreementTargetGroups[];
  targetSector: string;
  economicRegions: string;
  communitiesServed: string;
  specifyOther: string;
  interventionCredential?: InterventionCredential;
};

const defaultLmdaWdaSplit = '80/20';

interface UseAgreementDetailsInput {
  isModal?: boolean;
  hideModal?: () => void;
  selectedAgreement?: Agreement;
}

const useAgreementDetails = ({ isModal, hideModal }: UseAgreementDetailsInput) => {
  const { agreement } = useLoadAgreement(undefined, isModal ? 'profile' : 'forms');
  const { goToNextStep, setActiveStep } = useNavigateAgreementStepper();
  const [showPleaseSpecify, setShowPleaseSpecify] = useState(false);
  const [selectedItems, setSelectedItems] = useState<SelectionType>({});
  const [selectedTargetSectors, setSelectedTargetSectors] = useState<SelectionType>({});
  const [selectedCommunitiesServed, setSelectedCommunitiesServed] = useState<SelectionType>({});
  const { agreementFormsStore, agreementStore } = useStore();
  const [noIndustrySpecified, setNoIndustrySpecified] = useState(false);

  const validateEconomicRegions = () => {
    return Object.keys(selectedItems).length > 0;
  };

  const validateTargetSectors = () => {
    return noIndustrySpecified || Object.keys(selectedTargetSectors).length > 0;
  };

  const validateCommunitiesServed = () => {
    return Object.keys(selectedCommunitiesServed).length > 0;
  };

  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    reset,
    watch,
    formState: { errors },
  } = useForm<AgreementFormData>({
    defaultValues: {
      targetLmdaWdaSplit: defaultLmdaWdaSplit,
    },
  });

  const initializeSelectedItems = useCallback((economicRegions: EconomicRegions[]): SelectionType => {
    return economicRegions.reduce((acc: SelectionType, region: EconomicRegions) => {
      const label = economicRegionLabels[region];
      if (!acc[label]) {
        acc[label] = new Set();
      }
      acc[label].add({ id: region, value: label });
      return acc;
    }, {});
  }, []);

  const initializeSelectedCommunities = useCallback((communitiesServed: string[]): SelectionType => {
    return communitiesServed.reduce((acc: SelectionType, community: string) => {
      const selectedRegion = communitiesData.find((region) => region.items.some((item) => item.key === community));
      if (selectedRegion) {
        const selectedCommunityKey = selectedRegion.items.find((item) => item.key === community)?.key;
        const selectedCommunityValue = selectedRegion.items.find((item) => item.key === community)?.value;

        if (!acc[selectedRegion.region]) {
          acc[selectedRegion.region] = new Set();
        }
        acc[selectedRegion.region].add({ id: selectedCommunityKey!, value: selectedCommunityValue! });
      }
      return acc;
    }, {});
  }, []);

  const initializeSelectedTargetSectors = useCallback((targetSectors: string[]): SelectionType => {
    return targetSectors.reduce((acc: SelectionType, sector: string) => {
      const selectedRegion = industryData.find((region) => region.items.some((item) => item.key === sector));
      if (selectedRegion) {
        const selectedSectorKey = selectedRegion.items.find((item) => item.key === sector)?.key;
        if (!acc[selectedRegion.region]) {
          acc[selectedRegion.region] = new Set();
        }
        acc[selectedRegion.region].add({ id: selectedSectorKey!, value: sector });
      }
      return acc;
    }, {});
  }, []);

  const { name: serviceLanguage } = register('serviceLanguage', {
    required: { value: true, message: 'Language selection is required' },
  });

  const { name: agreementName } = register('name', {
    required: { value: true, message: 'Agreement name is required' },
  });

  const { name: agreementNumber } = register('agreementNumber', {
    required: { value: true, message: 'Agreement number is required' },
    pattern: {
      value: /^\d+$/,
      message: 'Agreement number must contain numbers only',
    },
  });

  const { name: interventionCredential } = register('interventionCredential');

  const { name: startDate } = register('startDate', {
    required: { value: true, message: 'Agreement start date is required' },
  });

  const { name: lastIntakeDate } = register('lastIntakeDate', {
    required: { value: true, message: 'Agreement intake date is required' },
  });

  const { name: endDate } = register('endDate', {
    required: { value: true, message: 'Agreement end date is required' },
  });

  const { name: activeInterventionLength } = register('activeInterventionLength', {
    required: { value: true, message: 'Active intervention length is required' },
    validate: (value) =>
      parseInt(value?.toString() || '0', 10) >= 0 || 'Active intervention length must be greater than or equal to 0',
  });

  const { name: amendmentOption } = register('amendmentOption', {
    required: { value: true, message: 'Amendment option is required' },
  });

  const { name: participantsMaxNumber } = register('participantsMaxNumber', {
    required: { value: true, message: 'Participants max number is required' },
    validate: (value) => parseInt(value?.toString() || '0', 10) >= 0 || 'Number must be greater than or equal to 0',
  });

  const { name: targetLmdaWdaSplit } = register('targetLmdaWdaSplit', {
    required: { value: true, message: 'Target LMDA/WDA split is required' },
  });

  const { name: specifyOther } = register('specifyOther', {
    required: { value: showPleaseSpecify, message: 'Please specify a value for Other' },
    pattern: {
      value: /^(0\/100|100\/0|[1-9][0-9]?\/[1-9][0-9]?)$/,
      message: 'Please enter as a ratio with a backslash. e.g., 90/10',
    },
  });

  const { name: targetGroups } = register('targetGroups', {
    required: { value: true, message: 'Target group(s) is required' },
  });

  const { name: targetSector } = register('targetSector', {
    validate: () => {
      const isValid = validateTargetSectors();
      return isValid || 'Identify target sector(s) or select “General - No industry specified”';
    },
  });

  const { name: economicRegions } = register('economicRegions', {
    validate: () => {
      const isValid = validateEconomicRegions();
      return isValid || 'Economic region(s) is required';
    },
  });

  const { name: communitiesServed } = register('communitiesServed', {
    validate: () => {
      const isValid = validateCommunitiesServed();
      return isValid || 'Communities served is required';
    },
  });

  const formData = {
    serviceLanguage,
    agreementName,
    agreementNumber,
    startDate,
    lastIntakeDate,
    endDate,
    activeInterventionLength,
    amendmentOption,
    participantsMaxNumber,
    targetLmdaWdaSplit,
    targetGroups,
    targetSector,
    economicRegions,
    communitiesServed,
    specifyOther,
    interventionCredential,
  };

  const onChangeHandler = useCallback(
    (name: string, value: string | string[] | InterventionCredential) => {
      setValue(name as FormFieldName, value as string);
    },
    [setValue],
  );

  const onDateChangeHandler = useCallback(
    (name: string, value: string | undefined) => {
      setValue(name as FormFieldName, value);
    },
    [setValue],
  );

  const onTargetGroupsChangeHandler = useCallback(
    (selectedGroups: AgreementTargetGroups[]) => {
      setValue('targetGroups', selectedGroups);
    },
    [setValue],
  );

  const onMultiSelectChangeHandler = useCallback(
    (name: string, value: string | string[]) => {
      if (value) {
        setValue(name as FormFieldName, value as string);
      } else {
        setValue(name as FormFieldName, '');
      }
    },
    [setValue],
  );

  const onTargetLmdaWdaSplitChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue('targetLmdaWdaSplit', value);
      setShowPleaseSpecify(value === 'other');
    },
    [setValue, setShowPleaseSpecify],
  );

  const agreementDetailsSubmitHandler = useCallback(async () => {
    const payload = getValues();
    const selectedItemsKeys = Object.values(selectedItems)
      .flatMap((set) => Array.from(set))
      .map((item) => item.id);

    const selectedTargetSectorsKeys = Object.values(selectedTargetSectors)
      .flatMap((set) => Array.from(set))
      .map((item) => item.id);

    const selectedCommunitiesKeys = Object.values(selectedCommunitiesServed)
      .flatMap((set) => Array.from(set))
      .map((item) => item.id);
    const agreementPayload = {
      ...payload,
      startDate: payload.startDate ? new Date(payload.startDate) : undefined,
      lastIntakeDate: payload.lastIntakeDate ? new Date(payload.lastIntakeDate) : undefined,
      endDate: payload.endDate ? new Date(payload.endDate) : undefined,
      economicRegions: selectedItemsKeys,
      targetSectors: selectedTargetSectorsKeys,
      communitiesServed: selectedCommunitiesKeys,
      targetLmdaWdaSplit: payload.targetLmdaWdaSplit === 'other' ? payload.specifyOther : payload.targetLmdaWdaSplit,
      specifyOther: undefined,
    };

    if (!isModal) {
      await agreementFormsStore.updateAgreement(agreement!.id, agreementPayload as UpdateAgreement);
      agreementFormsStore.watchAgreement('details', agreementPayload);
      goToNextStep(agreement!.id);
    } else {
      agreementStore.updateAgreement(agreement!.id, agreementPayload as UpdateAgreement);
      hideModal!();
    }
  }, [
    agreement,
    agreementFormsStore,
    agreementStore,
    getValues,
    goToNextStep,
    hideModal,
    isModal,
    selectedCommunitiesServed,
    selectedItems,
    selectedTargetSectors,
  ]);

  const watchIntervetionLength = watch(activeInterventionLength);
  const watchParticipants = watch(participantsMaxNumber);

  const updateInterventionWeeks = useCallback(
    (weeks: number) => {
      let activeInterventionLengthValue = watchIntervetionLength || 0;
      if (typeof activeInterventionLengthValue !== 'number') {
        activeInterventionLengthValue = parseInt(activeInterventionLengthValue, 10);
      }
      const newValue = activeInterventionLengthValue + weeks;
      setValue(activeInterventionLength, newValue < 0 ? 0 : newValue);
    },
    [activeInterventionLength, setValue, watchIntervetionLength],
  );

  const updateMaxParticipants = useCallback(
    (count: number) => {
      let maxParticipantsValue = watchParticipants || 0;
      if (typeof maxParticipantsValue !== 'number') {
        maxParticipantsValue = parseInt(maxParticipantsValue, 10);
      }
      const newValue = maxParticipantsValue + count;
      setValue(participantsMaxNumber, newValue < 0 ? 0 : newValue);
    },
    [participantsMaxNumber, setValue, watchParticipants],
  );

  const onNumericStepperChangeHandler = useCallback(
    (name: string, value: string | string[]) => {
      if (name === activeInterventionLength || name === participantsMaxNumber) {
        const val = parseInt(Number.isNaN(value as string) ? '0' : (value as string), 10);
        setValue(name, val);
      }
    },
    [activeInterventionLength, participantsMaxNumber, setValue],
  );

  const handleNoIndustryCheckboxChange = useCallback(() => {
    setNoIndustrySpecified((prevState) => {
      const newState = !prevState;
      if (newState) {
        setSelectedTargetSectors({});
      }
      return newState;
    });
  }, []);

  const isSelectionTypeEmpty = useCallback((selection: SelectionType) => {
    return Object.keys(selection).length === 0;
  }, []);

  useEffect(() => {
    setActiveStep(AgreementFormsStepperKeys.AGREEMENT_DETAILS);
    if (agreement) {
      setValue('serviceLanguage', agreement?.serviceLanguage);
      setValue('name', agreement?.name || '');
      setValue('agreementNumber', agreement?.agreementNumber);
      setValue('startDate', agreement?.startDate ? toIsoFormat(agreement.startDate) : undefined);
      setValue('lastIntakeDate', agreement?.lastIntakeDate ? toIsoFormat(agreement.lastIntakeDate) : undefined);
      setValue('endDate', agreement?.endDate ? toIsoFormat(agreement.endDate) : undefined);
      setValue('activeInterventionLength', agreement?.activeInterventionLength);
      setValue('amendmentOption', agreement?.amendmentOption || '');
      setValue('participantsMaxNumber', agreement?.participantsMaxNumber);
      setValue('targetGroups', agreement?.targetGroups || []);
      setValue('interventionCredential', agreement?.interventionCredential);

      if (agreement.targetLmdaWdaSplit && agreement.targetLmdaWdaSplit !== defaultLmdaWdaSplit) {
        setValue('specifyOther', agreement.targetLmdaWdaSplit!);
        setValue('targetLmdaWdaSplit', 'other');
        setShowPleaseSpecify(true);
      } else {
        setValue('targetLmdaWdaSplit', agreement?.targetLmdaWdaSplit || defaultLmdaWdaSplit);
      }

      if (agreement.economicRegions) {
        setSelectedItems(initializeSelectedItems(agreement.economicRegions));
      }

      if (agreement.communitiesServed) {
        setSelectedCommunitiesServed(initializeSelectedCommunities(agreement.communitiesServed));
      }

      if (agreement.targetSectors) {
        setSelectedTargetSectors(initializeSelectedTargetSectors(agreement.targetSectors));

        if (agreement.serviceLanguage) {
          setNoIndustrySpecified(!agreement.targetSectors.length);
        }
      }
    } else {
      setValue(targetLmdaWdaSplit, defaultLmdaWdaSplit);
    }
  }, [
    agreement,
    initializeSelectedCommunities,
    initializeSelectedItems,
    initializeSelectedTargetSectors,
    isSelectionTypeEmpty,
    reset,
    setActiveStep,
    setValue,
    targetLmdaWdaSplit,
  ]);

  const setTargetSectorsAndHandleGeneralSectors = useCallback(
    (items: SelectionType) => {
      setSelectedTargetSectors(items);
      setNoIndustrySpecified(isSelectionTypeEmpty(items));
    },
    [isSelectionTypeEmpty],
  );

  return {
    agreementDetailsSubmitHandler,
    formData,
    onChangeHandler,
    register,
    watch,
    errors,
    handleSubmit,
    getValues,
    onDateChangeHandler,
    onTargetGroupsChangeHandler,
    onMultiSelectChangeHandler,
    showPleaseSpecify,
    onTargetLmdaWdaSplitChangeHandler,
    updateInterventionWeeks,
    updateMaxParticipants,
    validateEconomicRegions,
    selectedItems,
    setSelectedItems,
    setTargetSectorsAndHandleGeneralSectors,
    selectedTargetSectors,
    selectedCommunitiesServed,
    setSelectedCommunitiesServed,
    onNumericStepperChangeHandler,
    noIndustrySpecified,
    handleNoIndustryCheckboxChange,
    watchIntervetionLength,
    watchParticipants,
  };
};

export default useAgreementDetails;
