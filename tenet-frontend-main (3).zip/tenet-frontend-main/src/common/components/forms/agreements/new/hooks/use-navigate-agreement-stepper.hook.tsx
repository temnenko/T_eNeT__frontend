import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { AgreementFormsStepperKeys, agreementFormsStepperPaths } from '../../../../../../types/agreement-forms';

export const useNavigateAgreementStepper = () => {
  const navigate = useNavigate();
  const { agreementFormStepperStore } = useStore();

  const setActiveStep = useCallback(
    (stepKey: AgreementFormsStepperKeys) => {
      agreementFormStepperStore.setActiveStep(stepKey);
    },
    [agreementFormStepperStore],
  );

  const goToNextStep = useCallback(
    (assessmentId: string) => {
      const nextStepKey = agreementFormStepperStore.next();
      if (nextStepKey) {
        let nextStepPath = agreementFormsStepperPaths[nextStepKey];
        nextStepPath = nextStepPath.replace(':id', assessmentId);
        navigate(nextStepPath);
      }
    },
    [agreementFormStepperStore, navigate],
  );

  const goToPreviousStep = useCallback(
    (assessmentId: string) => {
      const previousStepKey = agreementFormStepperStore.previous();
      if (previousStepKey) {
        let previousStepPath = agreementFormsStepperPaths[previousStepKey];
        previousStepPath = previousStepPath.replace(':id', assessmentId);
        navigate(previousStepPath);
      }
    },
    [agreementFormStepperStore, navigate],
  );

  const jumpToStep = useCallback(
    (stepKey: AgreementFormsStepperKeys, assessmentId: string) => {
      let stepPath = agreementFormsStepperPaths[stepKey];
      stepPath = stepPath.replace(':id', assessmentId);
      navigate(stepPath);
    },
    [navigate],
  );

  return { goToNextStep, goToPreviousStep, setActiveStep, jumpToStep };
};
