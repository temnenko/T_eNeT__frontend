/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable no-nested-ternary */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';

import { useStore } from '../../../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { CanadaPostAddressFullAddress } from '../../../../../../services/canada-post.service';
import { RequestError } from '../../../../../../types/errors/errors';
import useValidateContactForm from '../../../clients/validations/use-validate-contact-form.hook';
import { LocationArgs } from '../../../../../../types/organization';
import { organizationService } from '../../../../../../services/organizations/organization.service';
import { AddressType } from '../../../../../../types/client';

export type DeliveryLocationFormData = {
  locationName: string;
  streetAddress: string;
  unit?: string;
  city: string;
  province: string;
  postalCode: string;
  country: string;
  phoneNumber?: string;
  emailAddress?: string;
};

export type FormFieldName =
  | 'locationName'
  | 'streetAddress'
  | 'unit'
  | 'city'
  | 'province'
  | 'postalCode'
  | 'country'
  | 'phoneNumber'
  | 'emailAddress';

export type DeliveryAddressFormFieldsType = {
  streetAddress: string;
  unit?: string;
  city: string;
  province: string;
  postalCode: string;
  country: string;
};

export type LocationFormArgs = {
  hideModal?: () => void;
};

const useAgreementLocationForm = ({ hideModal }: LocationFormArgs) => {
  const {
    agreementFormsStore: { editId, selectedLocations, setSelectedLocations, agreement },
    agreementStore: { selectedAgreement },
    organizationStore: { selectedOrganization },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();

  const {
    getValues,
    handleSubmit,
    register,
    unregister,
    reset,
    setValue,
    watch,
    control,
    formState: { errors },
  } = useForm<DeliveryLocationFormData>({
    mode: 'all',
  });

  const { validateStreetAddress, validateCity, validateCountry, validateProvince, validatePostalCode } =
    useValidateContactForm();

  const { name: locationName } = register(`locationName`, {
    required: { value: true, message: 'Location name is required.' },
    pattern: { value: /^[^-\s].*$/, message: 'Name cannot begin with a space' },
    min: 3,
  });

  const { name: streetAddress } = register('streetAddress', {
    required: { value: true, message: 'Street address required' },
    validate: {
      value: (value) => {
        return validateStreetAddress(value);
      },
    },
  });

  const { name: city } = register('city', {
    required: { value: true, message: 'City/town required' },
    validate: (value) => {
      return validateCity(value);
    },
  });

  const { name: unit } = register('unit');

  const { name: province } = register('province', {
    required: { value: true, message: 'Province required' },
    validate: (value) => {
      return validateProvince(value);
    },
  });

  const { name: country } = register('country', {
    required: { value: true, message: 'Country required' },
    validate: (value) => {
      return validateCountry(value);
    },
  });

  const { name: postalCode } = register('postalCode', {
    required: { value: true, message: 'Postal code required' },
    validate: (value) => {
      return validatePostalCode(value, watch(province), watch(country));
    },
  });

  const { name: phoneNumber } = register('phoneNumber', {
    pattern: {
      value: /^\(?\d{3}\)?([\s])?\d{3}([-])?\d{4}$/,
      message: 'Phone number must be valid',
    },
  });

  const { name: emailAddress } = register('emailAddress', {
    pattern: { value: /^\S+@\S+\.\S+$/, message: 'Invalid email address' },
  });

  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const formFields = useMemo(
    () => ({
      locationName,
      streetAddress,
      unit,
      city,
      province,
      postalCode,
      country,
      phoneNumber,
      emailAddress,
      addressType: AddressType.NONE,
    }),
    [city, country, emailAddress, locationName, phoneNumber, postalCode, province, streetAddress, unit],
  );

  const setupLocationForEdit = useCallback(() => {
    if (typeof editId === 'number') {
      const location = selectedLocations[editId];

      setValue('locationName', location.name ?? '');
      setValue('streetAddress', location.street);
      setValue('unit', location.unit);
      setValue('city', location.city);
      setValue('province', location.province);
      setValue('postalCode', location.postalCode);
      setValue('country', location.countryCode);
      setValue('phoneNumber', location.phoneNumber);
      setValue('emailAddress', location.email);
    }
  }, [editId, selectedLocations, setValue]);

  const deliveryLocationSaveHandler = useCallback(async () => {
    const location: LocationArgs = {
      name: getValues('locationName')?.trim(),
      street: getValues('streetAddress')?.trim(),
      unit: getValues('unit')?.trim() || '',
      city: getValues('city')?.trim(),
      province: getValues('province')?.trim(),
      postalCode: getValues('postalCode')?.trim(),
      countryCode: getValues('country')?.trim(),
      phoneNumber: getValues('phoneNumber')?.replace(/\D/g, '').trim(),
      email: getValues('emailAddress')?.trim().toLowerCase(),
    };

    try {
      setRequestError({});
      setLoading(true);

      const organizationId = !hideModal ? selectedAgreement!.organizationId : agreement!.organizationId;
      const isEditId = typeof editId === 'number';
      const result = isEditId
        ? await organizationService.updateLocation(selectedLocations[editId].id, location)
        : await organizationService.createLocation(selectedOrganization?.id ?? organizationId, location);

      if (isEditId) {
        const updated = [...selectedLocations];
        updated.splice(editId, 1, { ...result, canEdit: true });
        setSelectedLocations([...updated]);
      } else {
        setSelectedLocations([...selectedLocations, { ...result, canEdit: true }]);
      }

      reset();
      hideModal && hideModal();
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setLoading(false);
    }
  }, [
    agreement,
    editId,
    getValues,
    hideModal,
    requestErrorHandler,
    reset,
    selectedAgreement,
    selectedLocations,
    selectedOrganization,
    setSelectedLocations,
  ]);

  const onChangeHandler = useCallback(
    (name: string, value: string | Date | undefined) => {
      const processedValue = typeof value === 'string' ? value.trim() : '';
      setValue(name as FormFieldName, processedValue);
    },
    [setValue],
  );

  const onBlurHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value.trim(), { shouldValidate: true });
    },
    [setValue],
  );

  const setSearchableField = useCallback(
    (name: string, value: string) => {
      setValue(name as FormFieldName, value);
    },
    [setValue],
  );

  const onSelectAddress = useCallback(
    (addressData: CanadaPostAddressFullAddress) => {
      const addressValue =
        !addressData.BuildingNumber || !addressData.Street
          ? addressData.Line1
          : `${addressData.BuildingNumber} ${addressData.Street}`;
      setValue(streetAddress, addressValue, {
        shouldValidate: true,
      });
      setValue(unit, addressData.SubBuilding, { shouldValidate: true });
      setValue(city, addressData.City, { shouldValidate: true });
      setValue(province, addressData.Province, { shouldValidate: true });
      setValue(postalCode, addressData.PostalCode, { shouldValidate: true });
      setValue(country, addressData.CountryName, { shouldValidate: true });
    },
    [city, country, postalCode, province, setValue, streetAddress, unit],
  );

  const onErrorDismiss = useCallback(() => {
    setRequestError({});
  }, []);

  useEffect(() => {
    setupLocationForEdit();
  }, [setupLocationForEdit, editId]);

  return {
    loading,
    requestError,
    formFields,
    control,
    getValues,
    watch,
    deliveryLocationSaveHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    register,
    unregister,
    reset,
    onBlurHandler,
    onErrorDismiss,
    setSearchableField,
    onSelectAddress,
  };
};

export default useAgreementLocationForm;
