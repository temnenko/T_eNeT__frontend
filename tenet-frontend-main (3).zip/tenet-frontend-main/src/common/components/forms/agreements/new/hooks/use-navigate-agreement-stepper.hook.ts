import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { AgreementFormsStepperKeys, agreementFormsStepperPaths } from '../../../../../../types/agreement-forms';
import { useStore } from '../../../../../../hooks/use-store.hook';

export const useNavigateAgreementStepper = () => {
  const navigate = useNavigate();
  const { agreementFormStepperStore } = useStore();

  const setActiveStep = useCallback(
    (stepKey: AgreementFormsStepperKeys) => {
      agreementFormStepperStore.setActiveStep(stepKey);
    },
    [agreementFormStepperStore],
  );

  const goToNextStep = useCallback(
    (agreementId: string) => {
      const nextStepKey = agreementFormStepperStore.next();
      if (nextStepKey) {
        let nextStepPath = agreementFormsStepperPaths[nextStepKey];
        nextStepPath = nextStepPath.replace(':id', agreementId);
        navigate(nextStepPath);
      }
    },
    [agreementFormStepperStore, navigate],
  );

  const goToPreviousStep = useCallback(
    (agreementId: string) => {
      const previousStepKey = agreementFormStepperStore.previous();
      if (previousStepKey) {
        let previousStepPath = agreementFormsStepperPaths[previousStepKey];
        previousStepPath = previousStepPath.replace(':id', agreementId);
        navigate(previousStepPath);
      }
    },
    [agreementFormStepperStore, navigate],
  );

  const jumpToStep = useCallback(
    (stepKey: AgreementFormsStepperKeys, agreementId: string) => {
      let stepPath = agreementFormsStepperPaths[stepKey];
      stepPath = stepPath.replace(':id', agreementId);
      navigate(stepPath);
    },
    [navigate],
  );

  return { goToNextStep, goToPreviousStep, setActiveStep, jumpToStep };
};
