import {
  GoABlock,
  GoAButton,
  GoACheckbox,
  GoAFormItem,
  GoAInput,
  GoASpacer,
  GoATextarea,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import useAgreementContactForm, { AgreementContactFormArgs } from './hooks/use-agreement-contact-form.hook';
import { useFormatPhoneInput } from '../../../../../hooks/use-format-phone-input.hook';
import { Contact } from '../../../../../types/organization';

export const NewContactForm = observer(
  ({
    hideModal,
    submitLabel,
    selectedContact,
  }: AgreementContactFormArgs & {
    submitLabel: string | undefined;
    selectedContact?: Contact;
  }) => {
    const {
      formData,
      onChangeHandler,
      errors,
      handleSubmit,
      agreementContactSubmitHandler,
      getValues,
      watch,
      onCheckboxChangeHandler,
    } = useAgreementContactForm({ hideModal, selectedContact });
    const { contactName, role, phoneNumber, extension, emailAddress, note, agreementSignatory } = formData;
    const formatPhoneInput = useFormatPhoneInput();

    return (
      <form>
        <GoASpacer vSpacing="m" />
        <GoAFormItem label="Name of the contact" error={errors.name?.message as unknown as string}>
          <GoAInput width="100%" name={contactName} value={getValues(contactName)} onChange={onChangeHandler} focused />
        </GoAFormItem>
        <GoASpacer vSpacing="xs" />
        <GoACheckbox
          name={agreementSignatory}
          text="This is the agreement signatory"
          value={getValues(agreementSignatory)}
          onChange={onCheckboxChangeHandler}
          checked={watch(agreementSignatory)}
        />

        <GoASpacer vSpacing="s" />
        <GoAFormItem label="Job title" error={errors.role?.message as unknown as string}>
          <GoAInput width="100%" name={role} value={getValues(role)} onChange={onChangeHandler} />
        </GoAFormItem>

        <GoASpacer vSpacing="s" />

        <GoABlock direction="row" gap="xs">
          <GoAFormItem label="Phone number" error={errors.phoneNumber?.message as unknown as string}>
            <GoAInput
              onChange={onChangeHandler}
              name={phoneNumber}
              width="23.32rem"
              value={formatPhoneInput(watch(phoneNumber))}
              leadingContent="+1"
              type="tel"
            />
          </GoAFormItem>
          <GoAFormItem label="ext" error={errors.extension?.message as unknown as string}>
            <GoAInput onChange={onChangeHandler} name={extension} width="10rem" value={getValues(extension)} />
          </GoAFormItem>
        </GoABlock>

        <GoASpacer vSpacing="s" />

        <GoAFormItem label="Email" error={errors.emailAddress?.message as unknown as string}>
          <GoAInput width="100%" name={emailAddress} value={getValues(emailAddress)} onChange={onChangeHandler} />
        </GoAFormItem>

        <GoASpacer vSpacing="s" />

        <GoAFormItem
          label="Note"
          requirement="optional"
          labelSize="regular"
          helpText="Add relevant and helpful notes about this contact person, such as their responsible areas, pronouns etc."
        >
          <GoATextarea name={note} onChange={onChangeHandler} width="100%" value={getValues(note)} />
        </GoAFormItem>

        <GoASpacer vSpacing="m" />

        <GoAButton type="secondary" onClick={handleSubmit(agreementContactSubmitHandler)}>
          {submitLabel ?? 'Save and select contact'}
        </GoAButton>

        <GoASpacer vSpacing="m" />
      </form>
    );
  },
);
