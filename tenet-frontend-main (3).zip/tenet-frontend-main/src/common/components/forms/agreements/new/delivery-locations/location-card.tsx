import { GoABlock, GoAButton, GoASpacer } from '@abgov/react-components';

import { Location } from '../../../../../../types/organization';
import { useFormatPhoneNumber } from '../../../../../../hooks/use-format-phone-number';

type Props = {
  location: Location;
  onRemoveHandler: () => void;
  onEditHandler: (() => void) | undefined;
};

export default function LocationCard({ location: loc, onEditHandler, onRemoveHandler }: Props) {
  const formatPhone = useFormatPhoneNumber();

  return (
    <>
      <GoASpacer vSpacing="m" />
      <div className="location-card">
        <div className="justify-between">
          <div>{loc.name}</div>
          <GoABlock>
            <GoAButton leadingIcon="trash" type="tertiary" onClick={onRemoveHandler}>
              Remove
            </GoAButton>
            {onEditHandler && (
              <GoAButton leadingIcon="pencil" type="secondary" onClick={onEditHandler}>
                Edit
              </GoAButton>
            )}
          </GoABlock>
        </div>
        <GoASpacer vSpacing="3" />
        <GoABlock alignment="start">
          <GoABlock gap="1" direction="column" mr="2">
            <span className="client-bold-600">Address</span>
            <span>{`${loc.street}, ${loc.city} ${loc.province} ${loc.postalCode}`}</span>
          </GoABlock>
          <GoABlock gap="1" direction="column" mr="2">
            <span className="client-bold-600">Phone</span>
            <span>{formatPhone(loc.phoneNumber)}</span>
          </GoABlock>
          <GoABlock gap="1" direction="column">
            <span className="client-bold-600">Email</span>
            <span>{loc.email}</span>
          </GoABlock>
        </GoABlock>
      </div>
    </>
  );
}
