import { ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { search } from 'fast-fuzzy';

import { useNavigateAgreementStepper } from './use-navigate-agreement-stepper.hook';
import { AgreementFormsStepperKeys } from '../../../../../../types/agreement-forms';
import { useStore } from '../../../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';

interface UseAgreementContactGroupsInput {
  isModal?: boolean;
  hideModal?: () => void;
}

const useAgreementContactGroups = ({ isModal, hideModal }: UseAgreementContactGroupsInput) => {
  const { setActiveStep, goToNextStep } = useNavigateAgreementStepper();
  const [contactSearch, setContactSearch] = useState<string>('');
  const [noContactsError, setNoContactsError] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const {
    organizationStore: { selectedOrganization: organization, getOrganizationById },
    agreementFormsStore: {
      agreement,
      selectedContacts,
      editContactId,
      retrieveAgreement,
      watchAgreement,
      setEditContactId,
      setSelectedContacts,
      connectContactsToAgreement,
      disconnectContactsFromAgreement,
      getById,
    },
    agreementStore: { selectedAgreement, connectContactsToAgreement: connectContactsToAgreementForModal },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  const contactsData = useMemo(() => {
    if (organization?.contacts) {
      return organization.contacts;
    }
    return [];
  }, [organization?.contacts]);

  const filteredContacts = useMemo(() => {
    const contactsOnAgreement = isModal && selectedAgreement ? selectedAgreement?.contacts : [];
    const selectedIds = [...contactsOnAgreement, ...selectedContacts].map(({ id }) => id);
    const slimmedContactData = contactsData.filter(({ id }) => !selectedIds.includes(id));

    if (contactSearch) {
      return search(contactSearch, slimmedContactData, {
        keySelector: (obj) => obj.name,
      }).map((val) => ({
        id: val.id!,
        text: val.name,
        isCollection: false,
      }));
    }

    return slimmedContactData.map((val) => ({
      id: val.id!,
      text: val.name,
      isCollection: false,
    }));
  }, [contactSearch, contactsData, isModal, selectedAgreement, selectedContacts]);

  const onSelectContact = useCallback(
    (_id: string) => {
      if (selectedContacts.find(({ id }) => id === _id)) {
        return;
      }

      const updated = [...selectedContacts, contactsData.find(({ id }) => id === _id)!];
      setSelectedContacts(updated);
      watchAgreement('selectedContacts', updated);
      setContactSearch('');
    },
    [contactsData, selectedContacts, setSelectedContacts, watchAgreement],
  );

  const setSearchableField = useCallback((name: string, value: string) => {
    if (name === 'contactSearch') {
      setContactSearch(value);
    }
  }, []);

  const getAddedContacts = useCallback(() => {
    return selectedContacts.map(({ id }) => id!);
  }, [selectedContacts]);

  const doneButtonHandler = useCallback(async () => {
    setNoContactsError(false);
    if (!selectedContacts?.length) {
      setNoContactsError(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    try {
      setRequestError({});
      setLoading(true);

      const addedContactIds = getAddedContacts();
      await connectContactsToAgreementForModal(
        selectedAgreement!.organizationId,
        addedContactIds,
        selectedAgreement!.id!,
      );

      hideModal?.();
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setLoading(false);
    }
  }, [
    connectContactsToAgreementForModal,
    getAddedContacts,
    hideModal,
    requestErrorHandler,
    selectedAgreement,
    selectedContacts?.length,
  ]);

  const nextButtonHandler = useCallback(async () => {
    try {
      setRequestError({});
      setLoading(true);
      if (selectedContacts.length) {
        await connectContactsToAgreement(
          agreement!.organizationId,
          selectedContacts.map((val) => val.id!),
          agreement!.id!,
        );
        setSelectedContacts([]);
        watchAgreement('selectedContacts', undefined);
        setEditContactId(undefined);

        goToNextStep!(agreement!.id);

        return;
      }
      setRequestError({
        message: 'A contact is required to proceed to the next step.',
      });
      setNoContactsError(true);
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setLoading(false);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [
    agreement,
    connectContactsToAgreement,
    goToNextStep,
    requestErrorHandler,
    selectedContacts,
    setEditContactId,
    setSelectedContacts,
    watchAgreement,
  ]);

  const editContactHandler = useCallback(
    (id: number) => {
      setEditContactId(id);
    },
    [setEditContactId],
  );

  const removeContact = useCallback(
    async ({ id, pos }: { pos: number; id: string }) => {
      try {
        setRequestError({});
        const organizationId = hideModal ? selectedAgreement!.organizationId : agreement!.organizationId;
        const agreementId = hideModal ? selectedAgreement!.id : agreement!.id;
        await disconnectContactsFromAgreement(organizationId, [id], agreementId);
        await getById(agreementId);

        const updated = [...selectedContacts];
        updated.splice(pos, 1);
        setSelectedContacts([...updated]);
        watchAgreement('selectedContacts', updated);
      } catch (e) {
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
        // eslint-disable-next-line no-console
        console.error(e);
      }
    },
    [
      agreement,
      disconnectContactsFromAgreement,
      getById,
      hideModal,
      requestErrorHandler,
      selectedAgreement,
      selectedContacts,
      setSelectedContacts,
      watchAgreement,
    ],
  );

  const makeModalVisible = useCallback((content: ReactNode) => {
    setModalVisible(true);
    setModalContent(content);
  }, []);
  const hideVisibleModal = useCallback(() => {
    setModalVisible(false);
    setModalContent(null);
  }, []);

  useEffect(() => {
    if (!isModal && agreement) {
      setSelectedContacts(retrieveAgreement('selectedContacts') ?? agreement.contacts ?? []);
      watchAgreement('selectedContacts', retrieveAgreement('selectedContacts') ?? agreement.contacts ?? undefined);
    } else {
      setSelectedContacts([]);
      watchAgreement('selectedContacts', undefined);
    }

    setEditContactId(undefined);
    if (!organization && agreement) {
      getOrganizationById(agreement.organizationId);
    }
    setActiveStep(AgreementFormsStepperKeys.CONTACT_GROUP);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    agreement,
    organization,
    organization?.contacts?.length,
    setSelectedContacts,
    watchAgreement,
    retrieveAgreement,
    setEditContactId,
  ]);

  return {
    agreement,
    organization,
    contactsData,
    selectedContacts,
    filteredContacts,
    contactSearch,
    editContactId,
    loading,
    requestError,
    modalContent,
    modalVisible,
    makeModalVisible,
    hideVisibleModal,
    onSelectContact,
    setSearchableField,
    setSelectedContacts,
    nextButtonHandler,
    editContactHandler,
    removeContact,
    noContactsError,
    doneButtonHandler,
  };
};

export default useAgreementContactGroups;
