/* eslint-disable jsx-a11y/control-has-associated-label */
import { format } from 'date-fns';
import { GoABlock, GoADropdown, GoADropdownItem, GoAFormItem, GoAIconButton } from '@abgov/react-components';
import { Upload } from '../../../../../../types/files';
import ProgressBar from '../../../../progress-bar/progress-bar';
import { AgreementFileUploadTypes } from '../../../../../../types/agreement-forms';
import { toIsoDate } from '../../../../../../utils/date.util';

type Props = {
  uploads: Upload[];
  progressList: Record<string, number>;
  fileBeingDeleted: string | null;
  deleteHandler: (file: Upload) => void;
  formatFileSize: (bytes: number) => string;
  onFileTypeChange: (name: string, value: string | string[]) => void;
  errorMessage?: string;
};

export function AgreementFilesUploadRow({
  uploads,
  progressList,
  fileBeingDeleted,
  deleteHandler,
  formatFileSize,
  onFileTypeChange,
  errorMessage,
}: Props) {
  return (
    <>
      {uploads.map((upload) => (
        <tr key={`${upload.id}-${progressList[upload.id]}`}>
          <td>
            <GoABlock direction="column" gap="xs">
              <span>{upload.file.name}</span>
              <ProgressBar
                visualParts={[
                  {
                    percentage: progressList[upload.file.name],
                    color: '#004A8F',
                  },
                ]}
              />
            </GoABlock>
          </td>
          <td>
            <GoAFormItem error={upload.fileType === '' && errorMessage}>
              <GoADropdown
                width="200px"
                name={upload.id}
                ariaLabelledBy="fileTypeSelector"
                onChange={(name: string, value: string | string[]) => onFileTypeChange(name, value)}
                value={upload.fileType}
                disabled={upload.persisted}
                relative
              >
                <GoADropdownItem value="" name="selectType" label="-- Select --" />

                <GoADropdownItem
                  value={AgreementFileUploadTypes.AGREEMENTS_AND_SCHEDULES}
                  name="agreements-and-schedules"
                  label="Schedule A"
                />
                <GoADropdownItem
                  value={AgreementFileUploadTypes.AGREEMENT_MONITOR_PLAN}
                  name="agreement-monitor-plan"
                  label="Monitoring Plan"
                />
                <GoADropdownItem
                  value={AgreementFileUploadTypes.AGREEMENT_STAFFING_MATRIX}
                  name="agreement-staffing-matrix"
                  label="Staffing Matrix"
                />
                <GoADropdownItem
                  value={AgreementFileUploadTypes.AGREEMENT_OTHER}
                  name="agreement-other"
                  label="Other"
                />
              </GoADropdown>
            </GoAFormItem>
          </td>
          <td>{format(toIsoDate(upload.createdAt), 'MMM dd, yyyy')}</td>
          <td>{formatFileSize(upload.size)}</td>
          <td>
            <GoAIconButton
              onClick={() => deleteHandler(upload)}
              icon="trash"
              disabled={fileBeingDeleted === upload.adspId}
            />
          </td>
        </tr>
      ))}
    </>
  );
}

AgreementFilesUploadRow.defaultProps = {
  errorMessage: '',
};
