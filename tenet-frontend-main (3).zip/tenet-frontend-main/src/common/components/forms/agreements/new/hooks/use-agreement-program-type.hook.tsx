import { ReactNode, useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { GoASpacer } from '@abgov/react-components';
import useLoadAgreement from './use-load-agreement.hook';
import { AgreementProgramType, CreateAgreement } from '../../../../../../types/agreement';
import { useStore } from '../../../../../../hooks/use-store.hook';
import { useNavigateAgreementStepper } from './use-navigate-agreement-stepper.hook';
import { AgreementFormsStepperKeys } from '../../../../../../types/agreement-forms';
import { useCapitalizeFirstCharOfEveryWord } from '../../../../../../hooks/use-capitalize.hook';

type AgreementProgramTypeData = {
  agreementProgramType: AgreementProgramType;
};

type FormFieldName = 'agreementProgramType';

const useSubmitAgreementType = () => {
  const {
    agreementFormsStore: { watchAgreement, retrieveAgreement, createAgreement },
    organizationStore: { selectedOrganization },
  } = useStore();

  const { agreement } = useLoadAgreement();

  const capitalizeFirst = useCapitalizeFirstCharOfEveryWord();
  const { goToNextStep, setActiveStep } = useNavigateAgreementStepper();

  const {
    getValues,
    handleSubmit,
    register,
    setValue,
    formState: { errors },
    reset,
  } = useForm<AgreementProgramTypeData>({
    defaultValues: {
      agreementProgramType: retrieveAgreement('programType') ?? agreement?.programType,
    },
  });

  const { name: agreementProgramType } = register('agreementProgramType', {
    required: 'Please select an agreement program type',
  });

  const formFields = {
    agreementProgramType,
  };

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setActiveStep(AgreementFormsStepperKeys.PROGRAM_TYPE);
    reset({
      agreementProgramType: retrieveAgreement(agreementProgramType) ?? agreement?.programType,
    });
  }, [agreement?.programType, agreementProgramType, reset, retrieveAgreement, setActiveStep, setValue]);

  const agreementProgramTypeSubmitHandler = useCallback(async () => {
    if (agreement?.id && agreement.programType) {
      goToNextStep(agreement.id);
      return;
    }

    if (selectedOrganization?.id) {
      const agreementProgramTypeData: CreateAgreement = {
        programType: getValues('agreementProgramType') as AgreementProgramType,
        organizationId: selectedOrganization.id,
      };
      setLoading(true);
      let id = agreement?.id;
      try {
        const created = await createAgreement(agreementProgramTypeData);
        id = created!.id;
        goToNextStep(id);
      } catch (error) {
        setLoading(false);
        return;
      } finally {
        setLoading(false);
      }
    }
  }, [agreement?.id, agreement?.programType, selectedOrganization?.id, goToNextStep, getValues, createAgreement]);

  const onChangeHandler = useCallback(
    (name: string, value: AgreementProgramType) => {
      setValue(name as FormFieldName, value);
      watchAgreement(name, value);
    },
    [setValue, watchAgreement],
  );

  const getListItems = <T extends { [key: string]: string }, K extends { [key: string]: string }>(
    obj: T,
    optionalObj?: K,
  ): ReactNode => {
    if (obj) {
      const items = Object.keys(obj).map((key) => {
        if (key !== 'TRANSITION_TO_EMPLOYMENT') {
          const value = obj[key];
          let labels = capitalizeFirst(value.replaceAll('_', ' ').toLowerCase());
          const transtion = labels.toLowerCase().indexOf('transition');
          if (transtion !== -1) {
            labels = `${labels.substring(0, transtion).trim()}/${capitalizeFirst(labels.substring(transtion, labels.length).toLowerCase()).replaceAll('To', 'to')}`;
          } else {
            labels = labels.replaceAll('And', 'and');
          }
          return (
            <>
              <GoASpacer vSpacing="xs" />
              <div key={key}>
                <input type="radio" className="asssessment-employability-p" disabled checked={false} />
                <span className="asssessment-employability-span">{`${labels} (${optionalObj![key]})`}</span>
              </div>
            </>
          );
        }
        return undefined;
      });

      return items;
    }

    return undefined;
  };

  return {
    loading,
    formFields,
    getValues,
    agreementProgramTypeSubmitHandler,
    onChangeHandler,
    handleSubmit,
    errors,
    agreement,
    getListItems,
    capitalizeFirst,
  };
};

export default useSubmitAgreementType;
