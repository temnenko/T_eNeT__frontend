/* eslint-disable @typescript-eslint/no-unused-expressions */
/* eslint-disable no-nested-ternary */
import { ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import { search } from 'fast-fuzzy';

import { useStore } from '../../../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';
import { ConfirmationModal } from '../../../../modals/confirmation.modal';
import { Location } from '../../../../../../types/organization';
import { organizationService } from '../../../../../../services/organizations/organization.service';
import { agreementService } from '../../../../../../services/organizations/agreement.service';

type HookArgs = {
  goToNextStep?: (agreementId: string) => void;
  goToPreviousStep?: (agreementId: string) => void;
  hideModal?: () => void;
};

const useAgreementDeliveryLocation = ({ goToNextStep, goToPreviousStep, hideModal }: HookArgs) => {
  const {
    agreementFormsStore: {
      editId,
      selectedLocations,
      setEditId,
      setSelectedLocations,
      agreement,
      watchAgreement,
      retrieveAgreement,
      updateAgreement,
      getById,
    },
    agreementStore: { selectedAgreement, getAgreementById },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();
  const [locationData, setLocationData] = useState<Location[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const [locationSearch, setLocationSearch] = useState<string>('');

  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});

  const filteredLocations = useMemo(() => {
    const locationsOnAgreement = hideModal && !goToNextStep && selectedAgreement ? selectedAgreement?.locations : [];
    const selectedIds = [...locationsOnAgreement, ...selectedLocations].map(({ id }) => id);
    const slimmedLocationData = locationData.filter(({ id }) => !selectedIds.includes(id));
    const formatLocation = (val: Location) =>
      `${val.name} - ${val.street}, ${val.city} ${val.province} ${val.postalCode}`;

    if (locationSearch) {
      return search(locationSearch, slimmedLocationData, {
        keySelector: (obj) => formatLocation(obj),
      }).map((val) => ({
        id: val.id,
        text: formatLocation(val),
        isCollection: false,
      }));
    }

    return slimmedLocationData.map((val) => ({
      id: val.id,
      text: formatLocation(val),
      isCollection: false,
    }));
  }, [goToNextStep, hideModal, locationData, locationSearch, selectedAgreement, selectedLocations]);

  const editLocationHandler = useCallback(
    (id: number) => {
      setEditId(id);
    },
    [setEditId],
  );

  const getUpdatePayload = useCallback(() => {
    const locationIds = selectedLocations.length ? selectedLocations.map((val) => val.id) : undefined;

    if (!locationIds) {
      setRequestError({
        message: 'Select from existing locations or fill out the form to add a location',
      });
    }

    return {
      locationIds,
      isValid: !!locationIds,
    };
  }, [selectedLocations]);

  const addDeliveryLocation = useCallback(async () => {
    if (selectedAgreement) {
      const { locationIds } = getUpdatePayload();
      try {
        setRequestError({});
        setLoading(true);

        await updateAgreement(selectedAgreement.id, {
          locationIds,
        });
      } catch (e) {
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
      } finally {
        await getAgreementById(selectedAgreement.id);
        setLoading(false);
      }
    }
  }, [getAgreementById, getUpdatePayload, requestErrorHandler, selectedAgreement, updateAgreement]);

  const makeModalVisible = useCallback((content: ReactNode) => {
    setModalVisible(true);
    setModalContent(content);
  }, []);
  const hideVisibleModal = useCallback(() => {
    setModalVisible(false);
    setModalContent(null);
  }, []);

  const addDeliveryLocationHandler = useCallback(() => {
    const { isValid } = getUpdatePayload();

    if (!isValid) {
      return;
    }

    setModalVisible(true);
    setModalContent(
      <ConfirmationModal
        onConfirm={async () => {
          await addDeliveryLocation();
          setModalVisible(false);
          hideModal && hideModal();
        }}
        onDecline={() => setModalVisible(false)}
        heading="Add location"
        description="Are you sure you want to add this delivery location to the selected agreement?"
        loading={loading}
        confirmText="Add"
        declineText="No, go back"
        isDelete={false}
      />,
    );
  }, [addDeliveryLocation, getUpdatePayload, hideModal, loading]);

  const nextButtonClickHandler = useCallback(async () => {
    try {
      setRequestError({});
      setLoading(true);

      if (selectedLocations.length) {
        await updateAgreement(agreement!.id, {
          locationIds: selectedLocations.length ? selectedLocations.map((val) => val.id) : undefined,
        });
        setSelectedLocations([]);
        watchAgreement('selectedLocations', undefined);
        setEditId(undefined);

        goToNextStep!(agreement!.id);

        return;
      }

      setRequestError({
        message: 'A delivery location is required to proceed to the next step.',
      });
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [
    selectedLocations,
    updateAgreement,
    agreement,
    setSelectedLocations,
    watchAgreement,
    setEditId,
    goToNextStep,
    requestErrorHandler,
  ]);

  const removeLocationHandler = useCallback(
    async ({ id, pos }: { pos: number; id: string }) => {
      try {
        setRequestError({});

        const agreementId = goToNextStep ? agreement!.id : selectedAgreement!.id;

        await agreementService.removeLocations(agreementId, [id]);
        await getById(agreementId);

        const updated = [...selectedLocations];
        updated.splice(pos, 1);
        setSelectedLocations([...updated]);
        watchAgreement('selectedLocations', updated);
      } catch (e) {
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
        // eslint-disable-next-line no-console
        console.error(e);
      }
    },
    [
      goToNextStep,
      agreement,
      selectedAgreement,
      getById,
      selectedLocations,
      setSelectedLocations,
      watchAgreement,
      requestErrorHandler,
    ],
  );

  const previousButtonClickHandler = useCallback(() => {
    goToPreviousStep!(agreement!.id);
  }, [agreement, goToPreviousStep]);

  const setSearchableField = useCallback((name: string, value: string) => {
    if (name === 'locationSearch') {
      setLocationSearch(value);
    }
  }, []);

  const onSelectLocation = useCallback(
    (_id: string) => {
      if (selectedLocations.find(({ id }) => id === _id)) {
        return;
      }

      const updated = [...selectedLocations, locationData.find(({ id }) => id === _id)!];
      setSelectedLocations(updated);
      watchAgreement('selectedLocations', updated);
      setLocationSearch('');
    },
    [locationData, selectedLocations, setSelectedLocations, watchAgreement],
  );

  const onErrorDismiss = useCallback(() => {
    setRequestError({});
  }, []);

  useEffect(() => {
    if (goToNextStep) {
      const savedLocations = agreement?.locations?.length ? agreement.locations : undefined;
      setSelectedLocations(retrieveAgreement('selectedLocations') ?? savedLocations ?? []);
      watchAgreement('selectedLocations', retrieveAgreement('selectedLocations') ?? savedLocations ?? undefined);
    } else {
      setSelectedLocations([]);
      watchAgreement('selectedLocations', undefined);
    }

    setEditId(undefined);
    organizationService.getLocations(agreement?.organizationId ?? selectedAgreement!.organizationId).then((data) => {
      setLocationData(data);
    });
  }, [
    agreement,
    agreement?.organizationId,
    goToNextStep,
    retrieveAgreement,
    selectedAgreement,
    setEditId,
    setSelectedLocations,
    watchAgreement,
  ]);

  return {
    locationSearch,
    locationData,
    filteredLocations,
    selectedLocations,
    editId,
    loading,
    requestError,
    modalContent,
    modalVisible,
    removeLocationHandler,
    editLocationHandler,
    addDeliveryLocationHandler,
    nextButtonClickHandler,
    previousButtonClickHandler,
    onErrorDismiss,
    onSelectLocation,
    setEditId,
    setSelectedLocations,
    setSearchableField,
    makeModalVisible,
    hideVisibleModal,
  };
};

export default useAgreementDeliveryLocation;
