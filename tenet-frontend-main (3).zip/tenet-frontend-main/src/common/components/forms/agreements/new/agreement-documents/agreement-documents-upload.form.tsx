import { GoAFileUploadInput, GoAFormItem, GoANotification, GoASpacer, GoATable } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useEffect } from 'react';
import { Upload } from '../../../../../../types/files';
import { AgreementFilesUploadRow } from './agreement-files-upload-row';
import useSubmitAgreementFileUploads from '../hooks/use-submit-agreement-files.hook';
import { InvalidFileUploadError } from '../../../../../../types/errors/invalid-file-upload.error';

type Props = {
  formItemLabel: string;
  newUploadsAvailable?: (uploads: Upload[]) => void;
  invalidUploadError: InvalidFileUploadError | null;
};

export const AgreementFilesUploadForm = observer(
  ({ formItemLabel, newUploadsAvailable, invalidUploadError }: Props) => {
    const {
      uploads,
      progressList,
      deleteFile,
      uploadFile,
      formatBytes,
      onFileTypeChange,
      fileBeingDeleted,
      uploadError,
      setUploadError,
    } = useSubmitAgreementFileUploads();

    useEffect(() => {
      if (newUploadsAvailable) {
        newUploadsAvailable(uploads);
      }
    }, [newUploadsAvailable, uploads]);

    return (
      <form>
        <GoAFormItem label={formItemLabel} requirement="optional">
          <GoAFileUploadInput onSelectFile={uploadFile} maxFileSize="100MB" />
        </GoAFormItem>
        <GoASpacer vSpacing="l" />
        {uploadError && (
          <>
            <GoASpacer vSpacing="l" />
            <GoANotification type="important" onDismiss={() => setUploadError(null)}>
              {uploadError}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
        <GoATable>
          <thead>
            <tr>
              <th data-testid="clientCreationUploadedFiles">Files</th>
              <th data-testid="clientCreationFileType">Type</th>
              <th data-testid="clientCreationFilesDateAdded">Date added</th>
              <th data-testid="clientCreationFileSize">Size</th>
              <th>{}</th>
            </tr>
          </thead>
          <tbody data-testid="clientCreationUploadedFilesTableBody">
            <AgreementFilesUploadRow
              uploads={uploads}
              progressList={progressList}
              deleteHandler={deleteFile}
              formatFileSize={formatBytes}
              onFileTypeChange={onFileTypeChange}
              fileBeingDeleted={fileBeingDeleted}
              errorMessage={invalidUploadError?.message}
            />
          </tbody>
        </GoATable>
        <GoASpacer vSpacing="2xl" />
      </form>
    );
  },
);
