/* eslint-disable no-else-return */
import { useCallback } from 'react';
import { GoABadge, GoABlock, GoAContainer, GoAGrid, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import useActionButton from '../../../../../hooks/use-action-button.hook';

type Props = {
  title: string;
  data: {
    label: string;
    value?: string | number;
  }[];
  action: () => void;
};

type ContactProps = {
  title: string;
  data:
    | {
        name: string;
        title: string;
        phone: string;
        extension?: string;
        email: string;
        isSignatory?: boolean;
        note?: string;
      }[]
    | undefined;
  action: () => void;
};

type LocationProps = {
  title: string;
  data:
    | {
        address: string;
        phone?: string;
        email?: string;
        name: string;
      }[]
    | undefined;
  action: () => void;
};

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const AgreementReviewCard = observer(({ title, data, action }: Props) => {
  const actions = useActionButton(action);
  const getValue = useCallback((args: { label: string; value?: string | number }) => {
    if (args.label !== 'Expected length') {
      return args.value;
    }

    return typeof args.value === 'number' && args.value > 1 ? `${args.value} weeks` : `${args.value ?? 0} week`;
  }, []);

  return (
    <GoAContainer heading={title} accent="thick" actions={actions} padding="compact">
      <GoABlock direction="column">
        {data &&
          data.map((entry) => {
            return (
              <GoAGrid minChildWidth="200px" key={entry?.label} gap="none">
                <div className="client-review-card-label">
                  <span className="color-interactive">{entry?.label}</span>
                </div>
                <div className="client-review-card-value">
                  <span className="client-bold-600">{getValue(entry)}</span>
                </div>
              </GoAGrid>
            );
          })}
      </GoABlock>
    </GoAContainer>
  );
});

export const ContactReviewCard = observer(({ title, data, action }: ContactProps) => {
  const actions = useActionButton(action);
  if (data) {
    const FirstBox = (
      <GoAContainer heading={title} accent="thick" actions={actions} padding="compact">
        <div>
          {data[0] && (
            <>
              <GoABlock gap="m">
                <p>{data[0]?.name}</p>
                {data[0]?.isSignatory && <GoABadge type="information" content="Agreement signatory" />}
              </GoABlock>
              <GoASpacer vSpacing="xs" />
              <GoAGrid minChildWidth="100px" gap="4xl">
                <GoABlock direction="column" alignment="start">
                  <b>Title</b>
                  <span>{data[0]?.title}</span>
                </GoABlock>
                <GoABlock direction="column">
                  <b>Phone</b>
                  <span>{`${data[0]?.phone}`}</span>
                  <span>{data[0]?.extension ? `ext ${data[0]?.extension}` : ''}</span>
                </GoABlock>
                <GoABlock direction="column">
                  <b>Email</b>
                  <span>{data[0]?.email}</span>
                </GoABlock>
              </GoAGrid>
              <GoASpacer vSpacing="l" />
              <GoABlock direction="column">
                <b>Notes</b>
                <span>{data[0]?.note}</span>
              </GoABlock>
            </>
          )}
        </div>
      </GoAContainer>
    );
    if (data?.length > 1) {
      return (
        <GoABlock gap="none" direction="column">
          {FirstBox}
          <GoASpacer vSpacing="xs" />
          {Array.from(data)
            .slice(1)
            .map((entry?) => {
              return (
                <div key={`${entry?.name} - ${entry?.title}`} className="agreement-contact-card">
                  <GoABlock gap="m">
                    <p>{entry?.name}</p>
                    {entry?.isSignatory ? <GoABadge type="information" content="Agreement signatory" /> : undefined}
                  </GoABlock>
                  <GoASpacer vSpacing="xs" />
                  <GoABlock gap="4xl" alignment="start">
                    <GoABlock direction="column">
                      <b>Title</b>
                      <span>{entry?.title}</span>
                    </GoABlock>
                    <GoABlock direction="column">
                      <b>Phone</b>
                      <span>{`${entry?.phone} ext ${entry?.extension}`}</span>
                    </GoABlock>
                    <GoABlock direction="column">
                      <b>Email</b>
                      <span>{entry?.email}</span>
                    </GoABlock>
                  </GoABlock>
                  <GoASpacer vSpacing="l" />
                  <GoABlock direction="column">
                    <b>Notes</b>
                    <span>{entry?.note}</span>
                  </GoABlock>
                </div>
              );
            })}
        </GoABlock>
      );
    }
    return FirstBox;
  } else {
    return <div />;
  }
});

export const LocationReviewCard = observer(({ title, data, action }: LocationProps) => {
  const actions = useActionButton(action);
  if (data) {
    const FirstBox = (
      <GoAContainer heading={title} accent="thick" actions={actions} padding="compact" mb="none">
        <div key={data[0]?.name}>
          {data[0] && (
            <>
              <p>{data[0]?.name}</p>
              <GoAGrid minChildWidth="200px" gap="2xl">
                <GoABlock direction="column" alignment="start">
                  <b>Address</b>
                  <span>{data[0]?.address}</span>
                </GoABlock>
                <GoABlock direction="column">
                  <b>Phone</b>
                  <span>{data[0]?.phone}</span>
                </GoABlock>
                <GoABlock direction="column">
                  <b>Email</b>
                  <span>{data[0]?.email}</span>
                </GoABlock>
              </GoAGrid>
            </>
          )}
        </div>
      </GoAContainer>
    );
    if (data?.length > 1) {
      return (
        <GoABlock gap="none" direction="column">
          {FirstBox}
          <GoASpacer vSpacing="xs" />
          {Array.from(data)
            .slice(1)
            .map((entry?) => {
              return (
                <div key={entry?.name} className="agreement-location-card">
                  <p>{entry?.name}</p>
                  <GoABlock gap="2xl" alignment="start">
                    <GoABlock direction="column">
                      <b>Address</b>
                      <span>{entry?.address}</span>
                    </GoABlock>
                    <GoABlock direction="column">
                      <b>Phone</b>
                      <span>{entry?.phone}</span>
                    </GoABlock>
                    <GoABlock direction="column">
                      <b>Email</b>
                      <span>{entry?.email}</span>
                    </GoABlock>
                  </GoABlock>
                </div>
              );
            })}
        </GoABlock>
      );
    }
    return FirstBox;
  } else {
    return <div />;
  }
});

export default AgreementReviewCard;
