import { GoABadge, GoABlock, GoAButton, GoASpacer } from '@abgov/react-components';
import { useMemo } from 'react';

import { useFormatPhoneNumber } from '../../../../../hooks/use-format-phone-number';
import { Contact } from '../../../../../types/organization';

type Props = {
  contact: Contact;
  onRemoveHandler: () => void;
  onEditHandler: (() => void) | undefined;
};

export default function AgreementContactCard({ contact, onEditHandler, onRemoveHandler }: Props) {
  const formatPhone = useFormatPhoneNumber();
  const phoneNumber = useMemo(() => {
    const formattedPhone = formatPhone(contact.phoneNumber);
    const extension = contact.extension ? `ext ${contact.extension}` : '';

    return `${formattedPhone} ${extension}`;
  }, [contact.extension, contact.phoneNumber, formatPhone]);

  return (
    <>
      <GoASpacer vSpacing="m" />
      <div className="contact-card">
        <div className="justify-between">
          <GoABlock>
            <span>{contact.name}</span>
            {contact.agreementSignatory && <GoABadge type="information" content="Signatory" />}
          </GoABlock>
          <GoABlock>
            <GoAButton leadingIcon="trash" type="tertiary" onClick={onRemoveHandler}>
              Remove
            </GoAButton>
            {onEditHandler && (
              <GoAButton leadingIcon="pencil" type="secondary" onClick={onEditHandler}>
                Edit
              </GoAButton>
            )}
          </GoABlock>
        </div>
        <GoASpacer vSpacing="3" />
        <div className="justify-between">
          <GoABlock gap="1" direction="column">
            <span className="client-bold-600">Title</span>
            <span>{contact.role}</span>
          </GoABlock>
          <GoABlock gap="1" direction="column">
            <span className="client-bold-600">Phone</span>
            <span>{phoneNumber}</span>
          </GoABlock>
          <GoABlock gap="1" direction="column">
            <span className="client-bold-600">Email</span>
            <span>{contact.emailAddress}</span>
          </GoABlock>
        </div>
      </div>
    </>
  );
}
