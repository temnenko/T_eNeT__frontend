import {
  GoABlock,
  GoAButton,
  GoACheckbox,
  GoADropdown,
  GoADropdownItem,
  GoAFormItem,
  GoAGrid,
  GoAIconButton,
  GoAInput,
  GoARadioGroup,
  GoARadioItem,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { AgreementLanguage, AgreementTargetGroupsList, InterventionCredential } from '../../../../../types/agreement';
import useAgreementDetails from './hooks/use-agreement-details.hook';
import MultiSelectDropdown, { MultiSelectDropdownData } from '../../../multiselect/multiselect.component';
import { economicRegionLabels } from '../../../../../types/core';
import { industryData as allIndustryData } from './lists/industry.data';
import { communitiesData as allCommunitiesData } from './lists/communities.data';
import { useStore } from '../../../../../hooks/use-store.hook';
import { toIsoFormat } from '../../../../../utils/date.util';

interface Props {
  isModal?: boolean;
  hideModal?: () => void;
}

export const AgreementDetailsForm = observer(({ isModal, hideModal }: Props) => {
  const {
    agreementStore: { selectedAgreement },
  } = useStore();

  const {
    agreementDetailsSubmitHandler,
    formData,
    onChangeHandler,
    errors,
    watch,
    handleSubmit,
    getValues,
    onDateChangeHandler,
    onTargetGroupsChangeHandler,
    onMultiSelectChangeHandler,
    showPleaseSpecify,
    onTargetLmdaWdaSplitChangeHandler,
    updateInterventionWeeks,
    updateMaxParticipants,
    selectedItems,
    setSelectedItems,
    selectedTargetSectors,
    selectedCommunitiesServed,
    setSelectedCommunitiesServed,
    setTargetSectorsAndHandleGeneralSectors,
    onNumericStepperChangeHandler,
    noIndustrySpecified,
    handleNoIndustryCheckboxChange,
    watchIntervetionLength,
    watchParticipants,
  } = useAgreementDetails({ isModal, hideModal, selectedAgreement });

  const {
    serviceLanguage,
    agreementName,
    agreementNumber,
    startDate,
    lastIntakeDate,
    endDate,
    targetSector,
    communitiesServed,
    activeInterventionLength,
    amendmentOption,
    participantsMaxNumber,
    targetLmdaWdaSplit,
    specifyOther,
    economicRegions,
    interventionCredential,
  } = formData;
  const targetGroups = watch('targetGroups') || [];

  const economicRegionData: MultiSelectDropdownData = [
    {
      region: '',
      items: Object.entries(economicRegionLabels).map(([key, label]) => ({
        key,
        value: label,
      })),
    },
  ];

  const industryData: MultiSelectDropdownData = allIndustryData;

  const communitiesData: MultiSelectDropdownData = allCommunitiesData;

  return (
    <div className={`agreement-form${isModal ? ' relative' : ''}`}>
      <form className={isModal ? 'form-modal' : ''}>
        <GoAFormItem label="Official language of service" error={errors.serviceLanguage?.message as unknown as string}>
          <div>This information is required for LMTA reporting purposes</div>
          <GoASpacer vSpacing="m" />
          <GoARadioGroup
            orientation="vertical"
            name={serviceLanguage}
            value={getValues(serviceLanguage)}
            onChange={onChangeHandler}
          >
            <GoARadioItem value={AgreementLanguage.ENGLISH} label="English" />
            <GoARadioItem value={AgreementLanguage.FRENCH} label="French" />
            <GoARadioItem value={AgreementLanguage.NONE} label="Neither" />
          </GoARadioGroup>
        </GoAFormItem>

        <GoASpacer vSpacing="l" />

        <GoAFormItem label="Agreement name" error={errors.name?.message as unknown as string}>
          <GoAInput name={agreementName} onChange={onChangeHandler} width="100%" value={getValues(agreementName)} />
        </GoAFormItem>

        <GoASpacer vSpacing="l" />

        <GoAFormItem label="Agreement number" error={errors.agreementNumber?.message as unknown as string}>
          <GoAInput
            name={agreementNumber}
            onChange={onChangeHandler}
            width="100%"
            value={getValues(agreementNumber)}
            type="number"
          />
        </GoAFormItem>

        <GoASpacer vSpacing="l" />

        <GoAFormItem label="Does a participant receive a nationally or provincially/territortially recognized certificate after completing the intervention?">
          <GoASpacer vSpacing="m" />
          <GoARadioGroup
            orientation="vertical"
            name={interventionCredential}
            value={getValues(interventionCredential)}
            onChange={onChangeHandler}
          >
            <GoARadioItem value={InterventionCredential.YES} label="Yes" />
            <GoARadioItem value={InterventionCredential.NO} label="No" />
            <GoARadioItem value={InterventionCredential.NOT_APPLICABLE} label="Not applicable" />
          </GoARadioGroup>
        </GoAFormItem>

        <GoASpacer vSpacing="l" />

        <GoAGrid minChildWidth="287px" gap="2">
          <div>
            <GoAFormItem label="Agreement start date" error={errors.startDate?.message as unknown as string}>
              <GoAInput
                type="date"
                name={startDate}
                onChange={onDateChangeHandler}
                value={getValues(startDate) ? toIsoFormat(getValues(startDate)!) : undefined}
                min="0000-01-01"
                max="9999-12-31"
              />
            </GoAFormItem>
          </div>
          <div>
            <GoAFormItem label="Last intake date" error={errors.lastIntakeDate?.message as unknown as string}>
              <GoAInput
                type="date"
                name={lastIntakeDate}
                onChange={onDateChangeHandler}
                value={getValues(lastIntakeDate) ? toIsoFormat(getValues(lastIntakeDate)!) : undefined}
                min="0000-01-01"
                max="9999-12-31"
              />
            </GoAFormItem>
          </div>
          <div>
            <GoAFormItem label="Agreement end date" error={errors.endDate?.message as unknown as string}>
              <GoAInput
                type="date"
                name={endDate}
                onChange={onDateChangeHandler}
                value={getValues(endDate) ? toIsoFormat(getValues(endDate)!) : undefined}
                min="0000-01-01"
                max="9999-12-31"
              />
            </GoAFormItem>
          </div>
        </GoAGrid>

        <GoASpacer vSpacing="l" />

        <GoABlock direction="column">
          <div>
            <strong>Expected length of active intervention (in weeks)</strong>
          </div>
          <div>
            <GoAFormItem error={errors.activeInterventionLength?.message as unknown as string}>
              <div className="d-flex">
                <GoAIconButton icon="remove" size="medium" onClick={() => updateInterventionWeeks(-1)} />
                <GoAInput
                  onChange={onNumericStepperChangeHandler}
                  name={activeInterventionLength}
                  type="text"
                  width="71px"
                  value={watchIntervetionLength?.toString()}
                />
                <GoAIconButton icon="add" size="medium" onClick={() => updateInterventionWeeks(1)} />
              </div>
            </GoAFormItem>
          </div>
        </GoABlock>

        <GoASpacer vSpacing="l" />

        <GoAFormItem
          label="Eligible agreement amendment option"
          error={errors.amendmentOption?.message as unknown as string}
        >
          <GoADropdown
            name={amendmentOption}
            value={getValues(amendmentOption)}
            onChange={onChangeHandler}
            width="100%"
          >
            <GoADropdownItem value="NONE" label="None" />
            <GoADropdownItem value="ONE_YEAR" label="1 Year" />
            <GoADropdownItem value="TWO_YEARS" label="2 Years" />
            <GoADropdownItem value="THREE_YEARS" label="3 Years" />
          </GoADropdown>
        </GoAFormItem>

        <GoASpacer vSpacing="l" />

        <GoABlock direction="column">
          <div>
            <strong>Max number of starting participants</strong>
          </div>
          <div>
            <GoAFormItem error={errors.participantsMaxNumber?.message as unknown as string}>
              <div className="d-flex">
                <GoAIconButton icon="remove" size="medium" onClick={() => updateMaxParticipants(-1)} />
                <GoAInput
                  onChange={onNumericStepperChangeHandler}
                  value={watchParticipants?.toString()}
                  name={participantsMaxNumber}
                  type="text"
                  width="71px"
                />
                <GoAIconButton icon="add" size="medium" onClick={() => updateMaxParticipants(1)} />
              </div>
            </GoAFormItem>
          </div>
        </GoABlock>

        <GoASpacer vSpacing="l" />

        <GoAFormItem label="Target LMDA/WDA split" error={errors.targetLmdaWdaSplit?.message as string}>
          <GoASpacer vSpacing="m" />
          <GoARadioGroup
            orientation="vertical"
            name={targetLmdaWdaSplit}
            value={getValues(targetLmdaWdaSplit)}
            onChange={onTargetLmdaWdaSplitChangeHandler}
          >
            <GoARadioItem value="80/20" label="80/20" />
            <GoARadioItem value="other" label="Other" />
          </GoARadioGroup>
        </GoAFormItem>
        {showPleaseSpecify && (
          <div className="lmda-split-other">
            <GoAFormItem label="Please specify" error={errors.specifyOther?.message as string}>
              <GoAInput name={specifyOther} width="20rem" onChange={onChangeHandler} value={getValues(specifyOther)} />
            </GoAFormItem>
          </div>
        )}

        <GoASpacer vSpacing="l" />

        <GoAFormItem label="Target group(s)" error={errors.targetGroups?.message as string}>
          {AgreementTargetGroupsList.map(({ key, label }) => (
            <GoACheckbox
              key={key}
              name="targetGroups"
              text={label}
              checked={targetGroups.includes(key)} // Use the updated type here
              onChange={() => {
                const updatedGroups = targetGroups.includes(key)
                  ? targetGroups.filter((g) => g !== key)
                  : [...targetGroups, key];
                onTargetGroupsChangeHandler(updatedGroups);
              }}
            />
          ))}
        </GoAFormItem>

        <GoASpacer vSpacing="l" />

        <div>
          <MultiSelectDropdown
            data={industryData}
            selectedItems={selectedTargetSectors}
            setSelectedItems={setTargetSectorsAndHandleGeneralSectors}
            width="100%"
            title="Target sector (NAICS - industry groups)"
            name={targetSector}
            value={getValues(targetSector)}
            onChange={onMultiSelectChangeHandler}
            error={errors.targetSector?.message as string}
          />
          <GoASpacer vSpacing="m" />
          <GoACheckbox
            name="noIndustrySpecified"
            text="General - No industry specified"
            onChange={handleNoIndustryCheckboxChange}
            checked={noIndustrySpecified}
          />
        </div>

        <GoASpacer vSpacing="l" />

        <div>
          <MultiSelectDropdown
            data={economicRegionData}
            selectedItems={selectedItems}
            setSelectedItems={setSelectedItems}
            width="100%"
            title="Select the economic region(s) this location is in"
            name={economicRegions}
            value={getValues(economicRegions)}
            onChange={onMultiSelectChangeHandler}
            error={errors.economicRegions?.message as string}
          />
        </div>
        <GoASpacer vSpacing="l" />

        <div>
          <MultiSelectDropdown
            data={communitiesData}
            selectedItems={selectedCommunitiesServed}
            setSelectedItems={setSelectedCommunitiesServed}
            width="100%"
            title="Communities served"
            name={communitiesServed}
            value={getValues(communitiesServed)}
            onChange={onMultiSelectChangeHandler}
            error={errors.communitiesServed?.message as string}
          />
        </div>

        <GoASpacer vSpacing="xl" />

        <GoABlock alignment="end" direction="column">
          {isModal ? (
            <div className="modalfixed">
              <GoABlock>
                <GoAButton onClick={handleSubmit(agreementDetailsSubmitHandler)} type="primary">
                  Save
                </GoAButton>

                <GoAButton
                  type="secondary"
                  onClick={() => {
                    if (hideModal) hideModal();
                  }}
                >
                  Cancel
                </GoAButton>
              </GoABlock>
            </div>
          ) : (
            <GoAButton onClick={handleSubmit(agreementDetailsSubmitHandler)} type="primary">
              <strong>Next:</strong>
              <span> Delivery locations</span>
            </GoAButton>
          )}
        </GoABlock>
      </form>
    </div>
  );
});
