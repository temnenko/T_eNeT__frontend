import { useCallback, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

import useLoadAgreement from './use-load-agreement.hook';
import { useStore } from '../../../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../../types/errors/errors';
import { InvalidFileUploadError } from '../../../../../../types/errors/invalid-file-upload.error';
import { useNavigateAgreementStepper } from './use-navigate-agreement-stepper.hook';
import { AgreementFormsStepperKeys } from '../../../../../../types/agreement-forms';

const useAgreementDocuments = () => {
  const { id: agreementId } = useParams<{ id: string }>();
  const { agreement } = useLoadAgreement();

  const {
    agreementFilesStore: { uploadAgreementDocuments, getAgreementDocuments, documents },
    agreementFormsStore: { watchAgreement },
  } = useStore();

  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [invalidUploadError, setInvalidUploadError] = useState<InvalidFileUploadError | null>(null);
  const { goToNextStep, setActiveStep, goToPreviousStep } = useNavigateAgreementStepper();

  useEffect(() => {
    if (agreementId || agreement) {
      getAgreementDocuments(agreementId ?? agreement!.id);
    }
  }, [agreement, agreementId, getAgreementDocuments, watchAgreement]);

  const submitHandler = async () => {
    try {
      setInvalidUploadError(null);
      setLoading(true);
      await uploadAgreementDocuments(agreement!.id);
      goToNextStep(agreement!.id);
    } catch (error) {
      if (error instanceof InvalidFileUploadError) {
        setInvalidUploadError(error);
      } else {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setActiveStep(AgreementFormsStepperKeys.DOCUMENTS);
  }, [setActiveStep]);

  const previousButtonClickHandler = useCallback(() => {
    goToPreviousStep(agreement!.id);
  }, [agreement, goToPreviousStep]);

  return {
    submitHandler,
    loading,
    requestError,
    invalidUploadError,
    setInvalidUploadError,
    previousButtonClickHandler,
    getAgreementDocuments,
    agreement,
    documents,
  };
};

export default useAgreementDocuments;
