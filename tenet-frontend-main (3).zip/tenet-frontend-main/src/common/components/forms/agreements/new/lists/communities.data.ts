export const communitiesData = [
  {
    region: 'Airdrie',
    items: [
      {
        key: 'AIRDRIE',
        value: 'Airdrie',
      },
      {
        key: 'MADDEN',
        value: 'Madden',
      },
    ],
  },
  {
    region: 'Athabasca-Sturgeon-Redwater',
    items: [
      {
        key: 'ABEE',
        value: 'Abee',
      },
      {
        key: 'ATHABASCA',
        value: 'Athabasca',
      },
      {
        key: 'ATMORE',
        value: 'Atmore',
      },
      {
        key: 'BON ACCORD',
        value: 'Bon Accord',
      },
      {
        key: 'BOYLE',
        value: 'Boyle',
      },
      {
        key: 'BREYNAT',
        value: 'Breynat',
      },
      {
        key: 'BUFFALO LAKE METIS SETTLEMENT',
        value: 'Buffalo Lake Metis Settlement',
      },
      {
        key: 'CALLING LAKE',
        value: 'Calling Lake',
      },
      {
        key: 'CASLAN',
        value: 'Caslan',
      },
      {
        key: 'COLINTON',
        value: 'Colinton',
      },
      {
        key: 'DONATVILLE',
        value: 'Donatville',
      },
      {
        key: 'EGREMONT',
        value: 'Egremont',
      },
      {
        key: 'ELLSCOTT',
        value: 'Ellscott',
      },
      {
        key: 'GIBBONS',
        value: 'Gibbons',
      },
      {
        key: 'GRASSLAND',
        value: 'Grassland',
      },
      {
        key: 'ISLAND LAKE',
        value: 'Island Lake',
      },
      {
        key: 'ISLAND LAKE SOUTH',
        value: 'Island Lake South',
      },
      {
        key: 'LANCASTER PARK',
        value: 'Lancaster Park',
      },
      {
        key: 'MEANOOK',
        value: 'Meanook',
      },
      {
        key: 'NAMAO',
        value: 'Namao',
      },
      {
        key: 'NEWBROOK',
        value: 'Newbrook',
      },
      {
        key: 'OPAL',
        value: 'Opal',
      },
      {
        key: 'PERRYVALE',
        value: 'Perryvale',
      },
      {
        key: 'RADWAY',
        value: 'Radway',
      },
      {
        key: 'REDWATER',
        value: 'Redwater',
      },
      {
        key: 'ROCHESTER',
        value: 'Rochester',
      },
      {
        key: 'SMOKY LAKE',
        value: 'Smoky Lake',
      },
      {
        key: 'SMOKY LAKE COUNTY',
        value: 'Smoky Lake County',
      },
      {
        key: 'SOUTH BAPTISTE',
        value: 'South Baptiste',
      },
      {
        key: 'STURGEON COUNTY',
        value: 'Sturgeon County',
      },
      {
        key: 'THORHILD',
        value: 'Thorhild',
      },
      {
        key: 'WANDERING RIVER',
        value: 'Wandering River',
      },
      {
        key: 'WARSPITE',
        value: 'Warspite',
      },
      {
        key: 'WASKATENAU',
        value: 'Waskatenau',
      },
      {
        key: 'WEST BAPTISTE',
        value: 'West Baptiste',
      },
      {
        key: 'WHISPERING HILLS',
        value: 'Whispering Hills',
      },
      {
        key: 'WHITE GULL',
        value: 'White Gull',
      },
    ],
  },
  {
    region: 'Banff-Cochrane',
    items: [
      {
        key: 'BANFF',
        value: 'Banff',
      },
      {
        key: 'BRAGG CREEK',
        value: 'Bragg Creek',
      },
      {
        key: 'CANMORE',
        value: 'Canmore',
      },
      {
        key: 'COCHRANE',
        value: 'Cochrane',
      },
      {
        key: "DEAD MAN'S FLATS",
        value: "Dead Man'S Flats",
      },
      {
        key: 'EXSHAW',
        value: 'Exshaw',
      },
      {
        key: 'HARVIE HEIGHTS',
        value: 'Harvie Heights',
      },
      {
        key: 'KANANASKIS',
        value: 'Kananaskis',
      },
      {
        key: 'LAC DES ARCS',
        value: 'Lac Des Arcs',
      },
      {
        key: 'LAKE LOUISE',
        value: 'Lake Louise',
      },
      {
        key: 'MORLEY',
        value: 'Morley',
      },
      {
        key: 'SEEBE',
        value: 'Seebe',
      },
    ],
  },
  {
    region: 'Battle River',
    items: [
      {
        key: 'ALLIANCE',
        value: 'Alliance',
      },
      {
        key: 'ARMENA',
        value: 'Armena',
      },
      {
        key: 'BASHAW',
        value: 'Bashaw',
      },
      {
        key: 'BAWLF',
        value: 'Bawlf',
      },
      {
        key: 'BEAVER COUNTY',
        value: 'Beaver County',
      },
      {
        key: 'BRUCE',
        value: 'Bruce',
      },
      {
        key: 'CAMROSE COUNTY',
        value: 'Camrose County',
      },
      {
        key: 'DAYSLAND',
        value: 'Daysland',
      },
      {
        key: 'EDBERG',
        value: 'Edberg',
      },
      {
        key: 'FERINTOSH',
        value: 'Ferintosh',
      },
      {
        key: 'FORESTBURG',
        value: 'Forestburg',
      },
      {
        key: 'GALAHAD',
        value: 'Galahad',
      },
      {
        key: 'HAY LAKES',
        value: 'Hay Lakes',
      },
      {
        key: 'HEISLER',
        value: 'Heisler',
      },
      {
        key: 'HOLDEN',
        value: 'Holden',
      },
      {
        key: 'KELSEY',
        value: 'Kelsey',
      },
      {
        key: 'KILLAM',
        value: 'Killam',
      },
      {
        key: 'KINGMAN',
        value: 'Kingman',
      },
      {
        key: 'MEETING CREEK',
        value: 'Meeting Creek',
      },
      {
        key: 'NEW NORWAY',
        value: 'New Norway',
      },
      {
        key: 'OHATON',
        value: 'Ohaton',
      },
      {
        key: 'ROSALIND',
        value: 'Rosalind',
      },
      {
        key: 'ROUND HILL',
        value: 'Round Hill',
      },
      {
        key: 'RYLEY',
        value: 'Ryley',
      },
      {
        key: 'STROME',
        value: 'Strome',
      },
    ],
  },
  {
    region: 'Bonnyville-Cold Lake',
    items: [
      {
        key: 'ARDMORE',
        value: 'Ardmore',
      },
      {
        key: 'BONNYVILLE',
        value: 'Bonnyville',
      },
      {
        key: 'BONNYVILLE NO. 87',
        value: 'Bonnyville No. 87',
      },
      {
        key: 'CHERRY GROVE',
        value: 'Cherry Grove',
      },
      {
        key: 'COLD LAKE',
        value: 'Cold Lake',
      },
      {
        key: 'FORT KENT',
        value: 'Fort Kent',
      },
      {
        key: 'GLENDON',
        value: 'Glendon',
      },
      {
        key: 'GOODRIDGE',
        value: 'Goodridge',
      },
      {
        key: 'GRAND CENTRE',
        value: 'Grand Centre',
      },
      {
        key: 'GURNEYVILLE',
        value: 'Gurneyville',
      },
      {
        key: 'HOSELAW',
        value: 'Hoselaw',
      },
      {
        key: 'IRON RIVER',
        value: 'Iron River',
      },
      {
        key: 'KEHEWIN',
        value: 'Kehewin',
      },
      {
        key: 'LA COREY',
        value: 'La Corey',
      },
      {
        key: 'MD OF BONNYVILLE',
        value: 'Md Of Bonnyville',
      },
      {
        key: 'MEDLEY',
        value: 'Medley',
      },
      {
        key: 'SPUTINOW',
        value: 'Sputinow',
      },
      {
        key: 'THERIEN',
        value: 'Therien',
      },
    ],
  },
  {
    region: 'Brooks',
    items: [
      {
        key: 'BASSANO',
        value: 'Bassano',
      },
      {
        key: 'BROOKS',
        value: 'Brooks',
      },
      {
        key: 'DUCHESS',
        value: 'Duchess',
      },
      {
        key: 'GEM',
        value: 'Gem',
      },
      {
        key: 'LAKE NEWELL RESORT',
        value: 'Lake Newell Resort',
      },
      {
        key: 'PATRICIA',
        value: 'Patricia',
      },
      {
        key: 'RAINIER',
        value: 'Rainier',
      },
      {
        key: 'ROLLING HILLS',
        value: 'Rolling Hills',
      },
      {
        key: 'ROSEMARY',
        value: 'Rosemary',
      },
      {
        key: 'SCANDIA',
        value: 'Scandia',
      },
      {
        key: 'TILLEY',
        value: 'Tilley',
      },
    ],
  },
  {
    region: 'Calgary',
    items: [
      {
        key: 'CALGARY',
        value: 'Calgary',
      },
    ],
  },
  {
    region: 'Cardston-Taber-Warner',
    items: [
      {
        key: 'AETNA',
        value: 'Aetna',
      },
      {
        key: 'BARNWELL',
        value: 'Barnwell',
      },
      {
        key: 'CARDSTON',
        value: 'Cardston',
      },
      {
        key: 'CARDSTON NO. 6',
        value: 'Cardston No. 6',
      },
      {
        key: 'COUTTS',
        value: 'Coutts',
      },
      {
        key: 'CRANFORD',
        value: 'Cranford',
      },
      {
        key: 'DEL BONITA',
        value: 'Del Bonita',
      },
      {
        key: 'GLENWOOD',
        value: 'Glenwood',
      },
      {
        key: 'GRASSY LAKE',
        value: 'Grassy Lake',
      },
      {
        key: 'HILL SPRING',
        value: 'Hill Spring',
      },
      {
        key: 'MAGRATH',
        value: 'Magrath',
      },
      {
        key: 'MILK RIVER',
        value: 'Milk River',
      },
      {
        key: 'MOUNTAIN VIEW',
        value: 'Mountain View',
      },
      {
        key: 'NEW DAYTON',
        value: 'New Dayton',
      },
      {
        key: 'PURPLE SPRINGS',
        value: 'Purple Springs',
      },
      {
        key: 'RAYMOND',
        value: 'Raymond',
      },
      {
        key: 'SPRING COULEE',
        value: 'Spring Coulee',
      },
      {
        key: 'STAND OFF',
        value: 'Stand Off',
      },
      {
        key: 'STIRLING',
        value: 'Stirling',
      },
      {
        key: 'TABER',
        value: 'Taber',
      },
      {
        key: 'WARNER',
        value: 'Warner',
      },
      {
        key: 'WATERTON PARK',
        value: 'Waterton Park',
      },
      {
        key: 'WELLING',
        value: 'Welling',
      },
      {
        key: 'WRENTHAM',
        value: 'Wrentham',
      },
    ],
  },
  {
    region: 'Chestermere-Rocky View',
    items: [
      {
        key: 'BALZAC',
        value: 'Balzac',
      },
      {
        key: 'CHESTERMERE',
        value: 'Chestermere',
      },
      {
        key: 'CONRICH',
        value: 'Conrich',
      },
      {
        key: 'DALEMEAD',
        value: 'Dalemead',
      },
      {
        key: 'DELACOUR',
        value: 'Delacour',
      },
      {
        key: 'DALROY',
        value: 'Dalroy',
      },
      {
        key: 'KATHYRN',
        value: 'Kathyrn',
      },
      {
        key: 'KEOMA',
        value: 'Keoma',
      },
      {
        key: 'LANGDON',
        value: 'Langdon',
      },
      {
        key: 'REDWOOD MEADOWS',
        value: 'Redwood Meadows',
      },
      {
        key: 'ROCKY VIEW COUNTY',
        value: 'Rocky View County',
      },
      {
        key: "TSUU T'INA",
        value: "Tsuu T'Ina",
      },
    ],
  },
  {
    region: 'Conklin-Wood Buffalo',
    items: [
      {
        key: 'ANZAC',
        value: 'Anzac',
      },
      {
        key: 'CHARD',
        value: 'Chard',
      },
      {
        key: 'CONKLIN',
        value: 'Conklin',
      },
      {
        key: 'GREGOIRE LAKE ESTATES',
        value: 'Gregoire Lake Estates',
      },
      {
        key: 'FITZGERALD',
        value: 'Fitzgerald',
      },
      {
        key: 'FORT CHIPEWYAN',
        value: 'Fort Chipewyan',
      },
      {
        key: 'FORT MACKAY',
        value: 'Fort Mackay',
      },
      {
        key: 'FORT MCKAY FIRST NATION',
        value: 'Fort Mckay First Nation',
      },
    ],
  },
  {
    region: 'Cypress',
    items: [
      {
        key: 'ADEN',
        value: 'Aden',
      },
      {
        key: 'BOW ISLAND',
        value: 'Bow Island',
      },
      {
        key: 'BURDETT',
        value: 'Burdett',
      },
      {
        key: 'CYPRESS COUNTY',
        value: 'Cypress County',
      },
      {
        key: 'DESERT BLUME',
        value: 'Desert Blume',
      },
      {
        key: 'DUNMORE',
        value: 'Dunmore',
      },
      {
        key: 'ELKWATER',
        value: 'Elkwater',
      },
      {
        key: 'ETZIKOM',
        value: 'Etzikom',
      },
      {
        key: 'FOREMOST',
        value: 'Foremost',
      },
      {
        key: 'HILDA',
        value: 'Hilda',
      },
      {
        key: 'IRVINE',
        value: 'Irvine',
      },
      {
        key: 'MALEB',
        value: 'Maleb',
      },
      {
        key: 'MANYBERRIES',
        value: 'Manyberries',
      },
      {
        key: 'ONEFOUR',
        value: 'Onefour',
      },
      {
        key: 'ORION',
        value: 'Orion',
      },
      {
        key: 'RALSTON',
        value: 'Ralston',
      },
      {
        key: 'REDCLIFF',
        value: 'Redcliff',
      },
      {
        key: 'SCHULER',
        value: 'Schuler',
      },
      {
        key: 'SEVEN PERSONS',
        value: 'Seven Persons',
      },
      {
        key: 'SKIFF',
        value: 'Skiff',
      },
      {
        key: 'WALSH',
        value: 'Walsh',
      },
    ],
  },
  {
    region: 'Drayton Valley-Devon',
    items: [
      {
        key: 'ALDER FLATS',
        value: 'Alder Flats',
      },
      {
        key: 'ALSIKE',
        value: 'Alsike',
      },
      {
        key: 'BRAZEAU COUNTY',
        value: 'Brazeau County',
      },
      {
        key: 'BRAZEAU NO. 77',
        value: 'Brazeau No. 77',
      },
      {
        key: 'BRETON',
        value: 'Breton',
      },
      {
        key: 'BUCK CREEK',
        value: 'Buck Creek',
      },
      {
        key: 'BUCK LAKE',
        value: 'Buck Lake',
      },
      {
        key: 'CALMAR',
        value: 'Calmar',
      },
      {
        key: 'CARNWOOD',
        value: 'Carnwood',
      },
      {
        key: 'CYNTHIA',
        value: 'Cynthia',
      },
      {
        key: 'DEVON',
        value: 'Devon',
      },
      {
        key: 'DRAYTON VALLEY',
        value: 'Drayton Valley',
      },
      {
        key: 'FALUN',
        value: 'Falun',
      },
      {
        key: 'LINDALE',
        value: 'Lindale',
      },
      {
        key: 'LODGEPOLE',
        value: 'Lodgepole',
      },
      {
        key: 'MA-ME-O BEACH',
        value: 'Ma-Me-O Beach',
      },
      {
        key: 'MULHURST BAY',
        value: 'Mulhurst Bay',
      },
      {
        key: 'ROCKY RAPIDS',
        value: 'Rocky Rapids',
      },
      {
        key: 'SUNNYBROOK',
        value: 'Sunnybrook',
      },
      {
        key: 'THORSBY',
        value: 'Thorsby',
      },
      {
        key: 'WARBURG',
        value: 'Warburg',
      },
      {
        key: 'WESTEROSE',
        value: 'Westerose',
      },
      {
        key: 'WETASKIWIN COUNTY NO. 10',
        value: 'Wetaskiwin County No. 10',
      },
      {
        key: 'WINFIELD',
        value: 'Winfield',
      },
    ],
  },
  {
    region: 'Drumheller-Stettler',
    items: [
      {
        key: 'ACADIA VALLEY',
        value: 'Acadia Valley',
      },
      {
        key: 'ALTARIO',
        value: 'Altario',
      },
      {
        key: 'BADLANDS NO. 7',
        value: 'Badlands No. 7',
      },
      {
        key: 'BIG STONE',
        value: 'Big Stone',
      },
      {
        key: 'BIG VALLEY',
        value: 'Big Valley',
      },
      {
        key: 'BINDLOSS',
        value: 'Bindloss',
      },
      {
        key: 'BOTHA',
        value: 'Botha',
      },
      {
        key: 'BROWNFIELD',
        value: 'Brownfield',
      },
      {
        key: 'BUFFALO',
        value: 'Buffalo',
      },
      {
        key: 'BYEMOOR',
        value: 'Byemoor',
      },
      {
        key: 'CASTOR',
        value: 'Castor',
      },
      {
        key: 'CEREAL',
        value: 'Cereal',
      },
      {
        key: 'CESSFORD',
        value: 'Cessford',
      },
      {
        key: 'CHINOOK',
        value: 'Chinook',
      },
      {
        key: 'COMPEER',
        value: 'Compeer',
      },
      {
        key: 'CONSORT',
        value: 'Consort',
      },
      {
        key: 'CORONATION',
        value: 'Coronation',
      },
      {
        key: 'CRAIGMYLE',
        value: 'Craigmyle',
      },
      {
        key: 'DELIA',
        value: 'Delia',
      },
      {
        key: 'DONALDA',
        value: 'Donalda',
      },
      {
        key: 'DOROTHY',
        value: 'Dorothy',
      },
      {
        key: 'DRUMHELLER',
        value: 'Drumheller',
      },
      {
        key: 'EAST COULEE',
        value: 'East Coulee',
      },
      {
        key: 'EMPRESS',
        value: 'Empress',
      },
      {
        key: 'ENDIANG',
        value: 'Endiang',
      },
      {
        key: 'ERSKINE',
        value: 'Erskine',
      },
      {
        key: 'ESTHER',
        value: 'Esther',
      },
      {
        key: 'FENN',
        value: 'Fenn',
      },
      {
        key: 'FINNEGAN',
        value: 'Finnegan',
      },
      {
        key: 'FLEET',
        value: 'Fleet',
      },
      {
        key: 'IDDESLEIGH',
        value: 'Iddesleigh',
      },
      {
        key: 'JENNER',
        value: 'Jenner',
      },
      {
        key: 'KIRRIEMUIR',
        value: 'Kirriemuir',
      },
      {
        key: 'MICHICHI',
        value: 'Michichi',
      },
      {
        key: 'MONITOR',
        value: 'Monitor',
      },
      {
        key: 'MORRIN',
        value: 'Morrin',
      },
      {
        key: 'MUNSON',
        value: 'Munson',
      },
      {
        key: 'NACMINE',
        value: 'Nacmine',
      },
      {
        key: 'NEVIS',
        value: 'Nevis',
      },
      {
        key: 'NEW BRIGDEN',
        value: 'New Brigden',
      },
      {
        key: 'OYEN',
        value: 'Oyen',
      },
      {
        key: 'POLLOCKVILLE',
        value: 'Pollockville',
      },
      {
        key: 'RED WILLOW',
        value: 'Red Willow',
      },
      {
        key: 'ROCHON SANDS',
        value: 'Rochon Sands',
      },
      {
        key: 'ROSEDALE STATION',
        value: 'Rosedale Station',
      },
      {
        key: 'ROWLEY',
        value: 'Rowley',
      },
      {
        key: 'RUMSEY',
        value: 'Rumsey',
      },
      {
        key: 'SEDALIA',
        value: 'Sedalia',
      },
      {
        key: 'SIBBALD',
        value: 'Sibbald',
      },
      {
        key: 'SPECIAL AREA NO. 2',
        value: 'Special Area No. 2',
      },
      {
        key: 'STETTLER',
        value: 'Stettler',
      },
      {
        key: 'SUNNYNOOK',
        value: 'Sunnynook',
      },
      {
        key: 'THRONE',
        value: 'Throne',
      },
      {
        key: 'VETERAN',
        value: 'Veteran',
      },
      {
        key: 'WARDLOW',
        value: 'Wardlow',
      },
      {
        key: 'YOUNGSTOWN',
        value: 'Youngstown',
      },
    ],
  },
  {
    region: 'Dunvegan-Central Peace-Notley',
    items: [
      {
        key: 'BAY TREE',
        value: 'Bay Tree',
      },
      {
        key: 'BEAR CANYON',
        value: 'Bear Canyon',
      },
      {
        key: 'BERWYN',
        value: 'Berwyn',
      },
      {
        key: 'BIRCH HILLS NO. 19',
        value: 'Birch Hills No. 19',
      },
      {
        key: 'BLUEBERRY MOUNTAIN',
        value: 'Blueberry Mountain',
      },
      {
        key: 'BLUESKY',
        value: 'Bluesky',
      },
      {
        key: 'BONANZA',
        value: 'Bonanza',
      },
      {
        key: 'BROWNVALE',
        value: 'Brownvale',
      },
      {
        key: 'CHERRY POINT',
        value: 'Cherry Point',
      },
      {
        key: 'CLEARDALE',
        value: 'Cleardale',
      },
      {
        key: 'DONNELLY',
        value: 'Donnelly',
      },
      {
        key: 'EAGLESHAM',
        value: 'Eaglesham',
      },
      {
        key: 'EUREKA RIVER',
        value: 'Eureka River',
      },
      {
        key: 'FAIRVIEW',
        value: 'Fairview',
      },
      {
        key: 'FALHER',
        value: 'Falher',
      },
      {
        key: 'GIROUXVILLE',
        value: 'Girouxville',
      },
      {
        key: 'GORDONDALE',
        value: 'Gordondale',
      },
      {
        key: 'GRIMSHAW',
        value: 'Grimshaw',
      },
      {
        key: 'GUNDY',
        value: 'Gundy',
      },
      {
        key: 'GUY',
        value: 'Guy',
      },
      {
        key: 'HINES CREEK',
        value: 'Hines Creek',
      },
      {
        key: 'JEAN COTE',
        value: 'Jean Cote',
      },
      {
        key: 'MCLENNAN',
        value: 'Mclennan',
      },
      {
        key: 'RYCROFT',
        value: 'Rycroft',
      },
      {
        key: 'SILVER VALLEY',
        value: 'Silver Valley',
      },
      {
        key: 'SMOKY RIVER NO. 130',
        value: 'Smoky River No. 130',
      },
      {
        key: 'SPIRIT RIVER',
        value: 'Spirit River',
      },
      {
        key: 'TANGENT',
        value: 'Tangent',
      },
      {
        key: 'WANHAM',
        value: 'Wanham',
      },
      {
        key: 'WATINO',
        value: 'Watino',
      },
      {
        key: 'WHITELAW',
        value: 'Whitelaw',
      },
      {
        key: 'WOKING',
        value: 'Woking',
      },
      {
        key: 'WORSLEY',
        value: 'Worsley',
      },
    ],
  },
  {
    region: 'Edmonton and area',
    items: [
      {
        key: 'ACHESON',
        value: 'Acheson',
      },
      {
        key: 'ARDROSSAN',
        value: 'Ardrossan',
      },
      {
        key: 'BEAUMONT',
        value: 'Beaumont',
      },
      {
        key: 'CALAHOO',
        value: 'Calahoo',
      },
      {
        key: 'COOKING LAKE',
        value: 'Cooking Lake',
      },
      {
        key: 'EDMONTON',
        value: 'Edmonton',
      },
      {
        key: 'EDMONTON INTERNATIONAL AIRPORT',
        value: 'Edmonton International Airport',
      },
      {
        key: 'FORT SASKATCHEWAN',
        value: 'Fort Saskatchewan',
      },
      {
        key: 'KAVANAGH',
        value: 'Kavanagh',
      },
      {
        key: 'LEDUC',
        value: 'Leduc',
      },
      {
        key: 'LEDUC COUNTY',
        value: 'Leduc County',
      },
      {
        key: 'NEW SAREPTA',
        value: 'New Sarepta',
      },
      {
        key: 'NISKU',
        value: 'Nisku',
      },
      {
        key: 'NORTH COOKING LAKE',
        value: 'North Cooking Lake',
      },
      {
        key: 'ROLLY VIEW',
        value: 'Rolly View',
      },
      {
        key: 'SHERWOOD PARK',
        value: 'Sherwood Park',
      },
      {
        key: 'SPRUCE GROVE',
        value: 'Spruce Grove',
      },
      {
        key: 'ST. ALBERT',
        value: 'St. Albert',
      },
      {
        key: 'STRATHCONA COUNTY',
        value: 'Strathcona County',
      },
    ],
  },
  {
    region: 'Grande Prairie-Grande Cache',
    items: [
      {
        key: 'BEAVERLODGE',
        value: 'Beaverlodge',
      },
      {
        key: 'BEZANSON',
        value: 'Bezanson',
      },
      {
        key: 'CALAIS',
        value: 'Calais',
      },
      {
        key: 'CLAIRMONT',
        value: 'Clairmont',
      },
      {
        key: 'COUNTY OF GRANDE PRAIRIE NO. 1',
        value: 'County Of Grande Prairie No. 1',
      },
      {
        key: 'CROOKED CREEK',
        value: 'Crooked Creek',
      },
      {
        key: 'DEBOLT',
        value: 'Debolt',
      },
      {
        key: 'DEMMITT',
        value: 'Demmitt',
      },
      {
        key: 'ELMWORTH',
        value: 'Elmworth',
      },
      {
        key: 'GOODFARE',
        value: 'Goodfare',
      },
      {
        key: 'GRANDE CACHE',
        value: 'Grande Cache',
      },
      {
        key: 'GRANDE PRAIRIE',
        value: 'Grande Prairie',
      },
      {
        key: 'GREENVIEW NO. 16',
        value: 'Greenview No. 16',
      },
      {
        key: 'GROVEDALE',
        value: 'Grovedale',
      },
      {
        key: 'HYTHE',
        value: 'Hythe',
      },
      {
        key: 'LA GLACE',
        value: 'La Glace',
      },
      {
        key: 'LITTLE SMOKY',
        value: 'Little Smoky',
      },
      {
        key: 'MD OF GREENVIEW',
        value: 'Md Of Greenview',
      },
      {
        key: 'SADDLE HILLS COUNTY',
        value: 'Saddle Hills County',
      },
      {
        key: 'SEXSMITH',
        value: 'Sexsmith',
      },
      {
        key: 'SUNSET HOUSE',
        value: 'Sunset House',
      },
      {
        key: 'VALHALLA CENTRE',
        value: 'Valhalla Centre',
      },
      {
        key: 'VALLEYVIEW',
        value: 'Valleyview',
      },
      {
        key: 'WEMBLEY',
        value: 'Wembley',
      },
    ],
  },
  {
    region: 'Highwood',
    items: [
      {
        key: 'ALDERSYDE',
        value: 'Aldersyde',
      },
      {
        key: 'BLACK DIAMOND',
        value: 'Black Diamond',
      },
      {
        key: 'CAYLEY',
        value: 'Cayley',
      },
      {
        key: 'DE WINTON',
        value: 'De Winton',
      },
      {
        key: 'EDEN VALLEY',
        value: 'Eden Valley',
      },
      {
        key: 'FOOTHILLS NO. 31',
        value: 'Foothills No. 31',
      },
      {
        key: 'HERITAGE POINTE',
        value: 'Heritage Pointe',
      },
      {
        key: 'HIGH RIVER',
        value: 'High River',
      },
      {
        key: 'LONGVIEW',
        value: 'Longview',
      },
      {
        key: 'MILLARVILLE',
        value: 'Millarville',
      },
      {
        key: 'OKOTOKS',
        value: 'Okotoks',
      },
      {
        key: 'PRIDDIS',
        value: 'Priddis',
      },
      {
        key: 'PRIDDIS GREENS',
        value: 'Priddis Greens',
      },
      {
        key: 'TURNER VALLEY',
        value: 'Turner Valley',
      },
    ],
  },
  {
    region: 'Lac La Biche-St. Paul-Two Hills',
    items: [
      {
        key: 'ASHMONT',
        value: 'Ashmont',
      },
      {
        key: 'BEAUVALLON',
        value: 'Beauvallon',
      },
      {
        key: 'BELLIS',
        value: 'Bellis',
      },
      {
        key: 'BOYNE LAKE',
        value: 'Boyne Lake',
      },
      {
        key: 'BROSSEAU',
        value: 'Brosseau',
      },
      {
        key: 'DERWENT',
        value: 'Derwent',
      },
      {
        key: 'ELK POINT',
        value: 'Elk Point',
      },
      {
        key: 'FOISY',
        value: 'Foisy',
      },
      {
        key: 'FROG LAKE',
        value: 'Frog Lake',
      },
      {
        key: 'GOODFISH LAKE',
        value: 'Goodfish Lake',
      },
      {
        key: 'HAIRY HILL',
        value: 'Hairy Hill',
      },
      {
        key: 'HEINSBURG',
        value: 'Heinsburg',
      },
      {
        key: 'HYLO',
        value: 'Hylo',
      },
      {
        key: 'KIKINO',
        value: 'Kikino',
      },
      {
        key: 'LAC LA BICHE',
        value: 'Lac La Biche',
      },
      {
        key: 'LAFOND',
        value: 'Lafond',
      },
      {
        key: 'LINDBERGH',
        value: 'Lindbergh',
      },
      {
        key: 'MALLAIG',
        value: 'Mallaig',
      },
      {
        key: 'MCRAE',
        value: 'Mcrae',
      },
      {
        key: 'MUSIDORA',
        value: 'Musidora',
      },
      {
        key: 'MYRNAM',
        value: 'Myrnam',
      },
      {
        key: 'PLAMONDON',
        value: 'Plamondon',
      },
      {
        key: 'SADDLE LAKE',
        value: 'Saddle Lake',
      },
      {
        key: 'SPEDDEN',
        value: 'Spedden',
      },
      {
        key: 'ST BRIDES',
        value: 'St Brides',
      },
      {
        key: 'ST LINA',
        value: 'St Lina',
      },
      {
        key: 'ST PAUL',
        value: 'St Paul',
      },
      {
        key: 'ST VINCENT',
        value: 'St Vincent',
      },
      {
        key: 'ST. PAUL COUNTY NO. 19',
        value: 'St. Paul County No. 19',
      },
      {
        key: 'TWO HILLS',
        value: 'Two Hills',
      },
      {
        key: 'VILNA',
        value: 'Vilna',
      },
      {
        key: 'WILLINGDON',
        value: 'Willingdon',
      },
    ],
  },
  {
    region: 'Lesser Slave Lake',
    items: [
      {
        key: 'ATIKAMEG',
        value: 'Atikameg',
      },
      {
        key: 'CADOTTE LAKE',
        value: 'Cadotte Lake',
      },
      {
        key: 'CANYON CREEK',
        value: 'Canyon Creek',
      },
      {
        key: 'DESMARAIS',
        value: 'Desmarais',
      },
      {
        key: 'DRIFTPILE',
        value: 'Driftpile',
      },
      {
        key: 'EAST PEACE NO. 131',
        value: 'East Peace No. 131',
      },
      {
        key: 'ENILDA',
        value: 'Enilda',
      },
      {
        key: 'FAUST',
        value: 'Faust',
      },
      {
        key: 'GIFT LAKE',
        value: 'Gift Lake',
      },
      {
        key: 'GROUARD',
        value: 'Grouard',
      },
      {
        key: 'HIGH PRAIRIE',
        value: 'High Prairie',
      },
      {
        key: 'HONDO',
        value: 'Hondo',
      },
      {
        key: 'JOUSSARD',
        value: 'Joussard',
      },
      {
        key: 'KINUSO',
        value: 'Kinuso',
      },
      {
        key: 'PEERLESS LAKE',
        value: 'Peerless Lake',
      },
      {
        key: 'RED EARTH CREEK',
        value: 'Red Earth Creek',
      },
      {
        key: 'SLAVE LAKE',
        value: 'Slave Lake',
      },
      {
        key: 'SMITH',
        value: 'Smith',
      },
      {
        key: 'TROUT LAKE',
        value: 'Trout Lake',
      },
      {
        key: 'WABASCA',
        value: 'Wabasca',
      },
      {
        key: 'WIDEWATER',
        value: 'Widewater',
      },
    ],
  },
  {
    region: 'Livingstone-Macleod',
    items: [
      {
        key: 'BELLEVUE',
        value: 'Bellevue',
      },
      {
        key: 'BLAIRMORE',
        value: 'Blairmore',
      },
      {
        key: 'BROCKET',
        value: 'Brocket',
      },
      {
        key: 'CLARESHOLM',
        value: 'Claresholm',
      },
      {
        key: 'COLEMAN',
        value: 'Coleman',
      },
      {
        key: 'COWLEY',
        value: 'Cowley',
      },
      {
        key: 'FORT MACLEOD',
        value: 'Fort Macleod',
      },
      {
        key: 'GRANUM',
        value: 'Granum',
      },
      {
        key: 'HILLCREST MINES',
        value: 'Hillcrest Mines',
      },
      {
        key: 'LUNDBRECK',
        value: 'Lundbreck',
      },
      {
        key: 'NANTON',
        value: 'Nanton',
      },
      {
        key: 'PINCHER CREEK',
        value: 'Pincher Creek',
      },
      {
        key: 'STAVELY',
        value: 'Stavely',
      },
      {
        key: 'TWIN BUTTE',
        value: 'Twin Butte',
      },
    ],
  },
  {
    region: 'Medicine Hat',
    items: [
      {
        key: 'MEDICINE HAT',
        value: 'Medicine Hat',
      },
    ],
  },
  {
    region: 'Olds-Didsbury-Three Hills',
    items: [
      {
        key: 'ACME',
        value: 'Acme',
      },
      {
        key: 'BEISEKER',
        value: 'Beiseker',
      },
      {
        key: 'CARBON',
        value: 'Carbon',
      },
      {
        key: 'CARSTAIRS',
        value: 'Carstairs',
      },
      {
        key: 'CREMONA',
        value: 'Cremona',
      },
      {
        key: 'CROSSFIELD',
        value: 'Crossfield',
      },
      {
        key: 'DIDSBURY',
        value: 'Didsbury',
      },
      {
        key: 'HUXLEY',
        value: 'Huxley',
      },
      {
        key: 'IRRICANA',
        value: 'Irricana',
      },
      {
        key: 'KNEEHILL NO. 48',
        value: 'Kneehill No. 48',
      },
      {
        key: 'KNEEHILL COUNTY',
        value: 'Kneehill County',
      },
      {
        key: 'LINDEN',
        value: 'Linden',
      },
      {
        key: 'MOUNTAIN VIEW COUNTY',
        value: 'Mountain View County',
      },
      {
        key: 'OLDS',
        value: 'Olds',
      },
      {
        key: 'SWALWELL',
        value: 'Swalwell',
      },
      {
        key: 'THREE HILLS',
        value: 'Three Hills',
      },
      {
        key: 'TORRINGTON',
        value: 'Torrington',
      },
      {
        key: 'TROCHU',
        value: 'Trochu',
      },
      {
        key: 'WATER VALLEY',
        value: 'Water Valley',
      },
      {
        key: 'WIMBORNE',
        value: 'Wimborne',
      },
    ],
  },
  {
    region: 'Peace River',
    items: [
      {
        key: 'BUFFALO HEAD PRAIRIE',
        value: 'Buffalo Head Prairie',
      },
      {
        key: 'CARCAJOU',
        value: 'Carcajou',
      },
      {
        key: 'CHATEH',
        value: 'Chateh',
      },
      {
        key: 'DEADWOOD',
        value: 'Deadwood',
      },
      {
        key: 'DIXONVILLE',
        value: 'Dixonville',
      },
      {
        key: 'FORT VERMILION',
        value: 'Fort Vermilion',
      },
      {
        key: 'FOX LAKE',
        value: 'Fox Lake',
      },
      {
        key: 'GARDEN RIVER',
        value: 'Garden River',
      },
      {
        key: 'HIGH LEVEL',
        value: 'High Level',
      },
      {
        key: 'HOTCHKISS',
        value: 'Hotchkiss',
      },
      {
        key: "JOHN D'OR PRAIRIE",
        value: "John D'Or Prairie",
      },
      {
        key: 'KEG RIVER',
        value: 'Keg River',
      },
      {
        key: 'LA CRETE',
        value: 'La Crete',
      },
      {
        key: 'MANNING',
        value: 'Manning',
      },
      {
        key: 'MARIE REINE',
        value: 'Marie Reine',
      },
      {
        key: 'MEANDER RIVER',
        value: 'Meander River',
      },
      {
        key: 'NAMPA',
        value: 'Nampa',
      },
      {
        key: 'NORTH STAR',
        value: 'North Star',
      },
      {
        key: 'NORTHERN LIGHTS NO. 22',
        value: 'Northern Lights No. 22',
      },
      {
        key: 'NORTHERN SUNRISE COUNTY',
        value: 'Northern Sunrise County',
      },
      {
        key: 'NOTIKEWIN',
        value: 'Notikewin',
      },
      {
        key: 'PADDLE PRAIRIE',
        value: 'Paddle Prairie',
      },
      {
        key: 'PEACE RIVER',
        value: 'Peace River',
      },
      {
        key: 'RAINBOW LAKE',
        value: 'Rainbow Lake',
      },
      {
        key: 'ST ISIDORE',
        value: 'St Isidore',
      },
      {
        key: 'ZAMA CITY',
        value: 'Zama City',
      },
    ],
  },
  {
    region: 'Red Deer and area',
    items: [
      {
        key: 'BLACKFALDS',
        value: 'Blackfalds',
      },
      {
        key: 'HALF MOON BAY',
        value: 'Half Moon Bay',
      },
      {
        key: 'INNISFAIL',
        value: 'Innisfail',
      },
      {
        key: 'LACOMBE',
        value: 'Lacombe',
      },
      {
        key: 'MYNARSKI PARK',
        value: 'Mynarski Park',
      },
      {
        key: 'NORGLENWOLD',
        value: 'Norglenwold',
      },
      {
        key: 'PENHOLD',
        value: 'Penhold',
      },
      {
        key: 'RED DEER',
        value: 'Red Deer',
      },
      {
        key: 'SPRINGBROOK',
        value: 'Springbrook',
      },
      {
        key: 'SYLVAN LAKE',
        value: 'Sylvan Lake',
      },
    ],
  },
  {
    region: 'Rimbey-Rocky Mountain House-Sundre',
    items: [
      {
        key: 'ALHAMBRA',
        value: 'Alhambra',
      },
      {
        key: 'BENALTO',
        value: 'Benalto',
      },
      {
        key: 'BENTLEY',
        value: 'Bentley',
      },
      {
        key: 'BLUFFTON',
        value: 'Bluffton',
      },
      {
        key: 'CAROLINE',
        value: 'Caroline',
      },
      {
        key: 'CONDOR',
        value: 'Condor',
      },
      {
        key: 'ECKVILLE',
        value: 'Eckville',
      },
      {
        key: 'JAMES RIVER BRIDGE',
        value: 'James River Bridge',
      },
      {
        key: 'LESLIEVILLE',
        value: 'Leslieville',
      },
      {
        key: 'NORDEGG',
        value: 'Nordegg',
      },
      {
        key: 'RIMBEY',
        value: 'Rimbey',
      },
      {
        key: 'ROCKY MOUNTAIN HOUSE',
        value: 'Rocky Mountain House',
      },
      {
        key: 'STAUFFER',
        value: 'Stauffer',
      },
      {
        key: 'SUNDRE',
        value: 'Sundre',
      },
    ],
  },
  {
    region: 'Rural Red Deer',
    items: [
      {
        key: 'ALIX',
        value: 'Alix',
      },
      {
        key: 'BOWDEN',
        value: 'Bowden',
      },
      {
        key: 'CLIVE',
        value: 'Clive',
      },
      {
        key: 'COLLEGE HEIGHTS',
        value: 'College Heights',
      },
      {
        key: 'DELBURNE',
        value: 'Delburne',
      },
      {
        key: 'DICKSON',
        value: 'Dickson',
      },
      {
        key: 'ELNORA',
        value: 'Elnora',
      },
      {
        key: 'LACOMBE COUNTY',
        value: 'Lacombe County',
      },
      {
        key: 'LOUSANA',
        value: 'Lousana',
      },
      {
        key: 'MARKERVILLE',
        value: 'Markerville',
      },
      {
        key: 'MIRROR',
        value: 'Mirror',
      },
      {
        key: 'PINE LAKE',
        value: 'Pine Lake',
      },
      {
        key: 'PONOKA',
        value: 'Ponoka',
      },
      {
        key: 'PONOKA COUNTY NO. 3',
        value: 'Ponoka County No. 3',
      },
      {
        key: 'RED DEER COUNTY',
        value: 'Red Deer County',
      },
      {
        key: 'ROSEDALE VALLEY',
        value: 'Rosedale Valley',
      },
      {
        key: 'SPRUCE VIEW',
        value: 'Spruce View',
      },
      {
        key: 'TEES',
        value: 'Tees',
      },
    ],
  },
  {
    region: 'Stony Plain',
    items: [
      {
        key: 'CARVEL',
        value: 'Carvel',
      },
      {
        key: 'DUFFIELD',
        value: 'Duffield',
      },
      {
        key: 'ENOCH',
        value: 'Enoch',
      },
      {
        key: 'KAPASIWIN',
        value: 'Kapasiwin',
      },
      {
        key: 'PARKLAND COUNTY',
        value: 'Parkland County',
      },
      {
        key: 'SEBA BEACH',
        value: 'Seba Beach',
      },
      {
        key: 'SPRING LAKE',
        value: 'Spring Lake',
      },
      {
        key: 'STONY PLAIN',
        value: 'Stony Plain',
      },
      {
        key: 'TOMAHAWK',
        value: 'Tomahawk',
      },
      {
        key: 'WABAMUN',
        value: 'Wabamun',
      },
      {
        key: 'WINTERBURN',
        value: 'Winterburn',
      },
    ],
  },
  {
    region: 'Strathmore',
    items: [
      {
        key: 'CARSELAND',
        value: 'Carseland',
      },
      {
        key: 'CLUNY',
        value: 'Cluny',
      },
      {
        key: 'GLEICHEN',
        value: 'Gleichen',
      },
      {
        key: 'HUSSAR',
        value: 'Hussar',
      },
      {
        key: 'LYALTA',
        value: 'Lyalta',
      },
      {
        key: 'ROCKYFORD',
        value: 'Rockyford',
      },
      {
        key: 'ROSEBUD',
        value: 'Rosebud',
      },
      {
        key: 'STANDARD',
        value: 'Standard',
      },
      {
        key: 'STRATHMORE',
        value: 'Strathmore',
      },
      {
        key: 'WHEATLAND COUNTY',
        value: 'Wheatland County',
      },
    ],
  },
  {
    region: 'Vegreville',
    items: [
      {
        key: 'ANDREW',
        value: 'Andrew',
      },
      {
        key: 'BRUDERHEIM',
        value: 'Bruderheim',
      },
      {
        key: 'CHIPMAN',
        value: 'Chipman',
      },
      {
        key: 'HILLIARD',
        value: 'Hilliard',
      },
      {
        key: 'LAMONT',
        value: 'Lamont',
      },
      {
        key: 'LAVOY',
        value: 'Lavoy',
      },
      {
        key: 'MUNDARE',
        value: 'Mundare',
      },
      {
        key: 'ST MICHAEL',
        value: 'St Michael',
      },
      {
        key: 'STAR',
        value: 'Star',
      },
      {
        key: 'TOFIELD',
        value: 'Tofield',
      },
      {
        key: 'VEGREVILLE',
        value: 'Vegreville',
      },
      {
        key: 'WOSTOK',
        value: 'Wostok',
      },
    ],
  },
  {
    region: 'Vermilion-Lloydminster-Wainwright',
    items: [
      {
        key: 'AMISK',
        value: 'Amisk',
      },
      {
        key: 'BLACKFOOT',
        value: 'Blackfoot',
      },
      {
        key: 'BODO',
        value: 'Bodo',
      },
      {
        key: 'CADOGAN',
        value: 'Cadogan',
      },
      {
        key: 'CHAUVIN',
        value: 'Chauvin',
      },
      {
        key: 'CLANDONALD',
        value: 'Clandonald',
      },
      {
        key: 'CZAR',
        value: 'Czar',
      },
      {
        key: 'DENWOOD',
        value: 'Denwood',
      },
      {
        key: 'DEWBERRY',
        value: 'Dewberry',
      },
      {
        key: 'EDGERTON',
        value: 'Edgerton',
      },
      {
        key: 'HARDISTY',
        value: 'Hardisty',
      },
      {
        key: 'HAYTER',
        value: 'Hayter',
      },
      {
        key: 'HEATH',
        value: 'Heath',
      },
      {
        key: 'HUGHENDEN',
        value: 'Hughenden',
      },
      {
        key: 'INNISFREE',
        value: 'Innisfree',
      },
      {
        key: 'IRMA',
        value: 'Irma',
      },
      {
        key: 'ISLAY',
        value: 'Islay',
      },
      {
        key: 'KINSELLA',
        value: 'Kinsella',
      },
      {
        key: 'KITSCOTY',
        value: 'Kitscoty',
      },
      {
        key: 'LLOYDMINSTER',
        value: 'Lloydminster',
      },
      {
        key: 'LOUGHEED',
        value: 'Lougheed',
      },
      {
        key: 'MANNVILLE',
        value: 'Mannville',
      },
      {
        key: 'MARWAYNE',
        value: 'Marwayne',
      },
      {
        key: 'MCLAUGHLIN',
        value: 'Mclaughlin',
      },
      {
        key: 'METISKOW',
        value: 'Metiskow',
      },
      {
        key: 'MINBURN',
        value: 'Minburn',
      },
      {
        key: 'PARADISE VALLEY',
        value: 'Paradise Valley',
      },
      {
        key: 'PROVOST',
        value: 'Provost',
      },
      {
        key: 'RANFURLY',
        value: 'Ranfurly',
      },
      {
        key: 'RIBSTONE',
        value: 'Ribstone',
      },
      {
        key: 'RIVERCOURSE',
        value: 'Rivercourse',
      },
      {
        key: 'SEDGEWICK',
        value: 'Sedgewick',
      },
      {
        key: 'STREAMSTOWN',
        value: 'Streamstown',
      },
      {
        key: 'TULLIBY LAKE',
        value: 'Tulliby Lake',
      },
      {
        key: 'VERMILION',
        value: 'Vermilion',
      },
      {
        key: 'VERMILION RIVER COUNTY NO. 24',
        value: 'Vermilion River County No. 24',
      },
      {
        key: 'VIKING',
        value: 'Viking',
      },
      {
        key: 'WAINWRIGHT',
        value: 'Wainwright',
      },
      {
        key: 'WAINWRIGHT NO. 61',
        value: 'Wainwright No. 61',
      },
    ],
  },
  {
    region: 'West Yellowhead',
    items: [
      {
        key: 'BRULE',
        value: 'Brule',
      },
      {
        key: 'CADOMIN',
        value: 'Cadomin',
      },
      {
        key: 'EDSON',
        value: 'Edson',
      },
      {
        key: 'HINTON',
        value: 'Hinton',
      },
      {
        key: 'JASPER',
        value: 'Jasper',
      },
      {
        key: 'MARLBORO',
        value: 'Marlboro',
      },
      {
        key: 'ROBB',
        value: 'Robb',
      },
      {
        key: 'YELLOWHEAD COUNTY',
        value: 'Yellowhead County',
      },
    ],
  },
  {
    region: 'Wetaskiwin-Camrose',
    items: [
      {
        key: 'BITTERN LAKE',
        value: 'Bittern Lake',
      },
      {
        key: 'CAMROSE',
        value: 'Camrose',
      },
      {
        key: 'GWYNNE',
        value: 'Gwynne',
      },
      {
        key: 'MASKWACIS',
        value: 'Maskwacis',
      },
      {
        key: 'MILLET',
        value: 'Millet',
      },
      {
        key: 'WETASKIWIN',
        value: 'Wetaskiwin',
      },
    ],
  },
  {
    region: 'Whitecourt-Ste. Anne',
    items: [
      {
        key: 'ALBERTA BEACH',
        value: 'Alberta Beach',
      },
      {
        key: 'BLUE RIDGE',
        value: 'Blue Ridge',
      },
      {
        key: 'CARROT CREEK',
        value: 'Carrot Creek',
      },
      {
        key: 'CHERHILL',
        value: 'Cherhill',
      },
      {
        key: 'DARWELL',
        value: 'Darwell',
      },
      {
        key: 'ENTWISTLE',
        value: 'Entwistle',
      },
      {
        key: 'EVANSBURG',
        value: 'Evansburg',
      },
      {
        key: 'FALLIS',
        value: 'Fallis',
      },
      {
        key: 'FOX CREEK',
        value: 'Fox Creek',
      },
      {
        key: 'GAINFORD',
        value: 'Gainford',
      },
      {
        key: 'GLENEVIS',
        value: 'Glenevis',
      },
      {
        key: 'GREEN COURT',
        value: 'Green Court',
      },
      {
        key: 'GUNN',
        value: 'Gunn',
      },
      {
        key: 'LAC STE. ANNE COUNTY',
        value: 'Lac Ste. Anne County',
      },
      {
        key: 'LAKE ISLE',
        value: 'Lake Isle',
      },
      {
        key: 'MAYERTHORPE',
        value: 'Mayerthorpe',
      },
      {
        key: 'NITON JUNCTION',
        value: 'Niton Junction',
      },
      {
        key: 'ONOWAY',
        value: 'Onoway',
      },
      {
        key: 'PEERS',
        value: 'Peers',
      },
      {
        key: 'ROCHFORT BRIDGE',
        value: 'Rochfort Bridge',
      },
      {
        key: 'SANGUDO',
        value: 'Sangudo',
      },
      {
        key: 'SUNRISE BEACH',
        value: 'Sunrise Beach',
      },
      {
        key: 'WHITECOURT',
        value: 'Whitecourt',
      },
      {
        key: 'WILDWOOD',
        value: 'Wildwood',
      },
      {
        key: 'WOODLANDS COUNTY',
        value: 'Woodlands County',
      },
      {
        key: 'YELLOWSTONE',
        value: 'Yellowstone',
      },
    ],
  },
  {
    region: 'Barrhead-Morinville-Westlock',
    items: [
      {
        key: 'ALCOMDALE',
        value: 'Alcomdale',
      },
      {
        key: 'BARRHEAD',
        value: 'Barrhead',
      },
      {
        key: 'BARRHEAD COUNTY NO. 11',
        value: 'Barrhead Country No. 11',
      },
      {
        key: 'BLOOMSBURY',
        value: 'Bloomsbury',
      },
      {
        key: 'BUSBY',
        value: 'Busby',
      },
      {
        key: 'CAMP CREEK',
        value: 'Camp Creek',
      },
      {
        key: 'CHISOM',
        value: 'Chisom',
      },
      {
        key: 'CHISHOLM MILLS',
        value: 'Chisom Hills',
      },
      {
        key: 'CLYDE',
        value: 'Clyde',
      },
      {
        key: 'DAPP',
        value: 'Dapp',
      },
      {
        key: 'FAWCETT',
        value: 'Flatbush',
      },
      {
        key: 'FLATBUSH',
        value: 'Flatbush',
      },
      {
        key: 'FORT ASSINIBOINE',
        value: 'Fort Assinboine',
      },
      {
        key: 'JARVIE',
        value: 'Jarvie',
      },
      {
        key: 'LEGAL',
        value: 'Legal',
      },
      {
        key: 'LONE PINE',
        value: 'Lone Pine',
      },
      {
        key: 'MORINVILLE',
        value: 'Morinville',
      },
      {
        key: 'NEERLANDIA',
        value: 'Neerlandia',
      },
      {
        key: 'NESTOW',
        value: 'Nestow',
      },
      {
        key: 'PICKARDVILLE',
        value: 'Pickardville',
      },
      {
        key: 'RIVIERE QUI BARRE',
        value: 'Rivere Qui Barre',
      },
      {
        key: 'SWAN HILLS',
        value: 'Swan Hills',
      },
      {
        key: 'TAWATINAW',
        value: 'Tawatinaw',
      },
      {
        key: 'TIGER LILY',
        value: 'Tiger Lily',
      },
      {
        key: 'VEGA',
        value: 'Vega',
      },
      {
        key: 'VIMY',
        value: 'Vimy',
      },
      {
        key: 'WESTOCK',
        value: 'Westock',
      },
      {
        key: 'WESTLOCK COUNTY',
        value: 'Westlock County',
      },
    ],
  },
  {
    region: 'Fort McMurray',
    items: [
      {
        key: 'FORT MCMURRAY',
        value: 'Fort McMurray',
      },
    ],
  },
  {
    region: 'Lethbridge',
    items: [
      {
        key: 'LETHBRIDGE',
        value: 'Lethbridge',
      },
    ],
  },
  {
    region: 'Little Bow',
    items: [
      {
        key: 'ARROWWOOD',
        value: 'Arrowwood',
      },
      {
        key: 'BARONS',
        value: 'Barons',
      },
      {
        key: 'BLACKIE',
        value: 'Blackie',
      },
      {
        key: 'BRANT',
        value: 'Brant',
      },
      {
        key: 'CARMANGAY',
        value: 'Carmangay',
      },
      {
        key: 'CHAMPION',
        value: 'Champion',
      },
      {
        key: 'COALDALE',
        value: 'Coaldale',
      },
      {
        key: 'COALHURST',
        value: 'Coalhurst',
      },
      {
        key: 'DIAMOND CITY',
        value: 'Diamond City',
      },
      {
        key: 'ENCHANT',
        value: 'Enchant',
      },
      {
        key: 'ENSIGN',
        value: 'Ensign',
      },
      {
        key: 'HAYS',
        value: 'Hays',
      },
      {
        key: 'IRON SPRINGS',
        value: 'Iron Springs',
      },
      {
        key: 'LETHBRIDGE COUNTY',
        value: 'Lethbridge County',
      },
      {
        key: 'LOMOND',
        value: 'Lomond',
      },
      {
        key: 'MILO',
        value: 'Milo',
      },
      {
        key: 'MONARCH',
        value: 'Monarch',
      },
      {
        key: 'MOSSLEIGH',
        value: 'Mossleigh',
      },
      {
        key: 'NOBLEFORD',
        value: 'Nobleford',
      },
      {
        key: 'PICTURE BUTTE',
        value: 'Picture Butte',
      },
      {
        key: 'SHAUGHNESSY',
        value: 'Shaughnessy',
      },
      {
        key: 'SIKSIKA',
        value: 'Siksika',
      },
      {
        key: 'TURIN',
        value: 'Turin',
      },
      {
        key: 'VAUXHALL',
        value: 'Vauxhall',
      },
      {
        key: 'VULCAN',
        value: 'Vulcan',
      },
    ],
  },
];
