import { GoABlock } from '@abgov/react-components';

export default function InlineLoadingIndicator({ label }: { label?: string }) {
  return (
    <GoABlock gap="2xs">
      <span className="spin-icon">
        <ion-icon name="reload-outline" />
      </span>
      {label && ` ${label}`}
    </GoABlock>
  );
}

InlineLoadingIndicator.defaultProps = {
  label: undefined,
};
