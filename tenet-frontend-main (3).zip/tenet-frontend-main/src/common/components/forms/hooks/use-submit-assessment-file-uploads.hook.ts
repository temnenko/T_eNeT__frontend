import { useCallback, useEffect, useMemo, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { MockUploader, Upload } from '../../../../types/files';
import { useStore } from '../../../../hooks/use-store.hook';
import useFileNotValid from '../../../../utils/file.util';
import { InvalidFileUploadError } from '../../../../types/errors/invalid-file-upload.error';

const useSubmitAssessmentFileUploads = () => {
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [progressList, setProgressList] = useState<Record<string, number>>({});
  const [fileBeingDeleted, setFileBeingDeleted] = useState<string | null>(null);
  const [fileDeletedSuccessfully, setFileDeletedSuccessfully] = useState(false);

  const [loading, setLoading] = useState(false);
  const {
    assessmentFilesStore: { documents, addToNewUploads, deleteDocument },
  } = useStore();
  const [uploadError, setUploadError] = useState<string | null>(null);

  useEffect(() => {
    if (documents) {
      setUploads(
        documents.map((doc) => ({
          id: doc.id,
          file: new File([], doc.fileName),
          fileType: doc.typeName,
          uploader: {
            onprogress: () => {},
          },
          createdAt: doc.adspCreatedAt,
          size: doc.size,
          persisted: !!doc.adspId,
          addedByFullName: doc.addedByFullName,
          adspId: doc.adspId,
        })),
      );
    }
  }, [documents]);

  const deleteFile = useCallback(
    async (file: Upload) => {
      setFileDeletedSuccessfully(false);
      setFileBeingDeleted(file.id);
      await deleteDocument(file.id);
      setFileBeingDeleted(null);
      setUploads((uploadz) => {
        return uploadz.filter((u) => u.id !== file.id);
      });
      setFileDeletedSuccessfully(true);
    },
    [deleteDocument],
  );

  const onFileTypeChange = (id: string, type: string | string[]) => {
    const upload = uploads.find((u) => u.id === id);
    if (!upload) return;

    const updatedUpload = { ...upload, fileType: type as string };

    const updatedUploads = uploads.map((u) => (u.id === id ? updatedUpload : u));

    setUploads(updatedUploads);

    addToNewUploads(updatedUpload);
  };

  const { fileNotValidHandler } = useFileNotValid();

  const uploadFile = useCallback(
    (file: File) => {
      try {
        fileNotValidHandler(file.name, file.type);
        const reader = new FileReader();
        reader.onload = (e: ProgressEvent<FileReader>) => {
          if (!e.target) return;
          const url = e.target.result;
          const uploader: MockUploader = {
            onprogress: (percent) => {
              setProgressList((old) => ({ ...old, [file.name]: percent }));
            },
          };

          uploader.upload = () => {
            uploader.onprogress(200);
          };

          const newUpload = {
            file,
            uploader,
            fileType: '',
            id: uuidv4(),
            createdAt: new Date().toISOString(),
            size: file.size,
            adspId: '',
          };

          setUploads((old) => [...old, newUpload]);

          addToNewUploads(newUpload);

          if (url) {
            uploader.upload(url);
          }
        };
        reader.readAsDataURL(file);

        setLoading(false);
      } catch (e) {
        if (e instanceof InvalidFileUploadError) {
          setUploadError(e.message);
        }
      }
    },
    [addToNewUploads, fileNotValidHandler],
  );

  const formatBytes = useMemo(
    () =>
      (bytes: number, decimals = 1) => {
        if (!+bytes) return '0 Bytes';

        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return `${parseFloat((bytes / k ** i).toFixed(dm))} ${sizes[i]}`;
      },
    [],
  );

  return {
    uploads,
    progressList,
    loading,
    fileBeingDeleted,
    fileDeletedSuccessfully,
    deleteFile,
    uploadFile,
    formatBytes,
    onFileTypeChange,
    setFileDeletedSuccessfully,
    uploadError,
    setUploadError,
  };
};

export default useSubmitAssessmentFileUploads;
