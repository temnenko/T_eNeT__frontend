/* eslint-disable @typescript-eslint/no-unused-vars */
import '@testing-library/jest-dom';
import { renderHook } from '@testing-library/react';
import useSubmitFileUploads from './use-submit-file-uploads.hook';
import RootStore from '../../../../stores/root.store';
import * as hooks from '../../../../hooks/use-store.hook';
import * as useModalHook from '../../../../hooks/use-modal.hook';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}));

const mockStore = {
  clientFormStore: {
    saveClientAddresses: jest.fn(),
    client: {},
    loadClient: jest.fn(),
  },
  clientFormStepperStore: { done: jest.fn() },
  clientFilesStore: {
    documents: [],
  },
  permissionStore: { isSuperAdmin: true },
  userStore: {},
} as unknown as RootStore;

const mockModalContextValue = {
  showModal: jest.fn(),
  hideModal: jest.fn(),
  isVisible: false,
  modalContent: null,
};

describe('useSubmitFileUploads', () => {
  beforeEach(() => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);
    jest.spyOn(useModalHook, 'useModal').mockImplementation(() => mockModalContextValue);
  });
  test('should return correct value types', () => {
    const { result } = renderHook(() => useSubmitFileUploads());

    expect(result.current.deleteFile).toBeInstanceOf(Function);
    expect(result.current.formatBytes).toBeInstanceOf(Function);
    expect(result.current.uploadFile).toBeInstanceOf(Function);
    expect(result.current.uploads).toBeInstanceOf(Array);
    expect(result.current.progressList).toBeInstanceOf(Object);
    expect(result.current.loading).toBeFalsy();
  });
});
