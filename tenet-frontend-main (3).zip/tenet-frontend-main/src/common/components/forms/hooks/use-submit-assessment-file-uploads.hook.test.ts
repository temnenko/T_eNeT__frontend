/* eslint-disable @typescript-eslint/no-unused-vars */
import '@testing-library/jest-dom';
import { renderHook } from '@testing-library/react';
import useSubmitAssessmentFileUploads from './use-submit-assessment-file-uploads.hook';
import RootStore from '../../../../stores/root.store';
import * as hooks from '../../../../hooks/use-store.hook';

jest.mock('react-router-dom', () => ({
  ...jest.requireActual('react-router-dom'),
  useNavigate: jest.fn(),
}));

const mockStore = {
  clientFormStore: {
    saveClientAddresses: jest.fn(),
    client: {},
    loadClient: jest.fn(),
  },
  assessmentFilesStore: {
    documents: [],
  },
} as unknown as RootStore;

describe('useSubmitFileUploads', () => {
  beforeEach(() => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);
  });
  test('should return correct value types', () => {
    const { result } = renderHook(() => useSubmitAssessmentFileUploads());

    expect(result.current.deleteFile).toBeInstanceOf(Function);
    expect(result.current.formatBytes).toBeInstanceOf(Function);
    expect(result.current.uploadFile).toBeInstanceOf(Function);
    expect(result.current.uploads).toBeInstanceOf(Array);
    expect(result.current.progressList).toBeInstanceOf(Object);
    expect(result.current.loading).toBeFalsy();
  });
});
