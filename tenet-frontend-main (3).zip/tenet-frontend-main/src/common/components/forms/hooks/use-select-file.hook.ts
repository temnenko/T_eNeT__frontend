import { useCallback, useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { FileHandlerInput, MockUploader, Upload } from '../../../../types/files';
import { useStore } from '../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../hooks/use-request-error-handler.hook';
import { OrganizationComplianceFilesTypeMap } from '../../../../types/organization';
import { getEnumKeyByValue } from '../../../../utils/enums.util';
import { RequestError } from '../../../../types/errors/errors';
import useFileNotValid from '../../../../utils/file.util';
import { InvalidFileUploadError } from '../../../../types/errors/invalid-file-upload.error';

const useSelectFile = ({ name, setValue, uploadType, postUploadCallback, postDeleteCallback }: FileHandlerInput) => {
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [progressList, setProgressList] = useState<Record<string, number>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [uploadErrors, setUploadErrors] = useState<string[]>([]);
  const {
    organizationEnrollmentStore: {
      corporateIdentityDocuments,
      lobbyistCheckProof,
      wcbVerificationProof,
      liabilityPolicyProof,
      assessmentResult,
      uploadFiles,
      removeFile,
    },
  } = useStore();

  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});

  const updateUploads = useCallback(() => {
    let persistedUploads: Upload[] = [];

    switch (name) {
      case getEnumKeyByValue(
        OrganizationComplianceFilesTypeMap,
        OrganizationComplianceFilesTypeMap.corporateIdentityDocuments,
      ):
        persistedUploads = corporateIdentityDocuments ?? [];
        break;
      case getEnumKeyByValue(OrganizationComplianceFilesTypeMap, OrganizationComplianceFilesTypeMap.lobbyistCheckProof):
        persistedUploads = lobbyistCheckProof ?? [];
        break;
      case getEnumKeyByValue(
        OrganizationComplianceFilesTypeMap,
        OrganizationComplianceFilesTypeMap.wcbVerificationProof,
      ):
        persistedUploads = wcbVerificationProof ?? [];
        break;
      case getEnumKeyByValue(
        OrganizationComplianceFilesTypeMap,
        OrganizationComplianceFilesTypeMap.liabilityPolicyProof,
      ):
        persistedUploads = liabilityPolicyProof ?? [];
        break;
      case getEnumKeyByValue(OrganizationComplianceFilesTypeMap, OrganizationComplianceFilesTypeMap.assessmentResult):
        persistedUploads = assessmentResult ?? [];
        break;
      default:
        break;
    }
    setUploads(persistedUploads);
    setValue(name, persistedUploads);
  }, [
    name,
    setValue,
    corporateIdentityDocuments,
    lobbyistCheckProof,
    wcbVerificationProof,
    liabilityPolicyProof,
    assessmentResult,
  ]);

  const deleteFile = useCallback(
    async (upload: Upload) => {
      try {
        await removeFile(upload, uploadType as OrganizationComplianceFilesTypeMap);
        setUploads((old) => old.filter((u) => u.adspId !== upload.adspId));
        if (postDeleteCallback) {
          postDeleteCallback(upload);
        }
      } catch (e) {
        requestErrorHandler({
          error: e,
          setError: setRequestError,
        });
      }
    },
    [postDeleteCallback, removeFile, requestErrorHandler, uploadType],
  );

  const { fileNotValidHandler } = useFileNotValid();

  const selectFile = useCallback(
    (file: File) => {
      try {
        fileNotValidHandler(file.name, file.type);
        const reader = new FileReader();
        reader.onload = (e: ProgressEvent<FileReader>) => {
          if (!e.target) return;
          const url = e.target.result;
          const uploader: MockUploader = {
            onprogress: (percent) => {
              setProgressList((old) => ({ ...old, [file.name]: percent }));
            },
          };

          const selectedFileAsUpload: Upload = {
            file,
            uploader,
            fileType: uploadType,
            id: uuidv4(),
            createdAt: new Date().toISOString(),
            size: file.size,
            adspId: '',
          };

          uploader.upload = async () => {
            setIsLoading(true);
            const uploadedFiles = await uploadFiles(
              [selectedFileAsUpload],
              uploadType as OrganizationComplianceFilesTypeMap,
            ).finally(() => {
              setIsLoading(false);
            });
            if (uploadedFiles.length === 0) {
              setUploadErrors(['Failed to upload file']);
            } else {
              if (postUploadCallback) {
                postUploadCallback(
                  uploadedFiles.map((f) => {
                    return {
                      file,
                      uploader,
                      fileType: uploadType,
                      id: f.id,
                      createdAt: f.createdAt,
                      size: f.size,
                      adspId: f.adspId,
                    };
                  }),
                );
              }
              updateUploads();
            }
            uploader.onprogress(200);
          };

          if (url) {
            uploader.upload(url);
          }
        };
        reader.readAsDataURL(file);
      } catch (ex) {
        if (ex instanceof InvalidFileUploadError) {
          setUploadErrors([ex.message]);
        } else {
          requestErrorHandler({
            error: ex,
            setError: setRequestError,
          });
        }
      }
    },
    [fileNotValidHandler, postUploadCallback, requestErrorHandler, updateUploads, uploadFiles, uploadType],
  );

  useEffect(() => {
    updateUploads();
    setUploadErrors([]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [corporateIdentityDocuments, lobbyistCheckProof, wcbVerificationProof, liabilityPolicyProof, assessmentResult]);

  return {
    uploads,
    progressList,
    selectFile,
    deleteFile,
    isLoading,
    uploadErrors,
    requestError,
    setUploadErrors,
  };
};

export default useSelectFile;
