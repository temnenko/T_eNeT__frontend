import { useCallback, useEffect, useMemo, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { MockUploader, Upload } from '../../../../types/files';
import { useStore } from '../../../../hooks/use-store.hook';
import { ClientFormStepperKeys } from '../../../../types/client-forms';
import useFileNotValid from '../../../../utils/file.util';
import { InvalidFileUploadError } from '../../../../types/errors/invalid-file-upload.error';
import { useModal } from '../../../../hooks/use-modal.hook';
import { ConfirmationModal } from '../../modals/confirmation.modal';
import { toIsoDate } from '../../../../utils/date.util';

const useSubmitClientFileUploads = () => {
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [progressList, setProgressList] = useState<Record<string, number>>({});

  const [loading, setLoading] = useState(false);
  const [fileDeletedSuccessfully, setFileDeletedSuccessfully] = useState(false);
  const [fileBeingDeleted, setFileBeingDeleted] = useState<string | null>(null);
  const {
    clientFormStepperStore: { done },
    clientFilesStore: { documents, addToNewUploads, deleteDocument },
    permissionStore: { canDeleteInProgressClientFile },
  } = useStore();
  const [uploadError, setUploadError] = useState<string | null>(null);
  const { hideModal, showModal } = useModal();

  useEffect(() => {
    if (documents?.length) {
      setUploads(
        documents.map((doc) => ({
          id: doc.id,
          file: new File([], doc.fileName),
          fileType: doc.typeName,
          uploader: {
            onprogress: () => {},
          },
          addedByFullName: doc.addedByFullName,
          createdAt: doc.adspCreatedAt,
          size: doc.size,
          persisted: !!doc.adspId,
          adspId: doc.adspId,
        })),
      );
      done(ClientFormStepperKeys.FILES);
    }
  }, [documents, documents.length, done]);

  const deleteFile = useCallback(
    async (file: Upload) => {
      setLoading(true);
      hideModal();
      setFileDeletedSuccessfully(false);
      setFileBeingDeleted(file.id);
      await deleteDocument(file.id);
      setFileBeingDeleted(null);
      setUploads((uploadz) => {
        return uploadz.filter((u) => u.id !== file.id);
      });
      setFileDeletedSuccessfully(true);
      hideModal();
    },
    [deleteDocument, hideModal],
  );

  const openDeleteConfirmationDialog = useCallback(
    (file: Upload) => {
      showModal(
        <ConfirmationModal
          heading="Delete file?"
          description="Are you sure you want to delete this file?"
          declineText="Oops, go back"
          confirmText="Yes, delete"
          onConfirm={() => deleteFile(file)}
          onDecline={hideModal}
          isDelete
        />,
      );
    },
    [deleteFile, hideModal, showModal],
  );

  const onFileTypeChange = (id: string, type: string | string[]) => {
    const upload = uploads.find((u) => u.id === id);
    if (!upload) return;

    const updatedUpload = { ...upload, fileType: type as string };

    const updatedUploads = uploads.map((u) => (u.id === id ? updatedUpload : u));

    setUploads(updatedUploads);

    addToNewUploads(updatedUpload);
  };

  const { fileNotValidHandler } = useFileNotValid();

  const uploadFile = useCallback(
    (file: File) => {
      try {
        fileNotValidHandler(file.name, file.type);

        const reader = new FileReader();
        reader.onload = (e: ProgressEvent<FileReader>) => {
          if (!e.target) return;
          const url = e.target.result;
          const uploader: MockUploader = {
            onprogress: (percent) => {
              setProgressList((old) => ({ ...old, [file.name]: percent }));
            },
          };

          uploader.upload = () => {
            uploader.onprogress(200);
          };

          const newUpload = {
            file,
            uploader,
            fileType: '',
            id: uuidv4(),
            createdAt: toIsoDate(new Date()).toISOString(),
            size: file.size,
            addedByFullName: '',
            adspId: '',
          };

          setUploads((old) => [...old, newUpload]);

          addToNewUploads(newUpload);

          if (url) {
            uploader.upload(url);
          }
        };
        reader.readAsDataURL(file);

        setLoading(false);
      } catch (e) {
        if (e instanceof InvalidFileUploadError) {
          setUploadError(e.message);
        }
      }
    },
    [addToNewUploads, fileNotValidHandler],
  );

  const formatBytes = useMemo(
    () =>
      (bytes: number, decimals = 1) => {
        if (!+bytes) return '0 Bytes';

        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return `${parseFloat((bytes / k ** i).toFixed(dm))} ${sizes[i]}`;
      },
    [],
  );

  return {
    uploads,
    progressList,
    loading,
    deleteFile,
    uploadFile,
    formatBytes,
    onFileTypeChange,
    fileDeletedSuccessfully,
    fileBeingDeleted,
    setFileDeletedSuccessfully,
    uploadError,
    setUploadError,
    canDeleteFiles: canDeleteInProgressClientFile,
    openDeleteConfirmationDialog,
  };
};

export default useSubmitClientFileUploads;
