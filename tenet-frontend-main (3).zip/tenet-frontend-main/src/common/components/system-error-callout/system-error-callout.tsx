import { GoAButton, GoAButtonGroup, GoACallout } from '@abgov/react-components';
import useAnchorNavigate from '../../../hooks/use-anchor-navigate.hook';

export default function SystemErrorCallout() {
  const navigate = useAnchorNavigate('/dashboard');

  return (
    <GoACallout type="important" heading="Unable to submit due to system issue">
      <p className="client-font-with-margin">
        {`Opps! We're experiencing a system issue. Please hold off for a moment before re-submitting the form.`}
      </p>
      <p>Rest assured that your progress so far has been saved.</p>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton type="primary" leadingIcon="home" onClick={navigate}>
          Okay, go back
        </GoAButton>
      </GoAButtonGroup>
    </GoACallout>
  );
}
