import { GoAFileUploadCard, GoAFileUploadInput, GoAFormItem } from '@abgov/react-components';
import { Upload } from '../../types/files';

type Props = {
  label: string;
  error: string | undefined;
  maxSizeInMb: number;
  uploads: Upload[];
  progressList: Record<string, number>;
  isLoading: boolean;
  selectHandler: (file: File) => void;
  deleteHandler: (upload: Upload) => void;
  uploadOptional?: boolean;
};

export function FileUploadControl({
  label,
  error,
  maxSizeInMb,
  uploads,
  progressList,
  isLoading,
  selectHandler,
  deleteHandler,
  uploadOptional,
}: Props) {
  return (
    <GoAFormItem label={label} error={error} requirement={uploadOptional ? 'optional' : 'required'}>
      {isLoading && <div>Uploading...</div>}
      {!isLoading && (
        <>
          <GoAFileUploadInput onSelectFile={selectHandler} variant="button" maxFileSize={`${maxSizeInMb}MB`} />
          <div>{error}</div>
        </>
      )}
      {uploads.map((upload) => (
        <GoAFileUploadCard
          key={upload.file.name}
          filename={upload.file.name}
          type={upload.file.type}
          size={upload.size}
          progress={progressList[upload.file.name]}
          onDelete={() => deleteHandler(upload)}
          onCancel={() => deleteHandler(upload)}
        />
      ))}
    </GoAFormItem>
  );
}

FileUploadControl.defaultProps = {
  uploadOptional: false,
};
