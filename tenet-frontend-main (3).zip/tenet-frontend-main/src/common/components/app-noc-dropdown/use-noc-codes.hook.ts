import { useState, useCallback, useEffect } from 'react';
import { nocCodeService, NocOption } from '../../../services/noc-code.service';
import useRequestErrorHandler from '../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../types/errors/errors';

interface UseNocCodesProps {
  onSelectNocCode: (nocOption: NocOption) => void;
  setNocCodeField: (name: string, value: string) => void;
}

export const useNocCodes = ({ onSelectNocCode, setNocCodeField }: UseNocCodesProps) => {
  const [nocValues, setNocValues] = useState([] as NocOption[]);
  const [isFocused, setIsFocused] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});
  const [searchCompleted, setSearchCompleted] = useState(false);

  const fetchSuggestions = useCallback(async (query: string) => {
    try {
      setIsLoading(true);
      setRequestError({});
      const result = await nocCodeService.find(query);
      setNocValues(result);
      setSearchCompleted(true);
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setIsLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const isDigitOnly = /^\d+$/.test(searchTerm);
    const isTextOnly = /^[a-zA-Z\s]+$/.test(searchTerm);

    // If it's exactly 5 digits, call API
    if (isDigitOnly && searchTerm.length === 5) {
      fetchSuggestions(searchTerm);
    } else if (isTextOnly) {
      // If it's pure text, debounce the search
      const timeoutId = setTimeout(() => {
        if (searchTerm) {
          fetchSuggestions(searchTerm);
        } else {
          setNocValues([]);
        }
      }, 300);

      return () => clearTimeout(timeoutId); // Clean up timeout only in case of debounce
    } else {
      // If it's a mix of numbers and letters, or less than 5 digits, clear suggestions
      setNocValues([]);
    }

    return undefined;
  }, [fetchSuggestions, searchTerm]);

  const handleInputChange = useCallback(
    (name: string, value: string) => {
      setNocCodeField(name, value.trim());
      setSearchTerm(value.trim());
    },
    [setNocCodeField],
  );

  const handleFocus = useCallback(() => {
    setIsFocused(true);
  }, []);

  const handleBlur = useCallback(() => {
    setTimeout(() => {
      setIsFocused(false);
    }, 200);
  }, []);

  const handleSelectNocCode = useCallback(
    async (suggestion: NocOption) => {
      onSelectNocCode(suggestion);
    },
    [onSelectNocCode],
  );

  return {
    nocValues,
    isFocused,
    handleInputChange,
    handleFocus,
    handleBlur,
    handleSelectNocCode,
    isLoading,
    requestError,
    searchCompleted,
  };
};
