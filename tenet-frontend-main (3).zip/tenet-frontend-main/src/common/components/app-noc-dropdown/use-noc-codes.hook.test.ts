import { act, renderHook } from '@testing-library/react';
import { nocCodeService } from '../../../services/noc-code.service';
import { useNocCodes } from './use-noc-codes.hook';

jest.mock('../../../services/noc-code.service', () => ({
  __esModule: true,
  nocCodeService: {
    find: jest.fn(),
  },
}));

describe('useNocCodes', () => {
  const mockOnSelectNocCode = jest.fn();
  const mockSetNocCodeField = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should fetch suggestions when searchTerm is 5 digits', async () => {
    const mockNocOptions = [{ value: '001', label: 'Manager' }];
    (nocCodeService.find as jest.Mock).mockResolvedValueOnce(mockNocOptions);

    const { result } = renderHook(() =>
      useNocCodes({
        onSelectNocCode: mockOnSelectNocCode,
        setNocCodeField: mockSetNocCodeField,
      }),
    );

    act(() => {
      result.current.handleInputChange('noc', '12345');
    });

    expect(result.current.isLoading).toBe(true);

    await act(async () => {});

    expect(nocCodeService.find).toHaveBeenCalledWith('12345');
    expect(result.current.nocValues).toEqual(mockNocOptions);
    expect(result.current.isLoading).toBe(false);
  });

  it('should debounce and fetch suggestions when searchTerm is text', async () => {
    jest.useFakeTimers();

    const mockNocOptions = [{ value: '002', label: 'Engineer' }];
    (nocCodeService.find as jest.Mock).mockResolvedValueOnce(mockNocOptions);

    const { result } = renderHook(() =>
      useNocCodes({
        onSelectNocCode: mockOnSelectNocCode,
        setNocCodeField: mockSetNocCodeField,
      }),
    );

    act(() => {
      result.current.handleInputChange('noc', 'engineer');
    });

    expect(result.current.isLoading).toBe(false);

    act(() => {
      jest.advanceTimersByTime(300);
    });

    expect(result.current.isLoading).toBe(true);

    await act(async () => {});

    expect(nocCodeService.find).toHaveBeenCalledWith('engineer');
    expect(result.current.nocValues).toEqual(mockNocOptions);
    expect(result.current.isLoading).toBe(false);

    jest.useRealTimers();
  });

  it('should clear suggestions when searchTerm is a mix of text and digits', () => {
    const { result } = renderHook(() =>
      useNocCodes({
        onSelectNocCode: mockOnSelectNocCode,
        setNocCodeField: mockSetNocCodeField,
      }),
    );

    act(() => {
      result.current.handleInputChange('noc', '123abc');
    });

    expect(nocCodeService.find).not.toHaveBeenCalled();
    expect(result.current.nocValues).toEqual([]);
  });

  it('should handle focus and blur events correctly', () => {
    jest.useFakeTimers();

    const { result } = renderHook(() =>
      useNocCodes({
        onSelectNocCode: mockOnSelectNocCode,
        setNocCodeField: mockSetNocCodeField,
      }),
    );

    act(() => {
      result.current.handleFocus();
    });
    expect(result.current.isFocused).toBe(true);

    act(() => {
      result.current.handleBlur();
    });

    act(() => {
      jest.runAllTimers();
    });

    expect(result.current.isFocused).toBe(false);

    jest.useRealTimers();
  });

  it('should call onSelectNocCode when a NOC code is selected', async () => {
    const mockNocOption = { value: '001', label: 'Manager' };

    const { result } = renderHook(() =>
      useNocCodes({
        onSelectNocCode: mockOnSelectNocCode,
        setNocCodeField: mockSetNocCodeField,
      }),
    );

    await act(async () => {
      result.current.handleSelectNocCode(mockNocOption);
    });

    expect(mockOnSelectNocCode).toHaveBeenCalledWith(mockNocOption);
  });
});
