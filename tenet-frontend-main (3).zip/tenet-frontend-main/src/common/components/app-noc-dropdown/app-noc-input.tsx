import { GoABlock, GoAFormItem, GoAInput } from '@abgov/react-components';
import { FieldErrors, FieldValues } from 'react-hook-form';
import { useNocCodes } from './use-noc-codes.hook';
import { NocOption } from '../../../services/noc-code.service';

interface NocCodesDropdownProps<T extends FieldValues> {
  name: string;
  id: string;
  placeholder: string;
  width: string;
  value: string;
  errors: FieldErrors<T>;
  onSelectNocCode: (nocCode: NocOption) => void;
  setNocCodeField: (name: string, value: string) => void;
}

function NocInput<T extends FieldValues>({
  name,
  id,
  placeholder,
  width,
  value,
  onSelectNocCode,
  setNocCodeField,
  errors,
}: NocCodesDropdownProps<T>) {
  const {
    nocValues,
    isFocused,
    handleInputChange,
    handleBlur,
    handleFocus,
    handleSelectNocCode,
    isLoading,
    requestError,
    searchCompleted,
  } = useNocCodes({
    onSelectNocCode,
    setNocCodeField,
  });
  return (
    <div className="autocomplete-container" style={{ width }}>
      <GoAFormItem
        error={errors.noc?.message as unknown as string}
        helpText="Type a job title or 5-digit NOC code  to filter the list and select an option."
      >
        <GoAInput
          type="text"
          onChange={handleInputChange}
          onBlur={handleBlur}
          onFocus={handleFocus}
          name={name}
          id={id}
          placeholder={placeholder}
          width={width}
          value={value}
          leadingIcon="search"
        />
      </GoAFormItem>

      {isFocused && !isLoading && (
        <ul className="noc-dropdown">
          {!!nocValues?.length &&
            nocValues.map((suggestion, index) => (
              // eslint-disable-next-line react/no-array-index-key
              <li key={index}>
                <button
                  type="button"
                  onClick={() => {
                    handleSelectNocCode(suggestion);
                  }}
                  className="noc-item"
                >
                  {suggestion.value} - {suggestion.label}
                </button>
              </li>
            ))}
          {!nocValues?.length && !requestError?.message && searchCompleted && (
            <GoABlock>
              <p>We couldn’t find any matching results. Try different keywords.</p>
            </GoABlock>
          )}
          {requestError?.message && (
            <GoABlock>
              <p>
                We have trouble fetching federal data. Please find your NOC code directly through Government of Canada’s
                NOC site and manually enter it here.
              </p>
            </GoABlock>
          )}
        </ul>
      )}
      {isLoading && (
        <ul className="noc-dropdown d-flex align-items-center justify-content-center">
          <li className="d-flex align-items-center justify-content-center">
            <span>loading...</span>
          </li>
        </ul>
      )}
    </div>
  );
}
export default NocInput;
