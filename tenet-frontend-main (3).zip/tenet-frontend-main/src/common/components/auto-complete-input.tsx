/* eslint-disable react/require-default-props */
import { GoABlock, GoAButton, GoAInput } from '@abgov/react-components';
import { useMemo } from 'react';
import useAutocomplete, { Suggestion } from '../../hooks/use-auto-complete.hook';
import { CanadaPostAddressFullAddress } from '../../services/canada-post.service';
import { AddressType } from '../../types/client';
import { User } from '../../types/user';

type AutocompleteInputProps = {
  name: string;
  id: string;
  placeholder: string;
  width: string;
  value: string;
  subType: string;
  onSelectAddress: ((data: CanadaPostAddressFullAddress, type: AddressType) => void) | undefined;
  onSelectUser: ((data: User) => void) | undefined;
  setField: (name: string, value: string) => void;
  onSelectSuggestion?: (id: string) => void;
  addAction?: () => void;
  addLabel?: string;
  suggestionData?: Suggestion[];
  disabled?: boolean;
};

function AutocompleteInput({
  name,
  id,
  placeholder,
  width,
  onSelectAddress,
  onSelectUser,
  value,
  subType,
  setField,
  onSelectSuggestion,
  addAction,
  addLabel,
  suggestionData = [],
  disabled = false,
}: AutocompleteInputProps) {
  const { suggestions, isFocused, isCollection, handleInputChange, handleFocus, handleBlur, handleSelect } =
    useAutocomplete({
      onSelectAddress,
      onSelectUser,
      subType,
      setField,
      onSelectSuggestion,
      suggestionData,
    });
  const suggestionList = useMemo(
    () => (suggestionData.length ? suggestionData : suggestions),
    [suggestionData, suggestions],
  );
  const hasValue = useMemo(() => !!value?.length, [value?.length]);
  const showAddLink = useMemo(
    () => (value?.length >= 3 || suggestionList?.length === 0) && !!addAction,
    [addAction, suggestionList?.length, value?.length],
  );

  return (
    <div className="autocomplete-container" style={{ width }}>
      {/* GoA Modal auto sets focus on the first interactive child element */}
      <input hidden />
      <GoAInput
        type="text"
        onChange={handleInputChange}
        onBlur={handleBlur}
        onFocus={handleFocus}
        name={name}
        id={id}
        placeholder={placeholder}
        width={width}
        trailingIcon={hasValue ? 'search' : undefined}
        leadingIcon={!hasValue ? 'search' : undefined}
        disabled={disabled}
        value={value}
      />
      {(isFocused || isCollection) && (
        <ul className="autocomplete-dropdown">
          {suggestionList.map((suggestion, index) => (
            // eslint-disable-next-line react/no-array-index-key
            <li key={index}>
              <button
                type="button"
                onClick={() => {
                  handleSelect(suggestion);
                }}
                className="autocomplete-item"
              >
                {suggestion.text}
              </button>
            </li>
          ))}
          {!suggestionList?.length && <GoABlock>No matching result.</GoABlock>}
          {showAddLink && (
            <div className="autocomplete-footer">
              <GoAButton type="tertiary" leadingIcon="add" onClick={addAction}>
                {addLabel ?? 'Add'}
              </GoAButton>
            </div>
          )}
        </ul>
      )}
    </div>
  );
}

export default AutocompleteInput;
