import '@testing-library/jest-dom';
import { getByTestId, render } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';

import AppHeader from './app-header';
import * as hooks from '../../../hooks/use-store.hook';
import RootStore from '../../../stores/root.store';

describe('AppHeader', () => {
  const mockStore = {
    permissionStore: { isSuperAdmin: true },
    userStore: { displayName: 'Doe', logout: () => null },
    authStore: {
      accessToken: 'token',
      get isAuthenticated() {
        return !!this.accessToken;
      },
    },
  } as unknown as RootStore;

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('should render AppHeader', () => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: appHeader } = render(
      <BrowserRouter>
        <AppHeader />
      </BrowserRouter>,
    );
    const aDashboard = getByTestId(appHeader, 'a-dashboard');
    const aClients = getByTestId(appHeader, 'a-clients');
    const aOrganizations = getByTestId(appHeader, 'a-organizations');
    const aLogout = getByTestId(appHeader, 'a-logout');

    expect(appHeader).toBeInTheDocument();
    expect(aDashboard).toHaveTextContent('Dashboard');
    expect(aClients).toHaveTextContent('Clients');
    expect(aOrganizations).toHaveTextContent('Organizations');
    expect(aLogout).toHaveTextContent('Logout');
  });

  test('should render logout element when user is not logged-in', () => {
    mockStore.authStore.accessToken = '';

    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: appHeader } = render(
      <BrowserRouter>
        <AppHeader />
      </BrowserRouter>,
    );

    expect(appHeader).toBeInTheDocument();
    expect(() => getByTestId(appHeader, 'a-logout')).toThrow();
  });
});
