import { GoAAppHeader, GoAMicrositeHeader } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import { useLayoutEffect } from 'react';
import { useLocation } from 'react-router-dom';
import useAppHeaderNav from '../../../hooks/use-app-header-nav.hook';
import { useStore } from '../../../hooks/use-store.hook';

export const AppHeader = observer(() => {
  const appHeaderNav = useAppHeaderNav();
  const location = useLocation();
  useLayoutEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [location.pathname]);

  const {
    authStore: { headerUrl },
  } = useStore();

  return (
    <section slot="header">
      <GoAMicrositeHeader
        type="beta"
        version="TENET 1.0"
        feedbackUrl="https://github.com/GovAlta-EMU/tenet-frontend/issues/new/choose"
      />
      <GoAAppHeader url={headerUrl} heading="Training and Employment Services" maxContentWidth="100%">
        {appHeaderNav}
      </GoAAppHeader>
    </section>
  );
});

export default AppHeader;
