/* eslint-disable no-nested-ternary */
import { GoACheckbox, GoAChip, GoAFormItem, GoAInput } from '@abgov/react-components';
import useMultiselect, { SelectionType } from './use-multiselect.hook';

export type MultiSelectDropdownData = {
  region: string;
  items: { key: string; value: string }[];
}[];

type MultiSelectDropdownProps = {
  data: MultiSelectDropdownData;
  selectedItems: SelectionType;
  setSelectedItems: (updatedSelection: SelectionType) => void;
  title: string;
  width?: string;
  name: string;
  value: string;
  error: string;
  onChange: (name: string, value: string | string[]) => void;
  noDataMessage?: string;
};

function MultiSelectDropdown({
  data,
  selectedItems,
  setSelectedItems,
  title,
  width,
  name,
  value,
  error,
  onChange,
  noDataMessage,
}: MultiSelectDropdownProps) {
  const { isOpen, setIsOpen, handleRemoveChip, handleFilterChange, isItemVisible, handleSelect } = useMultiselect({
    selectedItems,
    setSelectedItems,
    data,
  });

  const renderChips = () => {
    return Object.entries(selectedItems).flatMap(([region, items]) =>
      Array.from(items as Set<{ id: string; value: string }>).map((item) => {
        let label;
        // if no regions, use the first data item
        if (data.length === 1) {
          label = data[0].items.find((i) => i.key === item.id)?.value;
        } else {
          label = data.find((d) => d.region === region)?.items.find((i) => i.key === item.id)?.value;
        }

        return (
          <span key={`${region}-${item.id}`} className="multiselect-chip">
            <GoAChip
              iconTheme="filled"
              deletable
              content={label!}
              onClick={() => handleRemoveChip(region, item.id)}
              mt="2"
            />
          </span>
        );
      }),
    );
  };

  return (
    <>
      <div className="multiselect-heading">
        <strong>{title}</strong>
      </div>
      <div style={{ width: width || '200px' }} className="multiselect-container">
        <div className="multiselect-input-container">
          <GoAFormItem error={error}>
            <GoAInput
              width={width || '200px'}
              onFocus={() => setIsOpen(true)}
              name={name}
              value={value}
              onChange={(_name: string, _value: string) => {
                handleFilterChange({ target: { value: _value } });
                onChange(_name, _value);
              }}
            />
          </GoAFormItem>
        </div>

        {isOpen && (
          <div id="dropdown-menu" className="multiselect-dropdown-content">
            {data && data.length > 0 ? (
              data
                .sort((a, b) => (a.region < b.region ? -1 : 1))
                .map(({ region, items }) => {
                  const visibleItems = items.filter((i) => isItemVisible(i.value));

                  // if there’s nothing to show for this region, skip it entirely
                  if (visibleItems.length === 0) return null;
                  return (
                    <div key={region} className="multiselect-separator">
                      <div className="multiselect-region">{region}</div>
                      {items && items.length > 0 ? (
                        items
                          .sort((a, b) => (a.key < b.key ? -1 : 1))
                          .map(({ key, value: itemValue }) => {
                            if (!isItemVisible(itemValue)) return null;
                            return (
                              <div key={key} className="multiselect-item">
                                <GoACheckbox
                                  id={`${region}-${key}`}
                                  checked={
                                    region
                                      ? selectedItems[region] &&
                                        [...selectedItems[region]].some((item) => item.id === key)
                                      : selectedItems[itemValue] &&
                                        [...selectedItems[itemValue]].some((item) => item.id === key)
                                  }
                                  onChange={() => handleSelect(region, key)}
                                  name="item"
                                />
                                <label htmlFor={`${region}-${key}`} className="multiselect-label">
                                  {itemValue}
                                </label>
                              </div>
                            );
                          })
                      ) : noDataMessage ? (
                        <div className="no-items">{noDataMessage}</div>
                      ) : null}
                    </div>
                  );
                })
            ) : (
              <div className="no-data">No Data</div>
            )}
          </div>
        )}
      </div>
      {selectedItems && <div className="multiselect-chip-container">{renderChips()}</div>}
    </>
  );
}

MultiSelectDropdown.defaultProps = {
  width: '200px',
  noDataMessage: 'No items available',
};

export default MultiSelectDropdown;
