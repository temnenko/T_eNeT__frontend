import { useEffect, useState } from 'react';

type UseMultiselectInput = {
  selectedItems: { [region: string]: Set<{ id: string; value: string }> };
  setSelectedItems: (updatedSelection: { [region: string]: Set<{ id: string; value: string }> }) => void;
  data: { region: string; items: { key: string; value: string }[] }[];
};

export type SelectionType = { [region: string]: Set<{ id: string; value: string }> };

const useMultiselect = ({ selectedItems, setSelectedItems, data }: UseMultiselectInput) => {
  const [filter, setFilter] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const handleRemoveChip = (region: string, itemId: string) => {
    const updatedSelection: SelectionType = { ...selectedItems };
    if (updatedSelection[region]) {
      updatedSelection[region] = new Set([...updatedSelection[region]].filter((item) => item.id !== itemId));
      if (updatedSelection[region].size === 0) {
        delete updatedSelection[region];
      }
    }
    setSelectedItems(updatedSelection);
  };

  // Close dropdown if clicked outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      const dropdown = document.getElementById('dropdown-menu');
      const input = document.getElementById('dropdown-input');
      if (!dropdown?.contains(e.target as Node) && !input?.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const handleSelectNoRegion = (itemId: string) => {
    const updatedSelection: SelectionType = { ...selectedItems };
    const selectedItem = data[0].items.find((i) => i.key === itemId);
    if (!selectedItem) return;

    updatedSelection[selectedItem.value] = updatedSelection[selectedItem.value] || new Set();
    const tempUpdatedSelection = new Set(
      [...updatedSelection[selectedItem.value]].filter((item) => item.id !== itemId),
    );
    if (![...updatedSelection[selectedItem.value]].some((item) => item.id === itemId)) {
      tempUpdatedSelection.add({ id: itemId, value: selectedItem.value });
    }
    updatedSelection[selectedItem.value] = tempUpdatedSelection;
    setSelectedItems(updatedSelection);
  };

  const handleSelect = (region: string, itemId: string) => {
    const updatedSelection: SelectionType = { ...selectedItems };
    const selectedItem = data.find((d) => d.region === region)?.items.find((i) => i.key === itemId);

    if (!selectedItem) return;

    if (!region) {
      handleSelectNoRegion(itemId);
      return;
    }

    updatedSelection[region] = updatedSelection[region] || new Set();

    const alreadySelected = [...updatedSelection[region]].some((item) => item.id === itemId);

    if (alreadySelected) {
      updatedSelection[region] = new Set([...updatedSelection[region]].filter((item) => item.id !== itemId));
    } else {
      updatedSelection[region].add({ id: itemId, value: selectedItem.value });
    }

    if (updatedSelection[region].size === 0) {
      delete updatedSelection[region];
    }

    setSelectedItems(updatedSelection);
  };

  const handleFilterChange = (event: { target: { value: string } }) => {
    setFilter(event.target.value.toLowerCase());
  };

  const isItemVisible = (item: string) => item.toLowerCase().includes(filter);

  return {
    filter,
    setFilter,
    isOpen,
    setIsOpen,
    handleRemoveChip,
    handleSelect,
    handleFilterChange,
    isItemVisible,
  };
};

export default useMultiselect;
