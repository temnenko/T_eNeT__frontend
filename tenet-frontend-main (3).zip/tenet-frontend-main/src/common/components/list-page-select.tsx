import { useCallback, useMemo } from 'react';
import { GoADropdown, GoADropdownItem } from '@abgov/react-components';

type Props = {
  perPageSize: number;
  pagePosition: number;
  changePagePosition: (value: number) => void;
  totalCount: number;
};

export function ListPageSelect({ perPageSize, pagePosition, changePagePosition, totalCount }: Props) {
  const pages = useMemo(
    () =>
      Array.from(
        { length: totalCount <= perPageSize ? 1 : Math.ceil(totalCount / perPageSize) },
        (_, index) => index + 1,
      ),
    [perPageSize, totalCount],
  );
  const pageSelectionHandler = useCallback(
    (_: string, value: string | string[]) => {
      changePagePosition(Number.parseInt(value as string, 10));
    },
    [changePagePosition],
  );

  return (
    <>
      <span>Page</span>
      <GoADropdown value={`${pagePosition}`} onChange={pageSelectionHandler} width="8ch" relative>
        {pages.map((value) => (
          <GoADropdownItem key={value} value={`${value}`} label={`${value}`} />
        ))}
      </GoADropdown>
      <span style={{ whiteSpace: 'nowrap' }}>
        {` `} of {pages!.length!}
      </span>
    </>
  );
}
