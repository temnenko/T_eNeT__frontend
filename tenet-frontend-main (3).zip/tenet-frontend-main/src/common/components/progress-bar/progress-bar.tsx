import { useEffect, useState } from 'react';

type VisualPart = {
  percentage: number;
  color: string;
};

type Props = {
  visualParts: VisualPart[];
};

function ProgressBar({
  visualParts = [
    {
      percentage: 0,
      color: '#004A8F',
    },
  ],
}: Props) {
  const [widths, setWidths] = useState(
    visualParts.map(() => {
      return 0;
    }),
  );

  useEffect(() => {
    requestAnimationFrame(() =>
      setWidths(
        visualParts.map((item) => {
          return item.percentage;
        }),
      ),
    );
  }, [visualParts]);

  return (
    <div className="progress-bar">
      {visualParts.map((item, index) => {
        return (
          <div
            key={`${item.color}-${item.percentage}`}
            style={{
              width: widths[index],
              backgroundColor: item.color,
            }}
            className="progress-visual"
          />
        );
      })}
    </div>
  );
}

export default ProgressBar;
