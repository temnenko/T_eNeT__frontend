/* eslint-disable react/require-default-props */
import { useMemo } from 'react';
import { GoABlock, GoADropdown, GoADropdownItem, GoAPagination, GoASpacer } from '@abgov/react-components';

type Props = {
  perPageSize: number;
  actualPageSize: number;
  perPageSizeOptions: number[];
  changePerPageSize: (name: string, value: string | string[]) => void;
  pagePosition: number;
  changePagePosition: (value: number) => void;
  totalCount: number;
  variant?: 'all' | 'links-only';
};

export function ListPagination({
  perPageSize,
  actualPageSize,
  perPageSizeOptions,
  changePerPageSize,
  pagePosition,
  changePagePosition,
  totalCount,
  variant = 'all',
}: Props) {
  const currentCount = useMemo(() => {
    const count = pagePosition * actualPageSize;

    return count < totalCount ? count : totalCount;
  }, [actualPageSize, pagePosition, totalCount]);
  const isShowAll = useMemo(() => variant === 'all', [variant]);

  return (
    <GoABlock mt="2xl" alignment="center">
      {isShowAll && (
        <GoABlock mb="m" alignment="center" gap="m">
          <span>Show</span>
          <GoADropdown value={`${perPageSizeOptions?.[0]}`} onChange={changePerPageSize} width="8ch" relative>
            {perPageSizeOptions.map((value) => (
              <GoADropdownItem key={value} value={`${value}`} label={`${value}`} />
            ))}
          </GoADropdown>
          <span style={{ whiteSpace: 'nowrap' }}>
            {totalCount ? 1 : 0}-{currentCount} of {totalCount}
          </span>
        </GoABlock>
      )}
      <GoASpacer hSpacing="fill" />
      <GoAPagination
        itemCount={totalCount}
        perPageCount={perPageSize}
        pageNumber={pagePosition}
        onChange={changePagePosition}
        variant={variant}
      />
    </GoABlock>
  );
}
