export function ClientHistoryView() {
  return (
    <>
      <h2>History</h2>
      <span>Under construction...</span>
    </>
  );
}
