import { observer } from 'mobx-react-lite';

import { useStore } from '../../../hooks/use-store.hook';
import { clientFormStepperTitles } from '../../../types/client-forms';
import { StepperFormHeader } from '../stepper-form/stepper-form-header';

export const ClientCreationHeader = observer(() => {
  const {
    clientFormStepperStore: { currentlyActive },
  } = useStore();

  return (
    <StepperFormHeader
      headingText="Create a new client"
      currentlyActive={currentlyActive}
      formStepperTitles={clientFormStepperTitles}
    />
  );
});
