import { GoABlock, GoAButton, GoADivider } from '@abgov/react-components';
import { useModal } from '../../../hooks/use-modal.hook';
import ContactDetailsModal from '../modals/contact-details.modal';

type Props = {
  title: string;
  data: {
    label: string;
    value: string | number;
  }[];
  postSubmit: () => void;
};

export default function ClientContactInformationCard({ title, data, postSubmit }: Props) {
  const { showModal, hideModal } = useModal();

  const onDeclineUpdate = () => {
    hideModal();
  };

  const showSuccess = () => {
    postSubmit();
  };

  return (
    <div className="client-info-card">
      <div className="client-info-card-heading client-margin-b-10">
        <h3 className="client-no-padding-no-margin">{title}</h3>
        <GoABlock>
          <GoAButton
            type="tertiary"
            size="compact"
            onClick={() => {
              showModal(<ContactDetailsModal onDecline={onDeclineUpdate} showSuccess={showSuccess} />);
            }}
          >
            Update
          </GoAButton>
          <GoAButton type="tertiary" size="compact" onClick={() => {}}>
            View History
          </GoAButton>
        </GoABlock>
      </div>
      <GoADivider />
      <div className="client-info-card-details">
        <GoABlock direction="column">
          <div>
            {data &&
              data.map((entry) => {
                return (
                  <GoABlock key={entry.label} gap="none">
                    <div className="client-info-card-label">
                      <span className="color-interactive" key={entry.label}>
                        {entry.label}
                      </span>
                    </div>
                    <div>
                      <span className="client-bold-600" key={entry.value}>
                        {entry.value}
                      </span>
                    </div>
                  </GoABlock>
                );
              })}
          </div>
        </GoABlock>
      </div>
    </div>
  );
}
