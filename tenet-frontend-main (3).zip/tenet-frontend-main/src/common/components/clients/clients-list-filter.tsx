import { GoAButton, GoAFormItem, GoAInput, GoASpacer, GoACallout } from '@abgov/react-components';
import { subYears } from 'date-fns';
import useClientFilters from '../../../hooks/use-clients-filter-hook';
import { useStore } from '../../../hooks/use-store.hook';
import { toIsoFormat } from '../../../utils/date.util';

export function ClientsListFilter() {
  const {
    onChange,
    getSearchCriteria,
    searchCriteria,
    resultsCount,
    reset,
    firstName,
    lastName,
    sinNumber,
    tenetNumber,
    goToCreateNewClient,
    dateOfBirth,
    invalidNameSearch,
    invalidSearchError,
  } = useClientFilters();

  const {
    permissionStore: { canCreateClient },
  } = useStore();

  return (
    <>
      {invalidSearchError && (
        <GoACallout type="important" heading="Invalid search input">
          <p>{invalidSearchError}</p>
        </GoACallout>
      )}
      {!invalidSearchError && invalidNameSearch && (
        <GoACallout type="important" heading="Minimum search criteria is missing">
          <p>Search requires a First name, Last name, and Date of birth.</p>
          <p>
            If you know the exact TENET ID# or the SIN # of the person you are searching, only one of these is needed.
          </p>
        </GoACallout>
      )}
      <section data-testid="clientsFilterSection" className="clients-filter-section">
        <form data-testid="clientsFilterForm" className="clients-filter-form-group">
          <div data-testid="clientsFilterTextboxes" className="clients-filter-textbox-group">
            <GoAFormItem label="SIN">
              <GoAInput type="search" value={sinNumber} onChange={onChange} name="sinNumber" width="20ch" />
            </GoAFormItem>
            <goa-spacer hspacing="xs" />
            <GoAFormItem label="TENET #">
              <GoAInput type="search" value={tenetNumber} onChange={onChange} name="tenetNumber" width="20ch" />
            </GoAFormItem>
            <goa-spacer hspacing="xs" />
            <GoAFormItem label="First name">
              <GoAInput type="search" value={firstName} onChange={onChange} name="firstName" width="20ch" />
            </GoAFormItem>
            <GoAFormItem label="Last name">
              <GoAInput type="search" value={lastName} onChange={onChange} name="lastName" width="20ch" />
            </GoAFormItem>
            <goa-spacer hspacing="xs" />
            <GoAFormItem label="Date of Birth">
              <GoAInput
                type="date"
                onChange={onChange}
                min={toIsoFormat(subYears(new Date(), 100))}
                max={toIsoFormat(subYears(new Date(), 17))}
                name="dateOfBirth"
                value={dateOfBirth}
              />
            </GoAFormItem>
          </div>
          <GoASpacer vSpacing="2xl" />
          <div className="clients-filter-buttons">
            <GoAFormItem>
              <GoAButton type="tertiary" onClick={reset}>
                Reset
              </GoAButton>
            </GoAFormItem>
            <GoAFormItem>
              <GoAButton type="secondary" onClick={getSearchCriteria}>
                Search
              </GoAButton>
            </GoAFormItem>
          </div>
        </form>
      </section>
      <div className="clients-search-results">
        {searchCriteria ? (
          <div>
            <p>
              Search results for <span>{searchCriteria}</span>
            </p>
            <p>{`Showing ${resultsCount} results`}</p>
          </div>
        ) : (
          <div />
        )}
        {canCreateClient && (
          <GoAButton type="primary" onClick={goToCreateNewClient} leadingIcon="add">
            Register new client
          </GoAButton>
        )}
      </div>
    </>
  );
}
