import { useMemo, useState } from 'react';
import { observer } from 'mobx-react-lite';
import { GoAButton, GoACallout, GoACheckbox, GoAIcon, GoASpacer, GoATable } from '@abgov/react-components';
import { format } from 'date-fns';
import { EducationForm } from '../forms/clients/education/education-history-form';
import { useModal } from '../../../hooks/use-modal.hook';
import useEducations from './hooks/use-educations.hook';
import EducationCard from './client-education-card';
import useEducationChangeMessage from './hooks/use-education-change-message.hooks';
import useHasEducationAndEmployment from './hooks/use-has-employment-and-education.hook';
import { MissingInfoCallout } from './missing-info-callout';
import { toIsoDate } from '../../../utils/date.util';
import useEducationHistoryPagination from './hooks/use-education-list-pagination.hook';
import useCapitalize from '../../../hooks/use-capitalize.hook';

const ClientEducationHistorySummary = observer(() => {
  const { hasBoth, hasEducation, hasEmployment } = useHasEducationAndEmployment();
  const { clientId, educations, archived, toggleShowCancelledEducations, canEditEducation } = useEducations();
  const { showModal } = useModal();
  const { message } = useEducationChangeMessage();

  const educationHistoryPagination = useEducationHistoryPagination();

  const [expandedId, setExpandedId] = useState<string | null>(null);
  const capitalize = useCapitalize();

  const actions = useMemo(() => {
    if (!canEditEducation) return null;
    return (
      <GoAButton
        type="secondary"
        leadingIcon="add"
        size="compact"
        onClick={() => {
          if (clientId) {
            showModal(<EducationForm clientId={clientId} canEditEducation={canEditEducation} />);
          }
        }}
      >
        Add Education
      </GoAButton>
    );
  }, [clientId, showModal, canEditEducation]);

  return (
    <section className="client-overview-section client-margin-t-10">
      <h2 className="client-no-padding-no-margin client-margin-b-10">Education</h2>
      {!hasBoth && <MissingInfoCallout hasEducation={hasEducation} hasEmployment={hasEmployment} />}
      {message && (
        <div className="width-750-px">
          <GoACallout type="success" size="medium">
            {message}
          </GoACallout>
        </div>
      )}
      <GoASpacer vSpacing="m" />
      <div>
        <p>Add client’s education experience here. The most recent education will automatically be on top.</p>
        {actions}
      </div>
      {clientId && educations?.length ? (
        <>
          <GoASpacer vSpacing="m" />
          <GoACheckbox
            name="showCancelledEducation"
            text="Show cancelled education"
            onChange={toggleShowCancelledEducations}
            checked={archived}
          />
        </>
      ) : undefined}
      <GoATable width="100%">
        <thead data-testid="educationTable-tableHeader">
          <tr>
            <th data-testid="educationTable-detailsHeader">{}</th>
            <th data-testid="educationTable-tenetNumberHeader">Level</th>
            <th data-testid="educationTable-clientNameHeader">Currently enrolled?</th>
            <th data-testid="educationTable-dateOfBirthHeader">Start</th>
            <th data-testid="educationTable-sinHeader">End</th>
            <th data-testid="educationTable-detailsHeader">{}</th>
          </tr>
        </thead>
        {clientId && educations?.length
          ? educations?.map((education) => {
              return (
                <>
                  <tr>
                    <td>
                      <GoAButton
                        type="tertiary"
                        onClick={() => setExpandedId(expandedId === education.id ? null : education.id)}
                      >
                        <GoAIcon type={expandedId === education.id ? 'chevron-down' : 'chevron-forward'} />
                      </GoAButton>
                    </td>
                    <td>{capitalize(education.levelOfEducation)}</td>
                    <td>{education.personAttendingTraining ? 'Yes' : 'No'}</td>
                    <td>{`${format(toIsoDate(education?.startDate ?? ''), 'dd MMM yyyy')}`}</td>
                    <td>{`${education?.completionDate ? format(toIsoDate(education.completionDate ? education.completionDate : education.expectedEndDate!), 'dd MMM yyyy') : ''}`}</td>
                    <td>
                      <GoAButton
                        type="tertiary"
                        onClick={() => {
                          showModal(
                            <EducationForm
                              clientId={clientId}
                              education={education}
                              canEditEducation={canEditEducation}
                            />,
                          );
                        }}
                      >
                        {education.archived ? 'View' : 'Edit'}
                      </GoAButton>
                    </td>
                  </tr>
                  {expandedId === education.id && (
                    <tr>
                      <td colSpan={6} width="100%">
                        <EducationCard key={education.id} education={education} />
                      </td>
                    </tr>
                  )}
                </>
              );
            })
          : undefined}
      </GoATable>

      {educationHistoryPagination}
    </section>
  );
});

export default ClientEducationHistorySummary;
