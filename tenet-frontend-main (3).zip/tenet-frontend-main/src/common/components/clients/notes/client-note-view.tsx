import { CreateNoteForm } from '../../forms/clients/notes/create-note-form';
import { NotesList } from '../service-plans/notes-list';

export function ClientNoteView() {
  return (
    <>
      <h2>Notes</h2>
      <CreateNoteForm />
      <NotesList notesFor="client" />
    </>
  );
}
