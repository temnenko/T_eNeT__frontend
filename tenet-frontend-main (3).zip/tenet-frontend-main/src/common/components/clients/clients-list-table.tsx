/* eslint-disable no-nested-ternary */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { useEffect } from 'react';
import { GoAButton, GoAIcon, GoASpacer, GoATable, GoATableSortHeader } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useNavigate } from 'react-router-dom';

import useClientRows from '../../../hooks/use-clients-rows.hook';
import { LoadingSkeleton } from './clients-list-table.skeleton';
import useClientsListPagination from '../../../hooks/use-clients-list-pagination.hook';
import { useStore } from '../../../hooks/use-store.hook';

export const ClientsTable = observer(() => {
  const { clientRows, sortData } = useClientRows();
  const clientsListPagination = useClientsListPagination();
  const {
    clientsStore: { unsetSelectedClient },
    clientsListStore: { hasClients, isLoading, isFiltered },
    servicePlansListStore: { resetServicePlans },
    permissionStore: { canCreateClient },
  } = useStore();

  const navigate = useNavigate();

  useEffect(() => {
    unsetSelectedClient();
    resetServicePlans();
  }, [resetServicePlans, unsetSelectedClient]);

  return (
    <>
      <GoATable width="100%" onSort={sortData}>
        <thead data-testid="clientsTable-tableHeader">
          <tr>
            <th data-testid="clientsTable-tenetNumberHeader">
              <GoATableSortHeader name="tenetNumber">TENET #</GoATableSortHeader>
            </th>
            <th data-testid="clientsTable-clientNameHeader">
              <GoATableSortHeader name="clientName">Client Name</GoATableSortHeader>
            </th>
            <th data-testid="clientsTable-dateOfBirthHeader">Date of Birth</th>
            <th data-testid="clientsTable-sinHeader">SIN</th>
            <th data-testid="clientsTable-detailsHeader">{}</th>
          </tr>
        </thead>
        {isLoading && <LoadingSkeleton />}
        {isFiltered && !isLoading && hasClients && <tbody>{clientRows}</tbody>}
      </GoATable>
      {!isFiltered && (
        <div className="client-search-display">
          <GoASpacer vSpacing="l" />
          <div className="orgBadgeDisplay">
            <div className="ellipse">
              <GoAIcon theme="outline" size="large" type="search" />
            </div>
          </div>
          <b>Search a client with any one or a combination of the above criteria</b>
        </div>
      )}
      <div className="client-search-display" data-testid="clientsTable-zero-results">
        {!hasClients && isFiltered && !isLoading && (
          <>
            <GoASpacer vSpacing="l" />
            <b>We found 0 result for the combination of filters selected.</b>
            <p>Try the following to see more results:</p>
            <br />
            <p>Check your spelling</p>
            <p>Removing some filters</p>
            <b>or</b>
            <br />
            {canCreateClient && (
              <GoAButton type="tertiary" onClick={() => navigate('/clients/create/personal-details')}>
                Create a new client
              </GoAButton>
            )}
          </>
        )}
      </div>
      {clientsListPagination}
    </>
  );
});
