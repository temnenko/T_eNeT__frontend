import { useMemo } from 'react';
import { GoABlock, GoAButton, GoADivider } from '@abgov/react-components';

type Props = {
  title: string;
  updateClick: () => void;
  data: {
    label: string;
    value: string | number;
  }[];
  additionalData: {
    label: string;
    value?: string;
  }[];
  setClientUpdated: React.Dispatch<React.SetStateAction<string>>;
  canEditCompletedClient: boolean;
};

export default function ClientInformationCard({
  title,
  updateClick,
  data,
  additionalData = [],
  setClientUpdated,
  canEditCompletedClient,
}: Props) {
  const consentText = useMemo(() => 'Consent and acknowledgement', []);
  const titles = useMemo(() => ['Demographics', 'Factors'], []);
  const labels = useMemo(() => ['Immigrant', 'Indigenous', 'Status'], []);

  return (
    <div className="client-info-card">
      <div className="client-info-card-heading client-margin-b-10">
        <h3 className="client-no-padding-no-margin">{title}</h3>
        <GoABlock>
          {canEditCompletedClient && (
            <GoAButton
              type="tertiary"
              size="compact"
              onClick={() => {
                setClientUpdated('');
                updateClick();
              }}
            >
              Update
            </GoAButton>
          )}

          <GoAButton type="tertiary" size="compact" onClick={() => {}}>
            View History
          </GoAButton>
        </GoABlock>
      </div>
      <GoADivider />
      <div className="client-info-card-details">
        <GoABlock direction="column">
          {data &&
            data.map((entry) => {
              if (labels.includes(entry.label) && titles.includes(title) && additionalData?.length) {
                return (
                  <GoABlock key={entry.label} gap="m">
                    <div className="client-info-card-label">
                      <span className="color-interactive" key={entry.label}>
                        {entry.label}
                      </span>
                    </div>
                    <div className="client-info-card-value">
                      <span className="client-bold-600" key={entry.value}>
                        {entry.value}
                      </span>
                    </div>
                    <div className="client-info-card-label-yol">
                      <span
                        className="color-interactive"
                        key={additionalData[entry.label !== 'Indigenous' ? 0 : 1]?.label}
                      >
                        {additionalData[entry.label !== 'Indigenous' ? 0 : 1]?.label}
                      </span>
                    </div>
                    <div>
                      <span
                        className="client-bold-600"
                        key={additionalData[entry.label !== 'Indigenous' ? 0 : 1]?.value}
                      >
                        {additionalData[entry.label !== 'Indigenous' ? 0 : 1]?.value}
                      </span>
                    </div>
                  </GoABlock>
                );
              }
              return (
                <GoABlock key={entry.label} gap="m">
                  <div className={title === consentText ? 'client-info-card-consent' : 'client-info-card-label'}>
                    <span className="color-interactive" key={entry.label}>
                      {entry.label}
                    </span>
                  </div>
                  <div>
                    <span className="client-bold-600" key={entry.value}>
                      {entry.value}
                    </span>
                  </div>
                </GoABlock>
              );
            })}
        </GoABlock>
      </div>
    </div>
  );
}
