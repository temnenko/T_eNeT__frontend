/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoATable } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

type Props = {
  employmentRows?: JSX.Element[];
};

export const EmploymentTable = observer(({ employmentRows }: Props) => {
  return (
    <GoATable width="100%">
      <thead>
        <th />
        <th>Job title</th>
        <th>Started</th>
        <th>Ended</th>
        <th>Employer</th>
        <th />
      </thead>
      {employmentRows?.length ? <tbody>{employmentRows}</tbody> : <div>No employment found</div>}
    </GoATable>
  );
});
