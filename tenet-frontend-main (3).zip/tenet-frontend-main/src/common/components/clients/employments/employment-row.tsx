/* eslint-disable no-plusplus */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { useMemo } from 'react';
import { GoABlock, GoAButton, GoAIcon } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { format } from 'date-fns';
import { useModal } from '../../../../hooks/use-modal.hook';
import { Employment } from '../../../../types/client';
import { toIsoDate } from '../../../../utils/date.util';
import { EmploymentForm } from '../../forms/clients/employmentHistory/employment-history-form';
import useCapitalize from '../../../../hooks/use-capitalize.hook';
import { formatAmount } from '../../../../utils/amount.util';

type Props = {
  employment: Employment;
  expandedRecordId?: string;
  canEditEmployment: boolean;
  toggleExpansion: (id: string) => void;
};

export const EmploymentRow = observer(({ expandedRecordId, employment, canEditEmployment, toggleExpansion }: Props) => {
  const isOpen = useMemo(() => expandedRecordId === employment.id, [expandedRecordId, employment.id]);
  const iconType = useMemo(() => (isOpen ? 'chevron-down' : 'chevron-forward'), [isOpen]);
  const capitalize = useCapitalize();
  const { showModal } = useModal();

  return (
    <>
      <tr key={employment.id}>
        <td>
          <button type="button" className="org-location-openBtn" onClick={() => toggleExpansion(employment.id)}>
            <GoAIcon type={iconType} />
          </button>
        </td>
        <td>{employment.jobTitle}</td>
        <td>{format(toIsoDate(employment.startDate), 'dd MMM yyyy')}</td>
        <td>{employment.endDate ? format(toIsoDate(employment.endDate), 'dd MMM yyyy') : '-'}</td>
        <td>{employment.employerName}</td>
        <td>
          {canEditEmployment && (
            <GoAButton
              type="tertiary"
              onClick={() => {
                showModal(
                  <EmploymentForm
                    clientId={employment.clientId}
                    employment={employment}
                    canEditEmployment={canEditEmployment}
                  />,
                );
              }}
            >
              Edit
            </GoAButton>
          )}
        </td>
      </tr>
      {isOpen && (
        <tr>
          <td colSpan={6}>
            <div className="client-employment-content">
              <GoABlock>
                <GoABlock direction="column">
                  <div className="detail-item">
                    <div className="detail-heading">Self employed</div>
                    <div>{employment.selfEmployed ? 'Yes' : 'No'}</div>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div className="detail-item">
                    <div className="detail-heading">Average hours per week</div>
                    <div>{employment.numberOfHourPerWeek}</div>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div className="detail-item">
                    <div className="detail-heading">Wage</div>
                    <div>{formatAmount(employment.wageCents)}</div>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div className="detail-item">
                    <div className="detail-heading">Frequency</div>
                    <div>{capitalize(employment.wageFrequency)}</div>
                  </div>
                </GoABlock>
                <GoABlock direction="column">
                  <div className="detail-item">
                    <div className="detail-heading">Reason for leaving</div>
                    <div>{capitalize(employment.reasonForLeaving?.replaceAll('_', ' '))}</div>
                  </div>
                </GoABlock>
              </GoABlock>
              <GoABlock mt="m">
                <GoABlock direction="column">
                  <div className="detail-item">
                    <div className="detail-heading">NOC</div>
                    <div>{employment.noc}</div>
                  </div>
                </GoABlock>
              </GoABlock>
            </div>
          </td>
        </tr>
      )}
    </>
  );
});
