/* eslint-disable no-nested-ternary */
import { GoABadge, GoABlock } from '@abgov/react-components';
import { Education } from '../../../types/client';
import useEducationCards from './hooks/use-education-card.hook';

type Props = {
  education: Education;
};

export default function EducationCard({ education }: Props) {
  const { educationDetails } = useEducationCards(education);
  return (
    <div
      className={`client-with-padding-radius ${education.archived ? 'archived-emp' : education.personAttendingTraining ? 'in-progress' : ''}`}
    >
      <div>
        <GoABlock>
          {!education.personAttendingTraining && !education.credentialReceived && (
            <GoABadge type="information" content="Not completed" />
          )}
        </GoABlock>
      </div>
      <div className="education-details-card">
        <div className="education-details-grid">
          {educationDetails.map((item) => (
            <div key={item.label} className="detail-item">
              <div className="detail-heading">{item.label}</div>
              <div>{item.value}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
