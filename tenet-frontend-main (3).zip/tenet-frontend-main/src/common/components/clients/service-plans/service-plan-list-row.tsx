/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoABadge, GoAButton } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';
import { ServicePlanStatus } from '../../../../types/service-plan';
import { useModal } from '../../../../hooks/use-modal.hook';
import ReopenServicePlanModal from './modals/service-plan-reopen-modal';

type Props = {
  id: string;
  clientId: string;
  status: ServicePlanStatus;
  type: string;
  startdate: string;
  agreementName: string;
  managedBy: string;
  manage: boolean;
  isSuperAdmin: boolean;
};

export function ServicePlanRow({
  id,
  clientId,
  status,
  startdate,
  type,
  agreementName,
  managedBy,
  manage,
  isSuperAdmin,
}: Props) {
  const navigate = useNavigate();
  const { showModal, hideModal } = useModal();

  const renderAction = () => {
    if (manage) {
      return (
        <GoAButton
          onClick={() => navigate(`/clients/${clientId}/service-plans/transition-to-employment/${id}`)}
          type="tertiary"
        >
          Manage
        </GoAButton>
      );
    }
    return (
      <GoAButton
        onClick={() => navigate(`/clients/${clientId}/service-plans/transition-to-employment/${id}`)}
        type="tertiary"
      >
        View
      </GoAButton>
    );
  };

  return (
    <tr>
      <td>
        <GoABadge type="information" content={status} />
      </td>
      <td>{`${status === ServicePlanStatus.NOT_STARTED ? '' : startdate}`}</td>
      <td>{type}</td>
      <td>{agreementName}</td>
      <td>{managedBy}</td>
      <td>{renderAction()}</td>
      {isSuperAdmin && [ServicePlanStatus.CLOSED, ServicePlanStatus.CANCELLED].includes(status) && (
        <td>
          <GoAButton
            onClick={() =>
              showModal(<ReopenServicePlanModal servicePlanId={id} clientId={clientId} hideModal={hideModal} />)
            }
            type="tertiary"
          >
            Reopen
          </GoAButton>
        </td>
      )}
    </tr>
  );
}
