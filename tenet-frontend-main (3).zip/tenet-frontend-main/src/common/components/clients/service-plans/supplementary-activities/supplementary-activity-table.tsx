/* eslint-disable jsx-a11y/control-has-associated-label */
import { useEffect } from 'react';
import { GoACallout, GoATable } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { useStore } from '../../../../../hooks/use-store.hook';

type Props = {
  activityRows: JSX.Element[] | undefined;
  message: string | undefined;
  isReadOnly: boolean;
};

export const SupplementaryActivityTable = observer(({ activityRows, message }: Props) => {
  const {
    supplementaryActivityFormStore: { getActivities },
  } = useStore();

  useEffect(() => {
    getActivities().catch(() => {});
  }, [getActivities]);

  return (
    <div>
      {!activityRows?.length ? (
        <p>
          You haven’t added any activity. Add Short Courses, Employment Readiness Support items, and/or Unpaid Work
          Experience in this section.
        </p>
      ) : undefined}
      {activityRows?.length ? (
        <GoATable>
          <tbody>{activityRows}</tbody>
        </GoATable>
      ) : undefined}

      {message && (
        <GoACallout mt="m" type="success" size="medium" maxWidth="26rem">
          {message}
        </GoACallout>
      )}
    </div>
  );
});
