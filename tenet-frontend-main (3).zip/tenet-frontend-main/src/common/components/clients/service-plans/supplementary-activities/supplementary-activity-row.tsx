/* eslint-disable no-plusplus */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { useEffect, useMemo, useState } from 'react';
import { format, isPast } from 'date-fns';
import { GoAButton, GoADropdown, GoADropdownItem, GoAIcon } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import {
  SupplementaryActivity,
  SupplementaryActivityOutcome,
  supplementaryActivityOutcomeLabels,
  SupplementaryActivityType,
  supplementaryActivityTypeLabels,
} from '../../../../../types/service-plan';
import { noteService } from '../../../../../services/note.service';
import { useModal } from '../../../../../hooks/use-modal.hook';
import SupplementaryActivityForm from '../../../forms/clients/service-plans/supplementary-activity-form';
import useUpdateOutcome from '../hooks/use-update-outcome.hook';
import { toIsoDate } from '../../../../../utils/date.util';

type Props = {
  activity: SupplementaryActivity;
  expandedRecordId?: string;
  toggleExpansion: (id: string) => void;
  setMessage: (message: string) => void;
  isReadOnly: boolean;
};

export const SupplementaryActivityRow = observer(
  ({ expandedRecordId, activity, toggleExpansion, setMessage, isReadOnly }: Props) => {
    const { showModal } = useModal();
    const isActivityCancelled = useMemo(
      () => activity.outcome === SupplementaryActivityOutcome.CANCELLED,
      [activity.outcome],
    );
    const outcome = useMemo(
      () => (activity.outcome ? supplementaryActivityOutcomeLabels[activity.outcome] : undefined),
      [activity.outcome],
    );
    const isOpen = useMemo(
      () => isReadOnly || expandedRecordId === activity.id,
      [isReadOnly, expandedRecordId, activity.id],
    );
    const iconType = useMemo(() => (isOpen ? 'chevron-down' : 'chevron-forward'), [isOpen]);
    const [comment, setComment] = useState<string | undefined>(undefined);

    const { updateOutcome } = useUpdateOutcome({
      activityId: activity.id,
      setMessage,
    });
    const isOutcomeSelectionDisabled = useMemo(() => {
      if (isReadOnly) {
        return isReadOnly;
      }
      if (activity.endDate) {
        return !isPast(activity.endDate);
      }
      if (activity.supportProvidedOn) {
        return !isPast(activity.supportProvidedOn);
      }

      return false;
    }, [activity.endDate, activity.supportProvidedOn, isReadOnly]);

    useEffect(() => {
      noteService
        .getByRecordId(activity.id)
        .then((notes) => {
          setComment(notes.length ? notes[0].message : undefined);
        })
        .catch(() => {});
    }, [activity, activity.id]);

    return (
      <>
        <tr key={activity.id}>
          <td>
            <button type="button" className="org-location-openBtn" onClick={() => toggleExpansion(activity.id)}>
              <GoAIcon type={iconType} />
            </button>
          </td>
          <td>{supplementaryActivityTypeLabels[activity.activityType]}</td>
          <td>{activity.name ?? activity.supportItem ?? activity.competencyToDevelop}</td>
          <td>
            {isActivityCancelled && 'Cancelled'}
            {!isActivityCancelled && (
              <GoADropdown
                name="outcomeSelector"
                ariaLabelledBy="outcomeSelector"
                value={activity.outcome}
                onChange={updateOutcome}
                placeholder="Select outcome"
                disabled={isOutcomeSelectionDisabled}
              >
                {activity.activityType === SupplementaryActivityType.UNPAID_WORK_EXPERIENCE ? (
                  <>
                    <GoADropdownItem
                      value={SupplementaryActivityOutcome.COMPLETE_JOB_OFFER}
                      name="outcome"
                      label={supplementaryActivityOutcomeLabels[SupplementaryActivityOutcome.COMPLETE_JOB_OFFER]}
                    />
                    <GoADropdownItem
                      value={SupplementaryActivityOutcome.COMPLETE_NO_JOB_OFFER}
                      name="outcome"
                      label={supplementaryActivityOutcomeLabels[SupplementaryActivityOutcome.COMPLETE_NO_JOB_OFFER]}
                    />
                  </>
                ) : (
                  <GoADropdownItem
                    value={SupplementaryActivityOutcome.COMPLETE}
                    name="outcome"
                    label={supplementaryActivityOutcomeLabels[SupplementaryActivityOutcome.COMPLETE]}
                  />
                )}
                <GoADropdownItem
                  value={SupplementaryActivityOutcome.INCOMPLETE}
                  name="outcome"
                  label={supplementaryActivityOutcomeLabels[SupplementaryActivityOutcome.INCOMPLETE]}
                />
                <GoADropdownItem
                  value={SupplementaryActivityOutcome.FAILED_TO_REPORT}
                  name="outcome"
                  label={supplementaryActivityOutcomeLabels[SupplementaryActivityOutcome.FAILED_TO_REPORT]}
                />
              </GoADropdown>
            )}
          </td>
          <td>
            {!isActivityCancelled && !isReadOnly && (
              <GoAButton
                type="tertiary"
                onClick={() => {
                  showModal(<SupplementaryActivityForm heading="Edit activity" btnLabel="Save" activity={activity} />);
                }}
              >
                Edit
              </GoAButton>
            )}
          </td>
        </tr>
        {isOpen && (
          <tr>
            <td colSpan={5} className="padding-0">
              <div className="details-container">
                {activity.supportProvidedOn && (
                  <div className="details-item">
                    <div className="detail-heading">Support provided on</div>
                    <div>{format(toIsoDate(activity.supportProvidedOn), 'MMMM d, yyyy')}</div>
                  </div>
                )}
                {activity.startDate && (
                  <div className="details-item">
                    <div className="detail-heading">Start date</div>
                    <div>{format(toIsoDate(activity.startDate), 'MMMM d, yyyy')}</div>
                  </div>
                )}
                {activity.endDate && (
                  <div className="details-item">
                    <div className="detail-heading">End date</div>
                    <div>{format(toIsoDate(activity.endDate), 'MMMM d, yyyy')}</div>
                  </div>
                )}
                <div className="details-item">
                  <div className="detail-heading">Provider</div>
                  <div>{activity.provider}</div>
                </div>
                <div className="details-item">
                  <div className="detail-heading">Cost</div>
                  <div>{activity.cost?.toFixed(2)}</div>
                </div>
              </div>
              <div className="details-container">
                <div className="details-item">
                  <div className="detail-heading">Outcome</div>
                  <div>{outcome}</div>
                </div>
                <div className="details-item">
                  <div className="detail-heading">Description</div>
                  <div>{activity.description}</div>
                </div>
                <div className="details-item">
                  <div className="detail-heading">General comments</div>
                  <div>{comment}</div>
                </div>
              </div>
            </td>
          </tr>
        )}
      </>
    );
  },
);
