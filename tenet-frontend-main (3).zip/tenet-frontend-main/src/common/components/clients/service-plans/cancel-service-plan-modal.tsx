import { GoAButton, GoAButtonGroup, GoAModal, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

interface Props {
  hideModal: () => void;
  cancelServicePlan: () => void;
}

export const ServicePlanCancelModal = observer(({ hideModal, cancelServicePlan }: Props) => {
  return (
    <GoAModal maxWidth="500px" open width="480px" transition="slow" heading="Cancel service plan" onClose={hideModal}>
      <p>The client never started the intervention. This will remove the client from any reporting.</p>
      <GoASpacer vSpacing="l" />
      <GoAButtonGroup alignment="end">
        <GoAButton onClick={hideModal}>Go back</GoAButton>
        <GoAButton onClick={cancelServicePlan} variant="destructive">
          Cancel
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
});
