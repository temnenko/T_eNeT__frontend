import { useMemo } from 'react';
import { observer } from 'mobx-react-lite';
import { GoADivider, GoADropdown, GoADropdownItem, GoASpacer } from '@abgov/react-components';
import { useNotesList } from '../hooks/use-notes-list.hook';
import { NoteCard } from './note-card';
import { Note } from '../../../../types/note';
import { ListPagination } from '../../list-pagination';
import { useSoftDeleteNote } from '../hooks/use-soft-delete-note.hook';

type Props = {
  notesFor: 'client' | 'service-plan';
};

export const NotesList = observer(({ notesFor }: Props) => {
  const isClient = useMemo(() => notesFor === 'client', [notesFor]);
  const {
    notes,
    onSortOrderChangeHandler,
    sortOrder,
    page,
    pageSize,
    actualPageSize,
    changePerPageSize,
    onPaginationChangeHandler,
    fetchNotes,
    notesTotalCount,
  } = useNotesList(isClient);
  const { softDeleteNoteHandler } = useSoftDeleteNote(fetchNotes);

  return (
    <div>
      <GoADivider />
      <GoASpacer vSpacing="m" />
      {notes.length === 0 && <center>No notes have been added yet.</center>}
      {notes.length > 0 && (
        <>
          <div className="d-flex align-items-center">
            <div>
              <strong>Sort by</strong>
              &nbsp;
            </div>
            <div>
              <GoADropdown value={sortOrder} onChange={onSortOrderChangeHandler}>
                <GoADropdownItem value="desc" label="Newest first" />
                <GoADropdownItem value="asc" label="Oldest first" />
              </GoADropdown>
            </div>
          </div>
          <GoASpacer vSpacing="m" />
        </>
      )}
      {notes.map((note: Note) => (
        <>
          <NoteCard isClient={isClient} note={note} softDeleteNoteHandler={softDeleteNoteHandler} key={note.id} />
          <GoASpacer vSpacing="m" />
        </>
      ))}
      <GoASpacer vSpacing="m" />
      <ListPagination
        variant={isClient ? 'all' : 'links-only'}
        perPageSize={pageSize}
        actualPageSize={actualPageSize}
        perPageSizeOptions={[10, 20, 30]}
        changePerPageSize={changePerPageSize}
        pagePosition={page}
        changePagePosition={onPaginationChangeHandler}
        totalCount={notesTotalCount}
      />
    </div>
  );
});
