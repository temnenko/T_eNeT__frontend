import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';

import { differenceInDays } from 'date-fns';
import {
  FollowUpOutcomeEmploymentReason,
  ServicePlanFollowUpOutcome,
  ServicePlanStatus,
} from '../../../../../types/service-plan';
import { useStore } from '../../../../../hooks/use-store.hook';
import { getListItems } from '../../../../../utils/list-items.util';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../types/errors/errors';
import { toIsoFormat } from '../../../../../utils/date.util';

type FollowupOutcomeFieldName = 'outcome' | 'contactDate' | 'sameEmployment';

type FollowupOutcomeFieldData = {
  outcome: ServicePlanFollowUpOutcome;
  contactDate: string;
  sameEmployment: FollowUpOutcomeEmploymentReason;
};

const useFollowupOutcome = () => {
  const {
    servicePlanStore: { servicePlan, updateServicePlan, setStep, startDate },
  } = useStore();
  const [loading, setLoading] = useState(false);
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});
  const [visible, setVisible] = useState(false);

  const {
    getValues,
    register,
    setValue,
    handleSubmit,
    watch,
    formState: { errors },
    reset,
    setError,
  } = useForm<FollowupOutcomeFieldData>({
    defaultValues: {
      outcome: servicePlan?.followUpOutcome,
      contactDate: servicePlan?.contactDate ? toIsoFormat(servicePlan?.contactDate) : undefined,
      sameEmployment: servicePlan?.outcomeMatchesEmployment
        ? FollowUpOutcomeEmploymentReason.Yes
        : FollowUpOutcomeEmploymentReason.No,
    },
  });

  useEffect(() => {
    if (servicePlan) {
      reset({
        outcome: servicePlan?.followUpOutcome,
        contactDate: servicePlan?.contactDate ? toIsoFormat(servicePlan?.contactDate) : undefined,
        sameEmployment: servicePlan?.outcomeMatchesEmployment
          ? FollowUpOutcomeEmploymentReason.Yes
          : FollowUpOutcomeEmploymentReason.No,
      });
    }
  }, [reset, servicePlan]);

  const { name: outcome } = register('outcome', {
    required: { value: true, message: 'This field is required' },
  });

  const { name: contactDate } = register('contactDate', {
    required: { value: true, message: 'This field is required' },
  });

  const watchOutcome = watch(outcome);

  const { name: sameEmployment } = register('sameEmployment', {
    required: {
      value: watchOutcome === ServicePlanFollowUpOutcome.EMPLOYED_RELATED_FIELD,
      message: 'This field is required',
    },
  });
  const watchEmployment = watch(sameEmployment);

  const formFields = {
    outcome,
    contactDate,
    sameEmployment,
    watchEmployment,
  };

  const outcomeOptions = getListItems(ServicePlanFollowUpOutcome, 'dropdown');

  const onChangeHandler = useCallback(
    (name: string, value: string | ServicePlanFollowUpOutcome | FollowUpOutcomeEmploymentReason) => {
      setValue(name as FollowupOutcomeFieldName, value);
    },
    [setValue],
  );

  const hasInvalidFields = useCallback(() => {
    const contact = getValues(contactDate);
    if (differenceInDays(contact, new Date()) > 0) {
      setError(contactDate, { type: 'custom', message: 'Cannot select a future follow up date' });
      return true;
    }

    return false;
  }, [contactDate, getValues, setError]);

  const saveFollowupOutcome = useCallback(async () => {
    try {
      if (hasInvalidFields()) {
        return;
      }
      if (servicePlan?.id) {
        setLoading(true);
        const { id, clientId } = servicePlan;
        const recordOutcome = {
          followUpOutcome: getValues(outcome),
          contactDate: new Date(getValues(contactDate)),
          outcomeMatchesEmployment: getValues(sameEmployment) === FollowUpOutcomeEmploymentReason.Yes,
          status: ServicePlanStatus.COMPLETE,
        };
        await updateServicePlan(id, clientId, recordOutcome);
        setLoading(false);
        setVisible(true);
        setTimeout(() => {
          setVisible(false);
        }, 5000);
        setStep(3);
      }
    } catch (error) {
      setLoading(false);
      requestErrorHandler({
        error,
        setError: setRequestError,
      });
    }
  }, [
    hasInvalidFields,
    servicePlan,
    getValues,
    outcome,
    contactDate,
    sameEmployment,
    updateServicePlan,
    setStep,
    requestErrorHandler,
  ]);

  return {
    formFields,
    handleSubmit,
    onChangeHandler,
    errors,
    setValue,
    getValues,
    outcomeOptions,
    saveFollowupOutcome,
    loading,
    followupContactDate: servicePlan?.contactDate,
    requestError,
    contactDate,
    employment: servicePlan?.employmentId,
    visible,
    startDate,
  };
};

export default useFollowupOutcome;
