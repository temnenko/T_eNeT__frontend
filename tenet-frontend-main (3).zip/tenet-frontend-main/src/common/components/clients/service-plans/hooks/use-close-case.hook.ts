import { useCallback, useMemo } from 'react';
import { useStore } from '../../../../../hooks/use-store.hook';
import useToastMessage from '../../../../../hooks/use-toast-message.hook';
import { ServicePlanOutcome, ServicePlanStatus } from '../../../../../types/service-plan';

const useCloseCase = () => {
  const { message, setToastMessage } = useToastMessage();

  const {
    clientsStore: { getClientById },
    servicePlanStore: { servicePlan, closeCase },
    supplementaryActivityFormStore: { supplementaryActivities },
  } = useStore();

  const activityOutcomeRecorded = useMemo(() => {
    return supplementaryActivities
      ?.filter(({ servicePlanId }) => servicePlan?.id === servicePlanId)
      ?.every(({ outcome }) => !!outcome);
  }, [servicePlan?.id, supplementaryActivities]);

  const allRequiredFieldsCompleted = useMemo(() => {
    return (
      !!servicePlan?.actualStartDate &&
      !!servicePlan?.startDate &&
      !!servicePlan.contactDate &&
      !!servicePlan.followUpOutcome &&
      !!servicePlan.outcome &&
      servicePlan.outcomeMatchesEmployment !== undefined &&
      ![ServicePlanStatus.CANCELLED, ServicePlanStatus.CLOSED, ServicePlanStatus.NOT_STARTED].includes(
        servicePlan.status,
      )
    );
  }, [
    servicePlan?.actualStartDate,
    servicePlan?.contactDate,
    servicePlan?.followUpOutcome,
    servicePlan?.outcome,
    servicePlan?.outcomeMatchesEmployment,
    servicePlan?.startDate,
    servicePlan?.status,
  ]);

  const isIncompleteAndInProgress = useMemo(
    () =>
      servicePlan?.outcome === ServicePlanOutcome.INCOMPLETE && servicePlan?.status === ServicePlanStatus.IN_PROGRESS,
    [servicePlan?.outcome, servicePlan?.status],
  );

  const caseClosable = useMemo(
    () => (activityOutcomeRecorded && allRequiredFieldsCompleted) || isIncompleteAndInProgress,
    [activityOutcomeRecorded, allRequiredFieldsCompleted, isIncompleteAndInProgress],
  );

  const closeCaseHandler = useCallback(async () => {
    if (caseClosable && servicePlan) {
      try {
        await closeCase(servicePlan.clientId, servicePlan.id);
        await getClientById(servicePlan.clientId);
        setToastMessage('Case closed successfully');
      } catch (e) {
        // eslint-disable-next-line no-console
        console.error(e);
      }
    }
  }, [caseClosable, closeCase, getClientById, servicePlan, setToastMessage]);

  return {
    caseClosable,
    closeCaseHandler,
    message,
    shouldCloseWithoutValidation: isIncompleteAndInProgress,
  };
};

export default useCloseCase;
