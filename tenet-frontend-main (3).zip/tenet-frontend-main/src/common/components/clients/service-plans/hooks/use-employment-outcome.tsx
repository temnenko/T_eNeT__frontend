import { useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';
import { ServicePlanFollowUpOutcome, UpdateServicePlan } from '../../../../../types/service-plan';
import { useStore } from '../../../../../hooks/use-store.hook';
import { getListItems } from '../../../../../utils/list-items.util';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../types/errors/errors';
import { toIsoFormat } from '../../../../../utils/date.util';

type FollowupOutcomeFieldName = 'employmentOutcome' | 'outcomeDate';

type FollowupOutcomeFieldData = {
  employmentOutcome: ServicePlanFollowUpOutcome;
  outcomeDate: string;
};

const useEmploymentOutcome = () => {
  const {
    servicePlanStore: { servicePlan, updateServicePlan, employmentAdded },
    permissionStore: { canEditEmployment },
  } = useStore();
  const [loading, setLoading] = useState(false);
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});
  const [visible, setVisible] = useState(false);

  const {
    getValues,
    register,
    setValue,
    handleSubmit,
    formState: { errors },
    watch,
    reset,
  } = useForm<FollowupOutcomeFieldData>({
    defaultValues: {
      employmentOutcome: servicePlan?.followUpOutcome,
      outcomeDate: servicePlan?.outcomeDate ? toIsoFormat(servicePlan?.outcomeDate) : undefined,
    },
  });

  const { name: employmentOutcome } = register('employmentOutcome', {
    required: { value: true, message: 'This field is required' },
  });
  const { name: outcomeDate } = register('outcomeDate', {
    required: { value: true, message: 'This field is required' },
  });

  const watchEmploymentOutcome = watch(employmentOutcome);

  const formFields = {
    employmentOutcome,
    outcomeDate,
  };

  const outcomeOptions = getListItems(ServicePlanFollowUpOutcome, 'dropdown');

  const onChangeHandler = useCallback(
    (name: string, value: string | ServicePlanFollowUpOutcome) => {
      setValue(name as FollowupOutcomeFieldName, value);
    },
    [setValue],
  );

  const saveEmploymentOutcome = useCallback(async () => {
    try {
      if (servicePlan?.id) {
        setLoading(true);
        const { id, clientId } = servicePlan;
        const recordOutcome: UpdateServicePlan = {
          followUpOutcome: getValues(employmentOutcome),
          outcomeDate: new Date(getValues(outcomeDate)),
        };
        await updateServicePlan(id, clientId, recordOutcome);
        setLoading(false);
        setVisible(true);
        setTimeout(() => {
          setVisible(false);
        }, 10000);
      }
    } catch (error) {
      setLoading(false);
      requestErrorHandler({
        error,
        setError: setRequestError,
      });
    }
  }, [servicePlan, getValues, employmentOutcome, outcomeDate, updateServicePlan, requestErrorHandler]);

  const updateText = useMemo(() => {
    if (loading) {
      return 'Saving';
    }

    if (servicePlan) {
      if (watchEmploymentOutcome && servicePlan.followUpOutcome !== watchEmploymentOutcome) {
        return 'Save';
      }
      return 'Edit';
    }
    return 'Save';
  }, [loading, servicePlan, watchEmploymentOutcome]);

  useEffect(() => {
    if (servicePlan) {
      reset({
        employmentOutcome: servicePlan.followUpOutcome,
        outcomeDate: servicePlan.outcomeDate ? toIsoFormat(servicePlan.outcomeDate) : undefined,
      });
    }
  }, [reset, servicePlan]);

  return {
    formFields,
    handleSubmit,
    onChangeHandler,
    errors,
    setValue,
    getValues,
    outcomeOptions,
    saveEmploymentOutcome,
    loading,
    requestError,
    employmentId: servicePlan?.employmentId,
    employmentAdded,
    visible,
    serviceplanId: servicePlan?.id,
    canEditEmployment,
    updateText,
  };
};

export default useEmploymentOutcome;
