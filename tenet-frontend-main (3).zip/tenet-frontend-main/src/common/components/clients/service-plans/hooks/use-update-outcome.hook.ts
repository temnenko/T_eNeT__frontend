import { useCallback, useState } from 'react';

import { useStore } from '../../../../../hooks/use-store.hook';
import { SupplementaryActivityOutcome } from '../../../../../types/service-plan';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../types/errors/errors';

type Args = {
  activityId: string;
  setMessage: (message: string) => void;
};

const useUpdateOutcome = ({ activityId, setMessage }: Args) => {
  const {
    supplementaryActivityFormStore: { updateActivity },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});

  const updateOutcome = useCallback(
    async (_name: string, value: string | string[]) => {
      try {
        if (typeof value === 'string') {
          await updateActivity(activityId, { outcome: value as SupplementaryActivityOutcome });

          setMessage('Outcome updated.');
        }
      } catch (error) {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      }
    },
    [activityId, requestErrorHandler, setMessage, updateActivity],
  );

  return {
    requestError,
    updateOutcome,
  };
};

export default useUpdateOutcome;
