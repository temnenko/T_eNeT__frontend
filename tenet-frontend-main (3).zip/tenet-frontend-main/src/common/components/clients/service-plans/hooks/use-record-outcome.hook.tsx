import { useCallback, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';

import {
  ServicePlanDropoutReason,
  ServicePlanOutcome,
  ServicePlanStatus,
  UpdateServicePlan,
} from '../../../../../types/service-plan';
import { useStore } from '../../../../../hooks/use-store.hook';
import { getListItems } from '../../../../../utils/list-items.util';
import useRequestErrorHandler from '../../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../../types/errors/errors';
import useTransitionToEmploymentForm from '../../hooks/use-transition-to-employment-form.hook';
import { toIsoFormat } from '../../../../../utils/date.util';

type RecordOutcomeFieldName = 'outcome' | 'serviceEndDate' | 'dropoutReason';

type RecordOutcomeFieldData = {
  outcome: ServicePlanOutcome;
  serviceEndDate: string;
  dropoutReason: ServicePlanDropoutReason;
};

const useRecordOutcome = () => {
  const {
    servicePlanStore: { servicePlan, updateServicePlan },
  } = useStore();
  const [loading, setLoading] = useState(false);
  const requestErrorHandler = useRequestErrorHandler();
  const [requestError, setRequestError] = useState<RequestError>({});

  const {
    getValues,
    register,
    setValue,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<RecordOutcomeFieldData>({
    defaultValues: {
      outcome: servicePlan?.outcome,
      serviceEndDate: servicePlan?.endDate ? toIsoFormat(servicePlan?.endDate) : undefined,
      dropoutReason: servicePlan?.dropoutReason,
    },
  });

  const { name: outcome } = register('outcome', {
    required: { value: true, message: 'This field is required' },
  });

  const { name: serviceEndDate } = register('serviceEndDate', {
    required: { value: true, message: 'This field is required' },
  });

  const watchOutcome = watch(outcome);
  const watchEndDate = watch(serviceEndDate);

  const { name: dropoutReason } = register('dropoutReason', {
    required: { value: watchOutcome === ServicePlanOutcome.INCOMPLETE, message: 'This field is required' },
  });

  const watchReason = watch(dropoutReason);

  const formFields = {
    outcome,
    serviceEndDate,
    dropoutReason,
    watchOutcome,
  };
  const { isPlanInProgress, isPlanInProgressOrComplete } = useTransitionToEmploymentForm();

  const outcomeOptions = getListItems(
    ServicePlanOutcome,
    'radio',
    undefined,
    !!servicePlan?.outcome || !isPlanInProgress,
  );

  const reasonOptions = getListItems(ServicePlanDropoutReason, 'dropdown', true);

  const onChangeHandler = useCallback(
    (name: string, value: string | ServicePlanOutcome | ServicePlanDropoutReason) => {
      setValue(name as RecordOutcomeFieldName, value);
    },
    [setValue],
  );

  const saveRecordOutcome = useCallback(async () => {
    try {
      if (servicePlan?.id) {
        setLoading(true);
        const { id, clientId, followUpOutcome, contactDate } = servicePlan;
        const isFollowUpRecorded = !!followUpOutcome && !!contactDate;
        const status =
          getValues(outcome) === ServicePlanOutcome.INCOMPLETE || isFollowUpRecorded
            ? ServicePlanStatus.COMPLETE
            : ServicePlanStatus.IN_FOLLOW_UP;
        const recordOutcome: UpdateServicePlan = {
          outcome: getValues(outcome),
          dropoutReason: getValues(dropoutReason),
          endDate: new Date(getValues(serviceEndDate)),
          status,
        };
        await updateServicePlan(id, clientId, recordOutcome);
        setLoading(false);
      }
    } catch (error) {
      setLoading(false);
      requestErrorHandler({
        error,
        setError: setRequestError,
      });
    }
  }, [dropoutReason, getValues, outcome, requestErrorHandler, serviceEndDate, servicePlan, updateServicePlan]);

  const updateText = useMemo(() => {
    if (loading) {
      return 'Saving';
    }

    if (servicePlan) {
      if (
        (watchEndDate && servicePlan?.endDate && toIsoFormat(servicePlan?.endDate) !== watchEndDate) ||
        (watchOutcome && servicePlan.outcome !== watchOutcome) ||
        (watchReason && servicePlan.dropoutReason !== watchReason)
      ) {
        return 'Save';
      }
      return 'Edit';
    }
    return 'Save';
  }, [loading, servicePlan, watchEndDate, watchOutcome, watchReason]);

  return {
    formFields,
    handleSubmit,
    onChangeHandler,
    errors,
    setValue,
    getValues,
    outcomeOptions,
    reasonOptions,
    saveRecordOutcome,
    loading,
    requestError,
    servicePlan,
    isPlanInProgressOrComplete,
    updateText,
  };
};

export default useRecordOutcome;
