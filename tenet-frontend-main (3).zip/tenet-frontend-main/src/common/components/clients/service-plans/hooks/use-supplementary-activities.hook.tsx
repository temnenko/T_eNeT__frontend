import { useCallback, useMemo, useState } from 'react';
import { useStore } from '../../../../../hooks/use-store.hook';
import { SupplementaryActivityRow } from '../supplementary-activities/supplementary-activity-row';
import useToastMessage from '../../../../../hooks/use-toast-message.hook';

const useSupplementaryActivities = (isReadOnly: boolean) => {
  const [expandedRecordId, setExpandedRecordId] = useState<string>();
  const { message, setToastMessage } = useToastMessage();

  const {
    supplementaryActivityFormStore: { supplementaryActivities },
  } = useStore();

  const toggleExpansion = useCallback(
    (id: string) => {
      if (id === expandedRecordId) {
        setExpandedRecordId(undefined);
      } else {
        setExpandedRecordId(id);
      }
    },
    [expandedRecordId],
  );

  const activityRows = useMemo(() => {
    return supplementaryActivities?.map((activity) => (
      <SupplementaryActivityRow
        key={activity.id}
        activity={activity}
        expandedRecordId={expandedRecordId}
        toggleExpansion={toggleExpansion}
        setMessage={setToastMessage}
        isReadOnly={isReadOnly}
      />
    ));
  }, [expandedRecordId, isReadOnly, setToastMessage, supplementaryActivities, toggleExpansion]);

  return {
    activityRows,
    message,
  };
};

export default useSupplementaryActivities;
