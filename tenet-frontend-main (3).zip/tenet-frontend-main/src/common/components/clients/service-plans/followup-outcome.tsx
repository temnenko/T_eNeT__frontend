import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoACallout,
  GoADropdown,
  GoAFormItem,
  GoAInput,
  GoANotification,
  GoARadioGroup,
  GoARadioItem,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { format } from 'date-fns';
import useFollowupOutcome from './hooks/use-followup-outcome.hook';
import { FollowUpOutcomeEmploymentReason, ServicePlanFollowUpOutcome } from '../../../../types/service-plan';
import useTransitionToEmploymentForm from '../hooks/use-transition-to-employment-form.hook';
import { toIsoDate, toIsoFormat } from '../../../../utils/date.util';

type Props = {
  isReadOnly: boolean;
};

export const FollowupOutcomeForm = observer(({ isReadOnly }: Props) => {
  const {
    formFields,
    handleSubmit,
    onChangeHandler,
    errors,
    getValues,
    outcomeOptions,
    saveFollowupOutcome,
    loading,
    followupContactDate,
    requestError,
    employment,
    visible,
    startDate,
  } = useFollowupOutcome();
  const { isPlanInProgress } = useTransitionToEmploymentForm();

  const { outcome, contactDate, sameEmployment, watchEmployment } = formFields;
  return (
    <GoABlock direction="column">
      <div>
        <GoABlock direction="column" gap="s">
          <div className={!contactDate ? 'field-interactive-error' : ''}>
            <GoAFormItem error={errors[contactDate]?.message as unknown as string} label="Contact date">
              <GoAInput
                type="date"
                onChange={(name: string, value: string | undefined) => {
                  if (value) {
                    onChangeHandler(name, value);
                  }
                }}
                name={contactDate}
                value={getValues(contactDate) ? toIsoFormat(getValues(contactDate)!) : undefined}
                disabled={!isPlanInProgress || isReadOnly}
                min={startDate ? toIsoFormat(startDate) : '0000-01-01'}
                max={toIsoFormat(new Date())}
              />
            </GoAFormItem>
          </div>
        </GoABlock>
        <GoASpacer vSpacing="s" />
        <GoABlock direction="column">
          <GoAFormItem label="Followup outcome" error={errors.outcome?.message as unknown as string}>
            <GoADropdown
              name={outcome}
              value={getValues(outcome)}
              onChange={(name, value) => {
                onChangeHandler(name, ServicePlanFollowUpOutcome[value as unknown as ServicePlanFollowUpOutcome]);
              }}
              width="398px"
              filterable
              relative
              disabled={!isPlanInProgress || isReadOnly}
            >
              {outcomeOptions}
            </GoADropdown>
          </GoAFormItem>
          <GoASpacer vSpacing="s" />
        </GoABlock>
        {getValues(outcome) === ServicePlanFollowUpOutcome.EMPLOYED_RELATED_FIELD && (
          <GoABlock direction="column">
            <GoAFormItem
              label="Is this still the same employment as added above?"
              error={errors.sameEmployment?.message as unknown as string}
            >
              <GoARadioGroup
                name={sameEmployment}
                value={getValues(sameEmployment)}
                onChange={(name, value) => {
                  onChangeHandler(
                    name,
                    FollowUpOutcomeEmploymentReason[value as unknown as FollowUpOutcomeEmploymentReason],
                  );
                }}
                orientation="vertical"
                disabled={!isPlanInProgress || isReadOnly}
              >
                <GoARadioItem
                  value={FollowUpOutcomeEmploymentReason.Yes}
                  label="Yes"
                  disabled={!isPlanInProgress || isReadOnly}
                />
                <GoARadioItem value={FollowUpOutcomeEmploymentReason.No} label="No" disabled={!!followupContactDate} />
              </GoARadioGroup>
            </GoAFormItem>
            <GoASpacer vSpacing="xs" />
            {watchEmployment === FollowUpOutcomeEmploymentReason.No && !employment && (
              <>
                <GoACallout type="important" size="medium">
                  Update new employment information.
                </GoACallout>
                <GoASpacer vSpacing="xs" />
              </>
            )}
          </GoABlock>
        )}

        {!isReadOnly && (
          <GoAButtonGroup alignment="start">
            <GoAButton
              type="secondary"
              onClick={handleSubmit(saveFollowupOutcome)}
              disabled={loading || !isPlanInProgress}
            >
              Save
            </GoAButton>
          </GoAButtonGroup>
        )}

        <GoASpacer vSpacing="xs" />
        {!loading && followupContactDate && visible && (
          <GoACallout type="success" size="medium">
            {`Followup result is saved on ${format(toIsoDate(followupContactDate), 'MMMM dd, yyyy')}`}
          </GoACallout>
        )}
        {requestError?.message && (
          <>
            <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
              {requestError.message}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
      </div>
    </GoABlock>
  );
});
