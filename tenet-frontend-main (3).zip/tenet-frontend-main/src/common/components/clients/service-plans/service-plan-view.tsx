import { observer } from 'mobx-react-lite';
import { useEffect, useState } from 'react';
import { GoASpacer } from '@abgov/react-components';
import { useParams, useSearchParams } from 'react-router-dom';
import { ServicePlansTable } from './service-plan-list-table';
import { useStore } from '../../../../hooks/use-store.hook';

export const ServicePlanView = observer(() => {
  const {
    supplementaryActivityFormStore: { resetActivityStore },
    servicePlanStore: { resetPlanStore },
    servicePlansListStore: { getAllServicePlans, hasPlans },
  } = useStore();
  const [isLoading, setIsLoading] = useState(true);
  const { id: clientId } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const origin = searchParams.get('origin') ?? undefined;

  useEffect(() => {
    if (clientId) {
      getAllServicePlans(clientId, origin).finally(() => setIsLoading(false));
    }

    resetActivityStore();
    resetPlanStore();
  }, [clientId, getAllServicePlans, origin, resetActivityStore, resetPlanStore]);
  return (
    <div className="service-plan-list">
      <p>Service Plans</p>
      <span>Service plans are generated automatically based on a complete and approved assessment. </span>
      <GoASpacer vSpacing="xs" />
      <ServicePlansTable isLoading={isLoading} hasPlans={hasPlans} />
    </div>
  );
});
