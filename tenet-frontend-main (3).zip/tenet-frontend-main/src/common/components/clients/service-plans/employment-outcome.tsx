import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoACallout,
  GoADropdown,
  GoAFormItem,
  GoAInput,
  GoANotification,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { ServicePlanFollowUpOutcome } from '../../../../types/service-plan';
import useEmploymentOutcome from './hooks/use-employment-outcome';
import useTransitionToEmploymentForm from '../hooks/use-transition-to-employment-form.hook';
import { EmploymentForm } from '../../forms/clients/employmentHistory/employment-history-form';
import { useModal } from '../../../../hooks/use-modal.hook';
import { toIsoFormat } from '../../../../utils/date.util';

type Props = {
  isReadOnly: boolean;
};

export const EmploymentOutcomeForm = observer(({ isReadOnly }: Props) => {
  const {
    formFields,
    handleSubmit,
    onChangeHandler,
    errors,
    getValues,
    outcomeOptions,
    saveEmploymentOutcome,
    loading,
    requestError,
    employmentId,
    employmentAdded,
    visible,
    serviceplanId,
    canEditEmployment,
    updateText,
  } = useEmploymentOutcome();
  const { clientId, isPlanInProgress } = useTransitionToEmploymentForm();

  const { employmentOutcome, outcomeDate } = formFields;
  const { showModal } = useModal();

  return (
    <GoABlock direction="column">
      <div>
        <GoABlock direction="column">
          <GoAFormItem label="Outcome" error={errors.employmentOutcome?.message as unknown as string}>
            <GoADropdown
              name={employmentOutcome}
              value={getValues(employmentOutcome)}
              onChange={(name, value) => {
                onChangeHandler(name, ServicePlanFollowUpOutcome[value as unknown as ServicePlanFollowUpOutcome]);
              }}
              width="398px"
              filterable
              relative
              disabled={!isPlanInProgress || isReadOnly}
            >
              {outcomeOptions}
            </GoADropdown>
          </GoAFormItem>
          <GoASpacer vSpacing="s" />
        </GoABlock>
        <GoAFormItem error={errors[outcomeDate]?.message as unknown as string} label="Outcome date">
          <GoAInput
            type="date"
            onChange={(name: string, value: string | undefined) => {
              if (value) {
                onChangeHandler(name, value);
              }
            }}
            name={outcomeDate}
            value={getValues(outcomeDate) ? toIsoFormat(getValues(outcomeDate)!) : undefined}
            disabled={!isPlanInProgress || isReadOnly}
            min="0000-01-01"
            max={toIsoFormat(new Date())}
          />
          <GoASpacer vSpacing="s" />
        </GoAFormItem>
        {!isReadOnly && (
          <GoAButtonGroup alignment="start">
            <GoAButton
              type="tertiary"
              leadingIcon="add"
              size="compact"
              onClick={() => {
                if (clientId && !employmentId) {
                  showModal(
                    <EmploymentForm
                      clientId={clientId}
                      serviceplanId={serviceplanId}
                      canEditEmployment={canEditEmployment}
                    />,
                  );
                }
              }}
              disabled={!isPlanInProgress}
            >
              Add employment
            </GoAButton>
          </GoAButtonGroup>
        )}

        <GoASpacer vSpacing="xs" />
        {!loading && (employmentAdded || employmentId) && (
          <>
            <GoACallout type="information" size="medium">
              New employment record is added on and synced on client’s employment record.
            </GoACallout>
            <GoASpacer vSpacing="xs" />
          </>
        )}
        {!isReadOnly && (
          <GoAButtonGroup alignment="start">
            <GoAButton
              type="secondary"
              onClick={handleSubmit(saveEmploymentOutcome)}
              disabled={loading || !isPlanInProgress}
            >
              {updateText}
            </GoAButton>
          </GoAButtonGroup>
        )}

        {!loading && visible && (
          <>
            <GoASpacer vSpacing="xs" />
            <GoACallout type="success" size="medium">
              Employment outcome saved.
            </GoACallout>
          </>
        )}
        {requestError?.message && (
          <>
            <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
              {requestError.message}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
      </div>
    </GoABlock>
  );
});
