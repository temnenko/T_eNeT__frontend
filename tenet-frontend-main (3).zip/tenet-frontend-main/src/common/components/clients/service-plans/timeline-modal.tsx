import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoAFormItem,
  GoAIconButton,
  GoAInput,
  GoAModal,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { subDays } from 'date-fns';
import useTimelineModal from '../hooks/use-timeline-modal.hook';
import { toIsoFormat } from '../../../../utils/date.util';

interface Props {
  hideModal: () => void;
}

export const ServicePlanTimelineModal = observer(({ hideModal }: Props) => {
  const { formFields, handleSubmit, onChangeHandler, errors, saveTimeline, duration, isPlanStarted, getValues } =
    useTimelineModal();
  const { planDuration, startDate } = formFields;
  return (
    <GoAModal
      maxWidth="500px"
      open
      width="480px"
      transition="slow"
      heading={startDate ? 'Edit Date' : 'Start service plan'}
      onClose={hideModal}
    >
      <p>Enter key date info to start.</p>
      <GoABlock direction="column" gap="s">
        <div className={!startDate ? 'field-interactive-error' : ''}>
          <GoAFormItem error={errors[startDate]?.message as unknown as string} label="Start date">
            <GoAInput
              type="date"
              onChange={(name: string, value: string | undefined) => {
                if (value) {
                  onChangeHandler(name, value);
                }
              }}
              name={startDate}
              value={getValues(startDate) ? toIsoFormat(getValues(startDate)!) : undefined}
              min={toIsoFormat(subDays(new Date(), 1))}
              max="9999-12-31"
              disabled={isPlanStarted}
            />
          </GoAFormItem>
        </div>
      </GoABlock>
      <GoASpacer vSpacing="l" />
      <GoABlock direction="column">
        <div className="service-plan-duration">
          <p>Planned duration of active service</p>
          <GoASpacer hSpacing="m" />
          <span>(Weeks)</span>
        </div>
        <GoAFormItem error={errors[planDuration]?.message as unknown as string}>
          <div className="client-demographic-btn-flex">
            <GoABlock direction="column">
              <GoABlock>
                <GoAIconButton
                  icon="remove"
                  size="medium"
                  onClick={() => {
                    if (duration) {
                      onChangeHandler(planDuration, duration - 1);
                    }
                  }}
                />
                <GoAInput
                  onChange={(name: string, value: string): void => {
                    onChangeHandler(name, +value);
                  }}
                  name={planDuration}
                  type="text"
                  id="planDuration"
                  width="71px"
                  value={duration?.toString()}
                />
                <GoAIconButton
                  icon="add"
                  size="medium"
                  onClick={() => {
                    onChangeHandler(planDuration, (!duration ? 0 : duration) + 1);
                  }}
                />
              </GoABlock>
            </GoABlock>
          </div>
        </GoAFormItem>
      </GoABlock>
      <GoASpacer vSpacing="xl" />
      <GoAButtonGroup alignment="end">
        <GoAButton type="secondary" onClick={hideModal}>
          Cancel
        </GoAButton>
        <GoAButton onClick={handleSubmit(saveTimeline)}>Set up</GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
});
