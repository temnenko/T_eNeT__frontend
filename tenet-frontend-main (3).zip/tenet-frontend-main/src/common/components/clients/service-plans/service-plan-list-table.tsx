import { GoATable, GoATableSortHeader } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';

import useServicePlanListRows from '../hooks/use-service-plan-list-rows.hook';
import { LoadingSkeleton } from '../clients-list-table.skeleton';

type Props = {
  isLoading: boolean;
  hasPlans: boolean;
};

export const ServicePlansTable = observer(({ isLoading, hasPlans }: Props) => {
  const { serviceplanListRows, sortData } = useServicePlanListRows();

  return hasPlans && !isLoading ? (
    <GoATable width="100%" onSort={sortData}>
      <thead>
        <tr>
          <th>
            <GoATableSortHeader name="status">Status</GoATableSortHeader>
          </th>
          <th>
            <GoATableSortHeader name="startdate">Started On</GoATableSortHeader>
          </th>
          <th>
            <GoATableSortHeader name="type">Type</GoATableSortHeader>
          </th>
          <th>
            <GoATableSortHeader name="agreementName">Agreement Name</GoATableSortHeader>
          </th>
          <th>
            <GoATableSortHeader name="managedBy">Manage By</GoATableSortHeader>
          </th>
          <th>{}</th>
          <th>{}</th>
        </tr>
      </thead>
      {isLoading ? <LoadingSkeleton /> : <tbody data-testid="clientsTable-tableBody">{serviceplanListRows}</tbody>}
    </GoATable>
  ) : (
    <p data-testid="noPlanFound">No service plans found</p>
  );
});
