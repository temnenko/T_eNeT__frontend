import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoAFormItem,
  GoAInput,
  GoAModal,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import useStartServicePlanModal from '../hooks/use-start-service-plan-modal.hook';
import { toIsoFormat } from '../../../../utils/date.util';

interface Props {
  hideModal: () => void;
}

export const StartServicePlanModal = observer(({ hideModal }: Props) => {
  const { handleSubmit, onChangeHandler, errors, getValues, actualStartDate, startServicePlanButtonHandler } =
    useStartServicePlanModal();
  return (
    <GoAModal maxWidth="500px" open width="480px" transition="slow" heading="Start service plan" onClose={hideModal}>
      <p>Confirm the client is starting the service plan on this date.</p>
      <GoABlock direction="column" gap="s">
        <GoAFormItem error={errors[actualStartDate]?.message as unknown as string} label="Actual start date">
          <GoAInput
            type="date"
            onChange={(name: string, value: string | undefined) => {
              if (value) {
                onChangeHandler(name, value);
              }
            }}
            name={actualStartDate}
            value={getValues(actualStartDate) ? toIsoFormat(getValues(actualStartDate)!) : undefined}
            min="0000-01-01"
            max="9999-12-31"
          />
        </GoAFormItem>
      </GoABlock>
      <GoASpacer vSpacing="l" />

      <GoAButtonGroup alignment="end">
        <GoAButton type="secondary" onClick={hideModal}>
          Cancel
        </GoAButton>
        <GoAButton onClick={handleSubmit(startServicePlanButtonHandler)}>Confirm Start</GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
});
