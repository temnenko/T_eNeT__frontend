import {
  GoABlock,
  GoAButton,
  GoAButtonGroup,
  GoACallout,
  GoADropdown,
  GoAFormItem,
  GoAInput,
  GoANotification,
  GoARadioGroup,
  GoASpacer,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { format } from 'date-fns';
import useRecordOutcome from './hooks/use-record-outcome.hook';
import { ServicePlanDropoutReason, ServicePlanOutcome } from '../../../../types/service-plan';
import { toIsoDate, toIsoFormat } from '../../../../utils/date.util';

type Props = {
  isReadOnly: boolean;
};

export const ServicePlanRecordOutcome = observer(({ isReadOnly }: Props) => {
  const {
    formFields,
    handleSubmit,
    onChangeHandler,
    errors,
    getValues,
    outcomeOptions,
    reasonOptions,
    saveRecordOutcome,
    loading,
    requestError,
    servicePlan,
    isPlanInProgressOrComplete,
    updateText,
  } = useRecordOutcome();

  const { outcome, serviceEndDate, dropoutReason } = formFields;
  return (
    <GoABlock direction="column">
      <div className="service-plan-outcome">
        <GoABlock direction="column">
          <GoAFormItem label="Outcome" error={errors.outcome?.message as unknown as string}>
            <GoARadioGroup
              name={outcome}
              value={getValues(outcome)}
              onChange={(name, value) => {
                onChangeHandler(name, ServicePlanOutcome[value as unknown as ServicePlanOutcome]);
              }}
              disabled={!isPlanInProgressOrComplete || isReadOnly}
            >
              {outcomeOptions}
            </GoARadioGroup>
          </GoAFormItem>
        </GoABlock>
        {getValues(outcome) === ServicePlanOutcome.INCOMPLETE && (
          <GoABlock direction="column">
            <GoAFormItem label="Reason" error={errors.dropoutReason?.message as unknown as string}>
              <GoADropdown
                name={dropoutReason}
                value={getValues(dropoutReason)}
                onChange={(name, value) => {
                  onChangeHandler(name, ServicePlanDropoutReason[value as unknown as ServicePlanDropoutReason]);
                }}
                leadingIcon="search"
                width="398px"
                filterable
                relative
                disabled={!isPlanInProgressOrComplete || isReadOnly}
              >
                {reasonOptions}
              </GoADropdown>
            </GoAFormItem>
            <GoASpacer vSpacing="xs" />
          </GoABlock>
        )}
        <GoABlock direction="column" gap="s">
          <div className={!serviceEndDate ? 'field-interactive-error' : ''}>
            <GoAFormItem error={errors[serviceEndDate]?.message as unknown as string} label="Service end date">
              <GoAInput
                type="date"
                onChange={(name: string, value: string | undefined) => {
                  if (value) {
                    onChangeHandler(name, value);
                  }
                }}
                name={serviceEndDate}
                value={getValues(serviceEndDate) ? toIsoFormat(getValues(serviceEndDate)!) : undefined}
                disabled={!isPlanInProgressOrComplete || isReadOnly}
                min="0000-01-01"
                max={toIsoFormat(new Date())}
              />
            </GoAFormItem>
          </div>
        </GoABlock>

        {!isReadOnly && (
          <>
            <GoASpacer vSpacing="xs" />
            <GoAButtonGroup alignment="start">
              <GoAButton
                type="secondary"
                onClick={handleSubmit(saveRecordOutcome)}
                disabled={loading || !isPlanInProgressOrComplete}
              >
                {updateText}
              </GoAButton>
            </GoAButtonGroup>
          </>
        )}

        <GoASpacer vSpacing="xs" />
        {!loading && servicePlan?.endDate && (
          <GoACallout type="success" size="medium">
            {`Active service ended on ${format(toIsoDate(servicePlan?.endDate), 'MMMM dd, yyyy')}`}
          </GoACallout>
        )}
        {requestError?.message && (
          <>
            <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
              {requestError.message}
            </GoANotification>
            <GoASpacer vSpacing="s" />
          </>
        )}
      </div>
    </GoABlock>
  );
});
