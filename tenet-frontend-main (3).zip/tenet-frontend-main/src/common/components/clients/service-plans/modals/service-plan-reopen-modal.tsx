import { GoAButton, GoAButtonGroup, GoAModal, GoASpacer } from '@abgov/react-components';
import { ServicePlanStatus } from '../../../../../types/service-plan';
import { servicePlanService } from '../../../../../services/clients/service-plan.service';
import { useStore } from '../../../../../hooks/use-store.hook';

interface AssignProps {
  hideModal: () => void;
  servicePlanId: string;
  clientId: string;
}

function ReopenServicePlanModal({ hideModal, servicePlanId, clientId }: AssignProps) {
  const {
    servicePlansListStore: { getAllServicePlans },
  } = useStore();
  const id = BigInt(`0x${servicePlanId.substring(0, servicePlanId.indexOf('-'))}`);
  return (
    <GoAModal
      transition="slow"
      heading={`Reopen Service Plan (TES${id.toString()})`}
      open
      onClose={hideModal}
      width="500px"
    >
      <p>This will allow editing of the plan.</p>
      <GoASpacer vSpacing="m" />
      <GoAButtonGroup alignment="end">
        <GoAButton onClick={hideModal} type="tertiary">
          Oops, go back
        </GoAButton>
        <GoAButton
          type="secondary"
          onClick={async () => {
            const plan = {
              status: ServicePlanStatus.IN_PROGRESS,
            };
            await servicePlanService.update(servicePlanId, clientId, plan);
            await getAllServicePlans(clientId);
            hideModal();
          }}
        >
          Yes, reopen
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}

export default ReopenServicePlanModal;
