import { useMemo } from 'react';
import { format } from 'date-fns';
import { GoAIconButton } from '@abgov/react-components';

import { Note } from '../../../../types/note';
import { useStore } from '../../../../hooks/use-store.hook';
import { toIsoDateTime } from '../../../../utils/date.util';
import RichText from '../../rich-text-editor/rich-text';

type Props = {
  isClient: boolean;
  note: Note;
  softDeleteNoteHandler: (id: string) => void;
};

export function NoteCard({ note, isClient, softDeleteNoteHandler }: Props) {
  const {
    permissionStore: { isSuperAdmin },
  } = useStore();
  const subject = useMemo(() => {
    if (note.subject) {
      return note.subject;
    }

    return note.recordIds.length > 2 ? 'Supplementary activities' : 'Progress review';
  }, [note.recordIds.length, note.subject]);

  return (
    <div className="note">
      {isClient && (
        <div className="note-header justify-between client-bold-600">
          <span>{subject}</span>
          {isSuperAdmin && (
            <GoAIconButton icon="trash" variant="nocolor" mr="s" onClick={() => softDeleteNoteHandler(note.id)} />
          )}
        </div>
      )}
      <div className="note-header">{`${note.creator} | Added ${format(toIsoDateTime(note.createdAt), "MMM dd, yyyy 'at' h:mm a")}`}</div>
      <div className="note-body">
        <RichText html={note.message} />
      </div>
    </div>
  );
}
