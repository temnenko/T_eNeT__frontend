import { useCallback } from 'react';
import {
  GoAButton,
  GoASpacer,
  GoAPages,
  GoAAccordion,
  GoAFormItem,
  GoACallout,
  GoAButtonGroup,
} from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { format } from 'date-fns';
import useTransitionToEmploymentForm from '../hooks/use-transition-to-employment-form.hook';
import { ServicePlanStatus } from '../../../../types/service-plan';
import { useModal } from '../../../../hooks/use-modal.hook';
import SupplementaryActivityForm from '../../forms/clients/service-plans/supplementary-activity-form';
import useSupplementaryActivities from './hooks/use-supplementary-activities.hook';
import { SupplementaryActivityTable } from './supplementary-activities/supplementary-activity-table';
import { NotesList } from './notes-list';
import { ServicePlanRecordOutcome } from './record-outcome';
import Stepper from '../../form-stepper/form-stepper';
import { FollowupOutcomeForm } from './followup-outcome';
import { EmploymentOutcomeForm } from './employment-outcome';
import useCloseCase from './hooks/use-close-case.hook';
import { ConfirmationModal } from '../../modals/confirmation.modal';
import { toIsoDate } from '../../../../utils/date.util';
import RichTextEditor from '../../rich-text-editor/rich-text-editor';

type Props = {
  isReadOnly: boolean;
};

export const TransitionToEmploymentForm = observer(({ isReadOnly }: Props) => {
  const { showModal, hideModal } = useModal();
  const {
    step,
    setStep,
    formFields,
    handleSubmit,
    control,
    saveServicePlanReview,
    errors,
    cancelStepPlanSetup,
    editTimeline,
    openStartServicePlanModal,
    steps,
    servicePlan,
    canCancelPlan,
    isPlanInProgress,
    isPlanIncomplete,
  } = useTransitionToEmploymentForm();
  const { activityRows, message } = useSupplementaryActivities(isReadOnly);
  const { caseClosable, closeCaseHandler, message: closeMessage, shouldCloseWithoutValidation } = useCloseCase();

  const confirmCaseClose = useCallback(() => {
    const description = shouldCloseWithoutValidation
      ? 'Are you sure you want to close the case?'
      : 'Please ensure all activity is accurately recorded before closing.';

    if (caseClosable) {
      showModal(
        <ConfirmationModal
          heading="Close case"
          description={description}
          confirmText="Continue"
          declineText="Go back"
          onDecline={hideModal}
          onConfirm={async () => {
            await closeCaseHandler();
            hideModal();
          }}
          size="sm"
        />,
      );
    }
  }, [caseClosable, closeCaseHandler, hideModal, shouldCloseWithoutValidation, showModal]);

  const { review } = formFields;

  return (
    <>
      <div className="service-plan-section">
        <GoASpacer vSpacing="l" />
        <div className="service-plan-header">
          <h2>Transition to Employment</h2>
          <GoASpacer hSpacing="xl" />
          {!isReadOnly && (
            <div className="service-plan-buttons justify-between">
              <GoAButton type="secondary" onClick={() => editTimeline()}>
                Edit timeline
              </GoAButton>
              {canCancelPlan && servicePlan?.status !== ServicePlanStatus.IN_PROGRESS && (
                <GoAButton
                  type="tertiary"
                  variant="destructive"
                  leadingIcon="remove-circle"
                  onClick={() => cancelStepPlanSetup()}
                >
                  Cancel
                </GoAButton>
              )}
            </div>
          )}
        </div>

        <div className="service-plan-stepper">
          <Stepper
            steps={steps}
            currentStep={step}
            onChange={(page) => {
              if (isReadOnly) {
                return;
              }
              if (page < 1 || page > 3) {
                return;
              }
              setStep(page);
            }}
            endProgressOnStep={isPlanIncomplete ? 2 : 0}
          />
        </div>
      </div>

      <GoAPages current={step} mb="3xl">
        <div className="service-plan-section">
          <div>
            <div>
              {isPlanInProgress && servicePlan?.actualStartDate ? (
                <GoACallout type="success">
                  {`Service plan started on ${format(toIsoDate(servicePlan.actualStartDate), 'MMM d, yyyy')}`}
                </GoACallout>
              ) : undefined}
              {closeMessage && <GoACallout type="success">{closeMessage}</GoACallout>}
            </div>
            <div className="justify-between">
              <h3>Active service</h3>
              {servicePlan?.status === ServicePlanStatus.NOT_STARTED && !!servicePlan.duration && !isReadOnly ? (
                <GoAButton type="primary" onClick={() => openStartServicePlanModal()}>
                  Start service plan
                </GoAButton>
              ) : undefined}
            </div>
            <GoASpacer vSpacing="m" />
            <GoAAccordion heading="Supplementary activities">
              <SupplementaryActivityTable activityRows={activityRows} message={message} isReadOnly />
              <GoASpacer vSpacing="m" />
              {!isReadOnly && (
                <GoAButton
                  leadingIcon="add"
                  type="secondary"
                  disabled={!isPlanInProgress}
                  onClick={() => {
                    showModal(<SupplementaryActivityForm heading="Add activity" btnLabel="Add" activity={undefined} />);
                  }}
                >
                  Add an activity
                </GoAButton>
              )}
            </GoAAccordion>
            <GoASpacer vSpacing="m" />
            <GoAAccordion heading="Progress review">
              {!isReadOnly && (
                <div>
                  <GoAFormItem error={errors.review?.message as unknown as string}>
                    <RichTextEditor
                      name={review}
                      control={control}
                      placeholder={undefined}
                      rules={{ required: 'Review is required' }}
                    />
                  </GoAFormItem>
                  <GoASpacer vSpacing="s" />
                  <GoAButton type="primary" disabled={!isPlanInProgress} onClick={handleSubmit(saveServicePlanReview)}>
                    Post review
                  </GoAButton>
                </div>
              )}

              <GoASpacer vSpacing="m" />
              <NotesList notesFor="service-plan" />
            </GoAAccordion>
          </div>
          <GoASpacer vSpacing="l" />
          <div>
            <h3>Record outcome</h3>
            <GoAAccordion heading="Service outcome">
              <ServicePlanRecordOutcome isReadOnly={isReadOnly} />
            </GoAAccordion>
            <GoAAccordion heading="Employment placement outcome">
              <GoASpacer vSpacing="m" />
              <EmploymentOutcomeForm isReadOnly={isReadOnly || isPlanIncomplete} />
            </GoAAccordion>
            <GoAAccordion heading="Follow-up outcome">
              <FollowupOutcomeForm isReadOnly={isReadOnly || isPlanIncomplete} />
            </GoAAccordion>
          </div>
        </div>
        <div>End TES program content</div>
        <div>Followup program content</div>
      </GoAPages>
      {!isReadOnly && (
        <GoAButtonGroup alignment="end">
          <GoAButton disabled={!caseClosable} onClick={confirmCaseClose} type="secondary" leadingIcon="lock-closed">
            Close case
          </GoAButton>
        </GoAButtonGroup>
      )}
    </>
  );
});
