import { GoAButton, GoAIcon, GoASpacer } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { NavLink, useNavigate } from 'react-router-dom';
import useTransitionToEmployment from '../hooks/use-transition-to-employment.hook';
import { TransitionToEmploymentForm } from './transition-to-employment-form';
import { ServicePlanStatus } from '../../../../types/service-plan';
import Stepper from '../../form-stepper/form-stepper';

export const TransitionToEmployment = observer(() => {
  const { clientId, cancelStepPlanSetup, servicePlan, setupServicePlan, steps, isReadOnly } =
    useTransitionToEmployment();
  const navigate = useNavigate();

  return (
    <>
      <div className="service-plan-section">
        <section>
          <NavLink className="service-plan-link" to="#" onClick={() => navigate(`/clients/${clientId}/service-plans`)}>
            Service Plans
          </NavLink>
          <GoAIcon type="chevron-forward" />
          <GoASpacer hSpacing="2xs" />
          <span>Transition to Employment</span>
        </section>
        <GoASpacer vSpacing="l" />
        {servicePlan?.status === ServicePlanStatus.NOT_STARTED && !servicePlan?.duration && (
          <>
            <div className="service-plan-header">
              <h2>Transition to Employment</h2>
              <GoASpacer hSpacing="xl" />
              {!isReadOnly && (
                <div className="service-plan-buttons justify-between">
                  <GoAButton type="primary" onClick={() => setupServicePlan()}>
                    Set up
                  </GoAButton>
                  <GoAButton
                    type="tertiary"
                    variant="destructive"
                    leadingIcon="remove-circle"
                    onClick={() => cancelStepPlanSetup()}
                  >
                    Cancel
                  </GoAButton>
                </div>
              )}
            </div>
            <div className="service-plan-stepper">
              <Stepper steps={steps} currentStep={0} onChange={() => {}} />
            </div>
          </>
        )}
      </div>
      {servicePlan &&
        ([
          ServicePlanStatus.IN_PROGRESS,
          ServicePlanStatus.COMPLETE,
          ServicePlanStatus.IN_FOLLOW_UP,
          ServicePlanStatus.CLOSED,
        ].includes(servicePlan.status) ||
          !!servicePlan.duration) && <TransitionToEmploymentForm isReadOnly={isReadOnly} />}
    </>
  );
});
