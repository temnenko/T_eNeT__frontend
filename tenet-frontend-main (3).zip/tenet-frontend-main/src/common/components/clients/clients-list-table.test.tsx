import '@testing-library/jest-dom';
import { getByTestId, render, waitFor } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';

import { ClientsTable } from './clients-list-table';
import * as hooks from '../../../hooks/use-store.hook';
import RootStore from '../../../stores/root.store';
import { ClientWithFullName, Language } from '../../../types/client';
import { ModalProvider } from '../../../contexts/modal.context';

describe('ClientsTable', () => {
  const mockStore = {
    clientsStore: { unsetSelectedClient: jest.fn() },
    clientsListStore: {
      clients: [],
      get hasClients() {
        return this.clients.length > 0;
      },
      getAllClients: jest.fn().mockResolvedValue([]),
    },
    servicePlansListStore: { resetServicePlans: jest.fn() },
    permissionStore: {
      CanCreateClient: jest.fn().mockResolvedValue(true),
    },
  } as unknown as RootStore;

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('Renders ClientsTable with zero results', async () => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: clientsTable } = render(
      <ModalProvider>
        <BrowserRouter>
          <ClientsTable />
        </BrowserRouter>
      </ModalProvider>,
    );

    await waitFor(() => {
      const zeroResults = getByTestId(clientsTable, 'clientsTable-zero-results');

      expect(clientsTable).toBeInTheDocument();
      expect(zeroResults).toBeInTheDocument();
    });
  });

  test('Renders ClientsTable with clients table', async () => {
    const clients: ClientWithFullName[] = [
      {
        id: 'test-id',
        tenetNumber: '81726354',
        firstName: 'test-g-name',
        lastName: 'test-f-name',
        sinRecords: [{ id: '123', sinNumber: '987654321' }],
        language: Language.EN,
        dateOfBirth: new Date().toISOString(),
        addresses: [],
        phones: [],
        emailAddresses: [],
        creationCompleted: false,
        clientName: '',
      },
    ];

    mockStore.clientsListStore.clients = clients;
    mockStore.clientsListStore.getAllClients = jest.fn().mockResolvedValue(clients);

    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: clientsTable } = render(
      <ModalProvider>
        <BrowserRouter>
          <ClientsTable />
        </BrowserRouter>
      </ModalProvider>,
    );

    await waitFor(() => {
      const tableBody = getByTestId(clientsTable, 'clientsTable-tableHeader');

      expect(clientsTable).toBeInTheDocument();
      expect(tableBody).toBeInTheDocument();
    });
  });
});
