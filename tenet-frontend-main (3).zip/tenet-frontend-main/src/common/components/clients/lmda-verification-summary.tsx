/* eslint-disable react/no-array-index-key */
import { GoAButton, GoABlock, GoAGrid, GoASpacer, GoAContainer, GoANotification } from '@abgov/react-components';
import { observer } from 'mobx-react-lite';
import { LMDAVerificationTable } from './lmda-table';
import useVerifyLmda from './modals/hooks/use-verify-lmda.hook';
import InlineLoadingIndicator from '../forms/inline-loading-indicator';
import { MissingInfoCallout } from './missing-info-callout';
import useHasEducationAndEmployment from './hooks/use-has-employment-and-education.hook';

export const LMDAVerificationView = observer(() => {
  const { verifyNowHandler, clearErrorMessage, loading, errorMessage } = useVerifyLmda();
  const { hasBoth, hasEducation, hasEmployment } = useHasEducationAndEmployment();

  return (
    <>
      <h2>LMDA Verification</h2>
      {!hasBoth && <MissingInfoCallout hasEducation={hasEducation} hasEmployment={hasEmployment} />}

      <GoABlock>
        LMDA verification is run automatically upon the initial regiatration of a client. You may trigger verification
        on this page
      </GoABlock>
      <GoASpacer vSpacing="m" />
      <GoABlock>
        <GoAContainer type="interactive" accent="filled" padding="compact">
          <h3>Run one time verification</h3>
          <p>Run a one-time verification now.</p>
          <GoAButton
            type="secondary"
            onClick={verifyNowHandler}
            disabled={loading}
            mb={errorMessage ? 'xl' : undefined}
          >
            {loading ? <InlineLoadingIndicator label="Verifying..." /> : <>Verify Now</>}
          </GoAButton>
          {errorMessage && (
            <GoANotification type="emergency" onDismiss={clearErrorMessage}>
              {errorMessage}
            </GoANotification>
          )}
        </GoAContainer>
      </GoABlock>
      <GoAGrid minChildWidth="auto" gap="xl">
        <div className="verificationDiv">
          <h3>Results</h3>
        </div>
        <LMDAVerificationTable />
      </GoAGrid>
      <GoASpacer vSpacing="xl" />
    </>
  );
});
