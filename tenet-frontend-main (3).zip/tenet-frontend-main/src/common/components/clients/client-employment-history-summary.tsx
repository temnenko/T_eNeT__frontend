import { observer } from 'mobx-react-lite';
import { GoABlock, GoAButton } from '@abgov/react-components';
import { useMemo } from 'react';
import { useModal } from '../../../hooks/use-modal.hook';
import { EmploymentForm } from '../forms/clients/employmentHistory/employment-history-form';
import useEmploymentHistory from '../forms/clients/employmentHistory/hooks/use-employments-hook';
import useHasEducationAndEmployment from './hooks/use-has-employment-and-education.hook';
import { MissingInfoCallout } from './missing-info-callout';
import useEmploymentsPagination from './hooks/use-employments-pagination.hook';
import { EmploymentTable } from './employments/employment-table';

const ClientEmploymentHistorySummary = observer(() => {
  const { hasBoth, hasEducation, hasEmployment } = useHasEducationAndEmployment();
  const { clientId, employmentRows, canEditEmployment } = useEmploymentHistory();
  const employmentsPagination = useEmploymentsPagination();
  const { showModal } = useModal();

  const actions = useMemo(() => {
    if (!canEditEmployment) return null;
    return (
      <GoAButton
        type="secondary"
        leadingIcon="add"
        size="compact"
        onClick={() => {
          if (clientId) {
            showModal(<EmploymentForm clientId={clientId} canEditEmployment={canEditEmployment} />);
          }
        }}
      >
        Add Employment
      </GoAButton>
    );
  }, [canEditEmployment, clientId, showModal]);

  return (
    <section className="client-overview-section client-margin-t-10">
      <h2 className="client-no-padding-no-margin client-margin-b-10">Employment</h2>
      {!hasBoth && <MissingInfoCallout hasEducation={hasEducation} hasEmployment={hasEmployment} />}
      <GoABlock alignment="start" gap="4xl">
        <p>Add client’s employment experience here. The most recent experience will automatically be on top.</p>
        {actions}
      </GoABlock>
      {/* TODO: show archived - {clientId ? (
        <>
          <GoASpacer vSpacing="m" />
          <GoACheckbox
            name="showCancelledEmployment"
            text="Show cancelled employment"
            onChange={toggleShowCancelledEmployment}
            checked={archived}
          />
        </>
      ) : undefined} */}
      <div className="client-tables-display">
        <EmploymentTable employmentRows={employmentRows} />
        {employmentsPagination}
      </div>
    </section>
  );
});

export default ClientEmploymentHistorySummary;
