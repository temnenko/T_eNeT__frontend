import { GoAButton, GoASpacer } from '@abgov/react-components';
import { format } from 'date-fns';
import { EmploymentForm } from '../forms/clients/employmentHistory/employment-history-form';
import { useModal } from '../../../hooks/use-modal.hook';
import { Employment } from '../../../types/client';
import { toIsoDate } from '../../../utils/date.util';

type Props = {
  clientId: string;
  employment: Employment;
  canEditEmployment: boolean;
};

export default function ClientEmploymentHistoryCard({ clientId, employment, canEditEmployment }: Props) {
  const { showModal } = useModal();
  const actions = (
    <GoAButton
      type="tertiary"
      onClick={() => {
        showModal(<EmploymentForm clientId={clientId} employment={employment} canEditEmployment={canEditEmployment} />);
      }}
    >
      Edit
    </GoAButton>
  );
  return (
    <>
      <GoASpacer vSpacing="m" />
      <div className={`client-with-padding-radius ${employment.archived && 'archived-emp'}`}>
        <div>
          <p>{employment.jobTitle}</p>
          {actions}
        </div>
        <p>{employment.employerName}</p>
        <p>{`${format(toIsoDate(employment?.startDate ?? ''), 'dd MMM yyyy')} - ${employment?.endDate && !employment?.currentEmployment ? format(toIsoDate(employment?.endDate), 'dd MMM yyyy') : 'Present'}`}</p>
      </div>
    </>
  );
}
