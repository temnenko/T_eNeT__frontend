import { observer } from 'mobx-react-lite';
import { GoABlock, GoAButton, GoACallout, GoANotification, GoASpacer } from '@abgov/react-components';

import { useState } from 'react';
import { ClientRegistrationSection } from '../client-registration-section';
import { MissingInfoCallout } from '../missing-info-callout';
import { ClientFilesUploadForm } from '../../forms/client-files-upload-form';
import InlineLoadingIndicator from '../../forms/inline-loading-indicator';
import useClientDocumentsHook from './use-client-documents-hook';
import { Upload } from '../../../../types/files';
import useHasEducationAndEmployment from '../hooks/use-has-employment-and-education.hook';

export const ClientDocuments = observer(() => {
  const {
    client,
    submitHandler,
    loading,
    requestError,
    invalidUploadError,
    setInvalidUploadError,
    isSuccess,
    downloadFile,
    canUploadClientFiles,
  } = useClientDocumentsHook();
  const { hasBoth, hasEducation, hasEmployment } = useHasEducationAndEmployment();

  const [newUploadsAvailable, setNewUploadsAvailable] = useState(false);

  const handleNewUploadsAvailable = (uploads: Upload[]) => {
    setNewUploadsAvailable(uploads.some((upload) => !upload.persisted));
  };

  return (
    <>
      <h2>Documents</h2>
      <ClientRegistrationSection />
      {!hasBoth && <MissingInfoCallout hasEducation={hasEducation} hasEmployment={hasEmployment} />}
      <GoASpacer vSpacing="m" />
      {isSuccess && <GoACallout type="success">Files uploaded successfully</GoACallout>}
      {requestError?.message && (
        <>
          <GoANotification type="emergency" onDismiss={requestError.onDismiss}>
            {requestError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {invalidUploadError && (
        <>
          <GoANotification type="emergency" onDismiss={() => setInvalidUploadError(null)}>
            {invalidUploadError.message}
          </GoANotification>
          <GoASpacer vSpacing="s" />
        </>
      )}
      {client && (
        <ClientFilesUploadForm
          formItemLabel="Client documents"
          newUploadsAvailable={handleNewUploadsAvailable}
          downloadFile={downloadFile}
          canUploadClientFiles={canUploadClientFiles(client)}
        />
      )}

      <GoASpacer vSpacing="l" />
      <GoABlock direction="column" alignment="end">
        <GoAButton type="primary" onClick={submitHandler} disabled={loading || !newUploadsAvailable}>
          {loading ? <InlineLoadingIndicator label="Uploading..." /> : <>Confirm upload</>}
        </GoAButton>
      </GoABlock>
    </>
  );
});
