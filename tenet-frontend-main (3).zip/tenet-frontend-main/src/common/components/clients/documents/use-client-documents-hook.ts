import { useCallback, useEffect, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../hooks/use-request-error-handler.hook';
import { RequestError } from '../../../../types/errors/errors';
import { InvalidFileUploadError } from '../../../../types/errors/invalid-file-upload.error';
import { fileService } from '../../../../services/clients/client-files.service';

const useClientDocumentsHook = () => {
  const {
    clientsStore: { selectedClient: client },
    permissionStore: { canUploadClientFiles },
  } = useStore();

  const {
    clientFilesStore: { uploadClientDocuments, getClientDocuments, documents },
  } = useStore();

  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [invalidUploadError, setInvalidUploadError] = useState<InvalidFileUploadError | null>(null);

  useEffect(() => {
    const call = async (clientId: string) => {
      await getClientDocuments(clientId);
    };
    if (client) {
      call(client.id);
    }
  }, [client, getClientDocuments]);

  const submitHandler = async () => {
    try {
      setIsSuccess(false);
      setInvalidUploadError(null);
      setLoading(true);
      await uploadClientDocuments(client!.id);
      setIsSuccess(true);
    } catch (error) {
      setIsSuccess(false);
      if (error instanceof InvalidFileUploadError) {
        setInvalidUploadError(error);
      } else {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
        // eslint-disable-next-line no-console
        console.error(error);
      }
    } finally {
      setLoading(false);
    }
  };

  const downloadFile = useCallback(
    async (adspId: string, filename: string, filesize: number) => {
      try {
        fileService.downloadFileByAdspId(adspId, filename, filesize);
      } catch (error) {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    },
    [requestErrorHandler],
  );

  return {
    submitHandler,
    loading,
    requestError,
    invalidUploadError,
    setInvalidUploadError,
    getClientDocuments,
    client,
    documents,
    isSuccess,
    downloadFile,
    canUploadClientFiles,
  };
};

export default useClientDocumentsHook;
