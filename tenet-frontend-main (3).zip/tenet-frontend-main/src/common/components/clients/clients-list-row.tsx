/* eslint-disable jsx-a11y/control-has-associated-label */
import { GoAButton } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';
import useDeleteClient from './modals/hooks/use-delete-client.hook';

type Props = {
  id: string;
  clientName: string;
  dateOfBirth: string;
  maskedSin: string;
  tenetNumber: string;
};

export function ClientRow({ id, clientName, dateOfBirth, maskedSin, tenetNumber }: Props) {
  const { modalVisible, modalContent } = useDeleteClient(id);
  const navigate = useNavigate();

  return (
    <tr>
      {modalVisible && modalContent}
      <td>{tenetNumber}</td>
      <td>{clientName}</td>
      <td>{dateOfBirth}</td>
      <td>{maskedSin}</td>
      <td>
        <GoAButton onClick={() => navigate(`/clients/${id}/overview`)} type="tertiary">
          View
        </GoAButton>
      </td>
    </tr>
  );
}
