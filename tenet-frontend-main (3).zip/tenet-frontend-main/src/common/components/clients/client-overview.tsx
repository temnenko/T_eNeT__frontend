import { useMemo } from 'react';
import { observer } from 'mobx-react-lite';
import { GoABlock, GoACallout, GoASpacer } from '@abgov/react-components';
import { format } from 'date-fns';

import ClientInformationCard from './client-information-card';
import useClientInfo from '../../../hooks/use-client-info.hook';
import { useStore } from '../../../hooks/use-store.hook';
import useHasEducationAndEmployment from './hooks/use-has-employment-and-education.hook';
import { MissingInfoCallout } from './missing-info-callout';
import { toIsoDate } from '../../../utils/date.util';

const ClientOverview = observer(() => {
  const { hasBoth, hasEducation, hasEmployment } = useHasEducationAndEmployment();
  const { clientInfo, clientUpdated, setClientUpdated, modalContent, modalVisible } = useClientInfo();
  const {
    clientsStore: { selectedClient },
    permissionStore: { canEditCompletedClient },
  } = useStore();
  const registrationDate = useMemo(
    () => (selectedClient?.completedAt ? format(toIsoDate(selectedClient.completedAt), 'dd MMM, yyyy') : undefined),
    [selectedClient?.completedAt],
  );

  return (
    <>
      {modalVisible && modalContent}
      <section className="client-overview-section client-margin-t-10">
        <h2 className="client-no-padding-no-margin client-margin-b-10">Client overview</h2>
        <GoABlock gap="4xl">
          <GoABlock gap="2xl">
            <span className="client-margin-b-10">Registration date</span>
            <span className="client-margin-b-10">{registrationDate}</span>
          </GoABlock>
        </GoABlock>
        {!hasBoth && <MissingInfoCallout hasEducation={hasEducation} hasEmployment={hasEmployment} />}

        {clientUpdated && (
          <div className="client-success-width-700">
            <GoACallout type="success" size="large">
              {`${selectedClient?.firstName} ${selectedClient?.lastName}'s ${clientUpdated} information has been updated.`}
            </GoACallout>
          </div>
        )}
        {clientInfo && selectedClient
          ? clientInfo.map(({ title, data, secondary, updateAction }) => (
              <>
                <GoASpacer vSpacing="m" />
                <ClientInformationCard
                  key={title}
                  title={title}
                  data={data}
                  additionalData={secondary ?? []}
                  setClientUpdated={setClientUpdated}
                  updateClick={updateAction}
                  canEditCompletedClient={canEditCompletedClient}
                />
              </>
            ))
          : undefined}
      </section>
      <GoASpacer vSpacing="xl" />
    </>
  );
});

export default ClientOverview;
