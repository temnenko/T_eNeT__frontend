import { ReactNode, useCallback, useState } from 'react';
import { useModal } from '../../../../../hooks/use-modal.hook';
import DeleteClientModal from '../delete-client.modal';
import { useStore } from '../../../../../hooks/use-store.hook';

const useDeleteClient = (id: string) => {
  const {
    clientsListStore: { hardDeleteClient },
  } = useStore();
  const { hideModal } = useModal();

  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const closeModal = useCallback(() => {
    setModalVisible(false);
    hideModal();
  }, [hideModal]);

  const onDeleteHandler = useCallback(async () => {
    try {
      setLoading(true);

      await hardDeleteClient(id);
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
      closeModal();
    }
  }, [closeModal, hardDeleteClient, id]);

  const deleteClientHandler = useCallback(async () => {
    setModalVisible(true);

    setModalContent(<DeleteClientModal onClose={closeModal} onConfirm={onDeleteHandler} loading={loading} />);
  }, [closeModal, loading, onDeleteHandler]);

  return {
    modalContent,
    modalVisible,
    deleteClientHandler,
  };
};

export default useDeleteClient;
