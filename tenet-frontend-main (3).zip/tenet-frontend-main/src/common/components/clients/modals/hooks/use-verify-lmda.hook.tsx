import { useCallback, useState } from 'react';
import { useStore } from '../../../../../hooks/use-store.hook';

const useVerifyLmda = () => {
  const {
    clientsStore: { selectedClient, verifyLmda, getClientLmdaVerificationRecords },
  } = useStore();

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string>();

  const verifyNowHandler = useCallback(async () => {
    try {
      setLoading(true);

      const sinPosition = (selectedClient?.sinRecords?.length ?? 1) - 1;
      const sinRecordId = selectedClient?.sinRecords?.[sinPosition]?.id;

      if (sinRecordId) {
        await verifyLmda(sinRecordId);
        await getClientLmdaVerificationRecords(selectedClient.id);
      }
    } catch (e) {
      setErrorMessage('LMDA Verification service is temporarily unavailable. Please try again later.');
    } finally {
      setLoading(false);
    }
  }, [getClientLmdaVerificationRecords, selectedClient?.id, selectedClient?.sinRecords, verifyLmda]);
  const clearErrorMessage = useCallback(() => {
    setErrorMessage(undefined);
  }, []);

  return {
    verifyNowHandler,
    clearErrorMessage,
    errorMessage,
    loading,
  };
};

export default useVerifyLmda;
