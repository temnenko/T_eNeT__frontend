import { GoAButton, GoAButtonGroup, GoAFormItem, GoAModal, GoARadioGroup, GoARadioItem } from '@abgov/react-components';
import InlineLoadingIndicator from '../../forms/inline-loading-indicator';

type Props = {
  onConfirm: () => Promise<void>;
  onClose: () => void;
  loading: boolean;
};

export default function DeleteClientModal({ onConfirm, onClose, loading }: Props) {
  return (
    <GoAModal heading="Delete registration" transition="slow" maxWidth="500px" onClose={onClose} open>
      <p className="client-font-with-margin">
        Are you sure you want to delete this in-progress registration? This will remove all data collected so far
        permanently.
      </p>
      <h4>Reason to delete</h4>
      <GoAFormItem>
        <GoARadioGroup name="reason" onChange={() => {}}>
          <GoARadioItem value="APPLICANT_WITHDRAWAL" label="Applicant withdrawal" />
          <GoARadioItem value="APPLICANT_UNFIT" label="Applicant is unfit for the program" />
          <GoARadioItem value="OTHER" label="Other" />
        </GoARadioGroup>
      </GoAFormItem>
      <GoAButtonGroup alignment="end" mt="l">
        <GoAButton leadingIcon="trash" disabled={loading} type="secondary" variant="destructive" onClick={onConfirm}>
          {loading && <InlineLoadingIndicator />} Delete
        </GoAButton>
        <GoAButton disabled={loading} type="primary" onClick={onClose}>
          No, go back
        </GoAButton>
      </GoAButtonGroup>
    </GoAModal>
  );
}
