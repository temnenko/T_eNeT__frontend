import { GoABlock, GoADivider } from '@abgov/react-components';
import RichText from '../../rich-text-editor/rich-text';

type Props = {
  title: string;
  data: {
    label: string;
    value: JSX.Element | string | number;
  }[];
};

export default function AssessmentInfoCard({ title, data }: Props) {
  return (
    <div className="client-info-card">
      <div className="client-info-card-heading client-margin-b-10">
        <h3 className="client-no-padding-no-margin">{title}</h3>
      </div>
      <GoADivider />
      <div className="client-info-card-details">
        <GoABlock direction="column">
          {data.map((entry) => (
            <GoABlock key={entry.label} gap="none">
              <div className="assessment-info-card-label">
                <span className="color-interactive">{entry.label}</span>
              </div>
              <div>
                <span className="client-bold-600">
                  <RichText html={entry.value as string} />
                </span>
              </div>
            </GoABlock>
          ))}
        </GoABlock>
      </div>
    </div>
  );
}
