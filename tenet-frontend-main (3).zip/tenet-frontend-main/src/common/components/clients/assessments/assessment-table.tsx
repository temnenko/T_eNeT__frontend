/* eslint-disable jsx-a11y/control-has-associated-label */
import { useCallback } from 'react';
import { observer } from 'mobx-react-lite';
import { useNavigate } from 'react-router-dom';
import { GoATable, GoAIcon, GoAButton, GoATableSortHeader } from '@abgov/react-components';
import { useStore } from '../../../../hooks/use-store.hook';
import { AssessmentKey } from '../../../../types/assessment';
import { AssessmentRow } from './assessment-row';

type Props = {
  hasAssessments: boolean;
};

export const AssessmentTable = observer(({ hasAssessments }: Props) => {
  const navigate = useNavigate();
  const {
    assessmentListStore: { assessments, sortData },
    assessmentFormStore: { resetAssessment },
    permissionStore: { isSuperAdmin, canEditInProgressAssessment },
  } = useStore();
  const sortAssessments = useCallback(
    (sortBy: string, sortDir: number) => {
      sortData(sortBy as AssessmentKey, sortDir);
    },
    [sortData],
  );

  return (
    <div className="client-assessment-list">
      <GoATable width="75rem" onSort={sortAssessments}>
        <thead>
          <tr>
            <th>
              <GoATableSortHeader name="status">Status</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="completedAt">Completed on</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="assessmentType">Type</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="organizationName">Organization</GoATableSortHeader>
            </th>
            <th>
              <GoATableSortHeader name="assessorName">Assessed by</GoATableSortHeader>
            </th>
            <th />
            <th />
          </tr>
        </thead>
        {hasAssessments && (
          <tbody>
            {assessments.map((assessment) => (
              <AssessmentRow
                key={assessment.id}
                id={assessment.id}
                status={assessment.status}
                completedOn={assessment.completedAt}
                type={assessment.assessmentType}
                assessedBy={assessment.assessorName}
                organizationName={assessment.organizationName}
                canDelete={isSuperAdmin}
                canEditInProgressAssessment={canEditInProgressAssessment}
              />
            ))}
          </tbody>
        )}
      </GoATable>
      {!hasAssessments && (
        <div className="badgeDisplay">
          <div className="container">
            <div className="ellipse">
              <GoAIcon theme="outline" size="large" type="file-tray" />
            </div>
          </div>
          <p>{`This client doesn't have any assessment.`}</p>
          <GoAButton
            type="tertiary"
            onClick={() => {
              resetAssessment();
              navigate('/assessments/new/assessment-type/');
            }}
          >
            Start assessment
          </GoAButton>
        </div>
      )}
    </div>
  );
});
