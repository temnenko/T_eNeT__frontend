/* eslint-disable jsx-a11y/control-has-associated-label */
import { useCallback, useMemo } from 'react';
import { observer } from 'mobx-react-lite';
import { useNavigate, useParams } from 'react-router-dom';
import { GoABadge, GoAButton, GoAIconButton } from '@abgov/react-components';
import { format } from 'date-fns/format';
import {
  AssessmentStatus,
  AssessmentType,
  assessmentBadgeMap,
  assessmentStatusMap,
} from '../../../../types/assessment';
import { useCapitalizeFirstCharOfEveryWord } from '../../../../hooks/use-capitalize.hook';
import useDeleteAssessment from './use-delete-assessment';

type Props = {
  id: string;
  status: AssessmentStatus;
  completedOn?: Date;
  type: AssessmentType;
  organizationName: string;
  assessedBy: string;
  canDelete: boolean;
  canEditInProgressAssessment?: boolean;
};

export const AssessmentRow = observer(
  ({ id, status, completedOn, type, organizationName, assessedBy, canDelete, canEditInProgressAssessment }: Props) => {
    const capitalize = useCapitalizeFirstCharOfEveryWord();
    const navigate = useNavigate();
    const { id: clientId } = useParams<{ id: string }>();
    const openHandler = useCallback(() => navigate(`/clients/${clientId}/assessments/${id}`), [clientId, id, navigate]);
    const editHandler = useCallback(() => navigate(`/assessments/new/assessment-type/${id}`), [id, navigate]);
    const { openDeleteConfirmationDialog } = useDeleteAssessment(id);
    const inProgress = useMemo(() => status === AssessmentStatus.IN_PROGRESS, [status]);
    const actionLabel = useMemo(
      () => (inProgress && canEditInProgressAssessment ? 'Edit' : 'View'),
      [canEditInProgressAssessment, inProgress],
    );
    const actionHandler = useMemo(
      () => (inProgress ? editHandler : openHandler),
      [editHandler, inProgress, openHandler],
    );

    return (
      <tr>
        <td>
          <GoABadge type={assessmentBadgeMap[status]} content={assessmentStatusMap[status]} />
        </td>
        <td>{completedOn ? format(completedOn, 'MMM dd, yyy') : '-'}</td>
        <td>{capitalize(type)}</td>
        <td>{organizationName}</td>
        <td>{assessedBy}</td>
        <td>
          <GoAButton onClick={actionHandler} type="tertiary">
            {actionLabel}
          </GoAButton>
        </td>
        <td>
          {canDelete && (
            <GoAIconButton
              variant="dark"
              size="medium"
              icon="trash"
              ariaLabel="delete icon"
              onClick={openDeleteConfirmationDialog}
            />
          )}
        </td>
      </tr>
    );
  },
);
