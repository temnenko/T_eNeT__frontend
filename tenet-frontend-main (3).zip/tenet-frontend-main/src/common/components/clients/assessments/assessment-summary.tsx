import { observer } from 'mobx-react-lite';
import { format } from 'date-fns';
import { GoABlock, GoAButton, GoASpacer } from '@abgov/react-components';
import { useNavigate } from 'react-router-dom';
import useAssessmentInfo from '../hooks/use-assessment-info.hook';
import AssessmentInfoCard from './assessment-info-card';
import { useStore } from '../../../../hooks/use-store.hook';
import useCapitalize from '../../../../hooks/use-capitalize.hook';
import { toIsoDate } from '../../../../utils/date.util';

export const AssessmentSummary = observer(() => {
  const { serviceRecommendation, needsIdentification, employmentStatus, jobSearchStatus } = useAssessmentInfo();
  const {
    assessmentFormStore: { assessment },
  } = useStore();
  const navigate = useNavigate();
  const capitalizeFirst = useCapitalize();

  return (
    <section className="client-overview-section client-margin-t-10">
      <h2>Overview</h2>
      <GoABlock gap="4xl">
        <GoABlock gap="2xl">
          <span className="client-margin-b-10">Assessed by</span>
          <span>{assessment?.assessorName ?? `[Julia Jobfinder]`}</span>
        </GoABlock>
        <GoABlock gap="2xl">
          <span className="client-margin-b-10">Assessed on</span>
          <span>
            {assessment?.assessmentDate
              ? format(toIsoDate(assessment.assessmentDate), 'dd MMM yyyy')
              : `[Apr 12, 2024]`}
          </span>
        </GoABlock>
      </GoABlock>
      <GoASpacer vSpacing="xl" />
      <GoABlock gap="4xl">
        <span>LMDA status at intake</span>
        <b>{capitalizeFirst(assessment?.lmdaIntakeType?.replaceAll('_', ' ').toLowerCase())}</b>
      </GoABlock>
      <AssessmentInfoCard title={serviceRecommendation.title} data={serviceRecommendation.data} />
      <GoAButton
        onClick={() => {
          if (assessment?.clientId) {
            navigate(`/clients/${assessment.clientId}/service-plans/transition-to-employment`);
          }
        }}
        size="compact"
        type="tertiary"
        trailingIcon="arrow-forward"
      >
        Go to Service plan
      </GoAButton>
      <AssessmentInfoCard title={needsIdentification.title} data={needsIdentification.data} />
      <AssessmentInfoCard title={employmentStatus.title} data={employmentStatus.data} />
      <AssessmentInfoCard title={jobSearchStatus.title} data={jobSearchStatus.data} />
      <GoASpacer vSpacing="l" />
    </section>
  );
});
