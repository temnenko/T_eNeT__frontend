import { useCallback, useState } from 'react';
import { useModal } from '../../../../hooks/use-modal.hook';
import { ConfirmationModal } from '../../modals/confirmation.modal';
import { useStore } from '../../../../hooks/use-store.hook';

const useDeleteAssessment = (assessmentId: string) => {
  const { hideModal, showModal } = useModal();
  const [loading, setLoading] = useState(false);
  const {
    assessmentListStore: { deleteAssessment },
  } = useStore();

  const handleDeleteAssessment = useCallback(async () => {
    try {
      setLoading(true);
      await deleteAssessment(assessmentId);
      hideModal();
    } catch (e) {
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [assessmentId, deleteAssessment, hideModal]);

  const openDeleteConfirmationDialog = useCallback(() => {
    showModal(
      <ConfirmationModal
        heading="Delete assessment?"
        description="Are you sure you want to delete this assessment?"
        declineText="Oops, go back"
        confirmText="Yes, delete"
        onConfirm={() => handleDeleteAssessment()}
        onDecline={hideModal}
        isDelete
      />,
    );
  }, [handleDeleteAssessment, hideModal, showModal]);

  return {
    openDeleteConfirmationDialog,
    loading,
  };
};

export default useDeleteAssessment;
