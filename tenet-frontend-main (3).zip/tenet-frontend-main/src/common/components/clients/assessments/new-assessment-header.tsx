import { observer } from 'mobx-react-lite';

import { useStore } from '../../../../hooks/use-store.hook';
import { assessmentFormStepperTitles } from '../../../../types/assessment-forms';
import { StepperFormHeader } from '../../stepper-form/stepper-form-header';
import { TerminateAssessment } from '../../forms/clients/assessments/new/terminate-assessment';

export const NewAssessmentHeader = observer(() => {
  const {
    assessmentFormStepperStore: { currentlyActive },
    clientsStore: { selectedClient },
  } = useStore();

  return (
    <StepperFormHeader
      headingText={`New assessment: ${selectedClient?.firstName ?? ''} ${selectedClient?.lastName ?? ''}`}
      currentlyActive={currentlyActive}
      formStepperTitles={assessmentFormStepperTitles}
      headingControl={<TerminateAssessment />}
    />
  );
});
