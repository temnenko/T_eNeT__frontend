import { observer } from 'mobx-react-lite';
import { GoAButton, GoASpacer } from '@abgov/react-components';

import { useNavigate } from 'react-router-dom';
import { AssessmentTable } from './assessment-table';
import { useStore } from '../../../../hooks/use-store.hook';

export const AssessmentView = observer(() => {
  const navigate = useNavigate();
  const {
    assessmentListStore: { hasAssessments },
    assessmentFormStore: { resetAssessment },
    permissionStore: { canCreateAssessment },
  } = useStore();

  return (
    <>
      <h2>Assessments</h2>
      {canCreateAssessment && (
        <div className="d-flex-row justify-content-end">
          <GoAButton
            size="compact"
            onClick={() => {
              resetAssessment();
              navigate('/assessments/new/assessment-type/');
            }}
          >
            New assessment
          </GoAButton>
        </div>
      )}

      <GoASpacer vSpacing="m" />
      <AssessmentTable hasAssessments={hasAssessments} />
      <GoASpacer vSpacing="l" />
    </>
  );
});
