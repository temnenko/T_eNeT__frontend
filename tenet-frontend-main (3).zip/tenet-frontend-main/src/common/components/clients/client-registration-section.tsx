import { GoABlock } from '@abgov/react-components';

export function ClientRegistrationSection() {
  return (
    <section className="client-margin-t-10">
      <GoABlock gap="4xl">
        <GoABlock gap="2xl">
          <span className="client-margin-b-10">Registration date</span>
          <span className="client-margin-b-10">Feb 19, 2024</span>
        </GoABlock>
      </GoABlock>
    </section>
  );
}
