import { observer } from 'mobx-react-lite';
import { GoACallout } from '@abgov/react-components';

import { useState } from 'react';
import useClientContact from '../../../hooks/use-client-contact.hook';
import { MissingInfoCallout } from './missing-info-callout';
import ClientContactInformationCard from './client-contact-information-card';
import useHasEducationAndEmployment from './hooks/use-has-employment-and-education.hook';

const ClientContact = observer(() => {
  const clientContact = useClientContact();
  const { hasBoth, hasEducation, hasEmployment } = useHasEducationAndEmployment();
  const [isSuccess, setIsSuccess] = useState(false);

  const showSuccess = () => {
    setIsSuccess(true);
  };

  return (
    <section className="client-margin-t-10">
      {!hasBoth && <MissingInfoCallout hasEducation={hasEducation} hasEmployment={hasEmployment} />}
      {isSuccess && <GoACallout type="success">Contact Details have been updated</GoACallout>}
      {clientContact.map(({ title, data }) => (
        <ClientContactInformationCard key={title} title={title} data={data} postSubmit={showSuccess} />
      ))}
    </section>
  );
});

export default ClientContact;
