import { GoACallout } from '@abgov/react-components';
import { NavLink, useParams } from 'react-router-dom';

type Props = {
  hasEducation: boolean;
  hasEmployment: boolean;
};

export function MissingInfoCallout({ hasEducation, hasEmployment }: Props) {
  const { id } = useParams();
  return (
    <div className="client-max-width-600">
      <GoACallout type="important" size="medium" heading="Missing information">
        {!hasEmployment && (
          <>
            <span>
              <NavLink className="client-missing-info" to={`/clients/${id}/employments`}>
                Employment history
              </NavLink>{' '}
              will need to be completed before assessment.
            </span>
            <br />
          </>
        )}
        {!hasEducation && (
          <span>
            <span className="client-missing-info">
              <NavLink className="client-missing-info" to={`/clients/${id}/educations`}>
                Education history
              </NavLink>{' '}
            </span>{' '}
            will need to be completed before assessment.
          </span>
        )}
      </GoACallout>
    </div>
  );
}
