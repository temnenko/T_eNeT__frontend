/* eslint-disable react/no-array-index-key */
/* eslint-disable jsx-a11y/control-has-associated-label */
import { observer } from 'mobx-react-lite';
import { GoATable, GoASkeleton, GoAIcon, GoASpacer, GoAButton } from '@abgov/react-components';
import useLMDAVerificationRows from '../../../hooks/use-lmda-verification.hook';
import useLmdaRecordsPagination from './hooks/use-lmda-records-pagination.hook';

export const LMDAVerificationTable = observer(() => {
  const { rows: verificationRows, isLoading } = useLMDAVerificationRows();
  const lmdaListPagination = useLmdaRecordsPagination();

  const skeleton = () => {
    return (
      <>
        {Array.from({ length: 5 }).map((_, index) => (
          <tr key={index}>
            <td>
              <GoASkeleton type="text" />
            </td>
            <td>
              <GoASkeleton type="text" />
            </td>
            <td>
              <GoASkeleton type="text" />
            </td>
            <td>
              <GoASkeleton type="text" />
            </td>
          </tr>
        ))}
      </>
    );
  };

  return (
    <div className="client-tables-display">
      <GoATable width="100%">
        <thead>
          <tr>
            <th className="status" data-testid="lmdaTable_statusHeader">
              Status
            </th>
            <th className="detail" data-testid="lmdaTable_detailHeader">
              Result detail
            </th>
            <th data-testid="lmdaTable_dateHeader">Date Verified</th>
            <th />
          </tr>
        </thead>
        {isLoading && skeleton()}
        {verificationRows && <tbody data-testid="lmdaTable_tableBody">{verificationRows}</tbody>}
      </GoATable>
      {!verificationRows?.length && !isLoading && (
        <div className="badgeDisplay">
          <div className="container">
            <div className="ellipse">
              <GoAIcon theme="outline" size="large" type="shield-checkmark" testId="noLmdaVerificationBadge" />
            </div>
          </div>
          <p>The client has not been verified yet</p>
          <GoASpacer vSpacing="m" />
          <GoAButton type="tertiary">Run LMDA verification manually</GoAButton>
        </div>
      )}
      {lmdaListPagination}
    </div>
  );
});
