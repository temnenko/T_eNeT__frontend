import { useEffect } from 'react';
import { useParams } from 'react-router-dom';

import { useStore } from '../../../../hooks/use-store.hook';

const useLoadAssessments = () => {
  const { id: clientId } = useParams();
  const {
    assessmentListStore: { getByClientId, hasAssessments },
  } = useStore();

  useEffect(() => {
    if (clientId) {
      getByClientId(clientId);
    }
  }, [getByClientId, clientId]);

  return { hasAssessments };
};

export default useLoadAssessments;
