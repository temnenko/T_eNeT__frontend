import { useEffect, useMemo } from 'react';
import { useParams } from 'react-router-dom';

import { useStore } from '../../../../hooks/use-store.hook';

const useHasEducationAndEmployment = () => {
  const { id: clientId } = useParams<{ id: string }>();
  const {
    clientsStore: { educationHistory, employmentHistory, getEducations, getClientEmploymentHistory, selectedClient },
  } = useStore();

  useEffect(() => {
    const clientToUse = clientId ?? selectedClient?.id;
    if (clientToUse) {
      getEducations(clientToUse);
      getClientEmploymentHistory(clientToUse);
    }
  }, [clientId, getClientEmploymentHistory, getEducations, selectedClient?.id]);

  const hasEducation = useMemo(() => !!(educationHistory && educationHistory?.length > 0), [educationHistory]);
  const hasEmployment = useMemo(() => !!(employmentHistory && employmentHistory?.length > 0), [employmentHistory]);
  const hasBoth = useMemo(() => hasEducation && hasEmployment, [hasEducation, hasEmployment]);

  return {
    hasEducation,
    hasEmployment,
    hasBoth,
  };
};

export default useHasEducationAndEmployment;
