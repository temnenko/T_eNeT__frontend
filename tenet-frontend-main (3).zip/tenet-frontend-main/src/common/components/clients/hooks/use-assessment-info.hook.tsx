import { useEffect, useMemo } from 'react';
import { GoABadge } from '@abgov/react-components';

import { useParams } from 'react-router-dom';
import { format } from 'date-fns';
import { useStore } from '../../../../hooks/use-store.hook';
import { EmploymentStatusLabels } from '../../../../types/assessment-forms';
import { getEnumValue } from '../../../../utils/enums.util';
import { toIsoDate } from '../../../../utils/date.util';

const useAssessmentInfo = () => {
  const {
    assessmentFormStore: { assessment, assessmentNeedsString, loadAssessment },
  } = useStore();

  const { assessmentId } = useParams<{ assessmentId: string }>();

  useEffect(() => {
    if (assessmentId) {
      loadAssessment(assessmentId);
    }
  }, [assessmentId, loadAssessment]);

  return useMemo(
    () => ({
      serviceRecommendation: {
        title: 'Service recommendation',
        data: [
          {
            label: 'Program',
            value: assessment?.agreementId ?? 'Career transition program',
          },
          {
            label: 'Labour market destined',
            value: assessment?.laborMarketDestined ? 'Yes' : 'NO',
          },
          {
            label: 'RWA',
            value: assessment?.readyWillingAble ? 'Yes' : 'No',
          },
          {
            label: 'Recommendation',
            value: assessment?.serviceRecommendation?.replaceAll('_', '') ?? 'Important notes and rationale here',
          },
          {
            label: 'Assessor decision',
            value: <GoABadge type="success" content={assessment?.approved ? 'Approved' : 'Rejected'} />,
          },
          {
            label: 'Participant agreement',
            value: assessment?.agreementDate ? format(toIsoDate(assessment?.agreementDate), 'dd MMM, yyyy') : '',
          },
          {
            label: 'Assessment Date',
            value: assessment?.assessmentDate ? format(toIsoDate(assessment?.assessmentDate), 'dd MMM, yyyy') : '',
          },
        ],
      },
      needsIdentification: {
        title: 'Needs identification',
        data: [
          {
            label: 'Needs',
            value: assessmentNeedsString ?? 'Career advice, Career assistance, Job search assistance',
          },
        ],
      },
      employmentStatus: {
        title: 'Employment status',
        data: [
          {
            label: 'Job search activities',
            value: assessment?.jobSearchActivities ?? '',
          },
          {
            label: 'Employment',
            value: assessment?.employmentGoal ?? 'Employed at the time of assessment',
          },
          {
            label: 'Primary source of income',
            value: assessment?.financialResources ?? '',
          },
          {
            label: 'Employment status at intake',
            value: assessment?.employmentStatus
              ? (getEnumValue(EmploymentStatusLabels, assessment?.employmentStatus) as string)
              : '',
          },
        ],
      },
      jobSearchStatus: {
        title: 'Job search status',
        data: [
          {
            label: 'Goals and competency',
            value:
              assessment?.employmentGoal ??
              `Homer wants to get back in car design. He has a degree in mechanical engineering form 1995 from the US.`,
          },
          {
            label: 'Job search competency',
            value:
              assessment?.jobSearchCompetency ?? `Homer has an okay resume but interview skills needs improvement.`,
          },
          {
            label: 'Strengths and challenges/barriers',
            value:
              assessment?.strengthsAndBarriers ??
              `Since engineer is a regulated profession in Alberta, Homer must be registered with APEGA in order to be eligible to practice. He is not aware of this and thought his credentials would be automatically recognized. Will discuss with him in detail and provide resources and contacts in this regard.`,
          },
        ],
      },
    }),
    [
      assessment?.agreementDate,
      assessment?.agreementId,
      assessment?.approved,
      assessment?.assessmentDate,
      assessment?.employmentGoal,
      assessment?.employmentStatus,
      assessment?.financialResources,
      assessment?.jobSearchActivities,
      assessment?.jobSearchCompetency,
      assessment?.laborMarketDestined,
      assessment?.readyWillingAble,
      assessment?.serviceRecommendation,
      assessment?.strengthsAndBarriers,
      assessmentNeedsString,
    ],
  );
};

export default useAssessmentInfo;
