import { useCallback, useMemo } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';

import { ListPagination } from '../../list-pagination';

const useLmdaRecordsPagination = () => {
  const {
    clientsStore: {
      setCurrentLmdaListPosition,
      setLmdaListSize,
      getLmdaListSize,
      currentLmdaListPosition,
      totalLmdaCount,
    },
  } = useStore();

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      const newSize = Array.isArray(value) ? value[0] : value;

      setLmdaListSize(Number.parseInt(newSize, 10));
    },
    [setLmdaListSize],
  );

  return useMemo(() => {
    const actualPageSize = totalLmdaCount < getLmdaListSize ? totalLmdaCount : getLmdaListSize;
    return (
      <ListPagination
        perPageSize={getLmdaListSize}
        actualPageSize={actualPageSize}
        perPageSizeOptions={[10, 20, 50]}
        changePerPageSize={changePerPageSize}
        pagePosition={currentLmdaListPosition}
        changePagePosition={setCurrentLmdaListPosition}
        totalCount={totalLmdaCount}
      />
    );
  }, [totalLmdaCount, getLmdaListSize, changePerPageSize, currentLmdaListPosition, setCurrentLmdaListPosition]);
};

export default useLmdaRecordsPagination;
