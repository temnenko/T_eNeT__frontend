import { useCallback, useEffect, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import useRequestErrorHandler from '../../../../hooks/use-request-error-handler.hook';
import { InvalidFileUploadError } from '../../../../types/errors/invalid-file-upload.error';
import { useNavigateStepper } from '../../forms/clients/registration/hooks/use-navigate-steppers.hook';
import { ClientFormStepperKeys } from '../../../../types/client-forms';
import useLoadClient from '../../forms/clients/registration/hooks/use-load-client';
import { RequestError } from '../../../../types/errors/errors';
import { fileService } from '../../../../services/clients/client-files.service';

const useSubmitClientRegistrationDocuments = () => {
  const { client } = useLoadClient();

  const {
    clientFilesStore: { newUploads, getClientDocuments, documents },
    permissionStore: { canEditClientInProgress, canUploadClientFiles },
  } = useStore();

  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [invalidUploadError, setInvalidUploadError] = useState<InvalidFileUploadError | null>(null);
  const { goToNextStep, goToPreviousStep, setActiveStep } = useNavigateStepper();

  useEffect(() => {
    const call = async (clientId: string) => {
      await getClientDocuments(clientId);
    };
    if (client) {
      call(client.id);
    }
  }, [client, getClientDocuments]);

  const submitHandler = async () => {
    try {
      setInvalidUploadError(null);
      setLoading(true);

      if (newUploads.length && newUploads.some((f) => !f.fileType)) {
        throw new InvalidFileUploadError('Select a file type');
      }
      goToNextStep(client!.id);
    } catch (error) {
      if (error instanceof InvalidFileUploadError) {
        setInvalidUploadError(error);
      } else {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
        // eslint-disable-next-line no-console
        console.error(error);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setActiveStep(ClientFormStepperKeys.FILES);
  }, [setActiveStep]);

  const previousButtonClickHandler = useCallback(() => {
    goToPreviousStep(client!.id);
  }, [goToPreviousStep, client]);

  const downloadFile = useCallback(
    (fileId: string, filename: string, filesize: number) => {
      try {
        setLoading(true);
        fileService.downloadFileByAdspId(fileId, filename, filesize);
      } catch (error) {
        requestErrorHandler({
          error,
          setError: setRequestError,
        });
      } finally {
        setLoading(false);
      }
    },
    [requestErrorHandler],
  );

  return {
    submitHandler,
    loading,
    requestError,
    invalidUploadError,
    previousButtonClickHandler,
    getClientDocuments,
    client,
    documents,
    downloadFile,
    canEditClientInProgress,
    canUploadClientFiles,
  };
};

export default useSubmitClientRegistrationDocuments;
