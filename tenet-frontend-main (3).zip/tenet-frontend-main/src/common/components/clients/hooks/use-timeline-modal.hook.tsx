import { useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from 'react-hook-form';

import { useStore } from '../../../../hooks/use-store.hook';
import { useModal } from '../../../../hooks/use-modal.hook';
import { ServicePlanStatus, UpdateServicePlan } from '../../../../types/service-plan';
import { toIsoFormat } from '../../../../utils/date.util';

type TimelineFieldName = 'planDuration' | 'startDate';

type TimelineFieldData = {
  planDuration: number;
  startDate: string;
};

const useTimelineModal = () => {
  const [duration, setDuration] = useState<number | undefined>();

  const { hideModal } = useModal();

  const {
    servicePlanStore: { duration: spDuration, startDate: spStartDate, servicePlan, updateServicePlan },
  } = useStore();

  const isPlanStarted = useMemo(() => ![ServicePlanStatus.NOT_STARTED].includes(servicePlan!.status), [servicePlan]);

  useEffect(() => {
    if (spDuration) {
      setDuration(spDuration);
    }
  }, [spDuration]);

  const {
    getValues,
    register,
    setValue,
    handleSubmit,
    formState: { errors },
  } = useForm<TimelineFieldData>({
    defaultValues: {
      planDuration: spDuration,
      startDate: spStartDate ? toIsoFormat(spStartDate) : undefined,
    },
  });

  const { name: planDuration } = register('planDuration', {
    required: { value: true, message: 'This field is required' },
  });
  const { name: startDate } = register('startDate', {
    required: { value: true, message: 'This field is required' },
  });

  const formFields = {
    planDuration,
    startDate,
  };

  const onChangeHandler = useCallback(
    (name: string, value: string | number) => {
      setValue(name as TimelineFieldName, value);
      if (name === planDuration) {
        setDuration(value ? +value : 0);
      }
    },
    [planDuration, setValue],
  );

  const saveTimeline = useCallback(async () => {
    if (servicePlan?.id) {
      const { id, clientId } = servicePlan;
      const payload: UpdateServicePlan = {
        startDate: new Date(getValues(startDate)),
        duration: getValues(planDuration),
        status: servicePlan?.actualStartDate ? ServicePlanStatus.IN_PROGRESS : undefined,
      };
      await updateServicePlan(id, clientId, payload);
    }
    hideModal();
  }, [getValues, planDuration, servicePlan, hideModal, startDate, updateServicePlan]);

  return {
    formFields,
    handleSubmit,
    onChangeHandler,
    errors,
    setValue,
    getValues,
    saveTimeline,
    duration,
    isPlanStarted,
  };
};

export default useTimelineModal;
