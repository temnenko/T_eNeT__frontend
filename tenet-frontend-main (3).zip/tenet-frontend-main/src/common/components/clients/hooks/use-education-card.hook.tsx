import { useMemo } from 'react';
import { format } from 'date-fns';
import { toIsoDate } from '../../../../utils/date.util';
import { Education, TrainingLocations } from '../../../../types/client';
import useCapitalize from '../../../../hooks/use-capitalize.hook';

const useEducationCards = (education: Education) => {
  const capitalize = useCapitalize();

  const educationDetails = useMemo(() => {
    const details: { label: string; value: React.ReactNode }[] = [
      {
        label: 'Educational institution',
        value: capitalize(education.educationalInstitution),
      },
      {
        label: 'Field of study',
        value: capitalize(education.fieldOfStudy),
      },
      {
        label: 'Credential received',
        value: education?.credentialReceived ? 'Yes' : 'No',
      },
      {
        label: 'Name of credential',
        value: education.credentialName,
      },
      {
        label: 'Delivery',
        value: capitalize(education.trainingDeliveryMethod),
      },
    ];

    if (education.trainingLocation?.toLowerCase() === TrainingLocations.OUTSIDE_CANADA.toLowerCase()) {
      details.push(
        {
          label: 'Education location',
          value: education.trainingLocation,
        },
        { label: 'Credential assessed?', value: education.credentialAssessed ? 'Yes' : 'No' },
        { label: 'Assessment agency', value: education.assessmentAgencyName },
        {
          label: 'Date of assessment',
          value: education.assessmentDate ? format(toIsoDate(education.assessmentDate), 'MMM d, yyyy') : undefined,
        },
        { label: 'Credential equivalency', value: education.credentialEquivalency },
      );
    }

    if (education.trainingLocation?.toLowerCase() === TrainingLocations.IN_ALBERTA.toLowerCase()) {
      details.push({ label: 'Location', value: 'Alberta' });
    }

    if (education.personAttendingTraining) {
      details.push(
        { label: 'Classification', value: 'Part Time student' },
        { label: 'Hours per week', value: education.totalHoursPerWeek },
        { label: 'Location', value: education.trainingLocation },
        { label: 'Interference with employment', value: education.trainingInterferesWithEmployment ? 'Yes' : 'No' },
      );
    }

    return details.filter((item) => item.value !== undefined && item.value !== '');
  }, [capitalize, education]);

  return { educationDetails };
};

export default useEducationCards;
