import { useCallback, useEffect, useMemo, useState } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';
import { SortOrder } from '../../../../types/sort-order';

export const useNotesList = (isClient?: boolean) => {
  const {
    clientsStore: { selectedClient },
    servicePlanStore: {
      servicePlan,
      notes,
      getServicePlanNotes,
      notesTotalCount,
      page,
      setPage,
      sortOrder,
      setSortOrder,
    },
  } = useStore();
  const [pageSize, setPageSize] = useState<number>(10);
  const resourceId = useMemo(
    () => (isClient ? selectedClient?.id : servicePlan?.id),
    [isClient, selectedClient?.id, servicePlan?.id],
  );
  const actualPageSize = useMemo(
    () => (notesTotalCount < pageSize ? notesTotalCount : pageSize),
    [notesTotalCount, pageSize],
  );

  const fetchNotes = useCallback(async () => {
    if (resourceId) {
      const params = {
        sortOrder,
        batchSize: pageSize,
        skipCount: (page - 1) * pageSize,
      };
      try {
        await getServicePlanNotes(resourceId, params);
      } catch (e) {
        // some API based error log considerations
      }
    }
  }, [getServicePlanNotes, page, pageSize, resourceId, sortOrder]);

  useEffect(() => {
    fetchNotes();
  }, [fetchNotes, page, pageSize, resourceId, sortOrder]);

  const onSortOrderChangeHandler = useCallback(
    (name: string, value: string | string[]) => {
      setSortOrder(value as SortOrder);
    },
    [setSortOrder],
  );

  const onPaginationChangeHandler = useCallback(
    (pageNumber: number) => {
      setPage(pageNumber);
    },
    [setPage],
  );

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      const newSize = Array.isArray(value) ? value[0] : value;

      setPageSize(Number.parseInt(newSize, 10));
      setPage(1);
      setSortOrder('desc');
    },
    [setPage, setSortOrder],
  );

  return {
    notes,
    onSortOrderChangeHandler,
    sortOrder,
    page,
    pageSize,
    actualPageSize,
    changePerPageSize,
    onPaginationChangeHandler,
    fetchNotes,
    notesTotalCount,
  };
};
