import { useCallback, useState } from 'react';

const useEducationChangeMessage = () => {
  const [message, setMessage] = useState<string>();

  const clearMessage = useCallback(() => {
    setMessage('');
  }, []);

  return { message, setMessage, clearMessage };
};

export default useEducationChangeMessage;
