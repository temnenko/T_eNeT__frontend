import { useCallback, useMemo } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';

import { ListPagination } from '../../list-pagination';

const useEmploymentsPagination = () => {
  const {
    clientsStore: {
      setCurrentEmploymentListPosition,
      setEmploymentListSize,
      getEmploymentListSize,
      currentEmploymentListPosition,
      totalEmploymentCount,
    },
  } = useStore();

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      const newSize = Array.isArray(value) ? value[0] : value;

      setEmploymentListSize(Number.parseInt(newSize, 10));
    },
    [setEmploymentListSize],
  );

  return useMemo(() => {
    const actualPageSize = totalEmploymentCount < getEmploymentListSize ? totalEmploymentCount : getEmploymentListSize;
    return (
      <ListPagination
        perPageSize={getEmploymentListSize}
        actualPageSize={actualPageSize}
        perPageSizeOptions={[10, 15, 20]}
        changePerPageSize={changePerPageSize}
        pagePosition={currentEmploymentListPosition}
        changePagePosition={setCurrentEmploymentListPosition}
        totalCount={totalEmploymentCount}
      />
    );
  }, [
    totalEmploymentCount,
    getEmploymentListSize,
    changePerPageSize,
    currentEmploymentListPosition,
    setCurrentEmploymentListPosition,
  ]);
};

export default useEmploymentsPagination;
