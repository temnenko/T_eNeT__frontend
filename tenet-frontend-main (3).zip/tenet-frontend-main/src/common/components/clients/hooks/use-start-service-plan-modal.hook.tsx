import { useCallback } from 'react';
import { startOfToday } from 'date-fns';
import { useForm } from 'react-hook-form';

import { useStore } from '../../../../hooks/use-store.hook';
import { useModal } from '../../../../hooks/use-modal.hook';
import { validateNotFutureDate } from '../../../../utils/validate-date.util';
import { toIsoFormat } from '../../../../utils/date.util';

type StartServicePlanFieldName = 'actualStartDate';

type StartServicePlanFieldData = {
  actualStartDate: string;
};

const useStartServicePlanModal = () => {
  const { hideModal } = useModal();

  const {
    servicePlanStore: { progressServicePlan },
  } = useStore();

  const {
    getValues,
    register,
    setValue,
    handleSubmit,
    formState: { errors },
  } = useForm<StartServicePlanFieldData>({
    defaultValues: {
      actualStartDate: toIsoFormat(startOfToday()),
    },
  });

  const { name: actualStartDate } = register('actualStartDate', {
    required: { value: true, message: 'Actual start date is required' },
    validate: validateNotFutureDate,
  });

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as StartServicePlanFieldName, value);
    },
    [setValue],
  );

  const startServicePlanButtonHandler = useCallback(async () => {
    const { actualStartDate: servicePlanActualStartDate } = getValues();
    await progressServicePlan(new Date(servicePlanActualStartDate));
    hideModal();
  }, [getValues, hideModal, progressServicePlan]);

  return {
    handleSubmit,
    onChangeHandler,
    errors,
    setValue,
    getValues,
    startServicePlanButtonHandler,
    actualStartDate,
    hideModal,
  };
};

export default useStartServicePlanModal;
