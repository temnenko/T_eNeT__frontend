import { useCallback, useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';

import { useStore } from '../../../../hooks/use-store.hook';

const useEducations = () => {
  const { id: clientId } = useParams<{ id: string }>();
  const {
    clientsStore: {
      educationHistory,
      getEducations,
      selectedClient,
      currentEducationHistoryPosition,
      getEducationHistorySize,
    },
    permissionStore: { canEditEducation },
  } = useStore();
  const [archived, setArchived] = useState(false);
  const toggleShowCancelledEducations = useCallback(() => setArchived(!archived), [archived]);

  useEffect(() => {
    const clientToUse = clientId || selectedClient?.id;
    if (clientToUse) {
      getEducations(clientToUse, archived);
    }
    getEducationHistorySize();
  }, [archived, clientId, getEducations, selectedClient?.id, currentEducationHistoryPosition, getEducationHistorySize]);

  return useMemo(() => {
    return {
      educations: educationHistory,
      clientId,
      archived,
      toggleShowCancelledEducations,
      canEditEducation,
    };
  }, [archived, clientId, educationHistory, toggleShowCancelledEducations, canEditEducation]);
};

export default useEducations;
