/* eslint-disable no-console */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useStore } from '../../../../hooks/use-store.hook';
import { ServicePlanTimelineModal } from '../service-plans/timeline-modal';
import { useModal } from '../../../../hooks/use-modal.hook';
import { StartServicePlanModal } from '../service-plans/start-service-plan.modal';
import { ServicePlanCancelModal } from '../service-plans/cancel-service-plan-modal';
import { ServicePlanOutcome, ServicePlanStatus } from '../../../../types/service-plan';

type StepperFieldName = 'review' | 'activityDate' | 'activity' | 'timeline';

type StepperFieldData = {
  review?: string;
  activity?: string;
  activityDate?: Date;
  timeline?: Date;
};

export enum ServicePlanStepStatus {
  complete = 'complete',
  incomplete = 'incomplete',
}

const useTransitionToEmploymentForm = () => {
  const { id: clientId } = useParams<{ id: string }>();

  const { hideModal, showModal } = useModal();
  const [isPlanIncomplete, setIsPlanIncomplete] = useState(false);

  const {
    servicePlanStore: {
      duration,
      cancelServicePlanTimeline,
      setupServicePlan,
      planSetup,
      servicePlan,
      createNote,
      getEmploymentHistoryById,
      employment,
      steps,
      step,
      setStep,
    },
    permissionStore: { isSuperAdmin },
  } = useStore();

  const {
    getValues,
    register,
    setValue,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<StepperFieldData>({
    defaultValues: {},
  });

  useEffect(() => {
    if (servicePlan?.employmentId) {
      getEmploymentHistoryById(servicePlan.employmentId, false);
    }
    setIsPlanIncomplete(servicePlan?.outcome === ServicePlanOutcome.INCOMPLETE);
  }, [getEmploymentHistoryById, servicePlan?.employmentId, servicePlan?.outcome, servicePlan?.status]);

  const { name: review } = register('review', {
    required: { value: true, message: 'Review is required' },
  });
  const { name: activity } = register('activity');
  const { name: activityDate } = register('activityDate');
  const { name: timeline } = register('timeline');

  const cancelStepPlanSetup = useCallback(() => {
    showModal(
      <ServicePlanCancelModal
        cancelServicePlan={() => {
          setupServicePlan(false);
          setStep(0);
          cancelServicePlanTimeline();
          hideModal();
        }}
        hideModal={hideModal}
      />,
    );
  }, [cancelServicePlanTimeline, hideModal, setStep, setupServicePlan, showModal]);

  const saveServicePlanReview = useCallback(async () => {
    const message = getValues(review);
    if (!message || !servicePlan) return;
    await createNote({ message, subject: 'Progress review', recordIds: [servicePlan.id, servicePlan.clientId] });
    setValue(review, undefined);
  }, [createNote, getValues, review, servicePlan, setValue]);

  const editTimeline = useCallback(() => {
    showModal(<ServicePlanTimelineModal hideModal={hideModal} />);
  }, [hideModal, showModal]);

  const formFields = {
    review,
    activity,
    activityDate,
    timeline,
  };

  const onChangeHandler = useCallback(
    (name: string, value: string | string[] | Date | undefined) => {
      if (Array.isArray(value)) {
        setValue(name as StepperFieldName, value.join(','));
      } else {
        setValue(name as StepperFieldName, value);
      }
    },
    [setValue],
  );

  const isPlanInProgress = useMemo(() => servicePlan?.status === ServicePlanStatus.IN_PROGRESS, [servicePlan?.status]);
  const isPlanInProgressOrComplete = useMemo(
    () =>
      [ServicePlanStatus.IN_PROGRESS, ServicePlanStatus.COMPLETE, ServicePlanStatus.IN_FOLLOW_UP].includes(
        servicePlan!.status,
      ),
    [servicePlan],
  );

  const openStartServicePlanModal = useCallback(() => {
    showModal(<StartServicePlanModal hideModal={hideModal} />);
  }, [hideModal, showModal]);

  const canCancelPlan = useMemo(
    () => isSuperAdmin && ![ServicePlanStatus.CANCELLED, ServicePlanStatus.CLOSED].includes(servicePlan!.status),
    [isSuperAdmin, servicePlan],
  );

  return {
    clientId,
    step,
    setStep,
    formFields,
    handleSubmit,
    control,
    onChangeHandler,
    saveServicePlanReview,
    errors,
    planSetup,
    getValues,
    cancelStepPlanSetup,
    editTimeline,
    duration,
    openStartServicePlanModal,
    servicePlan,
    employment,
    steps,
    canCancelPlan,
    isPlanInProgress,
    isPlanInProgressOrComplete,
    isPlanIncomplete,
  };
};

export default useTransitionToEmploymentForm;
