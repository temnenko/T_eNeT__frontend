/* eslint-disable no-console */
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from '../../../../hooks/use-store.hook';
import { useModal } from '../../../../hooks/use-modal.hook';
import { ServicePlanTimelineModal } from '../service-plans/timeline-modal';
import { ServicePlanCancelModal } from '../service-plans/cancel-service-plan-modal';
import { ServicePlanStatus } from '../../../../types/service-plan';

const useTransitionToEmployment = () => {
  const { id: clientId, serviceId } = useParams<{ id: string; serviceId: string }>();
  const steps = useMemo(
    () => [
      { stepper: ['Attend TES'], done: false, position: 1 },
      { stepper: ['End TES'], done: false, position: 2 },
      { stepper: ['Follow up'], done: false, position: 3 },
    ],
    [],
  );

  const {
    servicePlanStore: { getServicePlanByClientId, cancelServicePlanTimeline, servicePlan },
    permissionStore: { isSuperAdmin, canManageServicePlan },
    userStore: { role, organizationId },
  } = useStore();

  const [isReadOnly, setIsReadOnly] = useState(false);

  const { hideModal, showModal } = useModal();

  const shouldShowManageServicePlan = useCallback(() => {
    return (
      isSuperAdmin ||
      (canManageServicePlan(servicePlan?.organizationId ?? '') && servicePlan?.status !== ServicePlanStatus.CLOSED)
    );
  }, [isSuperAdmin, canManageServicePlan, servicePlan?.organizationId, servicePlan?.status]);

  useEffect(() => {
    const createServiceplan = async () => {
      if (clientId) {
        await getServicePlanByClientId(clientId, serviceId);
      }
    };
    createServiceplan();
  }, [
    clientId,
    getServicePlanByClientId,
    role,
    serviceId,
    shouldShowManageServicePlan,
    servicePlan?.organizationId,
    organizationId,
  ]);

  useEffect(() => {
    if (servicePlan) {
      if (!shouldShowManageServicePlan()) {
        setIsReadOnly(true);
      } else {
        setIsReadOnly(false);
      }
    }
  }, [servicePlan, shouldShowManageServicePlan]);

  const cancelStepPlanSetup = useCallback(() => {
    showModal(
      <ServicePlanCancelModal
        cancelServicePlan={() => {
          cancelServicePlanTimeline();
          hideModal();
        }}
        hideModal={hideModal}
      />,
    );
  }, [cancelServicePlanTimeline, hideModal, showModal]);

  const setupServicePlan = useCallback(() => {
    showModal(<ServicePlanTimelineModal hideModal={hideModal} />);
  }, [hideModal, showModal]);

  return {
    clientId,
    cancelStepPlanSetup,
    servicePlan,
    setupServicePlan,
    steps,
    isReadOnly,
  };
};

export default useTransitionToEmployment;
