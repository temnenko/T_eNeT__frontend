import { useCallback } from 'react';

import { useModal } from '../../../../hooks/use-modal.hook';
import { noteService } from '../../../../services/note.service';
import { ConfirmationModal } from '../../modals/confirmation.modal';
import { useStore } from '../../../../hooks/use-store.hook';

export const useSoftDeleteNote = (refetch: () => Promise<void>) => {
  const { hideModal, showModal } = useModal();
  const {
    servicePlanStore: { setPage },
  } = useStore();

  const softDeleteNote = useCallback(
    async (id: string) => {
      try {
        await noteService.update(id, { deleted: true });
      } catch (e) {
        // some API based error log considerations
      } finally {
        setPage(1);
        await refetch();
        hideModal();
      }
    },
    [refetch, setPage, hideModal],
  );

  const softDeleteNoteHandler = useCallback(
    (id: string) => {
      showModal(
        <ConfirmationModal
          heading="Delete note?"
          description="You can recover this record from your Bin within 30 days."
          declineText="Oops, go back"
          confirmText="Move to bin"
          onConfirm={() => softDeleteNote(id)}
          onDecline={hideModal}
          isDelete
        />,
      );
    },
    [hideModal, showModal, softDeleteNote],
  );

  return {
    softDeleteNoteHandler,
  };
};
