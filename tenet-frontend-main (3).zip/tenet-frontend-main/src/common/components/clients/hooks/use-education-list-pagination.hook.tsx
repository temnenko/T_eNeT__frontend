import { useCallback, useMemo } from 'react';
import { useStore } from '../../../../hooks/use-store.hook';

import { ListPagination } from '../../list-pagination';

const useEducationHistoryPagination = () => {
  const {
    clientsStore: {
      setCurrentEducationHistoryPosition,
      setEducationHistorySize,
      getEducationHistorySize,
      currentEducationHistoryPosition,
      totalEducationHistoryCount,
    },
  } = useStore();
  const size = getEducationHistorySize();

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      const newSize = Array.isArray(value) ? value[0] : value;

      setEducationHistorySize(Number.parseInt(newSize, 10));
    },
    [setEducationHistorySize],
  );

  return useMemo(() => {
    const actualPageSize = totalEducationHistoryCount < size ? totalEducationHistoryCount : size;
    return (
      <ListPagination
        perPageSize={size}
        actualPageSize={actualPageSize}
        perPageSizeOptions={[10, 20, 50]}
        changePerPageSize={changePerPageSize}
        pagePosition={currentEducationHistoryPosition}
        changePagePosition={setCurrentEducationHistoryPosition}
        totalCount={totalEducationHistoryCount}
      />
    );
  }, [
    size,
    changePerPageSize,
    currentEducationHistoryPosition,
    setCurrentEducationHistoryPosition,
    totalEducationHistoryCount,
  ]);
};

export default useEducationHistoryPagination;
