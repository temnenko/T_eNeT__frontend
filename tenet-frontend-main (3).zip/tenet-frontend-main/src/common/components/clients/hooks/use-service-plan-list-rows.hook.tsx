import { useCallback, useMemo } from 'react';
import { format } from 'date-fns';

import { useStore } from '../../../../hooks/use-store.hook';
import { ServicePlanRow } from '../service-plans/service-plan-list-row';
import { ServicePlanKey } from '../../../../types/service-plan';
import { toIsoDate } from '../../../../utils/date.util';

const useServicePlanListRows = () => {
  const {
    servicePlansListStore: { planListView, hasPlans, sortData },
    permissionStore: { isSuperAdmin, canManageServicePlan },
  } = useStore();

  const shouldManageServicePlan = useCallback(
    (planId: string) => {
      const plan = planListView.find(({ id }) => id === planId);
      return canManageServicePlan(plan?.organizationId ?? '');
    },
    [canManageServicePlan, planListView],
  );

  return {
    serviceplanListRows: useMemo(() => {
      if (hasPlans) {
        return planListView.map(({ id, clientId, status, startdate, managedBy, agreementName, type }) => (
          <ServicePlanRow
            key={id}
            id={id}
            clientId={clientId}
            startdate={format(toIsoDate(startdate), 'MMM dd, yyyy')}
            agreementName={agreementName ?? ''}
            status={status}
            managedBy={managedBy}
            type={type}
            manage={shouldManageServicePlan(id)}
            isSuperAdmin={isSuperAdmin}
          />
        ));
      }

      return undefined;
    }, [hasPlans, isSuperAdmin, planListView, shouldManageServicePlan]),
    sortData: useCallback(
      (sortBy: string, sortDir: number) => {
        sortData(sortBy as ServicePlanKey, sortDir);
      },
      [sortData],
    ),
  };
};

export default useServicePlanListRows;
