import '@testing-library/jest-dom';
import { render, getByTestId } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import * as hooks from '../../../hooks/use-store.hook';
import { ClientsListFilter } from './clients-list-filter';
import RootStore from '../../../stores/root.store';

describe('ClientsListFilter', () => {
  const mockStore = {
    clientsListStore: {
      clients: [],
      get hasClients() {
        return this.clients.length > 0;
      },
      getClients: jest.fn(),
    },
    clientFormStore: { clearClient: jest.fn() },
    clientFormStepperStore: { resetSteps: jest.fn() },
    permissionStore: { canCreateClient: true },
    userStore: { role: 'SUPER_ADMIN' },
  } as unknown as RootStore;

  test('Renders ClientsListFilter', () => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { baseElement: clientsListFilter } = render(
      <BrowserRouter>
        <ClientsListFilter />
      </BrowserRouter>,
    );
    const clientsFilterSection = getByTestId(clientsListFilter, 'clientsFilterSection');
    const clientsFilterDropdowns = getByTestId(clientsListFilter, 'clientsFilterTextboxes');
    const clientsFilterForm = getByTestId(clientsListFilter, 'clientsFilterForm');

    expect(clientsListFilter).toBeInTheDocument();
    expect(clientsFilterSection).toBeInTheDocument();
    expect(clientsFilterDropdowns).toBeInTheDocument();
    expect(clientsFilterForm).toBeInTheDocument();
  });
});
