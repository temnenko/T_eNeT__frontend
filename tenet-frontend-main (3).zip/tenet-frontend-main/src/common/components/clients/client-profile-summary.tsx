import { useMemo } from 'react';
import { format } from 'date-fns';
import { observer } from 'mobx-react-lite';
import { GoABlock, GoAContainer, GoASpacer } from '@abgov/react-components';

import { useStore } from '../../../hooks/use-store.hook';
import { mapDateOfBirthToAge } from '../../../utils/dob.util';
import useCapitalize from '../../../hooks/use-capitalize.hook';
import { useFormatPhoneNumber } from '../../../hooks/use-format-phone-number';
import { humanizeNameType } from '../../../utils/humanize.util';
import { toIsoDate } from '../../../utils/date.util';

const ClientProfileSummary = observer(() => {
  const formatPhoneNumber = useFormatPhoneNumber();
  const {
    clientsStore: { selectedClient },
  } = useStore();
  const capitalize = useCapitalize();
  const clientGender = useMemo(() => {
    if (selectedClient?.demographic?.gender) {
      return capitalize(selectedClient.demographic.gender);
    }

    return undefined;
  }, [capitalize, selectedClient?.demographic?.gender]);

  return (
    <div className="client-profile-section">
      <GoASpacer vSpacing="l" />
      <GoAContainer type="info" width="full">
        <div className="client-summary-heading">
          <GoABlock alignment="center" gap="m">
            <h1 className="client-no-padding-no-margin heading-xl">{`${selectedClient?.firstName ?? ''} ${
              selectedClient?.lastName ?? ''
            }`}</h1>
            <span className="tenet-number">{selectedClient?.tenetNumber}</span>
          </GoABlock>
        </div>
        <GoABlock gap="4xl" mb="2xl">
          <GoABlock direction="column" gap="xs">
            <span>Age {selectedClient?.dateOfBirth ? mapDateOfBirthToAge(selectedClient.dateOfBirth) : ' '}</span>
            <span>
              {selectedClient?.dateOfBirth ? format(toIsoDate(selectedClient.dateOfBirth), 'dd MMM yyyy') : ' '}
            </span>
            <span>{clientGender}</span>
          </GoABlock>
          <GoABlock direction="column" gap="m">
            <span>{`${selectedClient?.phones && selectedClient?.phones.length > 0 ? formatPhoneNumber(selectedClient?.phones[0].phoneNumber) : ' '}`}</span>
            <span>{`${selectedClient?.emailAddresses && selectedClient.emailAddresses.length > 0 ? selectedClient.emailAddresses[0].emailAddress : ''}`}</span>
          </GoABlock>
          <GoABlock direction="column" gap="xs">
            <span>{`${selectedClient?.addresses && selectedClient.addresses.length > 0 ? selectedClient.addresses[0].street : ''}`}</span>
            <span>{`${selectedClient?.addresses && selectedClient.addresses.length > 0 ? selectedClient.addresses[0].city : ''}`}</span>
            <span>{`${selectedClient?.addresses && selectedClient.addresses.length > 0 ? `${selectedClient.addresses[0].province} ${selectedClient.addresses[0].postalCode.toUpperCase()}` : ''}`}</span>
          </GoABlock>
        </GoABlock>
        <div className="client-summary-section">
          <GoABlock direction="column" gap="1">
            <span className="heading-xs color-interactive">Current involvement</span>
            {selectedClient?.currentInvolvement}
          </GoABlock>
          <GoABlock direction="column" gap="1">
            <span className="heading-xs color-interactive">Support type</span>
            {selectedClient?.agreementName ? humanizeNameType(selectedClient.agreementName) : ''}
          </GoABlock>
          <GoABlock direction="column" gap="1">
            <span className="heading-xs color-interactive">{}</span>
          </GoABlock>
        </div>
      </GoAContainer>
      <GoASpacer vSpacing="l" />
    </div>
  );
});

export default ClientProfileSummary;
