import { useCallback } from 'react';
import { format } from 'date-fns';
import { GoABlock, GoAButton, GoAIcon, GoAModal, GoASpacer } from '@abgov/react-components';

import { ClientVerificationRecord, LmdaResultLanguage } from '../../../../types/client';
import { useModal } from '../../../../hooks/use-modal.hook';
import LmdaClaimDataDetails from './lmda-claim-data-details';
import useCapitalize from '../../../../hooks/use-capitalize.hook';
import { toIsoDate } from '../../../../utils/date.util';

type Props = {
  record: ClientVerificationRecord;
};

function LmdaVerificationRow({ record }: Props) {
  const { showModal, hideModal } = useModal();
  const formatDate = useCallback((dateString: string | number | Date) => {
    return format(toIsoDate(dateString), 'MMM d, yyyy');
  }, []);

  const moreDetailsViewHandler = useCallback(() => {
    showModal(
      <GoAModal maxWidth="768px" open width="768px" transition="slow" heading="More details" onClose={hideModal}>
        <LmdaClaimDataDetails record={record} />
      </GoAModal>,
    );
  }, [hideModal, record, showModal]);

  const capitalize = useCapitalize();

  return (
    <tr>
      <td className={record.result === 'ERROR' ? 'errorBadge' : 'lmdaResultBadge'}>
        <GoABlock>
          {record.result === 'ERROR' ? <GoAIcon type="warning" /> : undefined}
          <GoASpacer hSpacing="m" />
          <span>{capitalize(record.result?.toLowerCase())}</span>
        </GoABlock>
      </td>
      <td>
        {(record.rawResult &&
          record.rawResult?.StatusDescriptionText?.find((t) => t.lang === LmdaResultLanguage.eng)?.value) ||
          'Details not available'}
      </td>
      <td>{formatDate(record.createdAt)}</td>
      <td>
        {record.claimData && (
          <GoAButton type="tertiary" onClick={moreDetailsViewHandler}>
            View
          </GoAButton>
        )}
      </td>
    </tr>
  );
}

export default LmdaVerificationRow;
