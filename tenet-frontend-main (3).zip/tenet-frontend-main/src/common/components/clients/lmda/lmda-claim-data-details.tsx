/* eslint-disable react/no-array-index-key */
import { useCallback } from 'react';
import { format } from 'date-fns';
import { GoABlock } from '@abgov/react-components';

import { ClientVerificationRecord, LmdaBilingualKeyValuePair, LmdaResultLanguage } from '../../../../types/client';
import { formatAmount } from '../../../../utils/amount.util';
import { toIsoDate } from '../../../../utils/date.util';

type Props = {
  record: ClientVerificationRecord;
};

function LmdaClaimDataDetails({ record }: Props) {
  const formatMoney = useCallback((value: number | undefined) => {
    return typeof value === 'number' ? formatAmount(value) : 'NA';
  }, []);
  const formatDate = useCallback((dateString: string | number | Date | undefined) => {
    return dateString ? format(toIsoDate(dateString), 'MMM d, yyyy') : 'NA';
  }, []);
  const getValueEn = useCallback((input: string | LmdaBilingualKeyValuePair[]) => {
    if (typeof input === 'string') {
      return input;
    }
    return input?.find((obj) => obj.lang === LmdaResultLanguage.eng)?.value ?? 'NA';
  }, []);
  const { activityCategoryText, programBenefitClaimDetails, programBenefitEarning, disentitlement, disqualification } =
    record.claimData;

  return (
    <GoABlock direction="column">
      <span>Benefit info</span>
      <GoABlock gap="0" direction="column">
        <div className="details-container">
          <div className="details-item">
            <div className="detail-heading">Claim type</div>
            <div>{getValueEn(activityCategoryText)}</div>
          </div>
          <div className="details-item">
            <div className="detail-heading">Apprenticeship</div>
            <div>{getValueEn(programBenefitClaimDetails?.apprenticeshipIndicatorText)}</div>
          </div>
        </div>
        <div className="details-container">
          <div className="details-item">
            <div className="detail-heading">Claim start sate</div>
            <div>{formatDate(programBenefitClaimDetails?.benefitStartDate?.date)}</div>
          </div>
          <div className="details-item">
            <div className="detail-heading">Apprenticeship waiting period waived</div>
            <div>{getValueEn(programBenefitClaimDetails?.waitingPeriodWaivedIndicatorText)}</div>
          </div>
        </div>
        <div className="details-container">
          <div className="details-item">
            <div className="detail-heading">Number of weeks eligible</div>
            <div>{programBenefitClaimDetails?.eligibleWeekNumber ?? 'NA'}</div>
          </div>
          <div className="details-item">
            <div className="detail-heading">Payment stopped</div>
            <div>{getValueEn(programBenefitClaimDetails?.paymentStoppedIndicatorText)}</div>
          </div>
        </div>
      </GoABlock>
      <span>Number of weeks paid</span>
      <GoABlock gap="0" direction="column">
        <div className="details-container">
          <div className="details-item">
            <div className="detail-heading">Total</div>
            <div>{programBenefitClaimDetails?.totalWeekPaidNumber ?? 'NA'}</div>
          </div>
          <div className="details-item">
            <div className="detail-heading">Regular benefits</div>
            <div>{programBenefitClaimDetails?.regularWeekPaidNumber ?? 'NA'}</div>
          </div>
          <div className="details-item">
            <div className="detail-heading">Special benefits</div>
            <div>{programBenefitClaimDetails?.specialWeekPaidNumber ?? 'NA'}</div>
          </div>
        </div>
      </GoABlock>
      <span>EI benefit rate (Part I)</span>
      <GoABlock gap="0" direction="column">
        <div className="details-container">
          <div className="details-item">
            <div className="detail-heading">Amount</div>
            <div>{formatMoney(programBenefitClaimDetails?.weeklyBenefitRateNumber)}</div>
          </div>
        </div>
        <div className="details-container">
          <div className="details-item">
            <div className="detail-heading">Week of renewal</div>
            <div>{formatDate(programBenefitClaimDetails?.benefitRenewalDate?.date)}</div>
          </div>
          <div className="details-item">
            <div className="detail-heading">Provincial income tax</div>
            <div>{formatMoney(programBenefitClaimDetails?.wagesProvincialTaxWithheldAmount)}</div>
          </div>
        </div>
        <div className="details-container">
          <div className="details-item">
            <div className="detail-heading">Last week processed</div>
            <div>{formatDate(programBenefitClaimDetails?.lastProcessedDate?.date)}</div>
          </div>
          <div className="details-item">
            <div className="detail-heading">Expected end date</div>
            <div>{formatDate(programBenefitClaimDetails?.expectedEndDate?.date)}</div>
          </div>
        </div>
        <div className="details-container">
          <div className="details-item">
            <div className="detail-heading">Federal income tax</div>
            <div>{formatMoney(programBenefitClaimDetails?.wagesFederalTaxWithheldAmount)}</div>
          </div>
          <div className="details-item">
            <div className="detail-heading">Latest renewal week</div>
            <div>{formatDate(programBenefitClaimDetails?.latestRenewableDate?.date)}</div>
          </div>
        </div>
      </GoABlock>
      {!!programBenefitEarning?.length && (
        <>
          <span>Allocations of earnings</span>
          <GoABlock gap="0" direction="column">
            <div className="details-container">
              <div className="details-item">
                <div className="detail-heading">Start week</div>
              </div>
              <div className="details-item">
                <div className="detail-heading">End week</div>
              </div>
              <div className="details-item">
                <div className="detail-heading">Weekly amount</div>
              </div>
              <div className="details-item">
                <div className="detail-heading">Last week amount</div>
              </div>
            </div>
            {programBenefitEarning.map((item, id) => (
              <div className="details-container" key={id}>
                <div className="details-item">
                  <div>{formatDate(item?.programBenefitEarningDate?.dateRange?.startDate?.date)}</div>
                </div>
                <div className="details-item">
                  <div>{formatDate(item?.programBenefitEarningDate?.dateRange?.endDate?.date)}</div>
                </div>
                <div className="details-item">
                  <div>{formatMoney(item?.programBenefitEarningWeeklyAmount)}</div>
                </div>
                <div className="details-item">
                  <div>{formatMoney(item?.programBenefitEarningLastWeekAmount)}</div>
                </div>
              </div>
            ))}
          </GoABlock>
        </>
      )}
      {!!disentitlement?.length && (
        <>
          <span>Disentitlement</span>
          <GoABlock gap="0" direction="column">
            <div className="details-container">
              <div className="details-item">
                <div className="detail-heading">Start date</div>
              </div>
              <div className="details-item">
                <div className="detail-heading">End date</div>
              </div>
              <div className="details-item">
                <div className="detail-heading">Message</div>
              </div>
            </div>
            {disentitlement.map((item, id) => (
              <div className="details-container" key={id}>
                <div className="details-item">
                  <div>{formatDate(item?.dispositionDate?.dateRange?.startDate?.date)}</div>
                </div>
                <div className="details-item">
                  <div>{formatDate(item?.dispositionDate?.dateRange?.endDate?.date)}</div>
                </div>
                <div className="details-item">
                  <div>{getValueEn(item?.dispositionReasonText)}</div>
                </div>
              </div>
            ))}
          </GoABlock>
        </>
      )}
      {!!disqualification?.length && (
        <>
          <span>Disqualification</span>
          <GoABlock gap="0" direction="column">
            <div className="details-container">
              <div className="details-item">
                <div className="detail-heading">Effective date</div>
              </div>
              <div className="details-item">
                <div className="detail-heading">Weeks remaining</div>
              </div>
              <div className="details-item">
                <div className="detail-heading">Message</div>
              </div>
            </div>
            {disqualification.map((item, id) => (
              <div className="details-container" key={id}>
                <div className="details-item">
                  <div>{formatDate(item?.dispositionDate?.date)}</div>
                </div>
                <div className="details-item">
                  <div>{item?.disqualificationRemainingWeekNumber ?? 'NA'}</div>
                </div>
                <div className="details-item">
                  <div>{getValueEn(item?.dispositionReasonText)}</div>
                </div>
              </div>
            ))}
          </GoABlock>
        </>
      )}
    </GoABlock>
  );
}

export default LmdaClaimDataDetails;
