import { useRouteError, isRouteErrorResponse, useNavigate } from 'react-router-dom';
import { GoAButton, GoAButtonGroup, GoACallout, GoAOneColumnLayout, GoAPageBlock } from '@abgov/react-components';
import { ReactNode } from 'react';
import AppHeader from './components/app-header/app-header';
import AppFooter from './components/app-footer/app-footer';

interface Props {
  error: string;
}

function ErrorCallout({ error }: Props) {
  const navigate = useNavigate();
  return (
    <GoAOneColumnLayout>
      <AppHeader />

      <GoAPageBlock testId="errorboundary" width="904px">
        <GoACallout type="important" heading="Unable to proceed due to system issue">
          <p className="client-font-with-margin">
            {`We're experiencing a system issue. Please wait a moment before proceeding.`}
          </p>
          <p>{error}</p>
          <GoAButtonGroup alignment="end" mt="l">
            <GoAButton type="primary" leadingIcon="home" onClick={() => navigate(-1)}>
              Go back
            </GoAButton>
          </GoAButtonGroup>
        </GoACallout>
      </GoAPageBlock>

      <AppFooter />
    </GoAOneColumnLayout>
  );
}

interface ErrorProps {
  children?: ReactNode;
}

export function ErrorBoundary({ children }: ErrorProps) {
  const error = useRouteError();
  let errorMessage = '';

  if (isRouteErrorResponse(error)) {
    if (error.status === 404) {
      errorMessage = 'The requested page does not exist!';
    }

    if (error.status === 401 || error.status === 403) {
      errorMessage = 'You are not authorized to view this page!';
    }

    if (error.status === 418) {
      return <div>🫖</div>;
    }

    if (error.status >= 500) {
      errorMessage = 'Looks like our API is down!';
    }
  }

  errorMessage = 'Something went wrong';

  return (
    <>
      <ErrorCallout error={errorMessage} />
      {children}
    </>
  );
}

ErrorBoundary.defaultProps = {
  children: <div />,
};

export default ErrorBoundary;
