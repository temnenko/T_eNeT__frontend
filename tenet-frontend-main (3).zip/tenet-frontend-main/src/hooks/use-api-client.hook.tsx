// src/hooks/useApiClient.ts
import { useContext, useMemo } from 'react';
import { ConfigContext } from '../contexts/config.context';
import { Config } from '../types/config';
import { createApiClient } from '../services/api-client.service';

export const useApiClient = () => {
  const config = useContext<Config | null>(ConfigContext);
  if (!config) {
    throw new Error('useApiClient must be used within a ConfigProvider');
  }

  const client = useMemo(() => {
    return createApiClient(config);
  }, [config]);

  return client;
};
