import { useCallback } from 'react';

export const useFormatPhoneInput = () => {
  return useCallback((rawPhoneInput: string | undefined) => {
    const phoneInput = rawPhoneInput?.replace(/\D/g, '')?.trim();
    if (!phoneInput || phoneInput?.length <= 0) {
      return '';
    }

    if (phoneInput.length > 10) {
      return phoneInput;
    }

    if (phoneInput.length <= 3) {
      return `(${phoneInput}${phoneInput.length === 3 ? ')' : ''}`;
    }

    if (phoneInput.length <= 6) {
      return `(${phoneInput.slice(0, 3)}) ${phoneInput.slice(3)}`;
    }

    return `(${phoneInput.slice(0, 3)}) ${phoneInput.slice(3, 6)}-${phoneInput.slice(6)}`;
  }, []);
};
