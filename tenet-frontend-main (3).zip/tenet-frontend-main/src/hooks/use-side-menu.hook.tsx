/* eslint-disable jsx-a11y/anchor-is-valid */
import { useMemo } from 'react';
import { GoASideMenu, GoASideMenuGroup } from '@abgov/react-components';
import { Link } from 'react-router-dom';

import { useStore } from './use-store.hook';

const useSideMenu = () => {
  const {
    authStore: { isAuthenticated },
  } = useStore();

  return useMemo(() => {
    if (isAuthenticated) {
      return (
        <GoASideMenu>
          <Link to="/profile" data-testid="a-profile">
            Your Profile
          </Link>
          <GoASideMenuGroup heading="Contracts & Grants">
            <Link data-testid="a-sideMenu-createNewOrg" to="/organizations/enroll/primary-details">
              Create new org
            </Link>
          </GoASideMenuGroup>

          <Link data-testid="a-organization-invite" to="/organizations/invites">
            Invite organizations
          </Link>
          <Link data-testid="a-organizations" to="/organizations">
            Organization directory
          </Link>
          <Link data-testid="a-users" to="/users">
            TENET Directory
          </Link>
        </GoASideMenu>
      );
    }

    return '';
  }, [isAuthenticated]);
};

export default useSideMenu;
