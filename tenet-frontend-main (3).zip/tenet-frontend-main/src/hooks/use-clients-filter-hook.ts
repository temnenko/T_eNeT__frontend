import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import luhnCheck from 'luhn-js';
import { useStore } from './use-store.hook';
import { ClientSearchParams } from '../types/client';

const useClientFilters = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [sinNumber, setSinNumber] = useState('');
  const [tenetNumber, setTenetNumber] = useState('');
  const [searchCriteria, setSearchCriteria] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [invalidNameSearch, setInvalidNameSearch] = useState(false);
  const [invalidSearchError, setInvalidSearchError] = useState<string | null>(null);
  const {
    clientsListStore: { totalCount: resultsCount, filterClients, resetClients },
    clientFormStore: { clearClient },
    clientFormStepperStore: { resetSteps },
  } = useStore();

  const navigate = useNavigate();

  const validateNameSearch = (): boolean => {
    if (
      (firstName?.length || lastName?.length || dateOfBirth?.length) &&
      !(firstName?.length && lastName?.length && dateOfBirth?.length)
    ) {
      return false;
    }
    return true;
  };

  const validateSIN = (value: string) => {
    if (value.length === 9) {
      if (value.indexOf('0') === 0) {
        return false;
      }
      if (!/[0-9]{9}/.test(value)) {
        return false;
      }
      if (!luhnCheck.isValid(value)) {
        return false;
      }
      return true;
    }
    return false;
  };
  const validateTenetId = (value: string) => {
    if (value.length >= 8) {
      if (!/^[0-9]{8,}$/.test(value)) {
        return false;
      }
      return true;
    }
    return false;
  };

  const getSearchCriteria = async () => {
    const searched: ClientSearchParams = {};
    if (firstName?.length) {
      searched.firstName = firstName.trim();
      if (firstName.length < 2) {
        setInvalidSearchError('First name needs to be at least two characters long');
        return;
      }
    }
    if (lastName?.length) {
      searched.lastName = lastName.trim();
      if (lastName.length < 2) {
        setInvalidSearchError('Last name needs to be at least two characters long');
        return;
      }
    }
    if (sinNumber?.length) {
      searched.sin = sinNumber.trim();
      if (!validateSIN(sinNumber)) {
        setInvalidSearchError('Invalid SIN number. SIN number must be 9 digits and can only contain numbers');
        return;
      }
    }
    if (tenetNumber?.length) {
      searched.tenetNumber = tenetNumber.trim();
      if (!validateTenetId(tenetNumber)) {
        setInvalidSearchError('Invalid Tenet Id. Tenet Id must be at least 8 digits and can only contain numbers');
        return;
      }
    }
    if (dateOfBirth?.length) {
      searched.dateOfBirth = new Date(dateOfBirth).toISOString();
    }
    if (!validateNameSearch()) {
      setInvalidNameSearch(true);
      return;
    }
    if (Object.keys(searched)?.length) {
      await filterClients(searched);
    }
    searched.dateOfBirth = dateOfBirth ? format(dateOfBirth.replace(/-/g, '/'), 'MMM do yyyy') : '';
    setSearchCriteria(
      Object.values(searched).reduce((next, criterion) => `${next}${criterion ? ', ' : ''}${criterion}`),
    );
  };

  const onChange = (name: string, value: string) => {
    if (invalidNameSearch) {
      setInvalidNameSearch(false);
    }
    if (invalidSearchError) {
      setInvalidSearchError(null);
    }
    switch (name) {
      case 'firstName': {
        setFirstName(value);
        break;
      }
      case 'lastName': {
        setLastName(value);
        break;
      }
      case 'sinNumber': {
        setSinNumber(value);
        break;
      }
      case 'tenetNumber': {
        setTenetNumber(value);
        break;
      }
      case 'dateOfBirth': {
        setDateOfBirth(value);
        break;
      }
      default:
    }
  };

  const reset = async () => {
    setFirstName('');
    setLastName('');
    setSinNumber('');
    setTenetNumber('');
    setSearchCriteria('');
    setDateOfBirth('');
    await resetClients();
  };

  const goToCreateNewClient = () => {
    clearClient();
    resetSteps();
    navigate('/clients/create/personal-details');
  };

  return {
    onChange,
    getSearchCriteria,
    searchCriteria,
    resultsCount,
    reset,
    firstName,
    lastName,
    tenetNumber,
    sinNumber,
    goToCreateNewClient,
    dateOfBirth,
    invalidNameSearch,
    invalidSearchError,
  };
};

export default useClientFilters;
