import '@testing-library/jest-dom';
import { renderHook } from '@testing-library/react';

import * as hooks from './use-store.hook';
import RootStore from '../stores/root.store';
import { Roles } from '../types/role';
import useHasRole from './use-has-role.hook';

describe('useHasRole', () => {
  const mockStore = {
    userStore: {
      role: Roles.ADMIN,
    },
  } as unknown as RootStore;

  test('should return true on role match', () => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { result } = renderHook(() => useHasRole([Roles.ADMIN]));

    expect(result.current).toBeTruthy();
  });

  test('should return false on role mismatch', () => {
    jest.spyOn(hooks, 'useStore').mockImplementation(() => mockStore);

    const { result } = renderHook(() => useHasRole([Roles.SUPER_ADMIN]));

    expect(result.current).toBeFalsy();
  });
});
