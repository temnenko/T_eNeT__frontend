/* eslint-disable no-console */
import { ReactNode, useCallback, useState } from 'react';
import { RequestError } from '../../types/errors/errors';
import useRequestErrorHandler from '../use-request-error-handler.hook';
import { useStore } from '../use-store.hook';
import { ConfirmationModal } from '../../common/components/modals/confirmation.modal';
import { useModal } from '../use-modal.hook';
import { User, UserStatus } from '../../types/user';
import { userService } from '../../services/user.service';
import { SelectedProfileViewModal } from '../../views/profile/selected-profile-view-modal';
import useUserDocumentsHook from '../../common/components/users/documents/use-user-documents-hook';
import { fileService } from '../../services/clients/client-files.service';

const useUserActivation = (setSuccessMessage?: React.Dispatch<React.SetStateAction<string | undefined>>) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [requestError, setRequestError] = useState<RequestError>({});
  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);
  const { hideModal, showModal } = useModal();
  const { downloadFile } = useUserDocumentsHook();

  const {
    usersListStore: { getUsers },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();
  const updateUserStatus = useCallback(
    async (user: User, status: UserStatus) => {
      try {
        setLoading(true);
        await userService.updateUser(user.id, { status });
        await getUsers(user.organizationId);
      } catch (e) {
        requestErrorHandler({ error: e, setError: setRequestError });
      } finally {
        setLoading(false);
      }
    },
    [getUsers, requestErrorHandler],
  );
  const deactivateUser = useCallback(
    async (user: User) => {
      await updateUserStatus(user, UserStatus.INACTIVE);
      setModalVisible(false);
      setModalContent(<h1>Me</h1>);
      hideModal();
    },
    [hideModal, updateUserStatus],
  );

  const deactivateUserHandler = useCallback(
    async (user: User) => {
      try {
        setModalVisible(true);
        showModal(
          <ConfirmationModal
            onConfirm={async () => {
              deactivateUser(user);
            }}
            onDecline={() => {
              hideModal();
              setModalVisible(false);
            }}
            heading="Deactivating user?"
            description={`Are you sure to deactivate ${user.givenName} ${user.familyName}?`}
            loading={loading}
            confirmText="Deactivate"
            declineText="Cancel"
            isDelete
          />,
        );
      } catch (e) {
        console.log(e);
      } finally {
        setLoading(false);
      }
    },
    [deactivateUser, hideModal, loading, showModal],
  );

  const reactivateUserHandler = useCallback(
    async (user: User) => {
      await updateUserStatus(user, UserStatus.ACTIVE);

      if (!requestError.message && setSuccessMessage) {
        setSuccessMessage(`${user.givenName} ${user.familyName} is reactivated.`);

        setTimeout(() => setSuccessMessage(undefined), 2000);
      }
    },
    [requestError.message, setSuccessMessage, updateUserStatus],
  );

  const profileViewHandler = useCallback(
    async (user: User) => {
      const documents = await fileService.getFiles(user.id);
      showModal(
        <SelectedProfileViewModal
          givenName={user.givenName}
          familyName={user.familyName}
          emailAddress={user.emailAddress}
          jobTitle={user.jobTitle}
          phoneNumber={user.phoneNumber}
          policeRecordCheckCompletedOn={user.policeRecordCheckCompletedOn}
          foipTrainingCompletedOn={user.foipTrainingCompletedOn}
          termsAcceptedOn={user.termsAcceptedOn}
          hideModal={hideModal}
          downloadFile={downloadFile}
          documents={documents}
        />,
      );
    },
    [downloadFile, hideModal, showModal],
  );

  return {
    deactivateUserHandler,
    reactivateUserHandler,
    loading,
    requestError,
    modalContent,
    modalVisible,
    profileViewHandler,
  };
};

export default useUserActivation;
