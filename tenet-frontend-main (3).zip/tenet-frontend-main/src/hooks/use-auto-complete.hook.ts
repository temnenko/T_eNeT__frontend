import { useState, useEffect, useCallback } from 'react';
import { CanadaPostAddressFullAddress, canadaPostService } from '../services/canada-post.service';
import { AddressType } from '../types/client';
import { getEnumValue } from '../utils/enums.util';
import { User } from '../types/user';
import { userService } from '../services/user.service';

export interface Suggestion {
  text: string;
  id: string;
  isCollection: boolean;
}

type UseAutocompleteArgs = {
  onSelectAddress?: (data: CanadaPostAddressFullAddress, type: AddressType) => void;
  onSelectUser?: (data: User) => void;
  onSelectSuggestion?: (id: string) => void;
  subType: string;
  setField: (name: string, value: string) => void;
  suggestionData?: Suggestion[];
};

const useAutocomplete = ({
  onSelectAddress,
  onSelectUser,
  subType,
  setField,
  onSelectSuggestion,
  suggestionData = [],
}: UseAutocompleteArgs) => {
  const [suggestions, setSuggestions] = useState<Suggestion[]>(suggestionData);
  const [isFocused, setIsFocused] = useState<boolean>(false);
  const [isCollection, setIsCollection] = useState<boolean>(false);

  const fetchSuggestions = useCallback(
    async (searchTerm: string, searchId: string = '') => {
      if (onSelectSuggestion && suggestionData) {
        return;
      }

      if (onSelectAddress) {
        const result = await canadaPostService.find(searchTerm, searchId);
        setSuggestions(
          result.data.Items.map((item) => ({
            id: item.Id,
            text: `${item.Text}, ${item.Description}`,
            isCollection: item.Next === 'Find',
          })),
        );
      }

      if (onSelectUser) {
        const users = await userService.getSlimmedUsers({
          givenNameFilter: searchTerm,
          familyNameFilter: searchTerm,
          skipOrganizationFilter: true,
        });
        setSuggestions(
          users.map((user) => ({
            id: user.id,
            text: `${user.givenName} ${user.familyName}`,
            isCollection: false,
          })),
        );
      }
    },
    [onSelectAddress, onSelectSuggestion, onSelectUser, suggestionData],
  );

  const handleInputChange = useCallback(
    (name: string, value: string) => {
      setField(name, value);

      if (!value && !suggestionData.length) {
        setSuggestions([]);
      } else {
        fetchSuggestions(value);
      }
    },
    [fetchSuggestions, setField, suggestionData],
  );

  const handleFocus = useCallback(() => {
    if (suggestionData.length) {
      setSuggestions(suggestionData);
    }

    setIsFocused(true);
  }, [suggestionData]);

  const handleBlur = useCallback(() => {
    setTimeout(() => {
      setIsFocused(false);
    }, 200);
  }, []);

  const handleSelect = useCallback(
    async (suggestion: Suggestion) => {
      if (onSelectSuggestion) {
        onSelectSuggestion(suggestion.id);
        setIsCollection(false);
        return;
      }

      if (suggestion.isCollection) {
        setIsCollection(true);
        fetchSuggestions(suggestion.text, suggestion.id);
        setIsFocused(true);
        return;
      }
      setIsCollection(false);

      if (onSelectAddress) {
        const result = await canadaPostService.retrieve(suggestion.id);
        onSelectAddress(result.data.Items[0], getEnumValue(AddressType, subType)!);
      }

      if (onSelectUser) {
        const result = await userService.getUserById(suggestion.id);
        onSelectUser(result!);
      }
    },
    [onSelectSuggestion, onSelectAddress, onSelectUser, fetchSuggestions, subType],
  );

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (!(event.target instanceof HTMLElement) || !event.target.closest('.autocomplete-container')) {
        setIsFocused(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return {
    suggestions,
    isFocused,
    isCollection,
    handleInputChange,
    handleFocus,
    handleBlur,
    handleSelect,
  };
};

export default useAutocomplete;
