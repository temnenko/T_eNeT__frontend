import { useCallback, useState } from 'react';

const useToastMessage = () => {
  const [message, setMessage] = useState<string | undefined>(undefined);

  const setToastMessage = useCallback((msg: string) => {
    setMessage(msg);

    setTimeout(() => setMessage(undefined), 2000);
  }, []);

  return {
    message,
    setToastMessage,
  };
};

export default useToastMessage;
