import { act, renderHook } from '@testing-library/react';
import { canadaPostService } from '../services/canada-post.service';
import { userService } from '../services/user.service';
import useAutocomplete from './use-auto-complete.hook';
import { AddressType } from '../types/client';

jest.mock('../services/canada-post.service', () => ({
  canadaPostService: {
    find: jest.fn().mockResolvedValue({
      data: { Items: [{ Id: '1', Text: '123 Main St', Description: 'Anytown' }] },
    }),
    retrieve: jest.fn().mockResolvedValue({
      data: { Items: [{ FullAddress: '123 Main St, Anytown' }] },
    }),
    isTokenStillValid: jest.fn().mockReturnValue(true),
  },
}));

jest.mock('../services/user.service', () => ({
  userService: {
    getUsers: jest.fn().mockResolvedValue([]),
    getUserById: jest.fn().mockResolvedValue(null),
  },
}));

describe('useAutocomplete', () => {
  const mockSetAddressStreetField = jest.fn();

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should initialize with correct default states', () => {
    const { result } = renderHook(() =>
      useAutocomplete({
        onSelectAddress: jest.fn(),
        subType: AddressType.MAILING,
        setField: mockSetAddressStreetField,
      }),
    );

    expect(result.current.suggestions).toEqual([]);
    expect(result.current.isFocused).toBe(false);
  });

  it('should handle input change and fetch suggestions', async () => {
    const { result } = renderHook(() =>
      useAutocomplete({
        onSelectAddress: jest.fn(),
        subType: AddressType.MAILING,
        setField: mockSetAddressStreetField,
      }),
    );

    await act(async () => {
      result.current.handleInputChange('input', '123 Main');
    });

    expect(canadaPostService.find).toHaveBeenCalledWith('123 Main', '');
    expect(result.current.suggestions).toEqual([{ id: '1', text: '123 Main St, Anytown', isCollection: false }]);
    expect(mockSetAddressStreetField).toHaveBeenCalledWith('input', '123 Main');
  });

  it('should handle address selection', async () => {
    const onSelectAddressMock = jest.fn();
    const mockAddress = { FullAddress: '123 Main St, Anytown' };
    canadaPostService.retrieve = jest.fn().mockResolvedValue({ data: { Items: [mockAddress] } });
    userService.getUserById = jest.fn().mockResolvedValue(null);

    const { result } = renderHook(() =>
      useAutocomplete({
        onSelectAddress: onSelectAddressMock,
        subType: AddressType.MAILING,
        setField: mockSetAddressStreetField,
      }),
    );

    await act(async () => {
      result.current.handleSelect({ id: '1', text: '123 Main St, Anytown', isCollection: false });
    });

    expect(onSelectAddressMock).toHaveBeenCalledWith(mockAddress, AddressType.MAILING);
  });
});
