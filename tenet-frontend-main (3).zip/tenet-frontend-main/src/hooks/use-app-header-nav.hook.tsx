/* eslint-disable jsx-a11y/anchor-is-valid */
import { useMemo } from 'react';
import { NavLink } from 'react-router-dom';
import { GoAAppHeaderMenu, GoAIcon } from '@abgov/react-components';

import { useStore } from './use-store.hook';
import useLogout from './use-logout.hook';

const useAppHeaderNav = () => {
  const { authStore, permissionStore, userStore } = useStore();
  const { isSuperAdmin, isStandard } = permissionStore;
  const { displayName } = userStore;
  const { isAuthenticated } = authStore;
  const handleLogout = useLogout();

  return useMemo(() => {
    if (isAuthenticated) {
      return (
        <>
          {!isStandard && (
            <>
              <NavLink to="/dashboard" data-testid="a-dashboard">
                Dashboard
              </NavLink>
              <NavLink to="/clients" data-testid="a-clients">
                Clients
              </NavLink>
              <NavLink data-testid="a-organizations" to="/organizations">
                Organizations
              </NavLink>
              <NavLink to="#" data-testid="a-notifications">
                <span className="notification-bell">
                  <GoAIcon size="large" type="notifications" ariaLabel="notifications icon" />
                  <span className="notification-count">1</span>
                </span>
              </NavLink>
            </>
          )}
          <GoAAppHeaderMenu heading={displayName} leadingIcon="person-circle">
            {!isStandard && (
              <NavLink to="/profile" data-testid="a-admin">
                Profile
              </NavLink>
            )}
            {isSuperAdmin && (
              <NavLink to="/goa" data-testid="a-admin">
                GoA user management
              </NavLink>
            )}
            {isSuperAdmin && (
              <NavLink to="/" data-testid="a-admin">
                Admin Panel
              </NavLink>
            )}
            <NavLink to="#" data-testid="a-logout" onClick={handleLogout}>
              Logout
            </NavLink>
          </GoAAppHeaderMenu>
        </>
      );
    }

    return undefined;
  }, [isAuthenticated, isStandard, displayName, isSuperAdmin, handleLogout]);
};

export default useAppHeaderNav;
