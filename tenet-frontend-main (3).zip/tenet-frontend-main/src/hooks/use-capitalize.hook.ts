import { useCallback } from 'react';

const useCapitalize = () => {
  return useCallback((value: string | undefined) => {
    if (!value) {
      return '';
    }

    const trimmed = value.replaceAll('_', ' ').trim();

    return `${trimmed.charAt(0).toUpperCase()}${trimmed.slice(1).toLowerCase()}`;
  }, []);
};

export const useCapitalizeFirstCharOfEveryWord = () => {
  return useCallback((value: string | undefined) => {
    if (!value) {
      return '';
    }

    const word = value.replaceAll('_', ' ').trim().split(' ');
    const newWord = word.map((w) => `${w.charAt(0).toUpperCase()}${w.slice(1).toLowerCase()}`);

    return `${newWord.join(' ')}`;
  }, []);
};

export default useCapitalize;
