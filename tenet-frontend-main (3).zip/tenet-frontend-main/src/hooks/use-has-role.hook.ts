import { useMemo } from 'react';

import { useStore } from './use-store.hook';

const useHasRole = (roles: string[]) => {
  const {
    userStore: { role },
  } = useStore();

  return useMemo(() => roles.includes(role), [role, roles]);
};

export default useHasRole;
