import { useCallback, useMemo } from 'react';
import { format } from 'date-fns';

import { useStore } from './use-store.hook';
import { ClientRow } from '../common/components/clients/clients-list-row';
import { ClientKey } from '../types/client';
import { toIsoDate } from '../utils/date.util';

const useClientRows = () => {
  const {
    clientsListStore: { clients, hasClients, sortData },
  } = useStore();

  return {
    clientRows: useMemo(() => {
      if (hasClients) {
        return clients.map(({ id, clientName, dateOfBirth, sinRecords, tenetNumber }) => (
          <ClientRow
            key={id}
            id={id}
            clientName={clientName}
            dateOfBirth={format(toIsoDate(dateOfBirth), 'dd MMM, yyyy')}
            maskedSin={sinRecords![(sinRecords.length ?? 1) - 1]?.sinNumber?.slice(6)?.padStart(9, '*')}
            tenetNumber={tenetNumber ?? ''}
          />
        ));
      }

      return '';
    }, [hasClients, clients]),
    sortData: useCallback(
      (sortBy: string, sortDir: number) => {
        sortData(sortBy as ClientKey, sortDir);
      },
      [sortData],
    ),
  };
};

export default useClientRows;
