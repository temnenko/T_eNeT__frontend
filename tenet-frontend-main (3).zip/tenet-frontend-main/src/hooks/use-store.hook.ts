import { useContext } from 'react';

import { StoreContext } from '../contexts/store.context';
import RootStore from '../stores/root.store';

export const useStore = (): RootStore => useContext(StoreContext);
