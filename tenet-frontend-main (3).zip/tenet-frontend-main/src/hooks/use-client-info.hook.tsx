import { ReactNode, useEffect, useMemo, useState } from 'react';
import { format } from 'date-fns';

import { useParams } from 'react-router-dom';
import { useStore } from './use-store.hook';
import { UpdateConsentAcknowledgement } from '../common/components/modals/clients/update-consent-acknowledgement';
import PersonalDetailsForm from '../common/components/forms/clients/registration/personal-details-form';
import { DemographicForm } from '../common/components/forms/clients/registration/demographic-form';
import FactorsForm from '../common/components/forms/clients/registration/factors-form';
import { ClientUpdateModal } from '../common/components/forms/clients/update/client-update-modal';
import { FactorsOptions, languageReadable } from '../types/client';
import { humanizeNameType } from '../utils/humanize.util';
import useCapitalize from './use-capitalize.hook';
import { toIsoDate } from '../utils/date.util';

const useClientInfo = () => {
  const [clientUpdated, setClientUpdated] = useState('');
  const {
    clientsStore: { selectedClient: client, getClientById },
  } = useStore();
  const capitalize = useCapitalize();

  const [modalVisible, setModalVisible] = useState(false);
  const [modalContent, setModalContent] = useState<ReactNode>(null);

  const { id: clientId } = useParams<{ id: string }>();

  useEffect(() => {
    if (clientId) {
      getClientById(clientId);
    }
  }, [getClientById, clientId]);

  const hideModal = () => {
    setModalVisible(false);
    setModalContent(null);
  };

  return {
    clientUpdated,
    setClientUpdated,
    modalContent,
    modalVisible,
    clientInfo: useMemo(
      () => [
        {
          title: 'Personal Details',
          updateAction: () => {
            setModalVisible(true);
            setModalContent(
              <ClientUpdateModal title="Update Personal Details" hideModal={hideModal}>
                <PersonalDetailsForm
                  isModal
                  clientId={clientId}
                  setClientUpdated={(value: string) => setClientUpdated(value)}
                  hideModal={hideModal}
                />
              </ClientUpdateModal>,
            );
          },
          data: [
            ...(client?.previousName
              ? [
                  {
                    label: 'Other names',
                    value:
                      `${client.previousName.firstName} ${client.previousName.middleName ?? ''} ${client.previousName.lastName ?? ''} - (${humanizeNameType(client.previousName.type!)})`.trim(),
                  },
                ]
              : []),
            {
              label: 'First name',
              value: client?.firstName ?? '[Homer]',
            },
            {
              label: 'Middle name',
              value: client?.middleName ?? ' ',
            },
            {
              label: 'Last name',
              value: client?.lastName ?? '[Simpson]',
            },
            {
              label: 'DOB',
              value: client?.dateOfBirth ? format(toIsoDate(client.dateOfBirth), 'MMM dd, yyyy') : '[May 12, 1956]',
            },
            {
              label: 'SIN',
              value: client?.sinRecords[(client?.sinRecords.length ?? 1) - 1]?.sinNumber ?? '[******789]',
            },
            {
              label: 'Preferred official language',
              value: client?.language ? languageReadable[client.language] : '[English]',
            },
          ],
        },
        {
          title: 'Demographics',
          updateAction: () => {
            setModalVisible(true);
            setModalContent(
              <ClientUpdateModal title="Update Demographics" hideModal={hideModal}>
                <DemographicForm
                  isUpdate
                  clientId={clientId}
                  setClientUpdated={(value: string) => setClientUpdated(value)}
                  hideModal={hideModal}
                />
              </ClientUpdateModal>,
            );
          },
          data: [
            {
              label: 'Status',
              value: capitalize(client?.demographic?.statusInCanada) ?? '[Canadian Citizen]',
            },
            {
              label: 'Gender',
              value: capitalize(client?.demographic?.gender) ?? '[Male]',
            },
            {
              label: 'Marital status',
              value: capitalize(client?.demographic?.maritalStatus) ?? '[Married]',
            },
            {
              label: 'Dependents',
              value: client?.demographic?.numberOfDependents ?? '[0]',
            },
          ],
          secondary: [
            {
              label: 'Effective date',
              value: client?.demographic?.statusEffectiveDate
                ? format(toIsoDate(client.demographic.statusEffectiveDate), 'dd MMM, yyyy')
                : '',
            },
          ],
        },
        {
          title: 'Factors',
          updateAction: () => {
            setModalVisible(true);
            setModalContent(
              <ClientUpdateModal title="Update Factors" hideModal={hideModal}>
                <FactorsForm
                  isUpdate
                  clientId={clientId}
                  setClientUpdated={(value: string) => setClientUpdated(value)}
                  hideModal={hideModal}
                />
              </ClientUpdateModal>,
            );
          },
          data: [
            {
              label: 'Disability',
              value: capitalize(client?.factors?.disability),
            },
            {
              label: 'Immigrant',
              value: capitalize(client?.factors?.immigrant),
            },
            {
              label: 'Indigenous',
              value: capitalize(client?.factors?.indigenous),
            },
            {
              label: 'Visible minority',
              value: capitalize(client?.factors?.visibleMinority),
            },
          ],
          secondary: [
            {
              label: 'Year of landing',
              value: client?.factors?.yearOfLanding ?? '',
            },
            {
              label: client?.factors?.indigenous === FactorsOptions.YES ? 'Indigenous type' : '',
              value:
                client?.factors?.indigenous === FactorsOptions.YES ? capitalize(client?.factors.indigenousType) : '',
            },
          ],
        },
        {
          title: 'Consent and acknowledgement',
          updateAction: () => {
            setModalVisible(true);
            setModalContent(<UpdateConsentAcknowledgement hideModal={hideModal} clientId={clientId} />);
          },
          data: [
            {
              label: 'FOIP consent given',
              value: client?.foipConsentedAt ? format(toIsoDate(client.foipConsentedAt), 'dd MMM, yyyy') : '',
            },
            {
              label: 'WCB Acknowledge given',
              value: client?.wcbAcknowledgedAt ? format(toIsoDate(client.wcbAcknowledgedAt), 'dd MMM, yyyy') : '',
            },
          ],
        },
      ],
      [
        capitalize,
        client?.dateOfBirth,
        client?.demographic?.gender,
        client?.demographic?.maritalStatus,
        client?.demographic?.numberOfDependents,
        client?.demographic?.statusEffectiveDate,
        client?.demographic?.statusInCanada,
        client?.factors?.disability,
        client?.factors?.immigrant,
        client?.factors?.indigenous,
        client?.factors?.indigenousType,
        client?.factors?.visibleMinority,
        client?.factors?.yearOfLanding,
        client?.firstName,
        client?.foipConsentedAt,
        client?.language,
        client?.lastName,
        client?.middleName,
        client?.previousName,
        client?.sinRecords,
        client?.wcbAcknowledgedAt,
        clientId,
      ],
    ),
  };
};

export default useClientInfo;
