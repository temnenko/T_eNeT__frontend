/* eslint-disable jsx-a11y/anchor-is-valid */
import { useMemo } from 'react';
import { GoAIcon, GoASideMenu, GoASideMenuGroup, GoASpacer } from '@abgov/react-components';
import { useNavigate, useParams, NavLink } from 'react-router-dom';

import { useStore } from './use-store.hook';

const useClientSideMenu = () => {
  const {
    authStore: { isAuthenticated },
  } = useStore();
  const { id } = useParams();
  const navigate = useNavigate();

  const getActive = (isActive: boolean) => {
    if (isActive) {
      return { fontWeight: 'bold' };
    }
    return { fontWeight: 'normal' };
  };

  return useMemo(() => {
    if (isAuthenticated) {
      return (
        <section className="side-menu-section">
          <NavLink className="client-back-link" to="#" onClick={() => navigate('/clients')}>
            <span>
              <GoAIcon type="chevron-back" />
            </span>
            Back to Home
          </NavLink>
          <GoASpacer vSpacing="l" />
          <GoASideMenu>
            <GoASideMenuGroup heading="Client profile">
              <NavLink to={`/clients/${id}/overview`} style={({ isActive }) => getActive(isActive)}>
                Overview
              </NavLink>
              <NavLink
                data-testid="a-contact"
                to={`/clients/${id}/contact`}
                style={({ isActive }) => getActive(isActive)}
              >
                Contact
              </NavLink>
              <NavLink data-testid="a-lmda" to={`/clients/${id}/lmda`} style={({ isActive }) => getActive(isActive)}>
                LMDA verification
              </NavLink>
              <NavLink
                data-testid="a-employment"
                to={`/clients/${id}/employments`}
                style={({ isActive }) => getActive(isActive)}
              >
                Employment
              </NavLink>
              <NavLink
                data-testid="a-education"
                to={`/clients/${id}/educations`}
                style={({ isActive }) => getActive(isActive)}
              >
                Education
              </NavLink>
            </GoASideMenuGroup>
            <NavLink
              data-testid="a-assessments"
              to={`/clients/${id}/all-assessments`}
              style={({ isActive }) => getActive(isActive)}
            >
              Assessments
            </NavLink>
            <NavLink
              data-testid="a-plans"
              to={`/clients/${id}/service-plans`}
              style={({ isActive }) => getActive(isActive)}
            >
              Service plans
            </NavLink>
            <NavLink
              data-testid="a-documents"
              to={`/clients/${id}/documents`}
              style={({ isActive }) => getActive(isActive)}
            >
              Documents
            </NavLink>
            <NavLink data-testid="a-notes" to={`/clients/${id}/notes`} style={({ isActive }) => getActive(isActive)}>
              Notes
            </NavLink>
            <NavLink
              data-testid="a-history"
              to={`/clients/${id}/history`}
              style={({ isActive }) => getActive(isActive)}
            >
              History
            </NavLink>
          </GoASideMenu>
        </section>
      );
    }

    return '';
  }, [isAuthenticated, id, navigate]);
};

export default useClientSideMenu;
