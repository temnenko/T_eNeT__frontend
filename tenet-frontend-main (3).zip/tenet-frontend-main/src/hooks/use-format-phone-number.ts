import { useCallback } from 'react';
import { formatPhoneNumber as formatPhone } from 'react-phone-number-input';

export const useFormatPhoneNumber = () => {
  return useCallback((phoneNumber: string | undefined) => {
    if (!phoneNumber) {
      return '';
    }

    const rawPhoneNumberValue = phoneNumber.length > 10 ? phoneNumber : `+1${phoneNumber}`;
    const formattedPhoneNumber = formatPhone(rawPhoneNumberValue);

    return formattedPhoneNumber;
  }, []);
};
