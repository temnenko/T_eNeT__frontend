import { ReactNode, useCallback, useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { format } from 'date-fns';
import { GoAButton, GoAButtonGroup, GoAModal } from '@abgov/react-components';
import { useStore } from './use-store.hook';
import useRequestErrorHandler from './use-request-error-handler.hook';
import { RequestError } from '../types/errors/errors';
import { toIsoDate } from '../utils/date.util';

const useSubscriptionForLmdaMonitoring = () => {
  const {
    clientsStore: {
      lmdaSubscription,
      getUserLmdaSubscriptions,
      subscribeToLmdaVerification,
      unsubscribeLmdaMonitoring,
      selectedClient,
      updateLmdaSubsciptionDate,
    },
  } = useStore();
  const { id: clientId } = useParams<{ id: string }>();
  const requestErrorHandler = useRequestErrorHandler();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<RequestError>({});
  const [subscriptionStopDate, setSubscriptionDate] = useState<string | undefined>(undefined);
  const [subscriptionModalVisible, setModalVisible] = useState(false);
  const [subscriptionModalContent, setModalContent] = useState<ReactNode>(null);
  const [showSubscriptionDatePicker, setShowSubscriptionDatePicker] = useState(true);

  const formatDate = (dateString?: string | number | Date) => {
    return dateString && format(toIsoDate(dateString), 'MMMM dd, yyyy');
  };

  useEffect(() => {
    if (clientId && !lmdaSubscription) {
      getUserLmdaSubscriptions(clientId);
      setShowSubscriptionDatePicker(false);
    }
  }, [clientId, getUserLmdaSubscriptions, lmdaSubscription]);

  const monitorLMDAVerification = useCallback(async () => {
    try {
      setError({});
      setLoading(true);
      if (subscriptionStopDate && clientId && selectedClient?.sinRecords?.length) {
        if (!lmdaSubscription) {
          const res = await subscribeToLmdaVerification(
            clientId,
            selectedClient.sinRecords[selectedClient.sinRecords.length - 1].id,
            new Date(subscriptionStopDate),
          );
          setShowSubscriptionDatePicker(false);
          // eslint-disable-next-line no-console
          console.log(res);
        } else {
          const res = await updateLmdaSubsciptionDate(lmdaSubscription?.id, new Date(subscriptionStopDate));
          setShowSubscriptionDatePicker(false);
          // eslint-disable-next-line no-console
          console.log(res);
        }
      }
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError,
      });
      // eslint-disable-next-line no-console
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [
    subscriptionStopDate,
    clientId,
    selectedClient?.sinRecords,
    lmdaSubscription,
    subscribeToLmdaVerification,
    updateLmdaSubsciptionDate,
    requestErrorHandler,
  ]);

  const unsubscribeLmdaSubscription = async () => {
    setModalVisible(true);
    setModalContent(
      <GoAModal heading="Unsubscribe system monitor" maxWidth="500px" open>
        <p className="client-font-with-margin">Stop monitoring client’s LMDA verification?</p>
        <GoAButtonGroup alignment="end" mt="l">
          <GoAButton
            type="secondary"
            leadingIcon="remove-circle"
            onClick={() => {
              if (lmdaSubscription) {
                unsubscribeLmdaMonitoring(lmdaSubscription?.id);
              }
              setModalContent(null);
              setModalVisible(false);
              setShowSubscriptionDatePicker(false);
              setSubscriptionDate(undefined);
            }}
          >
            Unsubscribe
          </GoAButton>
          <GoAButton
            onClick={() => {
              setModalContent(null);
              setModalVisible(false);
            }}
          >
            Keep monitoring
          </GoAButton>
        </GoAButtonGroup>
      </GoAModal>,
    );
  };

  return {
    loading,
    error,
    monitorLMDAVerification,
    setSubscriptionDate,
    subscriptionStopDate,
    lmdaSubscription,
    unsubscribeLmdaSubscription,
    subscriptionModalContent,
    subscriptionModalVisible,
    formatDate,
    showSubscriptionDatePicker,
    setShowSubscriptionDatePicker,
  };
};

export default useSubscriptionForLmdaMonitoring;
