import { useEffect } from 'react';
import { useParams } from 'react-router-dom';

import { useStore } from './use-store.hook';

const useFetchSelectedClient = () => {
  const { clientsStore } = useStore();
  const { id } = useParams();

  useEffect(() => {
    const loadClient = async () => {
      if (id) {
        await clientsStore.getClientById(id);
      }
    };

    loadClient();
  }, [id, clientsStore]);

  return {
    client: clientsStore.selectedClient,
  };
};

export default useFetchSelectedClient;
