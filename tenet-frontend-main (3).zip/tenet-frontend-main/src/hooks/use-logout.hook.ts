import { useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

import { useStore } from './use-store.hook';

const useLogout = () => {
  const {
    userStore: { logout },
  } = useStore();
  const navigate = useNavigate();

  return useCallback(
    () =>
      logout().finally(() => {
        navigate('/login');
      }),
    [logout, navigate],
  );
};

export default useLogout;
