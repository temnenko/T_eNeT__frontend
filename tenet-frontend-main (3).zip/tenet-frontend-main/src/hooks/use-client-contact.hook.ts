import { useEffect, useMemo, useState } from 'react';

import { useStore } from './use-store.hook';
import { AddressType, EmailAddress, Phone } from '../types/client';
import { useFormatPhoneNumber } from './use-format-phone-number';

const useClientContact = () => {
  const formatPhoneNumber = useFormatPhoneNumber();
  const {
    clientsStore: { selectedClient },
  } = useStore();

  const [phones, setPhones] = useState<Phone[]>([]);
  const [emailAddresses, setEmailAddresses] = useState<EmailAddress[]>([]);

  useEffect(() => {
    if (selectedClient) {
      setPhones(selectedClient.phones || []);
      setEmailAddresses(selectedClient.emailAddresses || []);
    }
  }, [selectedClient?.phones, selectedClient?.emailAddresses, selectedClient]);

  const addresses = selectedClient?.addresses;
  const address = addresses?.find((entry) => entry.addressType === AddressType.BOTH);
  const mailingAddress = addresses?.find((entry) => entry.addressType === AddressType.MAILING) || address;
  const residentialAddress = addresses?.find((entry) => entry.addressType === AddressType.RESIDENTIAL) || address;

  const buildPhoneData = useMemo(() => {
    return phones.map((phone, index) => ({
      label: `Phone ${index ? index + 1 : ''}`,
      value: formatPhoneNumber(phone.phoneNumber) || phone.phoneNumber,
    }));
  }, [formatPhoneNumber, phones]);

  const buildEmailData = useMemo(() => {
    return emailAddresses.map((email, index) => ({
      label: `Email ${index ? index + 1 : ''}`,
      value: email.emailAddress,
    }));
  }, [emailAddresses]);

  const data = useMemo(() => {
    return [
      {
        title: 'Contact information',
        data: [
          {
            label: 'Mailing',
            value: mailingAddress?.street
              ? `${mailingAddress.street}, ${mailingAddress.city}, ${mailingAddress.province} ${mailingAddress.postalCode}`
              : '',
          },
          {
            label: 'Residential',
            value: residentialAddress?.street
              ? `${residentialAddress.street}, ${residentialAddress.city}, ${residentialAddress.province} ${residentialAddress.postalCode}`
              : '',
          },
          ...buildPhoneData,
          ...buildEmailData,
        ],
      },
    ];
  }, [buildPhoneData, buildEmailData, mailingAddress, residentialAddress]);

  return data;
};

export default useClientContact;
