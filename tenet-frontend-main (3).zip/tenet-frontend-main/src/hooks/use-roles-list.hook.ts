import { useMemo } from 'react';
import { useStore } from './use-store.hook';
import { Role, Roles } from '../types/role';

const useRolesItems = (isOrgRender?: boolean) => {
  const {
    rolesStore: { roles },
  } = useStore();

  return useMemo(() => {
    const filteredRoles = !isOrgRender
      ? roles.filter((role) => [Roles.CSC, Roles.SUPER_ADMIN].includes(role.name as Roles))
      : roles.filter((role) => [Roles.PROVIDER_USER, Roles.PROVIDER_SUPERVISOR].includes(role.name as Roles));

    return filteredRoles?.map(
      ({ id, name, description, status }): Role => ({
        id,
        name,
        description,
        status,
      }),
    );
  }, [isOrgRender, roles]);
};

export default useRolesItems;
