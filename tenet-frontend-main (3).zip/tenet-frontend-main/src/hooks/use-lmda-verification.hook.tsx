import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useStore } from './use-store.hook';
import LmdaVerificationRow from '../common/components/clients/lmda/LmdaVerificationRow';

const useLMDAVerificationRows = () => {
  const [isLoading, setIsLoading] = useState(true);

  const {
    clientsStore: {
      getClientLmdaVerificationRecords,
      lmdaVerificationRecords,
      getLmdaListSize,
      currentLmdaListPosition,
    },
  } = useStore();
  const { id: clientId } = useParams<{ id: string }>();

  useEffect(() => {
    const fetchData = async () => {
      await getClientLmdaVerificationRecords(clientId!).finally(() => setIsLoading(false));
    };
    fetchData();
  }, [clientId, getClientLmdaVerificationRecords, getLmdaListSize, currentLmdaListPosition]);

  const rows = useMemo(
    () => lmdaVerificationRecords?.map((record) => <LmdaVerificationRow key={record.id} record={record} />),
    [lmdaVerificationRecords],
  );

  return { rows, isLoading };
};

export default useLMDAVerificationRows;
