import { useCallback, useEffect, useState } from 'react';

import { useStore } from './use-store.hook';

const useFetchSelectedUser = (profileUserId?: string) => {
  const {
    userStore: { sid, selectedUser, getUserById, id: userId },
    userFileStore: { getUserDocuments },
  } = useStore();

  const [isLoading, setIsLoading] = useState(true);

  const getUserProfile = useCallback(
    async (userProfileId: string) => {
      await getUserById(userProfileId).finally(() => setIsLoading(false));
      await getUserDocuments(userProfileId).finally(() => {
        setIsLoading(false);
      });
    },
    [getUserById, getUserDocuments],
  );

  useEffect(() => {
    const loadUser = async () => {
      if (profileUserId) {
        getUserProfile(profileUserId);
      } else if (userId) {
        await getUserProfile(userId);
      } else {
        setIsLoading(false);
      }
    };

    loadUser();
  }, [getUserById, userId, getUserProfile, profileUserId]);

  const user = {
    sid: selectedUser?.sid,
    id: selectedUser?.id,
    familyName: selectedUser?.familyName,
    givenName: selectedUser?.givenName,
    role: selectedUser?.role,
    emailAddress: selectedUser?.emailAddress,
    jobTitle: selectedUser?.jobTitle,
    organizationName: selectedUser?.organization?.operatingName,
    status: selectedUser?.status,
    type: selectedUser?.type,
    phoneNumber: selectedUser?.phoneNumber,
    policeRecordCheckCompletedOn: selectedUser?.policeRecordCheckCompletedOn,
    foipTrainingCompletedOn: selectedUser?.foipTrainingCompletedOn,
    termsAcceptedOn: selectedUser?.termsAcceptedOn,
  };

  return { user, currentUserSid: sid, isLoading };
};

export default useFetchSelectedUser;
