import { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { RequestError } from '../types/errors/errors';
import { useStore } from './use-store.hook';
import useRequestErrorHandler from './use-request-error-handler.hook';
import { useModal } from './use-modal.hook';

type ProfileModalFieldName = 'givenName' | 'familyName' | 'emailAddress' | 'phoneNumber' | 'jobTitle';

type ProfileModalData = {
  givenName: string;
  familyName: string;
  emailAddress: string;
  jobTitle: string;
  phoneNumber: string;
};

export const useUpdateProfile = () => {
  const [requestError, setRequestError] = useState<RequestError>({});
  const {
    userStore: { selectedUser, updateUser },
  } = useStore();
  const requestErrorHandler = useRequestErrorHandler();
  const [loading, setLoading] = useState(false);
  const { hideModal } = useModal();

  const {
    getValues,
    handleSubmit,
    register,
    reset,
    setValue,
    watch,
    formState: { errors },
  } = useForm<ProfileModalData>();

  useEffect(() => {
    reset({
      givenName: selectedUser?.givenName,
      familyName: selectedUser?.familyName,
      emailAddress: selectedUser?.emailAddress,
      phoneNumber: selectedUser?.phoneNumber,
      jobTitle: selectedUser?.jobTitle,
    });
  }, [
    reset,
    selectedUser?.emailAddress,
    selectedUser?.familyName,
    selectedUser?.givenName,
    selectedUser?.jobTitle,
    selectedUser?.phoneNumber,
  ]);

  const { name: givenName } = register('givenName', {
    required: { value: true, message: 'First name is required!' },
  });

  const { name: familyName } = register('familyName', {
    required: { value: true, message: 'Last name is required!' },
  });

  const { name: phoneNumber } = register('phoneNumber', {
    required: { value: true, message: 'Phone number is required!' },
    pattern: {
      value: /^\(?\d{3}\)?([\s])?\d{3}([-])?\d{4}$/,
      message: 'Invalid Canadian phone number',
    },
  });

  const { name: jobTitle } = register('jobTitle', {
    required: { value: true, message: 'Job title is required!' },
  });

  const { name: emailAddress } = register('emailAddress', {
    required: { value: true, message: 'Email address is required!' },
    pattern: { value: /^\S+@\S+\.\S+$/, message: 'Invalid email address' },
  });

  const formsFields = {
    givenName,
    familyName,
    emailAddress,
    jobTitle,
    phoneNumber,
  };

  const userProfileSubmitHandler = useCallback(async () => {
    const rawPhoneNumber = getValues('phoneNumber').replace(/\D/g, '')?.trim();

    const data = {
      phoneNumber: rawPhoneNumber,
      jobTitle: getValues('jobTitle'),
    };
    setLoading(true);
    try {
      await updateUser(selectedUser!.id!, data);
      setLoading(false);
      hideModal();
    } catch (e) {
      requestErrorHandler({
        error: e,
        setError: setRequestError,
      });
    } finally {
      setLoading(false);
    }
  }, [getValues, hideModal, requestErrorHandler, selectedUser, updateUser]);

  const onChangeHandler = useCallback(
    (name: string, value: string) => {
      setValue(name as ProfileModalFieldName, value);
    },
    [setValue],
  );

  return {
    formsFields,
    errors,
    loading,
    onChangeHandler,
    requestError,
    userProfileSubmitHandler,
    handleSubmit,
    getValues,
    watch,
  };
};
