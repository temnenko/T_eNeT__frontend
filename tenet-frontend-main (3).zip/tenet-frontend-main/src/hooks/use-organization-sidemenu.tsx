import { useCallback, useMemo } from 'react';
import { GoAIcon, GoASideMenu, GoASpacer } from '@abgov/react-components';
import { useNavigate, useParams, NavLink, useLocation } from 'react-router-dom';

import { useStore } from './use-store.hook';

const useOrganizationSideMenu = () => {
  const {
    authStore: { isAuthenticated },
  } = useStore();
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const profileLink = `/organizations/${id}`;

  const getActive = useCallback((isActive: boolean) => {
    if (isActive) {
      return { fontWeight: 'bold' };
    }
    return { fontWeight: 'normal' };
  }, []);

  const getProfileActive = useCallback(
    (isActive: boolean) => {
      if (location.pathname === profileLink && isActive) {
        return { fontWeight: 'bold' };
      }
      return { fontWeight: 'normal' };
    },
    [location.pathname, profileLink],
  );

  return useMemo(() => {
    if (isAuthenticated) {
      return (
        <section className="org-side-menu-section">
          <NavLink className="organization-back-link" to="#" onClick={() => navigate('/organizations')}>
            <span>
              <GoAIcon type="chevron-back" />
            </span>
            Organization directory
          </NavLink>
          <GoASpacer vSpacing="2xl" />
          <div className="organization-side-menu">
            <GoASideMenu>
              <NavLink data-testid="a-orgProfile" to={profileLink} style={({ isActive }) => getProfileActive(isActive)}>
                Organization Profile
              </NavLink>
              <NavLink
                data-testid="a-contracts"
                to={`/organizations/${id}/agreements`}
                style={({ isActive }) => getActive(isActive)}
              >
                Agreements
              </NavLink>
              <NavLink
                data-testid="a-userManagement"
                to={`/organizations/${id}/user-management`}
                style={({ isActive }) => getActive(isActive)}
              >
                User management
              </NavLink>
              <NavLink
                data-testid="a-locations"
                to={`/organizations/${id}/locations`}
                style={({ isActive }) => getActive(isActive)}
              >
                Office Locations
              </NavLink>
              <NavLink
                data-testid="a-compliance"
                to={`/organizations/${id}/compliance`}
                style={({ isActive }) => getActive(isActive)}
              >
                Compliance management
              </NavLink>
            </GoASideMenu>
          </div>
        </section>
      );
    }

    return '';
  }, [isAuthenticated, profileLink, id, navigate, getProfileActive, getActive]);
};

export default useOrganizationSideMenu;
