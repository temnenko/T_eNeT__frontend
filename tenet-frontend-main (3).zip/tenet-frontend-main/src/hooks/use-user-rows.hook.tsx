import { useCallback, useEffect, useMemo } from 'react';

import { useStore } from './use-store.hook';
import { UserRow } from '../common/components/users/user-row';
import { UserRoleList } from '../common/components/users/user-role-list';
import useCapitalize from './use-capitalize.hook';
import { User } from '../types/user';
import useUserActivation from './users/use-user-activation.hook';

type UserKey = 'givenName' | 'familyName' | 'status';

const useUserRows = (
  orgName: string,
  isOrgRender?: boolean,
  allowAssignUsers?: boolean,
  setSuccessMessage?: React.Dispatch<React.SetStateAction<string | undefined>>,
) => {
  const {
    usersListStore: { users, setUsers, hasUsers },
    rolesStore: { hasRoles, getAllRoles },
  } = useStore();
  const capitalize = useCapitalize();

  useEffect(() => {
    if (!hasRoles) {
      getAllRoles();
    }
  }, [hasRoles, getAllRoles]);

  const sortData = useCallback(
    (sortBy: UserKey, sortDir: number) => {
      const sortedUsers = [...users];
      sortedUsers.sort((a: User, b: User) => {
        return (a[sortBy] > b[sortBy] ? 1 : -1) * sortDir;
      });

      setUsers(sortedUsers);
    },
    [setUsers, users],
  );

  const { reactivateUserHandler, deactivateUserHandler, profileViewHandler } = useUserActivation(setSuccessMessage);

  return {
    userRows: useMemo(() => {
      if (hasUsers) {
        return users?.map((user) => {
          const {
            id,
            status,
            givenName,
            familyName,
            emailAddress,
            roleObj,
            changeLog: log,
            accessRequestReviewedById,
          } = user;
          return (
            <UserRow
              key={id}
              id={id}
              status={status}
              organizationName={orgName}
              givenName={givenName}
              familyName={familyName}
              emailAddress={emailAddress}
              currentRole={capitalize(roleObj?.name?.replaceAll('_', ' '))}
              allowAssignUsers={allowAssignUsers}
              userRoleList={
                <UserRoleList
                  isOrgRender={isOrgRender}
                  roleObj={roleObj}
                  userId={id}
                  givenName={givenName}
                  familyName={familyName}
                  changedAt={log?.length ? log[log.length - 1]?.changedAt : ''}
                />
              }
              accessRequestReviewedById={accessRequestReviewedById}
              isOrgRender={!!isOrgRender}
              reactivateHandler={() => reactivateUserHandler(user)}
              deactivateHandler={() => deactivateUserHandler(user)}
              profileViewHandler={() => profileViewHandler(user)}
            />
          );
        });
      }

      return '';
    }, [
      allowAssignUsers,
      capitalize,
      deactivateUserHandler,
      hasUsers,
      isOrgRender,
      orgName,
      profileViewHandler,
      reactivateUserHandler,
      users,
    ]),
    sortUsersData: useCallback(
      (sortBy: string, sortDir: number) => {
        sortData(sortBy as UserKey, sortDir);
      },
      [sortData],
    ),
  };
};

export default useUserRows;
