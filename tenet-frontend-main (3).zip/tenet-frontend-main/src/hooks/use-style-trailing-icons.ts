/* eslint-disable no-param-reassign */
import { useEffect } from 'react';

export const useStyleTrailingIcons = (color: string, containerSelector: string) => {
  useEffect(() => {
    const applyStylesToIcons = (icons: NodeListOf<HTMLElement>) => {
      icons.forEach((icon) => {
        if (icon instanceof HTMLElement) {
          icon.style.color = color;
        }
      });
    };

    const findAndStyleIcons = (root: ShadowRoot | Document) => {
      const icons = root.querySelectorAll('.trailing-icon');
      applyStylesToIcons(icons as NodeListOf<HTMLElement>);
    };

    const observeShadowRoots = (element: Element) => {
      if (element.shadowRoot) {
        findAndStyleIcons(element.shadowRoot);

        const obs = new MutationObserver((mutations) => {
          mutations.forEach((mutation) => {
            if (mutation.type === 'childList') {
              findAndStyleIcons(mutation.target as ShadowRoot);
            }
          });
        });

        obs.observe(element.shadowRoot, { childList: true, subtree: true });
      }
    };

    const container = document.querySelector(`.${containerSelector}`);
    if (container) {
      const obs = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
          if (mutation.type === 'childList') {
            (mutation.target as ShadowRoot).querySelectorAll('*').forEach((element) => {
              observeShadowRoots(element);
            });
          }
        });
      });

      container.querySelectorAll('*').forEach((element) => {
        observeShadowRoots(element);
      });

      obs.observe(container, { childList: true, subtree: true });
    }
  }, [color, containerSelector]);
};
