import { useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import useLogout from './use-logout.hook';

const defaultInMinutes = 30;

export const useAutoLogout = () => {
  const logoutTime = defaultInMinutes * 60 * 1000;
  const navigate = useNavigate();
  const handleLogout = useLogout();

  const timerRef = useRef<number | null>(null);

  const doLogout = useCallback(() => {
    handleLogout();

    navigate('/login');
  }, [handleLogout, navigate]);

  const resetTimer = useCallback(() => {
    if (timerRef.current) {
      window.clearTimeout(timerRef.current);
    }

    timerRef.current = window.setTimeout(() => {
      doLogout();
    }, logoutTime);
  }, [doLogout, logoutTime]);

  useEffect(() => {
    const activityEvents = ['mousemove', 'keydown', 'scroll', 'touchstart'];

    const handleActivity = () => {
      resetTimer();
    };

    activityEvents.forEach((event) => {
      window.addEventListener(event, handleActivity);
    });

    resetTimer();

    // cleanup on unmount
    return () => {
      activityEvents.forEach((event) => {
        window.removeEventListener(event, handleActivity);
      });
      if (timerRef.current) {
        window.clearTimeout(timerRef.current);
      }
    };
  }, [resetTimer]);
  return null;
};
