import { useCallback, useMemo } from 'react';
import { useStore } from './use-store.hook';

import { ListPagination } from '../common/components/list-pagination';

const useClientsListPagination = () => {
  const {
    clientsListStore: { setCurrentListPosition, setListSize, getListSize, currentListPosition, totalCount },
  } = useStore();

  const changePerPageSize = useCallback(
    (_name: string, value: string | string[]) => {
      const newSize = Array.isArray(value) ? value[0] : value;

      setListSize(Number.parseInt(newSize, 10));
    },
    [setListSize],
  );

  return useMemo(() => {
    const actualPageSize = totalCount < getListSize ? totalCount : getListSize;
    return (
      <ListPagination
        perPageSize={getListSize}
        actualPageSize={actualPageSize}
        perPageSizeOptions={[15, 50]}
        changePerPageSize={changePerPageSize}
        pagePosition={currentListPosition}
        changePagePosition={setCurrentListPosition}
        totalCount={totalCount}
      />
    );
  }, [getListSize, changePerPageSize, currentListPosition, setCurrentListPosition, totalCount]);
};

export default useClientsListPagination;
