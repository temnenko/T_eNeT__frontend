import { GoAButton } from '@abgov/react-components';

const useActionButton = (navigateAction: () => void, label: string = 'Edit') => {
  return (
    <GoAButton type="tertiary" size="compact" onClick={navigateAction} disabled={false}>
      <span className="section-edit-button">{label}</span>
    </GoAButton>
  );
};

export default useActionButton;
