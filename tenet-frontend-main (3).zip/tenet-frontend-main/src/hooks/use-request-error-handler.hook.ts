import { AxiosError } from 'axios';
import { useCallback } from 'react';
import { RequestError } from '../types/errors/errors';

interface RequestErrorHandlerArgs {
  error: unknown;
  setError: React.Dispatch<React.SetStateAction<RequestError>>;
}

const useRequestErrorHandler = () =>
  useCallback(({ error, setError }: RequestErrorHandlerArgs) => {
    let errorCode: number | undefined;
    let errorMessage: string | undefined;

    if (error instanceof AxiosError) {
      errorCode = error.response?.status;
      errorMessage = error.response?.data?.error?.message ?? error.response?.data?.message ?? error.message;
    }

    if (errorCode && errorMessage) {
      const isUserError = errorCode < 500;

      setError({
        isUserError,
        isSystemError: !isUserError,
        message: errorMessage,
        onDismiss: () => setError({}),
      });
    }
  }, []);

export default useRequestErrorHandler;
