/* eslint-disable class-methods-use-this */
import { CreateNote, GetNotes, Note, NoteList, UpdateNote } from '../types/note';
import apiClient from './api-client.service';

class NoteService {
  public async getByRecordId(recordId: string): Promise<Note[]> {
    const response = await apiClient.get<Note[]>(`/notes/${recordId}`);

    return response.data;
  }

  public async create(payload: CreateNote): Promise<Note> {
    const response = await apiClient.post<Note>(`/notes`, payload);

    return response.data;
  }

  public async update(id: string, payload: UpdateNote): Promise<Note> {
    const response = await apiClient.put<Note>(`/notes/${id}`, payload);

    return response.data;
  }

  async getNotesAsList(recordId: string, params?: GetNotes): Promise<NoteList> {
    let queryParams = params?.sortOrder ? `?sortOrder=${params.sortOrder}` : '';
    queryParams += params?.batchSize ? `&batchSize=${params.batchSize}` : '';
    queryParams += params?.skipCount ? `&skipCount=${params.skipCount}` : '';

    const notes = await apiClient.get(`/notes/${recordId}/list${queryParams}`);
    return notes.data;
  }
}

export const noteService = new NoteService();
