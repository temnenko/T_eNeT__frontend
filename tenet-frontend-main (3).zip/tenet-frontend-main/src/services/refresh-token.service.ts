import axios from 'axios';
import { RefreshResponse } from '../types/responses/login-response';
import { appEventService } from './app-events.service';

class RefreshTokenService {
  /* eslint-disable class-methods-use-this */
  public refreshToken = async (apiBaseUrl: string): Promise<RefreshResponse> => {
    const auth = JSON.parse(sessionStorage.getItem('tenet-auth-token') ?? '');
    const response = await axios.get(`${apiBaseUrl}/auth/refresh?refreshToken=${auth.refreshToken}`);
    const newAuth = response.data;
    sessionStorage.setItem(
      'tenet-auth-token',
      JSON.stringify({
        accessToken: newAuth.accessToken,
        refreshToken: newAuth.refreshToken,
        expiresAt: newAuth.expiresAt,
        expiresIn: newAuth.expiresIn,
      }),
    );
    appEventService.emitTokensUpdated(newAuth);
    return newAuth;
  };
}

export const refreshTokenService = new RefreshTokenService();
