import apiClient, { apiAddressClientProxy } from './api-client.service';

export interface CanadaPostSuggestedAddress {
  Id: string;
  Text: string;
  Highlight: string;
  Cursor: number;
  Description: string;
  Next: string;
}

export interface CanadaPostAddressFullAddress {
  Id: string;
  DomesticId: number;
  LanguageAlternatives: string;
  Language: string;
  Department: string;
  Company: string;
  SubBuilding: string;
  BuildingNumber: string;
  BuildingName: string;
  SecondaryStreet: string;
  Street: string;
  Block: string;
  Neighbourhood: string;
  District: string;
  City: string;
  Line1: string;
  Line2: string;
  Line3: string;
  Line4: string;
  Line5: string;
  AdminAreaName: string;
  AdminAreaCode: string;
  Province: string;
  ProvinceName: string;
  ProvinceCode: string;
  PostalCode: string;
  CountryName: string;
  CountryIso2: string;
  CountryIso3: string;
  CountryIsoNumber: string;
  SortingNumber1: string;
  SortingNumber2: string;
  Barcode: string;
  POBoxNumber: string;
  Label: string;
  search: string;
  Type: string;
  DataLevel: string;
  createDate: string;
  modifiedDate: string;
}

export interface CanadaPostFindResponse {
  Items: CanadaPostSuggestedAddress[];
}

export interface CanadaPostRetrieveResponse {
  Items: CanadaPostAddressFullAddress[];
}

class CanadaPostService {
  token: string = '';

  tokenExpiry: number = 0;

  async find(searchTerm: string, searchId: string = '') {
    const params = new URLSearchParams();
    params.append('languagePreference', 'en');
    params.append('maxSuggestions', '5');
    params.append('searchTerm', searchTerm);
    if (searchId) {
      params.append('lastId', searchId);
    }

    if (!this.isTokenStillValid()) {
      await this.fetchToken();
    }
    return apiAddressClientProxy.get<CanadaPostFindResponse>('/find', {
      headers: {
        Authorization: `Bearer ${this.token}`,
      },
      params,
    });
  }

  async retrieve(id: string) {
    const params = new URLSearchParams();
    params.append('languagePreference', 'en');
    params.append('id', id);

    if (!this.isTokenStillValid()) {
      await this.fetchToken();
    }
    return apiAddressClientProxy.get<CanadaPostRetrieveResponse>('/retrieve', {
      headers: {
        Authorization: `Bearer ${this.token}`,
      },
      params,
    });
  }

  async getToken() {
    if (this.isTokenStillValid()) {
      return this.token;
    }
    return this.fetchToken();
  }

  async fetchToken() {
    const canadaPostToken = await apiClient.get<{ token: string }>(`/canada-post/token`);
    const currentTime = Math.floor(Date.now() / 1000);
    this.token = canadaPostToken.data.token;
    this.tokenExpiry = currentTime + 300;
    return this.token;
  }

  isTokenStillValid() {
    const currentTime = Math.floor(Date.now() / 1000);
    return this.token && this.tokenExpiry - currentTime > 30;
  }
}

export const canadaPostService = new CanadaPostService();
