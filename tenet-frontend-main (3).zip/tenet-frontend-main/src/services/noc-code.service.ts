/* eslint-disable class-methods-use-this */
import apiClient from './api-client.service';

export interface NocOption {
  value: string;
  label: string;
}

class NocCodeService {
  public async find(searchTerm: string): Promise<NocOption[]> {
    const params = new URLSearchParams();
    params.append('query', searchTerm);

    const result = await apiClient.get(`/noc/search`, { params });
    return result.data;
  }
}

export const nocCodeService = new NocCodeService();
