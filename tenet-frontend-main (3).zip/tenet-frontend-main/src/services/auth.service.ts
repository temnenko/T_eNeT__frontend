/* eslint-disable class-methods-use-this */
import { LoginResponse } from '../types/responses/login-response';
import { SetAuthInput } from '../types/user';
import { apiClientWithoutInterceptorsProxy } from './api-client.service';

class AuthService {
  async getLoginUrl(idpHint: string): Promise<void> {
    await apiClientWithoutInterceptorsProxy.get(`/auth/start-login?authType=${idpHint}`).then((response) => {
      window.location.href = response.data.loginUrl;
    });
  }

  async logout(): Promise<void> {
    const auth: SetAuthInput = JSON.parse(sessionStorage.getItem('tenet-auth-token') ?? '{}');

    if (auth.accessToken) {
      try {
        await apiClientWithoutInterceptorsProxy.post('/auth/logout', {
          accessToken: auth.accessToken,
          refreshToken: auth.refreshToken,
        });
      } finally {
        sessionStorage.removeItem('tenet-auth-token');
      }
    }
  }

  async exchangeCodeForToken(code: string, state: string): Promise<LoginResponse> {
    return apiClientWithoutInterceptorsProxy
      .get<LoginResponse>(`/auth/login?code=${code}&state=${state}`)
      .then((res) => {
        const loginResponse = res.data;

        sessionStorage.setItem('tenet-user', JSON.stringify(loginResponse.user));
        sessionStorage.setItem('tenet-organization', JSON.stringify(loginResponse.organization));
        sessionStorage.setItem(
          'tenet-auth-token',
          JSON.stringify({
            accessToken: loginResponse.accessToken,
            refreshToken: loginResponse.refreshToken,
            expiresAt: loginResponse.expiresAt,
            expiresIn: loginResponse.expiresIn,
          }),
        );

        return loginResponse;
      });
  }
}

export const authService = new AuthService();
