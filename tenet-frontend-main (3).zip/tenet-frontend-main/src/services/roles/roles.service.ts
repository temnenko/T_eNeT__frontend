/* eslint-disable class-methods-use-this */
import { Role } from '../../types/role';
import apiClient from '../api-client.service';

class RolesService {
  public async getAllRoles(): Promise<Role[]> {
    const roles = await apiClient.get<Role[]>(`/roles`);

    return roles.data;
  }

  public async getRoleById(id: string): Promise<Role | null> {
    const role = await apiClient.get<Role>(`/roles/${id}`);

    return role.data;
  }
}

export const rolesService = new RolesService();
