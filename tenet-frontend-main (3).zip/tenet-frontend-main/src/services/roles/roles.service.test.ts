import { reveal } from 'jest-auto-stub';
import apiClient from '../api-client.service';
import { rolesService } from './roles.service';
import { Role } from '../../types/role';

jest.mock('../api-client.service', () => {
  return {
    __esModule: true,
    default: {
      get: jest.fn(),
    },
  };
});

describe('RoleService', () => {
  describe('getRoleById', () => {
    it('should fetch roles data correctly', async () => {
      const mockRoles: Role = {
        id: '1',
        name: 'can view',
        description: 'Can View Roles',
        status: 'active',
      };

      reveal(apiClient).get.mockResolvedValueOnce({ data: mockRoles });
      const role = await rolesService.getRoleById('1');
      expect(apiClient.get).toHaveBeenCalledWith(`/roles/${role!.id}`);

      expect(role).toEqual(mockRoles);
    });

    it('should handle errors gracefully', async () => {
      (apiClient.get as jest.Mock).mockRejectedValueOnce(new Error('Role not found'));
      expect.assertions(1);

      try {
        await rolesService.getRoleById('ernq499');
      } catch (error) {
        expect(error).toEqual(new Error('Role not found'));
      }
    });
  });

  describe('getAllRoles', () => {
    it('should fetch all roles data correctly', async () => {
      const mockRoles: Role = {
        id: '1',
        name: 'can view',
        description: 'Can View Roles',
        status: 'active',
      };

      reveal(apiClient).get.mockResolvedValueOnce({ data: mockRoles });
      const role = await rolesService.getAllRoles();
      expect(apiClient.get).toHaveBeenCalledWith(`/roles`);

      expect(role).toEqual(mockRoles);
    });
  });
});
