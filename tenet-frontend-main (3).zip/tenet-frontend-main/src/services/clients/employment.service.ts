/* eslint-disable class-methods-use-this */
import { Employment, EmploymentArgs, GetEmploymentsResult, UpdateEmploymentArgs } from '../../types/client';
import apiClient from '../api-client.service';

export interface Emmployment {
  employmentHistory: Employment[];
  metaData: {
    hasNextBatch: boolean;
    totalCount: number;
  };
}

class EmploymentService {
  public async getEmploymentHistory(
    clientId: string,
    archived?: boolean,
    batchSize?: number,
    skipCount?: number,
  ): Promise<GetEmploymentsResult> {
    const clients = await apiClient.get<GetEmploymentsResult>(`/clients/${clientId}/employments`, {
      params: { batchSize, skipCount, archived },
    });

    return clients.data;
  }

  public async getEmploymentHistoryById(id: string, archived?: boolean): Promise<Employment> {
    const client = await apiClient.get<Employment>(`/clients/employments/${id}`, { params: { archived } });

    return this.mapEmployment(client.data);
  }

  public async createEmploymentHistory(clientId: string, args: EmploymentArgs): Promise<Employment> {
    const result = await apiClient.post<Employment>(
      `/clients/${clientId}/employments`,
      {
        ...args,
      },
      { headers: { 'client-id': clientId } },
    );

    return this.mapEmployment(result.data);
  }

  public async updateEmploymentHistory(id: string, args: UpdateEmploymentArgs): Promise<Employment> {
    const result = await apiClient.put<Employment>(`/clients/employments/${id}`, {
      ...args,
    });

    return this.mapEmployment(result.data);
  }

  public async archiveEmployment(id: string, archived: boolean): Promise<Employment> {
    const result = await apiClient.patch<Employment>(`/clients/employments/${id}`, {
      archived,
    });

    return this.mapEmployment(result.data);
  }

  public async hardDeleteEmployment(id: string): Promise<void> {
    await apiClient.delete(`/clients/employments/${id}`);
  }

  protected mapEmployment = (args: Employment): Employment => {
    return {
      ...args,
      createdAt: new Date(args.createdAt),
    };
  };
}

export const employmentService = new EmploymentService();
