import { reveal } from 'jest-auto-stub';
import apiClient from '../api-client.service';
import { Employment, EmploymentArgs, WageFrequencies } from '../../types/client';
import { employmentService } from './employment.service';

jest.mock('../api-client.service', () => {
  return {
    __esModule: true,
    default: {
      get: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      delete: jest.fn(),
    },
  };
});

describe('ClientEmploymentService', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  describe('getEmploymentHistoryById', () => {
    it('should fetch data', async () => {
      const mockEmployments: Employment = {
        id: '1',
        jobTitle: '',
        employerName: '',
        clientId: '1',
        selfEmployed: false,
        noc: '',
        startDate: new Date(12091998),
        numberOfHourPerWeek: 10,
        wageCents: 100,
        wageFrequency: WageFrequencies.HOURLY,
        canHardDelete: false,
        createdAt: new Date(),
      };

      reveal(apiClient).get.mockResolvedValueOnce({ data: mockEmployments });
      const employment = await employmentService.getEmploymentHistoryById('1');

      expect(apiClient.get).toHaveBeenCalledWith(`/clients/employments/${employment.id}`, {
        params: { archived: undefined },
      });

      expect(employment).toEqual(mockEmployments);
    });

    it('should throw error', async () => {
      reveal(apiClient).get.mockRejectedValueOnce(new Error('Employment not found'));

      await expect(employmentService.getEmploymentHistoryById('1')).rejects.toThrow('Employment not found');
    });
  });

  describe('getClientEmploymentHistory', () => {
    it(`should fetch client's employment history`, async () => {
      reveal(apiClient).get.mockResolvedValueOnce({
        data: [],
      });

      const result = await employmentService.getEmploymentHistory('1');

      expect(apiClient.get).toHaveBeenCalledWith(`/clients/1/employments`, { params: { archived: undefined } });
      expect(result).toEqual([]);
    });
  });

  describe('createClientEmmployment', () => {
    it('should create a client with success response', async () => {
      const mockEmployments: Employment = {
        id: '1',
        jobTitle: '',
        employerName: '',
        clientId: '1',
        selfEmployed: false,
        noc: '',
        startDate: new Date(12091998),
        numberOfHourPerWeek: 10,
        wageCents: 100,
        wageFrequency: WageFrequencies.HOURLY,
        canHardDelete: false,
        createdAt: new Date(),
      };

      const mockPayload: EmploymentArgs = {
        jobTitle: mockEmployments.jobTitle,
        employerName: mockEmployments.employerName,
        selfEmployed: mockEmployments.selfEmployed,
        noc: mockEmployments.noc,
        startDate: mockEmployments.startDate,
        numberOfHourPerWeek: mockEmployments.numberOfHourPerWeek,
        wageCents: mockEmployments.wageCents,
        wageFrequency: mockEmployments.wageFrequency,
      };

      reveal(apiClient).post.mockResolvedValueOnce({ data: mockEmployments });

      const employments = await employmentService.createEmploymentHistory('1', mockPayload);

      expect(employments).toEqual(mockEmployments);
    });
  });

  describe('hardDeleteEmployment', () => {
    it('should delete employment with success response', async () => {
      reveal(apiClient).delete.mockResolvedValueOnce({});

      await employmentService.hardDeleteEmployment('1');

      expect(apiClient.delete).toHaveBeenCalledWith(`/clients/employments/1`);
    });
  });
});
