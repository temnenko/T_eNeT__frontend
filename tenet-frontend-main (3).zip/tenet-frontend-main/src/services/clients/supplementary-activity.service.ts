/* eslint-disable class-methods-use-this */
import {
  CreateSupplementaryActivity,
  SupplementaryActivity,
  UpdateSupplementaryActivity,
} from '../../types/service-plan';
import apiClient from '../api-client.service';

class SupplementaryActivityService {
  public async getByServicePlanId({
    clientId,
    servicePlanId,
  }: {
    clientId: string;
    servicePlanId: string;
  }): Promise<SupplementaryActivity[]> {
    const response = await apiClient.get<SupplementaryActivity[]>(
      `/clients/${clientId}/service-plans/${servicePlanId}/supplementary-activities`,
    );

    return response.data;
  }

  public async update({
    id,
    payload,
    clientId,
    servicePlanId,
  }: {
    id: string;
    payload: UpdateSupplementaryActivity;
    clientId: string;
    servicePlanId: string;
  }): Promise<SupplementaryActivity> {
    const response = await apiClient.put<SupplementaryActivity>(
      `/clients/${clientId}/service-plans/${servicePlanId}/supplementary-activities/${id}`,
      payload,
    );

    return response.data;
  }

  public async create({
    payload,
    clientId,
    servicePlanId,
  }: {
    payload: CreateSupplementaryActivity;
    clientId: string;
    servicePlanId: string;
  }): Promise<SupplementaryActivity> {
    const response = await apiClient.post<SupplementaryActivity>(
      `/clients/${clientId}/service-plans/${servicePlanId}/supplementary-activities`,
      payload,
    );

    return response.data;
  }
}

export const supplementaryActivityService = new SupplementaryActivityService();
