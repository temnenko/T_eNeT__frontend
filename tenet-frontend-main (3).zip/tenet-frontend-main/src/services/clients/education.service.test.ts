import { reveal } from 'jest-auto-stub';
import apiClient from '../api-client.service';
import { Education, EducationArgs, LevelOfEducation } from '../../types/client';
import { educationService } from './education.service';

jest.mock('../api-client.service', () => {
  return {
    __esModule: true,
    default: {
      get: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      delete: jest.fn(),
      patch: jest.fn(),
    },
  };
});

describe('EducationService', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  describe('createClientEducation', () => {
    it('should create a client with success response', async () => {
      const mockEducations: Education = {
        id: '1',
        levelOfEducation: LevelOfEducation.COLLEGE_OR_NONUNIVERSITY_CERTIFICATE_OR_DIPLOMA,
        educationalInstitution: '',
        fieldOfStudy: '',
        personAttendingTraining: false,
        startDate: new Date(12091998),
        canHardDelete: false,
        createdAt: new Date(),
        clientId: '',
      };

      const mockPayload: EducationArgs = {
        levelOfEducation: LevelOfEducation.COLLEGE_OR_NONUNIVERSITY_CERTIFICATE_OR_DIPLOMA,
        educationalInstitution: '',
        fieldOfStudy: '',
        personAttendingTraining: false,
        startDate: new Date(),
      };

      reveal(apiClient).post.mockResolvedValueOnce({ data: mockEducations });

      const educations = await educationService.createEducationHistory('1', mockPayload);

      expect(educations).toEqual(mockEducations);
    });
  });

  describe('getEducations', () => {
    it(`should fetch client's education records`, async () => {
      reveal(apiClient).get.mockResolvedValueOnce({
        data: [],
      });

      const result = await educationService.getEducations('1', false, 50, 0);

      expect(apiClient.get).toHaveBeenCalledWith(`/clients/1/educations`, {
        params: { archived: false, batchSize: 50, skipCount: 0 },
      });
      expect(result.educationHistory).toEqual(undefined);
    });
  });

  describe('archiveEducation', () => {
    it('should delegate patch to archive education', async () => {
      reveal(apiClient).patch.mockResolvedValueOnce({ data: { createdAt: new Date().toISOString() } });

      await educationService.archiveEducation('1', true);

      expect(apiClient.patch).toHaveBeenCalledWith(`/clients/educations/1`, { archived: true });
    });
  });

  describe('hardDeleteEducation', () => {
    it('should delete education with success response', async () => {
      reveal(apiClient).delete.mockResolvedValueOnce({});

      await educationService.hardDeleteEducation('1');

      expect(apiClient.delete).toHaveBeenCalledWith(`/clients/educations/1`);
    });
  });

  describe('getEducationHistoryById', () => {
    it('should fetch data', async () => {
      const mockEducations: Education = {
        id: '1',
        levelOfEducation: LevelOfEducation.UNIVERSITY_DEGREE,
        educationalInstitution: '',
        fieldOfStudy: '',
        personAttendingTraining: false,
        startDate: new Date(12091998),
        canHardDelete: false,
        createdAt: new Date(),
        clientId: '',
      };

      reveal(apiClient).get.mockResolvedValueOnce({ data: mockEducations });
      const education = await educationService.getEducationHistoryById('1');

      expect(apiClient.get).toHaveBeenCalledWith(`/clients/educations/${education.id}`, {
        params: { archived: undefined },
      });

      expect(education).toEqual(mockEducations);
    });

    it('should throw error', async () => {
      reveal(apiClient).get.mockRejectedValueOnce(new Error('Education not found'));

      await expect(educationService.getEducationHistoryById('1')).rejects.toThrow('Education not found');
    });
  });
});
