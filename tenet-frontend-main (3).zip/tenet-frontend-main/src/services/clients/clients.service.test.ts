import { reveal } from 'jest-auto-stub';
import apiClient from '../api-client.service';
import {
  Client,
  CreateClientArgs,
  Language,
  AddressType,
  ContactStatus,
  UpdateClientArgs,
  NameType,
} from '../../types/client';
import { clientsService } from './clients.service';

jest.mock('../api-client.service', () => {
  return {
    __esModule: true,
    default: {
      get: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      delete: jest.fn(),
    },
  };
});

describe('ClientsService', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  describe('getById', () => {
    it('should fetch data', async () => {
      const mockClient: Client = {
        id: 'test-id',
        tenetNumber: '81726354',
        firstName: 'John',
        lastName: 'Doe',
        sinRecords: [{ id: '123', sinNumber: '987654321' }],
        language: Language.EN,
        dateOfBirth: '12091998',
        addresses: [],
        phones: [],
        emailAddresses: [],
        creationCompleted: false,
      };

      reveal(apiClient).get.mockResolvedValueOnce({ data: mockClient });
      const client = await clientsService.getById('test-id');
      expect(apiClient.get).toHaveBeenCalledWith(`/clients/${client!.id}`);

      expect(client).toEqual(mockClient);
    });

    it('should throw error', async () => {
      reveal(apiClient).get.mockRejectedValueOnce(new Error('Client not found'));

      await expect(clientsService.getById('test-id')).rejects.toThrow('Client not found');
    });
  });

  describe('deleteById', () => {
    it('should delete client', async () => {
      reveal(apiClient).delete.mockResolvedValueOnce({});

      await clientsService.deleteById('test-id');

      expect(apiClient.delete).toHaveBeenCalledWith(`/clients/test-id`);
    });

    it('should throw error', async () => {
      reveal(apiClient).delete.mockRejectedValueOnce(new Error('Client not found'));

      await expect(clientsService.deleteById('test-id')).rejects.toThrow('Client not found');
    });
  });

  describe('createClient', () => {
    it('should create a client with success response', async () => {
      const mockClient: Client = {
        id: 'test-id',
        tenetNumber: '81726354',
        firstName: 'John',
        lastName: 'Doe',
        sinRecords: [
          { id: '321', sinNumber: '987654321', sinExpiryDate: '2021-09-01', workPermitExpiryDate: '2021-09-01' },
        ],
        language: Language.EN,
        dateOfBirth: '12091998',
        addresses: [],
        phones: [],
        emailAddresses: [],
        previousName: { firstName: 'Jane', lastName: 'Doe', type: NameType.PREVIOUS_NAME },
        creationCompleted: false,
      };
      const mockPayload: CreateClientArgs = {
        firstName: mockClient.firstName,
        lastName: mockClient.lastName,
        sinRecords: mockClient.sinRecords,
        language: mockClient.language,
        dateOfBirth: mockClient.dateOfBirth,
        creationCompleted: mockClient.creationCompleted,
      };

      reveal(apiClient).post.mockResolvedValueOnce({ data: mockClient });

      const client = await clientsService.createClient(mockPayload);

      expect(client).toEqual(mockClient);
    });
  });

  describe('updateClient', () => {
    it('should update a client with success response', async () => {
      const mockClient: Client = {
        id: 'test-id',
        tenetNumber: '81726354',
        firstName: 'John',
        lastName: 'Doe',
        sinRecords: [{ id: '123', sinNumber: '987654321' }],
        language: Language.EN,
        dateOfBirth: '12091998',
        addresses: [],
        phones: [],
        emailAddresses: [],
        foipConsentedAt: new Date().toISOString(),
        wcbAcknowledgedAt: new Date().toISOString(),
        creationCompleted: false,
      };
      const mockPayload: UpdateClientArgs = {
        firstName: mockClient.firstName,
        lastName: mockClient.lastName,
        foipConsentedAt: mockClient.foipConsentedAt,
        wcbAcknowledgedAt: mockClient.wcbAcknowledgedAt,
      };

      reveal(apiClient).put.mockResolvedValueOnce({ data: mockClient });

      const client = await clientsService.updateClient(mockClient.id, mockPayload);

      expect(apiClient.put).toHaveBeenCalledWith(`/clients/${mockClient.id}`, mockPayload);
      expect(client).toEqual(mockClient);
    });
  });

  describe('getClients', () => {
    it('should fetch clients data', async () => {
      reveal(apiClient).get.mockResolvedValueOnce({
        data: {
          clients: [],
          metaData: {
            hasNextBatch: false,
            totalCount: 0,
          },
        },
      });

      const result = await clientsService.getClients();

      expect(apiClient.get).toHaveBeenCalledWith(`/clients`, {
        params: { batchSize: undefined, skipCount: undefined },
      });
      expect(result).toEqual({
        clients: [],
        metaData: {
          hasNextBatch: false,
          totalCount: 0,
        },
      });
    });
  });

  describe('getLmdaVerificationResults', () => {
    it('should fetch LMDA verification records for a client', async () => {
      reveal(apiClient).get.mockResolvedValueOnce({
        data: {
          results: [],
          metaData: {
            hasNextBatch: false,
            totalCount: 0,
          },
        },
      });

      const clientId = 'test-id';

      const result = await clientsService.getClientLmdaVerificationRecords(clientId, 10, 0);

      expect(apiClient.get).toHaveBeenCalledWith(`/clients/test-id/lmda-verifications`, {
        params: {
          batchSize: 10,
          skipCount: 0,
        },
      });
      expect(result).toEqual({
        results: [],
        metaData: {
          hasNextBatch: false,
          totalCount: 0,
        },
      });
    });
  });

  describe('saveClientContactDetails', () => {
    it('should save client contact details', async () => {
      const mockAddresses = [
        {
          street: '123 Test St',
          unit: '123',
          city: 'Test City',
          province: 'Test Province',
          postalCode: 'T3S T1N',
          countryCode: 'Test Country',
          effectiveDate: '2021-09-01',
          addressType: AddressType.MAILING,
        },
      ];
      const mockClient: Client = {
        id: 'test-id',
        tenetNumber: '81726354',
        firstName: 'John',
        lastName: 'Doe',
        sinRecords: [{ id: '123', sinNumber: '987654321' }],
        language: Language.EN,
        dateOfBirth: '12091998',
        addresses: mockAddresses,
        phones: [],
        emailAddresses: [],
        creationCompleted: false,
      };

      reveal(apiClient).put.mockResolvedValueOnce(mockClient);

      await clientsService.saveClientAddresses('test-id', mockAddresses);

      expect(apiClient.put).toHaveBeenCalledWith(`/clients/test-id/addresses`, mockAddresses);

      expect(apiClient.put).toHaveBeenCalledTimes(1);
    });
  });

  describe('saveClientEmailAndPhoneDetails', () => {
    it('should save client email and phone numbers', async () => {
      const mockEmailAddress1 = { emailAddress: 'xyz@mail.com', status: ContactStatus.ACTIVE };
      const mockEmailAddress2 = { emailAddress: 'abc@mail.com', status: ContactStatus.ACTIVE };
      const mockPhoneNumber1 = { phoneNumber: '1234567890', status: ContactStatus.ACTIVE };
      const mockPhoneNumber2 = { phoneNumber: '0987654321', status: ContactStatus.ACTIVE };

      const mockClient: Client = {
        id: 'test-id',
        tenetNumber: '81726354',
        firstName: 'John',
        lastName: 'Doe',
        sinRecords: [{ id: '123', sinNumber: '987654321' }],
        language: Language.EN,
        dateOfBirth: '12091998',
        addresses: [],
        phones: [mockPhoneNumber1, mockPhoneNumber2],
        emailAddresses: [mockEmailAddress1, mockEmailAddress2],
        creationCompleted: false,
      };

      reveal(apiClient).put.mockResolvedValueOnce(mockClient);

      await clientsService.saveClientContactDetails(
        'test-id',
        [mockEmailAddress1, mockEmailAddress2],
        [mockPhoneNumber1, mockPhoneNumber2],
      );

      expect(apiClient.put).toHaveBeenCalledWith(`/clients/test-id/contacts`, {
        emailAddresses: [mockEmailAddress1, mockEmailAddress2],
        phoneNumbers: [mockPhoneNumber1, mockPhoneNumber2],
      });
    });
  });
});
