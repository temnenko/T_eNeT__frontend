/* eslint-disable class-methods-use-this */
import { CreateServicePlan, ServicePlan, UpdateServicePlan, ServicePlanDashboardRow } from '../../types/service-plan';
import apiClient from '../api-client.service';

export interface OrganizationResult {
  servicePlans: ServicePlanDashboardRow[];
  totalCount: number;
}

export type ServicePlansSortableFields =
  | 'status'
  | 'clientName'
  | 'tenetNumber'
  | 'startDate'
  | 'endDate'
  | 'contactDate'
  | 'agreeementName'
  | 'assignee';

export interface ServicePlanFilters {
  agreementIds: string[];
  assigneeIds: string[];
  skipCount: number;
  batchSize: number;
  sortBy?: ServicePlansSortableFields;
  sortOrder?: 'asc' | 'desc';
}

class ServicePlanService {
  public async getByClientId(id: string): Promise<ServicePlan[]> {
    const result = await apiClient.get<ServicePlan[]>(`/clients/${id}/service-plans`);

    return result.data;
  }

  public async closeCase(clientId: string, id: string): Promise<ServicePlan> {
    const result = await apiClient.put<ServicePlan>(`/clients/${clientId}/service-plans/${id}/close`);

    return result.data;
  }

  public async getByClientServiceId(clientId: string, id: string): Promise<ServicePlan> {
    const result = await apiClient.get<ServicePlan>(`/clients/${clientId}/service-plans/${id}`);

    return result.data;
  }

  public async getServicePlansByUserId(clientId: string, userId: string): Promise<ServicePlan[]> {
    const result = await apiClient.get<ServicePlan[]>(`/clients/${clientId}/service-plans/${userId}`);

    return result.data;
  }

  public async getServicePlansByOrganizationId(
    organizationId: string,
    filters: ServicePlanFilters,
  ): Promise<OrganizationResult> {
    const formattedFilters = this.formatFilters(filters);

    const result = await apiClient.get<OrganizationResult>(`/organizations/${organizationId}/service-plans`, {
      params: formattedFilters,
    });

    return result.data;
  }

  public async update(id: string, clientId: string, payload: UpdateServicePlan): Promise<ServicePlan> {
    const updatedServicePlan = await apiClient.put<ServicePlan>(`/clients/${clientId}/service-plans/${id}`, payload);

    return updatedServicePlan.data;
  }

  public async assign(
    id: string,
    clientId: string,
    currentAssignee: string,
    newAssignee: string,
  ): Promise<ServicePlan[]> {
    const updatedServicePlan = await apiClient.patch<ServicePlan[]>(`/clients/${clientId}/service-plans/${id}/assign`, {
      currentAssignee,
      newAssignee,
    });

    return updatedServicePlan.data;
  }

  public async create(servicePlan: CreateServicePlan): Promise<ServicePlan> {
    const newServicePlan = await apiClient.post<ServicePlan>(
      `/clients/${servicePlan.clientId}/service-plans/`,
      servicePlan,
    );

    return newServicePlan.data;
  }

  private formatFilters(filters: ServicePlanFilters): URLSearchParams {
    const formattedFilters = new URLSearchParams();
    if (filters.assigneeIds.length) {
      filters.assigneeIds.forEach((id) => {
        formattedFilters.append('assigneeIds', id);
      });
    }

    if (filters.agreementIds.length) {
      filters.agreementIds.forEach((id) => {
        formattedFilters.append('agreementIds', id);
      });
    }

    formattedFilters.append('skipCount', filters.skipCount.toString());
    formattedFilters.append('batchSize', filters.batchSize.toString());

    if (filters.sortBy) {
      formattedFilters.append('sortBy', filters.sortBy);
    }

    if (filters.sortOrder) {
      formattedFilters.append('sortOrder', filters.sortOrder);
    }

    return formattedFilters;
  }
}

export const servicePlanService = new ServicePlanService();
