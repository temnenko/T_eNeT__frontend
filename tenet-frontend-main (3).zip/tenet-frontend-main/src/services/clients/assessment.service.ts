/* eslint-disable class-methods-use-this */
import { Assessment, CreateAssessment, GetAssessmentsResult, UpdateAssessment } from '../../types/assessment';
import apiClient from '../api-client.service';
import { SortableAssessmentField } from '../organizations/agreement.service';

export interface AssessmentFilters {
  agreementIds: string[];
  assigneeIds: string[];
  skipCount: number;
  batchSize: number;
  sortBy: SortableAssessmentField;
  sortOrder: 'asc' | 'desc';
}

class AssessmentService {
  public async getById(id: string): Promise<Assessment> {
    const assessment = await apiClient.get<Assessment>(`/assessments/${id}`);

    return assessment.data;
  }

  public async getByClientId(id: string): Promise<Assessment[]> {
    const result = await apiClient.get<Assessment[]>(`/assessments/clients/${id}`);

    return result.data;
  }

  public async getManyByOrganizationId(
    organizationId: string,
    filters: AssessmentFilters,
  ): Promise<GetAssessmentsResult> {
    const formattedFilters = this.formatFilters(filters);

    const result = await apiClient.get<GetAssessmentsResult>(`/assessments/organizations/${organizationId}`, {
      params: formattedFilters,
    });

    return result.data;
  }

  public async update(id: string, assessment: UpdateAssessment): Promise<Assessment> {
    const updatedAssessment = await apiClient.put<Assessment>(`/assessments/${id}`, assessment);

    return updatedAssessment.data;
  }

  public async create(assessment: CreateAssessment): Promise<Assessment> {
    const newAssessment = await apiClient.post<Assessment>('/assessments', assessment);

    return newAssessment.data;
  }

  public async complete(id: string): Promise<Assessment> {
    const completedAssessment = await apiClient.put<Assessment>(`/assessments/${id}/complete`);

    return completedAssessment.data;
  }

  public async delete(id: string): Promise<void> {
    await apiClient.delete(`/assessments/${id}`);
  }

  async getAssessmentFiles(assessmentId: string) {
    const files = await apiClient.get(`/files/${assessmentId}`);
    return files.data;
  }

  private formatFilters(filters: AssessmentFilters): URLSearchParams {
    const formattedFilters = new URLSearchParams();
    if (filters.assigneeIds.length) {
      filters.assigneeIds.forEach((id) => {
        formattedFilters.append('assigneeIds', id);
      });
    }

    if (filters.agreementIds.length) {
      filters.agreementIds.forEach((id) => {
        formattedFilters.append('agreementIds', id);
      });
    }

    formattedFilters.append('skipCount', filters.skipCount.toString());
    formattedFilters.append('batchSize', filters.batchSize.toString());

    if (filters.sortBy) {
      formattedFilters.append('sortBy', filters.sortBy);
    }

    if (filters.sortOrder) {
      formattedFilters.append('sortOrder', filters.sortOrder);
    }

    return formattedFilters;
  }
}

export const assessmentService = new AssessmentService();
