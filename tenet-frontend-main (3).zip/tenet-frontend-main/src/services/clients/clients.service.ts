/* eslint-disable class-methods-use-this */
import {
  Client,
  ClientAddressRecord,
  ClientSearchParams,
  ClientVerificationResults,
  CreateClientArgs,
  Demographic,
  EmailAddress,
  Phone,
  UpdateClientArgs,
} from '../../types/client';
import apiClient from '../api-client.service';

export interface ClientResult {
  clients: Client[];
  metaData: {
    hasNextBatch: boolean;
    totalCount: number;
  };
}

export interface SingleClientResult {
  client: Client;
  isDuplicate: boolean;
}

class ClientsService {
  public async getClients(
    batchSize?: number,
    skipCount?: number,
    searchParams?: ClientSearchParams,
  ): Promise<ClientResult> {
    const clients = await apiClient.get<ClientResult>(`/clients`, {
      params: {
        ...searchParams,
        batchSize,
        skipCount,
      },
    });

    return clients.data;
  }

  public async getById(id: string): Promise<Client> {
    const client = await apiClient.get<Client>(`/clients/${id}`);

    return client.data;
  }

  public async getClientLmdaVerificationRecords(
    id: string,
    batchSize?: number,
    skipCount?: number,
  ): Promise<ClientVerificationResults> {
    const client = await apiClient.get<ClientVerificationResults>(`/clients/${id}/lmda-verifications`, {
      params: {
        batchSize,
        skipCount,
      },
    });

    return client.data;
  }

  public async deleteById(id: string): Promise<void> {
    await apiClient.delete(`/clients/${id}`);
  }

  public async getIncompleteClients(): Promise<Client[]> {
    const result = await apiClient.get<Client[]>('/clients/incomplete');

    return result.data;
  }

  public async createClient(args: CreateClientArgs, clientId?: string): Promise<SingleClientResult> {
    const result = await apiClient.post<SingleClientResult>(
      '/clients',
      {
        firstName: args.firstName,
        lastName: args.lastName,
        middleName: args.middleName,
        dateOfBirth: args.dateOfBirth,
        sinRecords: args.sinRecords,
        demographic: args.demographic,
        factors: args.factors,
        language: args.language,
      },
      { headers: { 'client-id': clientId } },
    );

    return result.data;
  }

  public async updateClient(clientId: string, args: UpdateClientArgs): Promise<Client> {
    const result = await apiClient.put<Client>(`/clients/${clientId}`, {
      ...args,
    });

    return result.data;
  }

  public async saveClientAddresses(clientId: string, addresses: ClientAddressRecord[]): Promise<ClientAddressRecord[]> {
    const result = await apiClient.put<ClientAddressRecord[]>(`/clients/${clientId}/addresses`, addresses);

    return result.data;
  }

  public async saveClientContactDetails(
    clientId: string,
    emailAddresses: EmailAddress[],
    phoneNumbers: Phone[],
  ): Promise<Client> {
    const result = await apiClient.put<Client>(`/clients/${clientId}/contacts`, {
      emailAddresses,
      phoneNumbers,
    });

    return result.data;
  }

  public async saveClientDemographics(clientId: string, demographics: Demographic): Promise<Demographic> {
    const result = await apiClient.put<Demographic>(`/clients/${clientId}/demographics`, demographics);

    return result.data;
  }
}

export const clientsService = new ClientsService();
