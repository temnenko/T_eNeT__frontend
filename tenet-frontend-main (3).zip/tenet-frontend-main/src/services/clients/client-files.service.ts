/* eslint-disable class-methods-use-this */
import { encode } from 'base64-arraybuffer';
import { TenetFile, Upload } from '../../types/files';
import apiClient from '../api-client.service';

import useFileNotValid from '../../utils/file.util';
import { InvalidFileUploadError } from '../../types/errors/invalid-file-upload.error';

class FileService {
  async getFiles(recordId: string): Promise<TenetFile[]> {
    const files = await apiClient.get(`/files/${recordId}`);
    return files.data;
  }

  deleteFile(adspId: string) {
    return apiClient.delete(`/files/${adspId}`);
  }

  async softDeleteFile(adspId: string, archived: boolean): Promise<TenetFile[]> {
    const response = await apiClient.patch(`/files/${adspId}`, {
      archived,
    });
    return response.data;
  }

  async uploadFiles(recordId: string, files: Partial<Upload>[]): Promise<TenetFile[]> {
    try {
      const requestBody = {
        recordId,
        fileTypes: files.map((file) => file.fileType),
        files: await Promise.all(
          files.map(async (file) => {
            if (file.file?.name) {
              const { fileNotValidHandler } = useFileNotValid();
              fileNotValidHandler(file.file?.name, file.file.type);
            }
            const base64Data = await this.convertFileToBase64(file.file!);
            return {
              base64Data,
              filename: file.file!.name,
              mimeType: file.file!.type,
            };
          }),
        ),
      };

      const response = await apiClient.post('files', requestBody);
      return response.data;
    } catch (e) {
      if (e instanceof InvalidFileUploadError) {
        console.log(e.message);
      }
      return [];
    }
  }

  private async convertFileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsArrayBuffer(file);
      reader.onloadend = () => {
        try {
          const base64String = encode(reader.result as ArrayBuffer);
          resolve(base64String);
        } catch (error) {
          reject(error);
        }
      };
      reader.onerror = (error) => reject(error);
    });
  }

  async downloadFileByAdspId(adspId: string, filename: string, filesize: number): Promise<void> {
    const progressBar = document.getElementById(`statusBar-${adspId}`);
    if (progressBar) {
      progressBar.style.display = 'inline-flex';
    }
    const filedata = await apiClient.get(`/files/download/${adspId}`, {
      responseType: 'blob',
      onDownloadProgress: (progress) => {
        const percent = filesize ? 100 * (progress.loaded / filesize) : 0;
        if (progressBar) {
          progressBar.nodeValue = percent.toString();
        }
      },
    });
    if (progressBar) {
      progressBar.style.display = 'none';
    }
    if (!filedata.data || filedata.status === 404) {
      throw new Error(`This file, ${filename}, is not available for download`);
    }
    const url = window.URL.createObjectURL(new Blob([filedata.data], { type: 'blob' }));
    if (!url) {
      throw new Error(`There was an error downloading the file, ${filename}`);
    }
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    link.parentNode?.removeChild(link);
    window.URL.revokeObjectURL(url);
  }

  public async getClientDocuments(clientId: string): Promise<TenetFile[]> {
    const files = await apiClient.get(`/clients/${clientId}/documents`);
    return files.data;
  }
}

export const fileService = new FileService();
