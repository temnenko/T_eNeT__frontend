import { reveal } from 'jest-auto-stub';
import { randomUUID } from 'crypto';
import apiClient from '../api-client.service';
import { assessmentService } from './assessment.service';
import { AssessmentType } from '../../types/assessment';

jest.mock('../api-client.service', () => {
  return {
    __esModule: true,
    default: {
      get: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      delete: jest.fn(),
      patch: jest.fn(),
    },
  };
});

describe('AssessmentService', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  const mockAssessment = {
    id: '1',
    clientId: '1',
    agreementId: 'ef8d2166-bec9-4ccf-a26e-7b9c8565f159',
    workExperience: false,
    careerPlanning: false,
    educationAndTraining: false,
    jobSearchAssistance: false,
    careerAdvice: false,
    selfEmployment: false,
    laborMarketInformation: false,
    foreignCredentialRecognition: false,
    createdAt: new Date(),
    updatedAt: new Date(),
    assessedBy: '1',
    assessmentType: AssessmentType.SERVICE_NEEDS_DETERMINATION,
    programAssessedFor: randomUUID(),
  };

  describe('getById', () => {
    it('should fetch assessment by id', async () => {
      reveal(apiClient).get.mockResolvedValueOnce({ data: mockAssessment });

      const assessment = await assessmentService.getById('1');

      expect(assessment).toEqual(mockAssessment);
    });
  });

  describe('getByClientId', () => {
    it('should fetch assessment by id', async () => {
      reveal(apiClient).get.mockResolvedValueOnce({ data: [mockAssessment] });

      const assessments = await assessmentService.getByClientId('test-client-id');

      expect(apiClient.get).toHaveBeenCalledWith(`/assessments/clients/test-client-id`);
      expect(assessments).toEqual([mockAssessment]);
    });
  });

  describe('update', () => {
    it('should update assessment by id', async () => {
      const mockPayload = {
        ...mockAssessment,
        workExperience: true,
        careerPlanning: true,
        educationAndTraining: true,
        jobSearchAssistance: true,
        careerAdvice: true,
        selfEmployment: true,
        laborMarketInformation: true,
        foreignCredentialRecognition: true,
      };

      reveal(apiClient).put.mockResolvedValueOnce({ data: mockAssessment });

      const assessment = await assessmentService.update('1', mockPayload);

      expect(assessment).toEqual(mockAssessment);
    });
  });

  describe('create', () => {
    it('should create assessment by id', async () => {
      const mockPayload = {
        ...mockAssessment,
      };

      reveal(apiClient).post.mockResolvedValueOnce({ data: mockAssessment });

      const assessment = await assessmentService.create(mockPayload);

      expect(assessment).toEqual(mockAssessment);
    });
  });
});
