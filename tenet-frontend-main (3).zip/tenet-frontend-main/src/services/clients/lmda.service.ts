/* eslint-disable class-methods-use-this */
import { ClientVerificationRecord, LmdaSubscription } from '../../types/client';
import apiClient from '../api-client.service';

class LmdaService {
  public async verify(sinRecordId: string): Promise<ClientVerificationRecord> {
    const result = await apiClient.post(`/lmda/verify`, {
      sinRecordId,
    });
    return result.data;
  }

  public async subscribeToLmdaVerification(
    clientId: string,
    sinRecordId: string,
    subscriptionStopDate: Date,
  ): Promise<LmdaSubscription> {
    const subscription = await apiClient.post<LmdaSubscription>('/lmda/subscription', {
      clientId,
      sinRecordId,
      subscriptionStopDate,
    });

    return subscription.data;
  }

  public async removeLmdaSubscription(id: string): Promise<void> {
    await apiClient.delete(`/lmda/subscription/${id}`);
  }

  public async getLmdaSubscription(clientId: string): Promise<LmdaSubscription> {
    const subscription = await apiClient.get<LmdaSubscription>(`/lmda/subscription/${clientId}`);

    return subscription.data;
  }

  public async updateSubscription(id: string, subscriptionStopDate: Date): Promise<LmdaSubscription> {
    const subscription = await apiClient.put<LmdaSubscription>(`/lmda/subscription/${id}`, {
      subscriptionStopDate,
    });

    return subscription.data;
  }
}

export const lmdaService = new LmdaService();
