/* eslint-disable class-methods-use-this */
import { Education, EducationArgs, UpdateEducationArgs } from '../../types/client';
import apiClient from '../api-client.service';

export interface EducationBatch {
  educationHistory: Education[];
  metaData: {
    hasNextBatch: boolean;
    totalCount: number;
  };
}

export interface GetEducationArgs {
  skipCount?: number;
  batchSize?: number;
  archived?: boolean;
}

class EducationService {
  public async getEducations(
    clientId: string,
    archived?: boolean,
    batchSize?: number,
    skipCount?: number,
  ): Promise<EducationBatch> {
    const clients = await apiClient.get<EducationBatch>(`/clients/${clientId}/educations`, {
      params: { archived, batchSize, skipCount },
    });

    return { ...clients.data, educationHistory: clients.data.educationHistory?.map(this.mapEducation) };
  }

  public async getEducationHistoryById(id: string, archived?: boolean): Promise<Education> {
    const client = await apiClient.get<Education>(`/clients/educations/${id}`, { params: { archived } });

    return this.mapEducation(client.data);
  }

  public async createEducationHistory(clientId: string, args: EducationArgs): Promise<Education> {
    const result = await apiClient.post<Education>(
      `/clients/${clientId}/educations`,
      {
        ...args,
      },
      { headers: { 'client-id': clientId } },
    );

    return this.mapEducation(result.data);
  }

  public async updateEducationHistory(id: string, args: UpdateEducationArgs): Promise<Education> {
    const result = await apiClient.put<Education>(`/clients/educations/${id}`, {
      ...args,
    });

    return this.mapEducation(result.data);
  }

  public async archiveEducation(id: string, archived: boolean): Promise<Education> {
    const result = await apiClient.patch<Education>(`/clients/educations/${id}`, {
      archived,
    });

    return this.mapEducation(result.data);
  }

  public async hardDeleteEducation(id: string): Promise<void> {
    await apiClient.delete(`/clients/educations/${id}`);
  }

  protected mapEducation = (args: Education): Education => {
    return {
      ...args,
      createdAt: new Date(args.createdAt),
    };
  };
}

export const educationService = new EducationService();
