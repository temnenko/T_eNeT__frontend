/* eslint-disable class-methods-use-this */
import { Role } from '../../types/role';
import apiClient from '../api-client.service';
import { User, UserAccessRequestArgs } from '../../types/user';

class UserAccessService {
  public async getAllRoles(): Promise<Role[]> {
    const roles = await apiClient.get<Role[]>(`/roles`);

    return roles.data;
  }

  public async getUserAccessRequest(userId: string): Promise<User> {
    const req = await apiClient.get(`/users/${userId}`);

    return req.data;
  }

  public async updateAccessRequest(request: UserAccessRequestArgs): Promise<User | null> {
    const req = await apiClient.patch<User>(`/users/me`, request);

    return req.data;
  }

  public async completeAccessRequest(): Promise<User | null> {
    const req = await apiClient.patch<User>(`/users/me/access/complete`);

    return req.data;
  }
}

export const userAccessService = new UserAccessService();
