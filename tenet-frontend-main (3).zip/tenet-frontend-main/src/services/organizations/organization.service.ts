/* eslint-disable class-methods-use-this */
import {
  LocationArgs,
  Contact,
  Organization,
  Location,
  UpdateOrganization,
  CreateContact,
} from '../../types/organization';
import { UserInvite } from '../../types/user';
import apiClient from '../api-client.service';

export interface InviteOrganizationUserInput {
  organizationId: string;
  emailAddress: string;
  givenName?: string;
  roleId?: string;
}

export interface OrganizationResult {
  organizations: Organization[];
  metaData: {
    hasNextBatch: boolean;
    totalCount: number;
  };
}

class OrganizationService {
  public async getOrganizationById(organizationId: string): Promise<Organization> {
    const organization = await apiClient.get<Organization>(`/organizations/${organizationId}`);
    return organization.data;
  }

  public async getOrganizationsList(
    batchSize?: number,
    skipCount?: number,
    nameSearch?: string,
  ): Promise<OrganizationResult> {
    const organizations = await apiClient.get<OrganizationResult>(`/organizations`, {
      params: {
        batchSize,
        skipCount,
        nameSearch,
      },
    });
    return organizations.data;
  }

  public async getUserInvites(id: string): Promise<UserInvite[]> {
    const result = await apiClient.get<UserInvite[]>(`/organizations/${id}/invites`);
    return result.data;
  }

  public async updateOrganization(organization: UpdateOrganization): Promise<Organization> {
    const updatedOrganization = await apiClient.put<Organization>(`/organizations/${organization.id}`, organization);
    return updatedOrganization.data;
  }

  // may need to change the verb to PATCH instead of PUT
  public async patchOrganization(organization: Partial<Organization>): Promise<Organization> {
    const updatedOrganization = await apiClient.put<Organization>(`/organizations/${organization.id}`, organization);
    return updatedOrganization.data;
  }

  public async createLocation(organizationId: string, data: Omit<LocationArgs, 'economicRegion'>): Promise<Location> {
    const createdLocation = await apiClient.post<Location>(`/organizations/${organizationId}/locations`, data);
    return createdLocation.data;
  }

  public async updateLocation(id: string, data: Partial<LocationArgs>): Promise<Location> {
    const updatedLocation = await apiClient.put<Location>(`/organizations/locations/${id}`, data);
    return updatedLocation.data;
  }

  public async inviteOrganization(data: InviteOrganizationUserInput): Promise<void> {
    await apiClient.post(`/users/invites`, data);
  }

  public async getContactById(contactId: string): Promise<Contact> {
    const contact = await apiClient.get<Contact>(`/organizations/contacts/${contactId}`);
    return contact.data;
  }

  public async updateContact(id: string, contact: Partial<CreateContact>): Promise<Contact> {
    const updatedContact = await apiClient.put<Contact>(`/organizations/contacts/${id}`, contact);
    return updatedContact.data;
  }

  // looking at the backend code not sure if this is the correct endpoint
  public async updateOrganizationContact(orgId: string, contact: Partial<Contact>[]): Promise<Contact> {
    const updatedContact = await apiClient.post<Contact>(`/organizations/${orgId}/contacts`, contact);
    return updatedContact.data;
  }

  public async deleteOrganizationContact(organizationId: string, contactId: string): Promise<void> {
    await apiClient.delete(`/organizations/${organizationId}/contacts/${contactId}`);
  }

  public async deleteOrganizationLocation(organizationId: string, locationId: string): Promise<void> {
    await apiClient.delete(`/organizations/${organizationId}/locations/${locationId}`);
  }

  public async createOrganization(data: Partial<Organization>): Promise<Organization> {
    const createdOrganization = await apiClient.post<Organization>('/organizations', data);
    return createdOrganization.data;
  }

  public async completeOrganization(organizationId: string): Promise<Organization> {
    const updatedOrganization = await apiClient.post<Organization>(`/organizations/${organizationId}/complete`);
    return updatedOrganization.data;
  }

  public async getLocations(organizationId: string): Promise<Location[]> {
    const response = await apiClient.get<Location[]>(`/organizations/${organizationId}/locations`);

    return response.data;
  }

  public async getOfficeLocations(locationId: string): Promise<Location[]> {
    const locations = await apiClient.get<Location[]>(`/organizations/locations/${locationId}`);

    return locations.data;
  }
}

export const organizationService = new OrganizationService();
