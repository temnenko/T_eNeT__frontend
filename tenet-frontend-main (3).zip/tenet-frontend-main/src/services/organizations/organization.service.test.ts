import { reveal } from 'jest-auto-stub';
import apiClient from '../api-client.service';
import { organizationService } from './organization.service';

jest.mock('../api-client.service', () => {
  return {
    __esModule: true,
    default: {
      post: jest.fn(),
      get: jest.fn(),
      put: jest.fn(),
    },
  };
});

describe('OrganizationService', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });
  describe('inviteOrganization', () => {
    it('should delegate post to invite organization', async () => {
      reveal(apiClient).post.mockResolvedValueOnce({});

      const data = {
        organizationId: 'organization-id',
        givenName: 'Jumbo Ent',
        emailAddress: 'jumbo@ent.eg',
      };

      await organizationService.inviteOrganization(data);

      expect(apiClient.post).toHaveBeenCalledWith(`/users/invites`, data);
    });

    describe('update organization', () => {
      it('should update organization', async () => {
        const organization = {
          id: '1',
          operatingName: 'operatingName',
          legalName: 'legalName',
          emailAddress: 'emailAddress',
          website: 'website',
          createdAt: 'createdAt',
          updatedAt: 'updatedAt',
          businessIdentifier: 'businessIdentifier',
        };
        reveal(apiClient).put.mockResolvedValueOnce({
          data: organization,
        });

        const result = await organizationService.updateOrganization(organization);

        expect(apiClient.put).toHaveBeenCalledWith(`/organizations/1`, organization);
        expect(result).toEqual(organization);
      });
    });

    describe('create organization', () => {
      it('should create organization', async () => {
        const organization = {
          operatingName: 'operatingName',
          legalName: 'legalName',
          emailAddress: 'emailAddress',
          website: 'website',
          businessIdentifier: 'businessIdentifier',
        };
        reveal(apiClient).post.mockResolvedValueOnce({
          data: organization,
        });

        const result = await organizationService.createOrganization(organization);

        expect(apiClient.post).toHaveBeenCalledWith(`/organizations`, organization);
        expect(result).toEqual(organization);
      });
    });

    describe('update contact', () => {
      it('should update contact', async () => {
        const contact = [
          {
            name: 'Someone',
            role: 'Supervisor',
            extension: '111',
            phoneNumber: '4849494944',
            emailAddress: 'aaa@gmail.com',
          },
        ];
        reveal(apiClient).post.mockResolvedValueOnce({
          data: contact,
        });

        const result = await organizationService.updateOrganizationContact('1', contact);

        expect(apiClient.post).toHaveBeenCalledWith(`/organizations/1/contacts`, contact);
        expect(result).toEqual(contact);
      });
    });
  });
});
