/* eslint-disable class-methods-use-this */
import {
  Agreement,
  AgreementDashboardResult,
  AgreementSummary,
  CreateAgreement,
  GetAgreementClientsArgs,
  GetMetricsArgs,
  Metrics,
  UpdateAgreement,
} from '../../types/agreement';
import { LMDAIntakeTypes } from '../../types/assessment-forms';
import { Contact, CreateContact } from '../../types/organization';
import {
  ServicePlanFollowUpOutcome,
  ServicePlanOutcome,
  ServicePlanStatus,
  SupplementaryActivityType,
} from '../../types/service-plan';
import apiClient from '../api-client.service';

export interface GetAgreementsInput {
  organizationId: string;
  batchSize?: number;
  skipCount?: number;
  showExpiredAgreements?: boolean;
}

export type SortableAgreementField =
  | 'agreementNumber'
  | 'programType'
  | 'startDate'
  | 'endDate'
  | 'givenName'
  | 'tenetNumber'
  | 'firstName'
  | 'lastName'
  | 'status';

export type SortOrder = 'asc' | 'desc';

export interface AgreementFilters {
  assigneeId?: string[];
  skipCount: number;
  batchSize: number;
  sortBy?: SortableAgreementField;
  sortOrder?: SortOrder;
  nameOrNumberSearch?: string;
  includeInactive?: boolean;
}

export type AgreementActivityFields =
  | 'name'
  | 'outcomeDate'
  | 'cost'
  | 'id'
  | 'tenetNumber'
  | 'outcome'
  | 'activityType';

export interface AgreementActivityFilters {
  skipCount: number;
  batchSize: number;
  sortBy?: {
    sortKey: AgreementActivityFields;
    sortOrder: SortOrder;
  };
}

export interface GetAgreementsResult {
  agreements: Agreement[];
  metaData: {
    hasNextBatch: boolean;
    totalCount: number;
  };
}

export interface AgreementClient {
  servicePlanId: string;
  serviceOutcome?: ServicePlanOutcome;
  serviceOutcomeDate?: Date;
  followUpOutcome?: ServicePlanFollowUpOutcome;
  followUpOutcomeDate?: Date;
  employmentOutcome?: string;
  employmentOutcomeDate?: Date;
  lmdaIntakeType?: LMDAIntakeTypes;
  clientId: string;
  tenetNumber: string;
  firstName: string;
  lastName: string;
  startDate: Date;
  endDate?: Date;
  status: ServicePlanStatus;
}

export interface AgreementActivity {
  id: string;
  tenetNumber: string;
  activityType?: SupplementaryActivityType;
  title?: string;
  outcomeDate?: Date;
  cost?: number;
  outcome?: ServicePlanOutcome;
}

export interface AgreementClientsResult {
  clients: AgreementClient[];
  metaData: {
    totalCount: number;
    hasNextBatch: boolean;
  };
}

export interface AgreementActivitiesResult {
  supplementaryActivities: AgreementActivity[];
  metaData: {
    totalCount: number;
    hasNextBatch: boolean;
  };
}

export type SortableAssessmentField =
  | 'status'
  | 'tenetNumber'
  | 'assessmentDate'
  | 'agreementName'
  | 'givenName'
  | 'familyName'
  | 'firstName'
  | 'lastName';

class AgreementService {
  public async getById(id: string): Promise<Agreement> {
    const agreement = await apiClient.get<Agreement>(`/organizations/agreements/${id}`);

    return agreement.data;
  }

  public async getByOrganizationId({
    organizationId,
    batchSize,
    skipCount,
    showExpiredAgreements,
  }: GetAgreementsInput): Promise<GetAgreementsResult> {
    const result = await apiClient.get<GetAgreementsResult>(`/organizations/${organizationId}/agreements`, {
      params: {
        batchSize,
        skipCount,
        showExpiredAgreements,
      },
    });

    return result.data;
  }

  public async getMetrics({ id, organizationId }: GetMetricsArgs): Promise<Metrics> {
    const result = await apiClient.get<Metrics>(`/organizations/${organizationId}/agreements/${id}/metrics`);

    return result.data;
  }

  public async getClientsByAgreementId(
    { id, organizationId }: GetAgreementClientsArgs,
    filters: AgreementFilters,
  ): Promise<AgreementClientsResult> {
    const formattedFilters = this.formatFilters(filters);

    const result = await apiClient.get<AgreementClientsResult>(
      `/organizations/${organizationId}/agreements/${id}/clients`,
      {
        params: formattedFilters,
      },
    );

    return result.data;
  }

  public async getActivitiesByAgreementId(
    { id, organizationId }: GetMetricsArgs,
    filters: AgreementActivityFilters,
  ): Promise<AgreementActivitiesResult> {
    const result = await apiClient.get<AgreementActivitiesResult>(
      `/organizations/${organizationId}/agreements/${id}/activities`,
      {
        params: filters,
      },
    );

    return result.data;
  }

  public async getAgreementNamesByOrganization(organizationId: string): Promise<AgreementDashboardResult> {
    const result = await apiClient.get<AgreementDashboardResult>(`/organizations/${organizationId}/agreements/names`);

    return result.data;
  }

  public async getCompletedByOrganizationId(organizationId: string): Promise<AgreementSummary[]> {
    const result = await apiClient.get<AgreementSummary[]>(`/organizations/${organizationId}/agreements/completed`);

    return result.data;
  }

  public async getByClientId(id: string): Promise<Agreement[]> {
    const result = await apiClient.get<Agreement[]>(`/agreements/clients/${id}`);

    return result.data;
  }

  public async create(agreement: CreateAgreement): Promise<Agreement> {
    const newAgreement = await apiClient.post<Agreement>(
      `/organizations/${agreement?.organizationId}/agreements`,
      agreement,
    );

    return newAgreement.data;
  }

  public async removeLocations(id: string, locationIds: string[]): Promise<Agreement> {
    const result = await apiClient.patch<Agreement>(`/organizations/agreements/${id}/locations`, { locationIds });

    return result.data;
  }

  public async update(id: string, agreement: UpdateAgreement): Promise<Agreement> {
    const updated = await apiClient.put<Agreement>(`/organizations/agreements/${id}`, agreement);

    return updated.data;
  }

  public async complete(id: string): Promise<Agreement> {
    const completed = await apiClient.put<Agreement>(`/organizations/agreements/${id}/complete`);

    return completed.data;
  }

  public async createContacts(organizationId: string, contacts: CreateContact[]): Promise<Contact[]> {
    const newContacts = await apiClient.post<Contact[]>(`/organizations/${organizationId}/contacts`, contacts);

    return newContacts.data;
  }

  public async connectContactsToAgreement(
    organizationId: string,
    contactIds: string[],
    agreementId: string,
  ): Promise<Agreement> {
    const connectedContact = await apiClient.patch<Agreement>(
      `/organizations/${organizationId}/agreements/${agreementId}/contacts/connect`,
      contactIds,
    );

    return connectedContact.data;
  }

  public async disconnectContactsFromAgreement(
    organizationId: string,
    contactIds: string[],
    agreementId: string,
  ): Promise<Agreement> {
    const disconnectedContact = await apiClient.patch<Agreement>(
      `/organizations/${organizationId}/agreements/${agreementId}/contacts/disconnect`,
      contactIds,
    );

    return disconnectedContact.data;
  }

  public async getAgreementsForGoADashboard(filters: AgreementFilters): Promise<GetAgreementsResult> {
    const formattedFilters = this.formatFilters(filters);
    const result = await apiClient.get<GetAgreementsResult>('/organizations/agreements', {
      params: formattedFilters,
    });

    return result.data;
  }

  private formatFilters(filters: AgreementFilters): URLSearchParams {
    const formattedFilters = new URLSearchParams();

    if (filters.assigneeId?.length) {
      filters.assigneeId.forEach((id) => {
        formattedFilters.append('assigneeIds', id);
      });
    }

    formattedFilters.append('skipCount', filters.skipCount.toString());
    formattedFilters.append('batchSize', filters.batchSize.toString());

    if (filters.includeInactive !== undefined) {
      formattedFilters.append('includeInactive', `${filters.includeInactive}`);
    }

    if (filters.sortBy) {
      formattedFilters.append('sortBy', filters.sortBy);
    }

    if (filters.sortOrder) {
      formattedFilters.append('sortOrder', filters.sortOrder);
    }

    if (filters.nameOrNumberSearch) {
      formattedFilters.append('nameOrNumberSearch', filters.nameOrNumberSearch);
    }

    return formattedFilters;
  }
}

export const agreementService = new AgreementService();
