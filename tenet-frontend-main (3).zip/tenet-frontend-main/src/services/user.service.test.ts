import { reveal } from 'jest-auto-stub';
import apiClient from './api-client.service';
import { User, UserStatus } from '../types/user';
import { userService } from './user.service';

jest.mock('./api-client.service', () => {
  return {
    __esModule: true,
    default: {
      get: jest.fn(),
      put: jest.fn(),
      delete: jest.fn(),
    },
  };
});

describe('UserService', () => {
  describe('getUserById', () => {
    it('should fetch user data correctly', async () => {
      const mockUser: User = {
        id: 'test-id',
        sid: '1',
        givenName: 'Test',
        familyName: 'User',
        emailAddress: 'abc@xyz.com',
        type: 'GOA_STAFF',
        role: 'VIEWER',
        roleObj: {
          id: '1',
          name: 'VIEWER',
          status: 'ACTIVE',
          description: 'Viewer',
        },
        changeLog: [],
        status: UserStatus.ACTIVE,
      };

      reveal(apiClient).get.mockResolvedValueOnce({ data: mockUser });
      const user = await userService.getUserById('1');
      expect(apiClient.get).toHaveBeenCalledWith(`/users/${user!.sid}`);

      expect(user).toEqual(mockUser);
    });

    it('should handle errors gracefully', async () => {
      (apiClient.get as jest.Mock).mockRejectedValueOnce(new Error('User not found'));
      expect.assertions(1);

      try {
        await userService.getUserById('invalid-id');
      } catch (error) {
        expect(error).toEqual(new Error('User not found'));
      }
    });
  });

  describe('getUsers', () => {
    it('should fetch users data', async () => {
      reveal(apiClient).get.mockResolvedValueOnce({
        data: {
          users: [],
          metaData: {
            hasNextBatch: false,
            totalCount: 0,
          },
        },
      });

      const result = await userService.getUsers({});

      expect(apiClient.get).toHaveBeenCalledWith(`/users`, { params: { batchSize: undefined, skipCount: undefined } });
      expect(result).toEqual({
        users: [],
        metaData: {
          hasNextBatch: false,
          totalCount: 0,
        },
      });
    });
  });

  describe('assignRole', () => {
    it('should assign role to user', async () => {
      const mockUser: User = {
        id: 'test-id',
        sid: '1',
        givenName: 'Test',
        familyName: 'User',
        emailAddress: 'abc@xyz.com',
        type: 'GOA_STAFF',
        role: 'VIEWER',
        roleObj: {
          id: '1',
          name: 'VIEWER',
          status: 'ACTIVE',
          description: 'Viewer',
        },
        changeLog: [],
        status: UserStatus.ACTIVE,
      };

      const updatedUser: User = {
        ...mockUser,
        role: 'EDITOR',
      };

      reveal(apiClient).put.mockResolvedValueOnce({ data: updatedUser });
      const user = await userService.assignRole('1', 'editor_role_id');

      expect(apiClient.put).toHaveBeenCalledWith(`/users/${user!.sid}/roles/editor_role_id`);

      expect(user).toEqual(updatedUser);
    });
  });

  describe('unassignRole', () => {
    it('should unassign role from user', async () => {
      const mockUser: User = {
        id: 'test-id',
        sid: '1',
        givenName: 'Test',
        familyName: 'User',
        emailAddress: 'abc@xyz.com',
        type: 'GOA_STAFF',
        role: 'VIEWER',
        roleObj: {
          id: '1',
          name: 'VIEWER',
          status: 'ACTIVE',
          description: 'Viewer',
        },
        changeLog: [],
        status: UserStatus.ACTIVE,
      };

      const updatedUser = {
        ...mockUser,
        role: 'Unassigned',
        roleObj: null,
      };

      reveal(apiClient).delete.mockResolvedValueOnce({ data: updatedUser });
      const user = await userService.unassignRole('test-id');

      expect(apiClient.delete).toHaveBeenCalledWith(`/users/${user!.id}/roles`);

      expect(user).toEqual(updatedUser);
    });
  });
});
