import { EventEmitter } from 'eventemitter3';
import { SetAuthInput } from '../types/user';

class AppEventService {
  static instance: AppEventService;

  private emitter: EventEmitter;

  public static getInstance(): AppEventService {
    if (!AppEventService.instance) {
      AppEventService.instance = new AppEventService();
    }
    return AppEventService.instance;
  }

  constructor() {
    this.emitter = new EventEmitter();
  }

  emitTokensUpdated(data: SetAuthInput) {
    this.emitter.emit('tokensUpdated', data);
  }

  getEmitter() {
    return this.emitter;
  }
}

export const appEventService = AppEventService.getInstance();
