import { reveal } from 'jest-auto-stub';
import apiClient, { apiAddressClientProxy } from './api-client.service';
import { canadaPostService } from './canada-post.service';

jest.mock('axios');
jest.mock('./api-client.service', () => {
  return {
    __esModule: true,
    default: {
      get: jest.fn(),
    },
    apiAddressClientProxy: {
      get: jest.fn(),
    },
  };
});

describe('CanadaPostService', () => {
  afterEach(() => {
    jest.resetAllMocks();
    jest.clearAllMocks();
  });

  describe('getToken', () => {
    it('should return existing token if it is still valid', async () => {
      canadaPostService.token = 'existing-token';
      canadaPostService.tokenExpiry = Math.floor(Date.now() / 1000) + 60; // valid for 60 more seconds

      const token = await canadaPostService.getToken();

      expect(token).toBe('existing-token');
    });

    it('should fetch a new token if the existing token is expired', async () => {
      const newToken = 'new-token';
      const currentTime = Math.floor(Date.now() / 1000);
      reveal(apiClient).get.mockResolvedValueOnce({ data: { token: newToken } });

      canadaPostService.token = 'expired-token';
      canadaPostService.tokenExpiry = currentTime - 60; // expired 60 seconds ago

      const token = await canadaPostService.getToken();

      expect(apiClient.get).toHaveBeenCalledWith(`/canada-post/token`);
      expect(token).toBe(newToken);
      expect(canadaPostService.token).toBe(newToken);
      expect(canadaPostService.tokenExpiry).toBeGreaterThan(currentTime);
    });
  });

  describe('find', () => {
    it('should fetch address suggestions with a valid token', async () => {
      const mockResponse = { data: { Items: [] } };
      reveal(apiClient).get.mockResolvedValueOnce({ data: { token: 'valid-token' } });
      reveal(apiAddressClientProxy).get.mockResolvedValueOnce(mockResponse);

      canadaPostService.token = 'expired-token';
      canadaPostService.tokenExpiry = Math.floor(Date.now() / 1000) - 60; // expired 60 seconds ago

      const searchTerm = 'test';
      const response = await canadaPostService.find(searchTerm);

      expect(apiClient.get).toHaveBeenCalledWith(`/canada-post/token`);
      expect(apiAddressClientProxy.get).toHaveBeenCalledWith('/find', {
        headers: { Authorization: 'Bearer valid-token' },
        params: new URLSearchParams({
          languagePreference: 'en',
          maxSuggestions: '5',
          searchTerm,
        }),
      });
      expect(response).toEqual(mockResponse);
    });
  });

  describe('retrieve', () => {
    it('should fetch full address details with a valid token', async () => {
      const mockResponse = { data: { Items: [] } };
      reveal(apiClient).get.mockResolvedValueOnce({ data: { token: 'valid-token' } });
      reveal(apiAddressClientProxy).get.mockResolvedValueOnce(mockResponse);

      canadaPostService.token = 'expired-token';
      canadaPostService.tokenExpiry = Math.floor(Date.now() / 1000) - 60; // expired 60 seconds ago

      const id = 'test-id';
      const response = await canadaPostService.retrieve(id);

      expect(apiClient.get).toHaveBeenCalledWith(`/canada-post/token`);
      expect(apiAddressClientProxy.get).toHaveBeenCalledWith('/retrieve', {
        headers: { Authorization: 'Bearer valid-token' },
        params: new URLSearchParams({
          languagePreference: 'en',
          id,
        }),
      });
      expect(response).toEqual(mockResponse);
    });
  });

  describe('fetchToken', () => {
    it('should fetch a new token from the backend', async () => {
      const newToken = 'new-token';
      const currentTime = Math.floor(Date.now() / 1000);
      reveal(apiClient).get.mockResolvedValueOnce({ data: { token: newToken } });

      const token = await canadaPostService.fetchToken();

      expect(apiClient.get).toHaveBeenCalledWith(`/canada-post/token`);
      expect(token).toBe(newToken);
      expect(canadaPostService.token).toBe(newToken);
      expect(canadaPostService.tokenExpiry).toBeGreaterThan(currentTime);
    });
  });

  describe('isTokenStillValid', () => {
    it('should return true if the token is still valid for more than 30 seconds', () => {
      canadaPostService.token = 'valid-token';
      canadaPostService.tokenExpiry = Math.floor(Date.now() / 1000) + 60; // valid for 60 more seconds

      const isValid = canadaPostService.isTokenStillValid();

      expect(isValid).toBe(true);
    });

    it('should return false if the token is expired or about to expire', () => {
      canadaPostService.token = 'expired-token';
      canadaPostService.tokenExpiry = Math.floor(Date.now() / 1000) - 60; // expired 60 seconds ago

      const isValid = canadaPostService.isTokenStillValid();

      expect(isValid).toBe(false);
    });
  });
});
