/* eslint-disable class-methods-use-this */
import { User, UserConfig, UserIdNamePair } from '../types/user';
import apiClient from './api-client.service';

export interface GetUsersInput {
  batchSize?: number;
  skipCount?: number;
  organizationId?: string;
  givenNameFilter?: string;
  familyNameFilter?: string;
  skipOrganizationFilter?: boolean;
}

export interface GetUsersResult {
  users: User[];
  metaData: {
    hasNextBatch: boolean;
    totalCount: number;
  };
}

class UserService {
  public async getUserById(id: string): Promise<User | null> {
    const user = await apiClient.get<User>(`/users/${id}`);
    return user.data;
  }

  public async getSlimmedUsers({
    organizationId,
    givenNameFilter,
    familyNameFilter,
    skipOrganizationFilter,
  }: GetUsersInput): Promise<User[]> {
    const users = await apiClient.get<User[]>('/users/slimmed', {
      params: {
        organizationId,
        givenNameFilter,
        familyNameFilter,
        skipOrganizationFilter,
      },
    });
    return users.data;
  }

  public async getUsers({
    batchSize,
    skipCount,
    organizationId,
    givenNameFilter,
    familyNameFilter,
    skipOrganizationFilter,
  }: GetUsersInput): Promise<GetUsersResult> {
    const response = await apiClient.get<GetUsersResult>('/users', {
      params: {
        batchSize,
        skipCount,
        organizationId,
        givenNameFilter,
        familyNameFilter,
        skipOrganizationFilter,
      },
    });

    return response.data;
  }

  public async assignRole(userId: string, roleId: string): Promise<User> {
    const result = await apiClient.put(`/users/${userId}/roles/${roleId}`);
    return result.data;
  }

  public async unassignRole(userId: string): Promise<User> {
    const result = await apiClient.delete(`/users/${userId}/roles`);
    return result.data;
  }

  public async getAllRequests(): Promise<User[]> {
    const requests = await apiClient.get<User[]>(`/users/access-requests`);

    return requests.data;
  }

  public async reviewAccessRequest(status: boolean, requestUserId: string): Promise<User | null> {
    const req = await apiClient.patch<User>(`/users/${requestUserId}/access/${status ? 'approve' : 'deny'}`);

    return req.data;
  }

  public async updateUser(id: string, user: Partial<User>): Promise<User> {
    const result = await apiClient.patch(`/users/${id}`, user);
    return result.data;
  }

  public async saveUserConfig(agreementIds?: string[], assigneeIds?: string[]): Promise<UserConfig> {
    const result = await apiClient.put<UserConfig>(`/users/config`, {
      agreementIds,
      assigneeIds,
    });

    return result.data;
  }

  public async getUserConfig(): Promise<UserConfig> {
    const result = await apiClient.get<UserConfig>(`/users/config`);

    return result.data;
  }

  public async getUsersForDashboard(organizationId: string): Promise<UserIdNamePair[]> {
    const response = await apiClient.get<UserIdNamePair[]>(`/users/organization/${organizationId}`);

    return response.data;
  }
}

export const userService = new UserService();
