/* eslint-disable no-param-reassign */
import axios, { AxiosInstance } from 'axios';
import { SetAuthInput } from '../types/user';
import { refreshTokenService } from './refresh-token.service';
import { Config } from '../types/config';

const refreshTokenBeforeExpiry = 30; // seconds

interface QueueItem {
  resolve: (value?: string | PromiseLike<string | undefined> | undefined) => void;
  reject: (reason?: Error) => void;
}

let failedQueue: Array<QueueItem> = [];
let refreshPromise: Promise<string> | null = null;

const processQueue = (error: Error | null, token: string | null = null) => {
  failedQueue.forEach((promise) => {
    if (error) {
      promise.reject(error);
    } else {
      promise.resolve(token!);
    }
  });
  failedQueue = [];
};

const getAuthFromSessionStorage = (): SetAuthInput | null => {
  const item = sessionStorage.getItem('tenet-auth-token');
  return item ? JSON.parse(item) : null;
};

const getAccessToken = () => {
  const auth: SetAuthInput | null = getAuthFromSessionStorage();
  return auth?.accessToken;
};

const isTokenExpiredOrAboutToExpire = (): boolean => {
  const auth: SetAuthInput | null = getAuthFromSessionStorage();
  if (!auth) {
    return true;
  }
  const expiresAt = new Date(auth.expiresAt).getTime();
  const now = new Date().getTime() / 1000;
  return expiresAt - now < refreshTokenBeforeExpiry;
};

export const createAddressApiClient = (config: Config): AxiosInstance => {
  return axios.create({
    baseURL: config.VITE_CANADA_POST_URL,
  });
};

export const createApiClientWithoutInterceptors = (config: Config): AxiosInstance => {
  return axios.create({
    baseURL: config.VITE_TENET_API_URL,
  });
};

export const createApiClient = (config: Config): AxiosInstance => {
  const instance = axios.create({
    baseURL: config.VITE_TENET_API_URL,
  });

  instance.interceptors.request.use(
    async (reqConfig) => {
      if (isTokenExpiredOrAboutToExpire()) {
        if (!refreshPromise) {
          refreshPromise = refreshTokenService
            .refreshToken(config.VITE_TENET_API_URL)
            .then((newAuth) => {
              processQueue(null, newAuth.accessToken);
              refreshPromise = null;
              return newAuth.accessToken;
            })
            .catch((error) => {
              processQueue(error, null);
              refreshPromise = null;
              throw error;
            });
        }
        try {
          const newToken = await refreshPromise;
          reqConfig.headers.Authorization = `Bearer ${newToken}`;
        } catch (error) {
          return Promise.reject(error);
        }
      } else if (getAccessToken()) {
        reqConfig.headers.Authorization = `Bearer ${getAccessToken()}`;
      }
      return reqConfig;
    },
    (error) => Promise.reject(error),
  );

  return instance;
};

const apiClientContainer: {
  instance: AxiosInstance;
  instanceAddress: AxiosInstance;
  instanceWithoutInterceptors: AxiosInstance;
} = {
  instance: {} as AxiosInstance,
  instanceAddress: {} as AxiosInstance,
  instanceWithoutInterceptors: {} as AxiosInstance,
};

export const setApiClientInstance = (config: Config) => {
  apiClientContainer.instance = createApiClient(config);
  apiClientContainer.instanceAddress = createAddressApiClient(config);
  apiClientContainer.instanceWithoutInterceptors = createApiClientWithoutInterceptors(config);
};

const apiClientProxy = new Proxy({} as AxiosInstance, {
  get(target, prop, receiver) {
    return Reflect.get(apiClientContainer.instance, prop, receiver);
  },
  set(target, prop, value, receiver) {
    return Reflect.set(apiClientContainer.instance, prop, value, receiver);
  },
});

const apiAddressClientProxy = new Proxy({} as AxiosInstance, {
  get(target, prop, receiver) {
    return Reflect.get(apiClientContainer.instanceAddress, prop, receiver);
  },
  set(target, prop, value, receiver) {
    return Reflect.set(apiClientContainer.instanceAddress, prop, value, receiver);
  },
});

const apiClientWithoutInterceptorsProxy = new Proxy({} as AxiosInstance, {
  get(target, prop, receiver) {
    return Reflect.get(apiClientContainer.instanceWithoutInterceptors, prop, receiver);
  },
  set(target, prop, value, receiver) {
    return Reflect.set(apiClientContainer.instanceWithoutInterceptors, prop, value, receiver);
  },
});

export default apiClientProxy;
export { apiAddressClientProxy, apiClientWithoutInterceptorsProxy };
