import { reveal } from 'jest-auto-stub';
import apiClient from './api-client.service';
import { nocCodeService, NocOption } from './noc-code.service';

jest.mock('./api-client.service', () => {
  return {
    __esModule: true,
    default: {
      get: jest.fn(),
    },
  };
});

describe('NocCodeService', () => {
  beforeEach(() => {
    jest.resetAllMocks();
  });

  describe('find', () => {
    it('should fetch NOC options successfully', async () => {
      const mockNocOptions: NocOption[] = [
        { value: '001', label: 'Manager' },
        { value: '002', label: 'Engineer' },
      ];

      reveal(apiClient).get.mockResolvedValueOnce({ data: mockNocOptions });

      const result = await nocCodeService.find('engineer');

      expect(apiClient.get).toHaveBeenCalledWith('/noc/search', {
        params: new URLSearchParams({ query: 'engineer' }),
      });

      expect(result).toEqual(mockNocOptions);
    });

    it('should throw an error if the API call fails', async () => {
      reveal(apiClient).get.mockRejectedValueOnce(new Error('Network Error'));

      await expect(nocCodeService.find('engineer')).rejects.toThrow('Network Error');
    });
  });
});
