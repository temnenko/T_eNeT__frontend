/* eslint-disable no-plusplus */
/* eslint-disable no-underscore-dangle */
/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable @typescript-eslint/no-loop-func */
/* eslint-disable no-restricted-syntax */
/* eslint-disable import/no-cycle */
import { runInAction, observable, computed, makeAutoObservable } from 'mobx';

import { Client, ClientKey, ClientSearchParams, ClientWithFullName } from '../types/client';
import { clientsService } from '../services/clients/clients.service';

export interface IClientsListStore {
  clients: ClientWithFullName[];
  hasNextBatch: boolean;
  totalCount: number;
  currentListPosition: number;
  skipCount: number;
  isLoading: boolean;
  isFiltered: boolean;
}

class ClientsListStore implements IClientsListStore {
  @observable clients: ClientWithFullName[] = [];

  @observable hasNextBatch = true;

  @observable totalCount = 0;

  @observable currentListPosition = 1;

  @observable private listSize = 15;

  @observable skipCount = 0;

  @observable isLoading: boolean = false;

  @observable isFiltered: boolean = false;

  constructor() {
    makeAutoObservable(this);
  }

  getAllClients = async (searchParams?: ClientSearchParams) => {
    const batchSize = this.listSize;
    const { skipCount } = this;
    const { clients, metaData } = await clientsService.getClients(batchSize, skipCount, searchParams);

    runInAction(() => {
      this.clients = clients.map((client) => {
        return {
          ...client,
          clientName: `${client.firstName} ${client.lastName}`,
        };
      });
      this.hasNextBatch = metaData.hasNextBatch;
      this.totalCount = clients.length ?? metaData.totalCount;
      this.isLoading = false;
    });
  };

  hardDeleteClient = async (id: string) => {
    await clientsService.deleteById(id);

    await this.getAllClients();
  };

  setCurrentListPosition = (position: number) => {
    if (this.currentListPosition !== position) {
      this.currentListPosition = position;

      const skip = (position - 1) * this.listSize;

      this.skipCount = skip > 0 ? skip : 0;
    }
  };

  setListSize = (size: number) => {
    if (this.listSize !== size) {
      this.listSize = size;
      this.currentListPosition = 1;
      this.hasNextBatch = true;
      this.skipCount = 0;
    }
  };

  @computed get getListSize() {
    return this.listSize;
  }

  @computed get hasClients() {
    return this.clients.length > 0;
  }

  filterClients = async (searchParams: ClientSearchParams) => {
    runInAction(() => {
      this.isLoading = true;
      this.isFiltered = true;
    });
    await this.getAllClients(searchParams);
  };

  resetClients = async () => {
    runInAction(() => {
      this.totalCount = 0;
      this.clients = [];
      this.isFiltered = false;
    });
  };

  sortData = (sortBy: ClientKey, sortDir: number) => {
    const _clients = [...this.clients];
    _clients.sort((a: Client, b: Client) => {
      return (a[sortBy] > b[sortBy] ? 1 : -1) * sortDir;
    });
    runInAction(() => {
      this.clients = _clients;
    });
  };
}

export default ClientsListStore;
