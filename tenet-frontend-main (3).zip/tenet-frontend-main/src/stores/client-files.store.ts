import { makeAutoObservable, observable, runInAction } from 'mobx';
import { TenetFile, Upload } from '../types/files';
import { fileService } from '../services/clients/client-files.service';

class ClientFilesStore {
  @observable documents: TenetFile[] = [];

  @observable newUploads: Upload[] = [];

  constructor() {
    makeAutoObservable(this);
  }

  getClientDocuments = async (clientId: string) => {
    const documents = await fileService.getClientDocuments(clientId);
    runInAction(() => {
      this.documents = documents?.length
        ? documents
        : this.newUploads.map((file) => {
            return {
              id: file.id,
              adspId: '',
              recordId: '',
              addedByFullName: '',
              fileName: file.file.name,
              typeName: file.fileType,
              size: file.file.size,
              urn: '',
              scanned: false,
              infected: false,
              securityClassification: '',
              adspCreatedAt: file.createdAt,
              createdAt: file.createdAt,
              updatedAt: new Date().toISOString(),
            };
          });
    });
  };

  deleteDocument = async (id: string) => {
    runInAction(() => {
      this.newUploads = this.newUploads.filter((doc) => doc.id !== id);
    });
  };

  resetFiles = async () => {
    runInAction(() => {
      this.newUploads = [];
      this.documents = [];
    });
  };

  uploadClientDocuments = async (clientId: string) => {
    const newFiles = this.newUploads.filter(
      (newFile, index, self) => index === self.findIndex((f) => f.id === newFile.id),
    );

    if (newFiles.length === 0) {
      return;
    }

    await fileService.uploadFiles(clientId, newFiles);

    const documents = await fileService.getFiles(clientId);

    runInAction(() => {
      this.documents = documents;
      this.newUploads = [];
    });
  };

  addToNewUploads = (upload: Upload) => {
    const existingUpload = this.newUploads.find((u) => u.id === upload.id);
    runInAction(() => {
      if (existingUpload) {
        existingUpload.fileType = upload.fileType;
        const doc = this.documents.find((u) => u.id === upload.id);
        if (doc) {
          doc.typeName = upload.fileType;
        }
      } else {
        this.newUploads.push(upload);

        this.documents.push({
          id: upload.id,
          adspId: '',
          recordId: '',
          addedByFullName: '',
          fileName: upload.file.name,
          typeName: upload.fileType,
          size: upload.file.size,
          urn: '',
          scanned: false,
          infected: false,
          securityClassification: '',
          adspCreatedAt: upload.createdAt,
          createdAt: upload.createdAt,
          updatedAt: new Date().toISOString(),
        });
      }
    });
  };
}

export default ClientFilesStore;
