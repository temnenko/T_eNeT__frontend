import { observable, makeAutoObservable } from 'mobx';

import { TabsState, TabsTextState } from '../types/client-forms';
import { AssessmentFormStepperKeys } from '../types/assessment-forms';

type IAssessmentFormStepper = {
  tab: TabsState;
  tabText: TabsTextState;
};

export interface IAssessmentFormSteppers {
  type: IAssessmentFormStepper;
  need: IAssessmentFormStepper;
  employment: IAssessmentFormStepper;
  jobSearch: IAssessmentFormStepper;
  service: IAssessmentFormStepper;
  files: IAssessmentFormStepper;
  review: IAssessmentFormStepper;
}

export interface IAssessmentFormStepperStore {
  steppers: IAssessmentFormSteppers;
  currentlyActive: AssessmentFormStepperKeys;
}

const defaultSteppersValue: Record<AssessmentFormStepperKeys, IAssessmentFormStepper> = {
  [AssessmentFormStepperKeys.TYPE]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AssessmentFormStepperKeys.NEED]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AssessmentFormStepperKeys.EMPLOYMENT]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AssessmentFormStepperKeys.JOB_SEARCH]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AssessmentFormStepperKeys.SERVICE]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AssessmentFormStepperKeys.FILES]: {
    tab: TabsState.OPTIONAL,
    tabText: TabsTextState.DEFAULT,
  },
  [AssessmentFormStepperKeys.REVIEW]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
};

const initialSteppersValue: Record<AssessmentFormStepperKeys, IAssessmentFormStepper> = {
  ...defaultSteppersValue,
  [AssessmentFormStepperKeys.TYPE]: {
    tab: TabsState.ACTIVE,
    tabText: TabsTextState.ACTIVE,
  },
};

class AssessmentFormStepperStore implements IAssessmentFormStepperStore {
  @observable steppers: IAssessmentFormSteppers = initialSteppersValue;

  @observable currentlyActive: AssessmentFormStepperKeys = AssessmentFormStepperKeys.TYPE;

  constructor() {
    makeAutoObservable(this);
    this.initializeSteps();
  }

  initializeSteps = () => {
    this.active(AssessmentFormStepperKeys.TYPE);
  };

  setActiveStep = (key: AssessmentFormStepperKeys) => {
    this.active(key);
  };

  reset = (key: AssessmentFormStepperKeys) => {
    if (this.steppers[key].tab === TabsState.DONE) {
      this.steppers[key].tabText = TabsTextState.DONE;

      return;
    }

    this.steppers[key] = defaultSteppersValue[key];
  };

  active = (key: AssessmentFormStepperKeys) => {
    this.reset(this.currentlyActive);
    this.currentlyActive = key;
    sessionStorage.setItem('activeStepperKey', key);

    if (this.steppers[key].tab === TabsState.DONE) {
      this.steppers[key].tabText = TabsTextState.ACTIVE;

      return;
    }

    this.steppers[key] = {
      tab: TabsState.ACTIVE,
      tabText: TabsTextState.ACTIVE,
    };
  };

  done = (key: AssessmentFormStepperKeys) => {
    this.steppers[key] = {
      tab: TabsState.DONE,
      tabText: TabsTextState.DONE,
    };
  };

  next = (): AssessmentFormStepperKeys | undefined => {
    const keys = Object.keys(this.steppers) as AssessmentFormStepperKeys[];
    const currentIndex = keys.indexOf(this.currentlyActive);
    const nextKey = keys[currentIndex + 1] as AssessmentFormStepperKeys;

    if (currentIndex === keys.length - 1) {
      return undefined;
    }

    this.done(this.currentlyActive);
    this.active(nextKey);

    return nextKey;
  };

  previous = (): AssessmentFormStepperKeys | undefined => {
    const keys = Object.keys(this.steppers) as AssessmentFormStepperKeys[];
    const currentIndex = keys.indexOf(this.currentlyActive);
    const previousKey = keys[currentIndex - 1] as AssessmentFormStepperKeys;

    if (currentIndex === 0) {
      return undefined;
    }

    this.reset(this.currentlyActive);
    this.active(previousKey);

    return previousKey;
  };
}

export default AssessmentFormStepperStore;
