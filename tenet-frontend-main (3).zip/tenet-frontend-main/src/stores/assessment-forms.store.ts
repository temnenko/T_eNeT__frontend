import { computed, makeAutoObservable, observable, runInAction } from 'mobx';
import { Assessment, CreateAssessment, UpdateAssessment } from '../types/assessment';
import { assessmentService } from '../services/clients/assessment.service';

export class AssessmentFormStore {
  @observable assessment: Assessment | undefined;

  @observable assessmentWatch: Record<string, unknown> | undefined;

  constructor() {
    makeAutoObservable(this);
    this.assessmentWatch = {};
  }

  resetAssessment = () => {
    this.assessment = undefined;
    this.assessmentWatch = {};
  };

  loadAssessment = async (assessmentId: string) => {
    const assessment = await assessmentService.getById(assessmentId);
    runInAction(() => {
      this.assessment = assessment;
    });
  };

  watchAssessment = <T>(field: string, value: T) => {
    this.assessmentWatch![field] = value;
  };

  retrieveAssessment = <T>(field: string): T => {
    return this.assessmentWatch![field]! as T;
  };

  createAssessment = async (assessment: CreateAssessment) => {
    const newAssessment = await assessmentService.create(assessment);

    runInAction(() => {
      this.assessment = newAssessment;
    });

    return newAssessment;
  };

  updateAssessment = async (assessmentId: string, assessment: UpdateAssessment) => {
    const updatedAssessment = await assessmentService.update(assessmentId, assessment);

    runInAction(() => {
      this.assessment = updatedAssessment;
    });
  };

  completeAssessment = async (assessmentId: string) => {
    const completedAssessment = await assessmentService.complete(assessmentId);

    runInAction(() => {
      this.assessment = completedAssessment;
    });
  };

  @computed get assessmentNeedsString() {
    if (!this.assessment) return '';

    const needs = [
      this.assessment.workExperience && 'Work Experience',
      this.assessment.careerPlanning && 'Career Planning',
      this.assessment.educationAndTraining && 'Education and Training',
      this.assessment.jobSearchAssistance && 'Job Search Assistance',
      this.assessment.careerAdvice && 'Career Advice',
      this.assessment.selfEmployment && 'Self Employment',
      this.assessment.laborMarketInformation && 'Labor Market Information',
      this.assessment.foreignCredentialRecognition && 'Foreign Credential Recognition',
    ].filter(Boolean);

    return needs.join(', ');
  }
}
