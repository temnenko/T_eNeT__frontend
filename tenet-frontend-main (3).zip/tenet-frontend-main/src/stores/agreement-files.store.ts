import { makeAutoObservable, observable, runInAction } from 'mobx';
import { TenetFile, Upload } from '../types/files';
import { InvalidFileUploadError } from '../types/errors/invalid-file-upload.error';
import { fileService } from '../services/clients/client-files.service';

class AgreementFilesStore {
  @observable documents: TenetFile[] = [];

  @observable newUploads: Upload[] = [];

  constructor() {
    makeAutoObservable(this);
  }

  resetStore = () => {
    this.documents = [];
    this.newUploads = [];
  };

  getAgreementDocuments = async (agreementId: string) => {
    const documents = await fileService.getFiles(agreementId);
    runInAction(() => {
      this.documents = documents;
    });
  };

  deleteDocument = async (adspId: string) => {
    await fileService.deleteFile(adspId);
    runInAction(() => {
      this.documents = this.documents.filter((doc) => doc.adspId !== adspId);
    });
  };

  removeDocumentFromUploads = (id: string) => {
    this.newUploads = this.newUploads.filter((upload) => upload.id !== id);
  };

  uploadAgreementDocuments = async (agreementId: string): Promise<TenetFile[]> => {
    const newFiles = this.newUploads.filter(
      (newFile, index, self) => index === self.findIndex((f) => f.id === newFile.id),
    );

    if (newFiles.length === 0) {
      return [];
    }

    if (newFiles.some((f) => !f.fileType)) {
      throw new InvalidFileUploadError('Select a file type');
    }

    const documents = (await fileService.uploadFiles(agreementId, newFiles)).map((doc) => ({
      ...doc,
      persisted: true,
    }));

    runInAction(() => {
      this.documents = this.documents.concat(documents);
      this.newUploads = [];
    });

    return this.documents;
  };

  addToNewUploads = async (upload: Upload) => {
    const existingUpload = this.newUploads.find((u) => u.id === upload.id);
    if (existingUpload) {
      existingUpload.fileType = upload.fileType;
    } else {
      this.newUploads.push(upload);
    }
  };
}

export default AgreementFilesStore;
