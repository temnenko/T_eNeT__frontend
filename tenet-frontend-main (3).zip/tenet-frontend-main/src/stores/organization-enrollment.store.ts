/* eslint-disable class-methods-use-this */
import { runInAction, observable, makeAutoObservable } from 'mobx';
import { organizationService } from '../services/organizations/organization.service';
import { Contact, Location, OrganizationComplianceFilesTypeMap } from '../types/organization';
import { Upload } from '../types/files';
import { fileService } from '../services/clients/client-files.service';
import { getEnumKeyByValue } from '../utils/enums.util';

type IOrganization = {
  id: string;
  operatingName: string;
  legalName: string;
  emailAddress: string;
  website: string;
  createdAt: string;
  updatedAt: string;
  businessIdentifier: string;
  contacts?: Contact[];
  locations?: Location[];
  partnerNumber?: string;
  phoneNumber?: string;
  firstUserName?: string;
  firstUserEmail?: string;
  corporateIdentityNumber?: string;
  corporateIdentityDocuments?: Upload[];
  lobbyistCheckedDate?: Date;
  lobbyistCheckProof?: Upload[];
  wcbVerifiedOn?: Date;
  wcbVerificationProof?: Upload[];
  liabilityPolicyExpiresOn?: Date;
  liabilityPolicyProof?: Upload[];
  privacyAssessmentCompletedOn?: Date;
  assessmentResult?: Upload[];
};

export interface IOrganizationEnrollmentStore {
  selectedOrganization?: IOrganization;
  corporateIdentityDocuments?: Upload[];
  lobbyistCheckProof?: Upload[];
  wcbVerificationProof?: Upload[];
  liabilityPolicyProof?: Upload[];
  assessmentResult?: Upload[];
  lobbyistCheckDate?: Date;
  wcbVerifiedOn?: Date;
  liabilityPolicyExpiresOn?: Date;
  assessmentCompletedOn?: Date;
}

export type ComplianceFileFields =
  | 'corporateIdentityDocuments'
  | 'lobbyistCheckProof'
  | 'wcbVerificationProof'
  | 'liabilityPolicyProof'
  | 'assessmentResult';

class OrganizationEnrollmentStore implements IOrganizationEnrollmentStore {
  @observable selectedOrganization?: IOrganization = undefined;

  @observable corporateIdentityDocuments?: Upload[] = [];

  @observable lobbyistCheckProof?: Upload[] = [];

  @observable wcbVerificationProof?: Upload[] = [];

  @observable liabilityPolicyProof?: Upload[] = [];

  @observable assessmentResult?: Upload[] = [];

  @observable lobbyistCheckDate?: Date;

  @observable wcbVerifiedOn?: Date;

  @observable liabilityPolicyExpiresOn?: Date;

  @observable assessmentCompletedOn?: Date;

  @observable orgWatch: Record<string, unknown> | undefined;

  constructor() {
    makeAutoObservable(this);
    this.orgWatch = {};
  }

  resetStore = () => {
    this.selectedOrganization = undefined;
    this.corporateIdentityDocuments = [];
    this.lobbyistCheckProof = [];
    this.wcbVerificationProof = [];
    this.liabilityPolicyProof = [];
    this.assessmentResult = [];
    this.assessmentCompletedOn = undefined;
    this.liabilityPolicyExpiresOn = undefined;
    this.lobbyistCheckDate = undefined;
    this.wcbVerifiedOn = undefined;
    this.orgWatch = {};
  };

  watchOrg = <T>(field: string, value: T) => {
    this.orgWatch![field] = value;
  };

  retrieveOrg = <T>(field: string): T => {
    return this.orgWatch![field]! as T;
  };

  getOrganizationById = async (organizationId: string) => {
    const organization = await organizationService.getOrganizationById(organizationId);

    runInAction(() => {
      this.selectedOrganization = organization;
    });
  };

  updateOrganization = async (organization: IOrganization) => {
    const {
      corporateIdentityDocuments,
      lobbyistCheckProof,
      wcbVerificationProof,
      liabilityPolicyProof,
      assessmentResult,
      ...nofiles
    } = organization;

    const updatedOrganization = await organizationService.updateOrganization(nofiles);

    runInAction(() => {
      this.selectedOrganization = updatedOrganization;
      this.corporateIdentityDocuments = corporateIdentityDocuments?.length
        ? corporateIdentityDocuments
        : this.corporateIdentityDocuments;
      this.lobbyistCheckProof = lobbyistCheckProof?.length ? lobbyistCheckProof : this.lobbyistCheckProof;
      this.wcbVerificationProof = wcbVerificationProof?.length ? wcbVerificationProof : this.wcbVerificationProof;
      this.liabilityPolicyProof = liabilityPolicyProof?.length ? liabilityPolicyProof : this.liabilityPolicyProof;
      this.assessmentResult = assessmentResult?.length ? assessmentResult : this.assessmentResult;
    });
  };

  completeOrganizationEnrollment = async () => {
    const updatedOrganization = await organizationService.completeOrganization(this.selectedOrganization!.id);

    runInAction(() => {
      this.selectedOrganization = updatedOrganization;
    });
  };

  deleteOrganizationContact = async (id: string) => {
    if (this.selectedOrganization?.id) {
      await organizationService.deleteOrganizationContact(this.selectedOrganization?.id, id);
    }
  };

  deleteOrganizationLocation = async (id: string) => {
    if (this.selectedOrganization?.id) {
      await organizationService.deleteOrganizationLocation(this.selectedOrganization?.id, id);
    }
  };

  updateOrganizationContact = async (contact: Partial<Contact>[], orgId: string) => {
    const updatedContact = await organizationService.updateOrganizationContact(
      this.selectedOrganization?.id ?? orgId,
      contact,
    );
    return updatedContact;
  };

  createOrganization = async (organization: IOrganization) => {
    const createdOrganization = await organizationService.createOrganization(organization);

    runInAction(() => {
      this.selectedOrganization = createdOrganization;
    });

    return createdOrganization;
  };

  uploadFiles = async (files: Upload[], uploadType: OrganizationComplianceFilesTypeMap) => {
    const result = await fileService.uploadFiles(this.selectedOrganization!.id, files);

    const uploadedFiles: Upload[] = result.map((res) => ({
      id: res.id,
      file: new File([], res.fileName),
      uploader: { onprogress: () => {} },
      fileType: uploadType,
      createdAt: res.adspCreatedAt,
      size: res.size || 0,
      addedByFullName: res.addedByFullName,
      adspId: res.adspId,
    }));

    runInAction(() => {
      const propertyKey = getEnumKeyByValue(
        OrganizationComplianceFilesTypeMap,
        uploadType,
      ) as keyof IOrganizationEnrollmentStore;
      if (Array.isArray(this[propertyKey]) && this[propertyKey] instanceof Array) {
        (this[propertyKey] as Upload[]).push(...uploadedFiles);
      }
    });

    return result;
  };

  fetchFiles = async () => {
    if (!this.selectedOrganization?.id) {
      return [];
    }
    const files = await fileService.getFiles(this.selectedOrganization?.id);
    const uploads: Upload[] = files.map((file) => ({
      id: file.id,
      file: new File([], file.fileName),
      uploader: { onprogress: () => {} },
      fileType: file.typeName,
      createdAt: file.adspCreatedAt,
      size: file.size,
      addedByFullName: file.addedByFullName,
      adspId: file.adspId,
    }));

    runInAction(() => {
      this.corporateIdentityDocuments = uploads.filter(
        (upload) => upload.fileType === OrganizationComplianceFilesTypeMap.corporateIdentityDocuments,
      );
      this.lobbyistCheckProof = uploads.filter(
        (upload) => upload.fileType === OrganizationComplianceFilesTypeMap.lobbyistCheckProof,
      );
      this.wcbVerificationProof = uploads.filter(
        (upload) => upload.fileType === OrganizationComplianceFilesTypeMap.wcbVerificationProof,
      );
      this.liabilityPolicyProof = uploads.filter(
        (upload) => upload.fileType === OrganizationComplianceFilesTypeMap.liabilityPolicyProof,
      );
      this.assessmentResult = uploads.filter(
        (upload) => upload.fileType === OrganizationComplianceFilesTypeMap.assessmentResult,
      );
    });

    return uploads;
  };

  removeFile = async (upload: Upload, uploadType: OrganizationComplianceFilesTypeMap) => {
    await fileService.deleteFile(upload.adspId);

    runInAction(() => {
      const propertyKey = getEnumKeyByValue(
        OrganizationComplianceFilesTypeMap,
        uploadType,
      ) as keyof IOrganizationEnrollmentStore;

      if (Array.isArray(this[propertyKey]) && this[propertyKey] instanceof Array) {
        (this[propertyKey] as Upload[]).splice((this[propertyKey] as Upload[]).indexOf(upload), 1);
      }
    });
  };
}

export default OrganizationEnrollmentStore;
