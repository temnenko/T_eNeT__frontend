/* eslint-disable no-console */
/* eslint-disable class-methods-use-this */
/* eslint-disable import/no-cycle */
import { runInAction, observable, makeAutoObservable, computed } from 'mobx';

import { sortByDate } from '../utils/sortbydate.util';
import { clientsService } from '../services/clients/clients.service';
import { educationService } from '../services/clients/education.service';
import { employmentService } from '../services/clients/employment.service';
import { lmdaService } from '../services/clients/lmda.service';
import {
  ClientAddressRecord,
  ClientVerificationRecord,
  Demographic,
  Education,
  EducationArgs,
  EmailAddress,
  Employment,
  EmploymentArgs,
  Factors,
  Language,
  LmdaSubscription,
  Phone,
  PreviousName,
  SinRecord,
  UpdateEducationArgs,
} from '../types/client';
import RootStore from './root.store';
import { servicePlanService } from '../services/clients/service-plan.service';

type IClient = {
  id: string;
  tenetNumber: string;
  firstName: string;
  lastName: string;
  middleName?: string;
  dateOfBirth: string;
  sinRecords: SinRecord[];
  language: Language;
  demographic?: Demographic;
  factors?: Factors;
  addresses: ClientAddressRecord[];
  phones: Phone[];
  emailAddresses: EmailAddress[];
  educations?: Education[];
  employmentHistory?: Employment[];
  educationHistory?: Education[];
  foipConsentedAt?: string;
  wcbAcknowledgedAt?: string;
  completedAt?: Date;
  previousName?: PreviousName;
  supportType?: string;
  currentInvolvement?: string;
  currentInvolvementId?: string;
  createdBy?: string;
  agreementName?: string;
};

export interface IClientsStore {
  selectedClient?: IClient;
  employmentHistory?: Employment[];
  employment?: Employment;
  clientLmdaVerificationRecords?: ClientVerificationRecord[];
  lmdaSubscription?: LmdaSubscription;
  hasNextLmdaBatch: boolean;
  totalLmdaCount: number;
  currentLmdaListPosition: number;
  skipLmdaCount: number;
  educationHistory?: Education[];
  education?: Education;
}

class ClientsStore implements IClientsStore {
  rootStore: RootStore;

  @observable selectedClient?: IClient = undefined;

  @observable employmentHistory?: Employment[] = [];

  @observable employment?: Employment | undefined;

  @observable lmdaVerificationRecords: ClientVerificationRecord[] = [];

  @observable lmdaSubscription?: LmdaSubscription | undefined;

  @observable educationHistory: Education[] = [];

  @observable education?: Education | undefined;

  hasNextLmdaBatch: boolean = true;

  hasNextEducationBatch: boolean = true;

  totalLmdaCount: number = this.lmdaVerificationRecords?.length;

  totalEducationHistoryCount: number = this.educationHistory?.length;

  currentEducationHistoryPosition: number = 1;

  currentLmdaListPosition: number = 1;

  @observable private lmdaListSize = 10;

  @observable skipLmdaCount = 0;

  @observable private educationHistorySize = 10;

  @observable skipEducationCount = 0;

  @observable hasNextEmploymentBatch = true;

  @observable totalEmploymentCount = 0;

  @observable currentEmploymentListPosition = 1;

  @observable private employmentListSize = 10;

  @observable skipEmploymentCount = 0;

  constructor(rootStore: RootStore) {
    makeAutoObservable(this, { rootStore: false });
    this.rootStore = rootStore;
  }

  unsetSelectedClient = () => {
    this.selectedClient = undefined;
  };

  getEducationHistorySize = () => {
    return this.educationHistorySize;
  };

  getClientById = async (clientId: string) => {
    const {
      id,
      tenetNumber,
      firstName,
      lastName,
      middleName,
      dateOfBirth,
      sinRecords,
      language,
      addresses,
      emailAddresses,
      factors,
      phones,
      demographic,
      foipConsentedAt,
      wcbAcknowledgedAt,
      completedAt,
      previousName,
      currentInvolvement,
      currentInvolvementId,
      supportType,
      agreementName,
    } = await clientsService.getById(clientId);

    runInAction(() => {
      this.selectedClient = {
        id,
        tenetNumber,
        firstName,
        lastName,
        middleName,
        dateOfBirth,
        sinRecords,
        language,
        addresses,
        emailAddresses,
        phones,
        factors,
        demographic,
        foipConsentedAt,
        wcbAcknowledgedAt,
        completedAt,
        previousName,
        currentInvolvement,
        currentInvolvementId,
        supportType,
        agreementName,
      };
    });
  };

  getEmploymentHistoryById = async (id: string, archived?: boolean) => {
    if (this.selectedClient?.id) {
      const empHistory = await employmentService.getEmploymentHistoryById(id, archived);
      runInAction(() => {
        this.employment = empHistory;
      });
    }
  };

  getClientEmploymentHistory = async (clientId: string, archived?: boolean) => {
    const { employments, metaData } = await employmentService.getEmploymentHistory(
      clientId,
      archived,
      this.employmentListSize,
      this.skipEmploymentCount,
    );

    runInAction(() => {
      this.employmentHistory = sortByDate(employments);
      this.hasNextEmploymentBatch = metaData.hasNextBatch;
      this.totalEmploymentCount = metaData.totalCount;
    });
  };

  setCurrentEmploymentListPosition = (position: number) => {
    if (this.currentEmploymentListPosition !== position) {
      this.currentEmploymentListPosition = position;

      const skip = (position - 1) * this.employmentListSize;

      this.skipEmploymentCount = skip > 0 ? skip : 0;
    }
  };

  setEmploymentListSize = (size: number) => {
    if (this.employmentListSize !== size) {
      this.employmentListSize = size;
      this.currentEmploymentListPosition = 1;
      this.hasNextEmploymentBatch = true;
      this.skipEmploymentCount = 0;
    }
  };

  @computed get getEmploymentListSize() {
    return this.employmentListSize;
  }

  getEducations = async (clientId: string, archived?: boolean) => {
    const { educationHistory, metaData } = await educationService.getEducations(
      clientId,
      archived,
      this.educationHistorySize,
      this.skipEducationCount,
    );

    runInAction(() => {
      this.educationHistory = sortByDate(educationHistory);
      this.hasNextEducationBatch = metaData.hasNextBatch;
      this.totalEducationHistoryCount = metaData.totalCount;
    });
  };

  getEducationById = async (id: string, archived?: boolean) => {
    if (this.selectedClient?.id) {
      const empHistory = await educationService.getEducationHistoryById(id, archived);
      runInAction(() => {
        this.education = empHistory;
      });
    }
  };

  setEducationHistorySize = (size: number) => {
    if (this.educationHistorySize !== size) {
      this.educationHistorySize = size;
      this.currentEducationHistoryPosition = 1;
      this.hasNextEducationBatch = true;
      this.skipEducationCount = 0;
    }
  };

  setCurrentEducationHistoryPosition = (position: number) => {
    if (this.currentEducationHistoryPosition !== position) {
      this.currentEducationHistoryPosition = position;

      const skip = (position - 1) * this.educationHistorySize;

      this.skipEducationCount = skip > 0 ? skip : 0;
    }
  };

  getClientLmdaVerificationRecords = async (clientId: string) => {
    const lmdaRecords = await clientsService.getClientLmdaVerificationRecords(
      clientId,
      this.lmdaListSize,
      this.skipLmdaCount,
    );

    runInAction(() => {
      this.lmdaVerificationRecords = lmdaRecords.results;
      this.hasNextLmdaBatch = lmdaRecords.metaData.hasNextBatch;
      this.totalLmdaCount = lmdaRecords.metaData.totalCount;
    });
  };

  @computed get hasLmdaVerificationRecords() {
    return this.lmdaVerificationRecords.length > 0;
  }

  setCurrentLmdaListPosition = (position: number) => {
    if (this.currentLmdaListPosition !== position) {
      this.currentLmdaListPosition = position;

      const skip = (position - 1) * this.lmdaListSize;

      this.skipLmdaCount = skip > 0 ? skip : 0;
    }
  };

  setLmdaListSize = (size: number) => {
    if (this.lmdaListSize !== size) {
      this.lmdaListSize = size;
      this.currentLmdaListPosition = 1;
      this.hasNextLmdaBatch = true;
      this.skipLmdaCount = 0;
    }
  };

  @computed get getLmdaListSize() {
    return this.lmdaListSize;
  }

  getUserLmdaSubscriptions = async (clientId: string) => {
    const res = await lmdaService.getLmdaSubscription(clientId);
    runInAction(() => {
      this.lmdaSubscription = res;
    });
  };

  unsubscribeLmdaMonitoring = async (id: string) => {
    await lmdaService.removeLmdaSubscription(id);
    runInAction(() => {
      this.lmdaSubscription = undefined;
    });
  };

  subscribeToLmdaVerification = async (clientId: string, sinRecordId: string, subscriptionStopDate: Date) => {
    const res = await lmdaService.subscribeToLmdaVerification(clientId, sinRecordId, subscriptionStopDate);
    runInAction(() => {
      this.lmdaSubscription = res;
    });
  };

  updateLmdaSubsciptionDate = async (id: string, subscriptionStopDate: Date) => {
    const res = await lmdaService.updateSubscription(id, subscriptionStopDate);
    runInAction(() => {
      this.lmdaSubscription = res;
    });
  };

  verifyLmda = async (sinRecordId: string) => {
    const result = await lmdaService.verify(sinRecordId);

    runInAction(() => {
      this.lmdaVerificationRecords?.push(result);
    });
  };

  archiveEmployment = async (id: string, archived: boolean) => {
    await employmentService.archiveEmployment(id, archived);
  };

  archiveEducation = async (id: string, archived: boolean) => {
    await educationService.archiveEducation(id, archived);
  };

  deleteEmployment = async (id: string) => {
    await employmentService.hardDeleteEmployment(id);

    runInAction(() => {
      this.employmentHistory = this.employmentHistory?.filter((emp) => emp.id !== id);
    });
  };

  setEmploymentHistory = async (
    clientId: string,
    employmentHistory: EmploymentArgs,
    employmentId: string,
    servicePlanId?: string,
  ) => {
    try {
      if (employmentId) {
        await employmentService.updateEmploymentHistory(employmentId, employmentHistory);
      } else {
        const history = await employmentService.createEmploymentHistory(clientId, employmentHistory);
        if (this.rootStore.servicePlanStore.servicePlan?.clientId && servicePlanId) {
          await servicePlanService.update(servicePlanId, this.rootStore.servicePlanStore.servicePlan?.clientId, {
            employmentId: history.id,
          });
        }
        runInAction(() => {
          if (
            this.rootStore.servicePlanStore.servicePlan &&
            this.selectedClient?.id === this.rootStore.servicePlanStore.servicePlan.clientId
          ) {
            this.rootStore.servicePlanStore.servicePlan.employmentId = history.id;
            this.rootStore.servicePlanStore.employmentAdded = true;
          }
        });
      }
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    } finally {
      await this.getClientEmploymentHistory(clientId);
    }
  };

  setEducationHistory = async (clientId: string, educationHistory: EducationArgs) => {
    try {
      await educationService.createEducationHistory(clientId, educationHistory);
    } catch (error) {
      console.log(error);
    } finally {
      await this.getEducations(clientId);
    }
  };

  updateEducationHistory = async (clientId: string, educationHistory: UpdateEducationArgs, educationId: string) => {
    try {
      await educationService.updateEducationHistory(educationId, educationHistory);
    } catch (error) {
      console.log(error);
    } finally {
      await this.getEducations(clientId);
    }
  };

  deleteEducation = async (id: string) => {
    await educationService.hardDeleteEducation(id);

    runInAction(() => {
      this.educationHistory = this.educationHistory?.filter((edu) => edu.id !== id);
    });
  };

  saveClientAddresses = async (addresses: ClientAddressRecord[]) => {
    const data = await clientsService.saveClientAddresses(this.selectedClient!.id, addresses ?? []);

    runInAction(() => {
      this.selectedClient!.addresses = data;
    });
  };

  saveClientContactDetails = async (emailAddresses: EmailAddress[], phones: Phone[]) => {
    const data = await clientsService.saveClientContactDetails(
      this.selectedClient!.id!,
      emailAddresses ?? [],
      phones ?? [],
    );

    runInAction(() => {
      this.selectedClient!.emailAddresses = data.emailAddresses;
      this.selectedClient!.phones = data.phones;
    });
  };
}

export default ClientsStore;
