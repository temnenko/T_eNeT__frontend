/* eslint-disable class-methods-use-this */
/* eslint-disable prefer-template */
import { makeAutoObservable, observable, runInAction } from 'mobx';
import type RootStore from '../../root.store';
import { reportService } from '../../../services/organizations/agreement-report.service';
import type { SortableReportField } from '../../../services/organizations/agreement-report.service';
import { CreateAgreementReportRequest, AgreementReportRequest } from '../../../types/agreement-report';
import type { SortOrder } from '../../../types/sort-order';

export class AgreementReportStore {
  rootStore: RootStore;

  @observable reportRequests: AgreementReportRequest[] = [];

  @observable skipCount = 0;

  @observable batchSize = 10;

  @observable sortBy: SortableReportField = 'dateRequested';

  @observable sortOrder: SortOrder = 'desc';

  @observable hasNextBatch = false;

  @observable totalCount = 0;

  constructor(rootStore: RootStore) {
    makeAutoObservable(this);
    this.rootStore = rootStore;
  }

  setCurrentReportPosition = (position: number) => {
    const skipCount = (position - 1) * this.batchSize;
    if (this.skipCount !== skipCount) {
      this.skipCount = skipCount;
      this.getReportRequests(this.rootStore.agreementStore.selectedAgreement?.id || '');
    }
  };

  setCurrentReportBatchSize = (newSize: number) => {
    if (this.batchSize !== newSize) {
      this.batchSize = newSize;
      this.getReportRequests(this.rootStore.agreementStore.selectedAgreement?.id || '');
    }
  };

  requestReport = async (agreementId: string, payload: CreateAgreementReportRequest) => {
    await reportService.requestReport(agreementId, payload);
    runInAction(() => {
      this.getReportRequests(agreementId);
    });
  };

  getReportRequests = async (agreementId: string) => {
    const filters = {
      batchSize: this.batchSize,
      skipCount: this.skipCount,
      sortBy: this.sortBy,
      sortOrder: this.sortOrder,
    };
    const requests = await reportService.getReportRequests(agreementId, filters);
    runInAction(() => {
      this.reportRequests = requests.reportRequests;
      this.hasNextBatch = requests.metaData.hasNextBatch;
      this.totalCount = requests.metaData.totalCount;
    });
  };

  getReportDetails = async (requestId: string) => {
    await reportService.downloadReportByRequestId(requestId);
  };
}
