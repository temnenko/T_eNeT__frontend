/* eslint-disable import/no-cycle */
import { computed, makeAutoObservable, observable, runInAction } from 'mobx';

import type {
  Agreement,
  GetAgreementClientsArgs,
  GetMetricsArgs,
  Metrics,
  UpdateAgreement,
} from '../../../types/agreement';
import {
  AgreementActivity,
  AgreementActivityFilters,
  AgreementClient,
  AgreementFilters,
  agreementService,
} from '../../../services/organizations/agreement.service';
import { fileService } from '../../../services/clients/client-files.service';
import { TenetFile } from '../../../types/files';
import { CreateContact } from '../../../types/organization';
import RootStore from '../../root.store';
import { organizationService } from '../../../services/organizations/organization.service';

export interface IAgreementStore {
  selectedAgreement?: Agreement;
  metrics?: Metrics;
}

export class AgreementStore implements IAgreementStore {
  rootStore: RootStore;

  @observable selectedAgreement?: Agreement = undefined;

  @observable metrics?: Metrics = undefined;

  @observable documents: TenetFile[] = [];

  @observable agreementClients: AgreementClient[] = [];

  @observable clientsCurrentListPosition: number = 1;

  @observable clientsHasNextBatch: boolean = true;

  @observable clientsBatchSize: number = 15;

  @observable clientsSkipCount: number = 0;

  @observable includeInactive: boolean = false;

  @observable clientsSortObject: Record<string, 'asc' | 'desc'> = {
    startDate: 'desc',
  };

  @observable clientsTotalCount: number = this.agreementClients.length;

  @observable agreementActivities: AgreementActivity[] = [];

  @observable activityCurrentListPosition: number = 1;

  @observable activityHasNextBatch: boolean = true;

  @observable activityBatchSize: number = 15;

  @observable activitySkipCount: number = 0;

  @observable activityTotalCount: number = this.agreementClients.length;

  constructor(rootStore: RootStore) {
    makeAutoObservable(this);
    this.rootStore = rootStore;
  }

  unsetSelectedAgreement = () => {
    this.selectedAgreement = undefined;
    this.metrics = undefined;
    this.documents = [];
    this.agreementClients = [];
    this.clientsCurrentListPosition = 1;
    this.clientsBatchSize = 15;
    this.clientsSkipCount = 0;
    this.clientsTotalCount = 0;
    this.includeInactive = false;
    this.clientsHasNextBatch = true;
    this.clientsSortObject = {
      startDate: 'desc',
    };
    this.activityCurrentListPosition = 1;
    this.activityBatchSize = 15;
    this.activitySkipCount = 0;
    this.activityTotalCount = 0;
    this.activityHasNextBatch = true;
  };

  getAgreementById = async (agreementId: string) => {
    const {
      id,
      organizationId,
      programType,
      serviceLanguage,
      name,
      agreementNumber,
      startDate,
      lastIntakeDate,
      endDate,
      activeInterventionLength,
      amendmentOption,
      participantsMaxNumber,
      targetLmdaWdaSplit,
      targetGroups,
      targetSectors,
      economicRegions,
      communitiesServed,
      locations,
      contacts,
      creationCompleted,
      completedAt,
      interventionCredential,
    } = await agreementService.getById(agreementId);

    runInAction(() => {
      this.selectedAgreement = {
        id,
        organizationId,
        programType,
        serviceLanguage,
        name,
        agreementNumber,
        startDate,
        lastIntakeDate,
        endDate,
        activeInterventionLength,
        amendmentOption,
        participantsMaxNumber,
        targetLmdaWdaSplit,
        targetGroups,
        targetSectors,
        economicRegions,
        communitiesServed,
        locations,
        contacts,
        creationCompleted,
        completedAt,
        interventionCredential,
      };
    });
  };

  getAgreementClients = async (args: GetAgreementClientsArgs, filters: AgreementFilters) => {
    const result = await agreementService.getClientsByAgreementId(args, filters);

    runInAction(() => {
      this.agreementClients = result.clients;
      this.clientsTotalCount = result.metaData.totalCount;
      this.clientsHasNextBatch = result.metaData.hasNextBatch;
    });
  };

  setIncludeInactive = (value: boolean) => {
    this.includeInactive = value;
  };

  setClientsCurrentListPosition = (position: number) => {
    if (this.clientsCurrentListPosition !== position) {
      this.clientsCurrentListPosition = position;

      const skip = (position - 1) * this.clientsBatchSize;

      this.clientsSkipCount = skip > 0 ? skip : 0;
    }
  };

  setClientsListSize = (size: number) => {
    if (this.clientsBatchSize !== size) {
      this.clientsBatchSize = size;
      this.clientsCurrentListPosition = 1;
      this.clientsHasNextBatch = true;
      this.clientsSkipCount = 0;
    }
  };

  setClientsSortObject = (sortObject: Record<string, 'asc' | 'desc'>) => {
    runInAction(() => {
      this.clientsSortObject = sortObject;
    });
  };

  @computed get getClientsListSize() {
    return this.clientsBatchSize;
  }

  setActivityCurrentListPosition = (position: number) => {
    if (this.activityCurrentListPosition !== position) {
      this.activityCurrentListPosition = position;

      const skip = (position - 1) * this.activityBatchSize;

      this.activitySkipCount = skip > 0 ? skip : 0;
    }
  };

  setActivityListSize = (size: number) => {
    if (this.activityBatchSize !== size) {
      this.activityBatchSize = size;
      this.activityCurrentListPosition = 1;
      this.activityHasNextBatch = true;
      this.activitySkipCount = 0;
    }
  };

  @computed get getActivitiesListSize() {
    return this.activityBatchSize;
  }

  getAgreementActivities = async (args: GetMetricsArgs, filters: AgreementActivityFilters) => {
    const result = await agreementService.getActivitiesByAgreementId(args, filters);

    runInAction(() => {
      this.agreementActivities = result.supplementaryActivities;
      this.activityTotalCount = result.metaData.totalCount;
      this.activityHasNextBatch = result.metaData.hasNextBatch;
    });
  };

  sortAgreementActivities = async (filters: AgreementActivityFilters) => {
    if (this.selectedAgreement) {
      const result = await agreementService.getActivitiesByAgreementId(
        { organizationId: this.selectedAgreement?.organizationId, id: this.selectedAgreement?.id },
        filters,
      );

      runInAction(() => {
        this.agreementActivities = result.supplementaryActivities;
        this.activityTotalCount = result.metaData.totalCount;
        this.activityHasNextBatch = result.metaData.hasNextBatch;
      });
    }
  };

  getMetrics = async (args: GetMetricsArgs) => {
    const metrics = await agreementService.getMetrics(args);

    runInAction(() => {
      this.metrics = {
        ...metrics,
      };
    });
  };

  getAgreementDocuments = async (agreementId: string) => {
    const documents = await fileService.getFiles(agreementId);
    runInAction(() => {
      this.documents = documents;
    });
  };

  updateAgreement = async (id: string, agreement: UpdateAgreement) => {
    const updated = await agreementService.update(id, agreement);

    runInAction(() => {
      this.selectedAgreement = updated;
    });
  };

  createAndConnectContacts = async (organizationId: string, contacts: CreateContact[]) => {
    const newContacts = await agreementService.createContacts(organizationId, contacts);
    await this.connectContactsToAgreement(
      organizationId,
      newContacts.map((contact) => contact.id!),
      this.selectedAgreement!.id!,
    );

    runInAction(() => {
      if (this.rootStore.organizationStore.selectedOrganization?.contacts) {
        this.rootStore.organizationStore.selectedOrganization.contacts = [
          ...this.rootStore.organizationStore.selectedOrganization.contacts,
          ...newContacts,
        ];
      }
    });
  };

  connectContactsToAgreement = async (organizationId: string, contactIds: string[], agreementId: string) => {
    const agreement = await agreementService.connectContactsToAgreement(organizationId, contactIds, agreementId);

    runInAction(() => {
      this.selectedAgreement = agreement;
    });
  };

  disconnectContactsFromAgreement = async (organizationId: string, contactIds: string[], agreementId: string) => {
    await agreementService.disconnectContactsFromAgreement(organizationId, contactIds, agreementId);

    runInAction(() => {
      if (this.selectedAgreement?.contacts) {
        this.selectedAgreement.contacts = this.selectedAgreement.contacts.filter(
          (contact) => !contactIds.includes(contact.id!),
        );
        this.selectedAgreement = { ...this.selectedAgreement };
      }
    });
  };

  updateContact = async (id: string, contact: Partial<CreateContact>) => {
    const updatedContact = await organizationService.updateContact(id, contact);

    runInAction(() => {
      if (this.rootStore.organizationStore.selectedOrganization?.contacts) {
        const index = this.rootStore.organizationStore.selectedOrganization.contacts.findIndex((c) => c.id === id);

        this.rootStore.organizationStore.selectedOrganization.contacts[index] = updatedContact;
        this.rootStore.organizationStore.selectedOrganization.contacts = [
          ...this.rootStore.organizationStore.selectedOrganization.contacts,
        ];
      }

      if (this.selectedAgreement?.contacts) {
        const index = this.selectedAgreement.contacts.findIndex((c) => c.id === id);

        this.selectedAgreement.contacts[index] = updatedContact;
        this.selectedAgreement.contacts = [...this.selectedAgreement.contacts];
        this.selectedAgreement = { ...this.selectedAgreement };
      }
    });

    return updatedContact;
  };
}
