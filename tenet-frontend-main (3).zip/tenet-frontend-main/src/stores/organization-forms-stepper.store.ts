import { observable, makeAutoObservable } from 'mobx';

import { TabsState, TabsTextState } from '../types/client-forms';
import { OrganizationFormStepperKeys } from '../types/organization-forms';

type IOrganizationFormStepper = {
  tab: TabsState;
  tabText: TabsTextState;
};

export interface IOrganizationFormSteppers {
  primary: IOrganizationFormStepper;
  firstUser: IOrganizationFormStepper;
  files: IOrganizationFormStepper;
  review: IOrganizationFormStepper;
  submit: IOrganizationFormStepper;
}

export interface IOrganizationFormStepperStore {
  steppers: IOrganizationFormSteppers;
  currentlyActive: OrganizationFormStepperKeys;
}

const defaultSteppersValue: Record<OrganizationFormStepperKeys, IOrganizationFormStepper> = {
  [OrganizationFormStepperKeys.PRIMARY]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [OrganizationFormStepperKeys.FILES]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [OrganizationFormStepperKeys.FIRST_USER]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [OrganizationFormStepperKeys.REVIEW]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [OrganizationFormStepperKeys.SUBMIT]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
};

const initialSteppersValue: Record<OrganizationFormStepperKeys, IOrganizationFormStepper> = {
  ...defaultSteppersValue,
  [OrganizationFormStepperKeys.PRIMARY]: {
    tab: TabsState.ACTIVE,
    tabText: TabsTextState.ACTIVE,
  },
};

class OrganizationFormStepperStore implements IOrganizationFormStepperStore {
  @observable steppers: IOrganizationFormSteppers = initialSteppersValue;

  @observable currentlyActive: OrganizationFormStepperKeys = OrganizationFormStepperKeys.PRIMARY;

  constructor() {
    makeAutoObservable(this);
    this.initializeSteps();
  }

  initializeSteps = () => {
    this.active(OrganizationFormStepperKeys.PRIMARY);
  };

  setActiveStep = (key: OrganizationFormStepperKeys) => {
    this.active(key);
  };

  resetSteppers = () => {
    this.steppers = initialSteppersValue;
  };

  reset = (key: OrganizationFormStepperKeys) => {
    if (this.steppers[key].tab === TabsState.DONE) {
      this.steppers[key].tabText = TabsTextState.DONE;

      return;
    }

    this.steppers[key] = defaultSteppersValue[key];
  };

  active = (key: OrganizationFormStepperKeys) => {
    this.reset(this.currentlyActive);
    this.currentlyActive = key;
    sessionStorage.setItem('activeStepperKey', key);

    if (this.steppers[key].tab === TabsState.DONE) {
      this.steppers[key].tabText = TabsTextState.ACTIVE;

      return;
    }

    this.steppers[key] = {
      tab: TabsState.ACTIVE,
      tabText: TabsTextState.ACTIVE,
    };
  };

  done = (key: OrganizationFormStepperKeys) => {
    this.steppers[key] = {
      tab: TabsState.DONE,
      tabText: TabsTextState.DONE,
    };
  };

  next = (): OrganizationFormStepperKeys | undefined => {
    const keys = Object.keys(this.steppers) as OrganizationFormStepperKeys[];
    const currentIndex = keys.indexOf(this.currentlyActive);
    const nextKey = keys[currentIndex + 1] as OrganizationFormStepperKeys;

    if (currentIndex === keys.length - 1) {
      return undefined;
    }

    this.done(this.currentlyActive);
    this.active(nextKey);

    return nextKey;
  };

  previous = (): OrganizationFormStepperKeys | undefined => {
    const keys = Object.keys(this.steppers) as OrganizationFormStepperKeys[];
    const currentIndex = keys.indexOf(this.currentlyActive);
    const previousKey = keys[currentIndex - 1] as OrganizationFormStepperKeys;

    if (currentIndex === 0) {
      return undefined;
    }

    this.reset(this.currentlyActive);
    this.active(previousKey);

    return previousKey;
  };
}

export default OrganizationFormStepperStore;
