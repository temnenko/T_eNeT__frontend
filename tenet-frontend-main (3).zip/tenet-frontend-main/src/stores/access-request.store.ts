/* eslint-disable import/no-cycle */
import { runInAction, observable, makeAutoObservable } from 'mobx';
import { UserAccessRequestArgs, UserAccessRequestFilesTypeMap } from '../types/user';
import { userAccessService } from '../services/user-access/access-request.service';
import { Upload } from '../types/files';
import { fileService } from '../services/clients/client-files.service';
import { getEnumKeyByValue } from '../utils/enums.util';
import { userService } from '../services/user.service';
import RootStore from './root.store';

export interface IUserAccessRequest {
  id: string | undefined;
  jobTitle: string;
  phoneNumber: string;
  status?: string;
  policeRecordCheckCompletedOn?: Date;
  policeCheckProof?: Upload[];
  policeRecordCheckFilename?: string;
  foipTrainingCompletedOn?: Date;
  foipTrainingProof?: Upload[];
  foipTrainingFilename?: string;
  accessRequestReviewedById?: string;
  termsAcceptedOn?: Date;
}

class UserAccessStore implements IUserAccessRequest {
  @observable id: string | undefined = undefined;

  @observable jobTitle = '';

  @observable phoneNumber = '';

  @observable status?: string = undefined;

  @observable accessRequestReviewedById?: string = undefined;

  @observable policeRecordCheckCompletedOn?: Date = undefined;

  @observable policeCheckProof?: Upload[] = [];

  @observable policeRecordCheckFilename?: string = undefined;

  @observable foipTrainingCompletedOn?: Date = undefined;

  @observable foipTrainingProof?: Upload[] = [];

  @observable foipTrainingFilename?: string = undefined;

  @observable termsAcceptedOn?: Date = undefined;

  @observable accessRequestReviewer?: string | undefined;

  rootStore: RootStore;

  constructor(rootStore: RootStore) {
    makeAutoObservable(this, { rootStore: false });
    this.rootStore = rootStore;
  }

  getUserAccessRequest = async (userId: string) => {
    const user = await userAccessService.getUserAccessRequest(userId);

    runInAction(() => {
      this.id = user.id;
      this.phoneNumber = user?.phoneNumber ?? '';
      this.jobTitle = user?.jobTitle ?? '';
      this.accessRequestReviewedById = user?.accessRequestReviewedById ?? this.accessRequestReviewedById;
      this.policeRecordCheckCompletedOn = user?.policeRecordCheckCompletedOn;
      this.foipTrainingCompletedOn = user?.foipTrainingCompletedOn;
      this.termsAcceptedOn = user?.termsAcceptedOn;
    });

    if (this.accessRequestReviewedById) {
      const csc = await userService.getUserById(this.accessRequestReviewedById);
      runInAction(() => {
        this.accessRequestReviewer = `${csc?.givenName} ${csc?.familyName}`;
      });
    }
  };

  setReviewer = (userId: string, fullName: string) => {
    this.accessRequestReviewedById = userId;
    this.accessRequestReviewer = fullName;
  };

  updateAccessRequest = async (request: UserAccessRequestArgs) => {
    const result = await userAccessService.updateAccessRequest(request);

    runInAction(() => {
      this.jobTitle = result?.jobTitle ?? this.jobTitle;
      this.phoneNumber = result?.phoneNumber ?? this.phoneNumber;
      this.accessRequestReviewedById = result?.accessRequestReviewedById ?? this.accessRequestReviewedById;
      this.policeRecordCheckCompletedOn = result?.policeRecordCheckCompletedOn ?? this.policeRecordCheckCompletedOn;
      this.foipTrainingCompletedOn = result?.foipTrainingCompletedOn ?? this.foipTrainingCompletedOn;
      this.termsAcceptedOn = result?.termsAcceptedOn ?? this.termsAcceptedOn;
      if (this.rootStore.userStore.selectedUser) {
        this.rootStore.userStore.selectedUser.accessRequestFiles = result?.accessRequestFiles;
      }
    });
  };

  completeAccessRequest = async () => {
    const req = await userAccessService.completeAccessRequest();
    runInAction(() => {
      this.status = req?.status;
    });
  };

  uploadFiles = async (files: Upload[], uploadType: UserAccessRequestFilesTypeMap) => {
    const result = await fileService.uploadFiles(this.id!, files);

    const uploadedFiles: Upload[] = result.map((res) => ({
      id: res.id,
      file: new File([], res.fileName),
      uploader: { onprogress: () => {} },
      fileType: uploadType,
      createdAt: res.adspCreatedAt,
      size: res.size || 0,
      adspId: res.adspId,
    }));

    runInAction(() => {
      const propertyKey = getEnumKeyByValue(UserAccessRequestFilesTypeMap, uploadType) as keyof IUserAccessRequest;
      if (Array.isArray(this[propertyKey]) && this[propertyKey] instanceof Array) {
        (this[propertyKey] as Upload[]).push(...uploadedFiles);
      }
    });

    return result;
  };

  fetchFiles = async (userId?: string) => {
    if (!this.id && !userId) {
      return [];
    }

    const files = await fileService.getFiles(this.id ?? userId ?? '');
    const uploads: Upload[] = files.map((file) => ({
      id: file.id,
      file: new File([], file.fileName),
      uploader: { onprogress: () => {} },
      fileType: file.typeName,
      createdAt: file.adspCreatedAt,
      size: file.size,
      adspId: file.adspId,
    }));

    runInAction(() => {
      this.policeCheckProof = uploads.filter(
        (upload) => upload.fileType === UserAccessRequestFilesTypeMap.policeCheckProof,
      );
      this.foipTrainingProof = uploads.filter(
        (upload) => upload.fileType === UserAccessRequestFilesTypeMap.foipTrainingProof,
      );
    });

    return uploads;
  };

  removeFile = async (upload: Upload, uploadType: UserAccessRequestFilesTypeMap) => {
    await fileService.deleteFile(upload.adspId);

    runInAction(() => {
      const propertyKey = getEnumKeyByValue(UserAccessRequestFilesTypeMap, uploadType) as keyof IUserAccessRequest;

      if (Array.isArray(this[propertyKey]) && this[propertyKey] instanceof Array) {
        (this[propertyKey] as Upload[]).splice((this[propertyKey] as Upload[]).indexOf(upload), 1);
      }
    });
  };
}

export default UserAccessStore;
