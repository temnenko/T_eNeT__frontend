import { runInAction, observable, computed, makeAutoObservable } from 'mobx';

import { Assessment, AssessmentKey } from '../types/assessment';
import { assessmentService } from '../services/clients/assessment.service';

export interface IAssessmentListStore {
  assessments: Assessment[];
}

class AssessmentListStore implements IAssessmentListStore {
  @observable assessments: Assessment[] = [];

  constructor() {
    makeAutoObservable(this);
  }

  getByClientId = async (clientId: string) => {
    const assessments = await assessmentService.getByClientId(clientId);

    runInAction(() => {
      this.assessments = assessments;
    });
  };

  @computed get hasAssessments() {
    return this.assessments.length > 0;
  }

  sortData = (sortBy: AssessmentKey, sortDir: number) => {
    const assessmentClone = [...this.assessments];
    assessmentClone.sort((a: Assessment, b: Assessment) => {
      return (a[sortBy]! > b[sortBy]! ? 1 : -1) * sortDir;
    });
    runInAction(() => {
      this.assessments = assessmentClone;
    });
  };

  deleteAssessment = async (assessmentId: string) => {
    await assessmentService.delete(assessmentId);
    runInAction(() => {
      this.assessments = this.assessments.filter((assessment) => assessment.id !== assessmentId);
    });
  };
}

export default AssessmentListStore;
