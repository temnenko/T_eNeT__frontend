/* eslint-disable import/no-cycle */
import { makeAutoObservable, observable, runInAction } from 'mobx';
import { Agreement, CreateAgreement, UpdateAgreement } from '../types/agreement';
import { agreementService } from '../services/organizations/agreement.service';
import { Contact, CreateContact, Location } from '../types/organization';
import RootStore from './root.store';
import { organizationService } from '../services/organizations/organization.service';

export class AgreementFormsStore {
  rootStore: RootStore;

  @observable agreement: Agreement | undefined;

  @observable editId: number | undefined;

  @observable selectedLocations: (Location & { canEdit?: boolean })[];

  @observable agreementWatch: Record<string, unknown> | undefined;

  @observable editContactId: number | undefined;

  @observable selectedContacts: (Contact & { canEdit?: boolean })[];

  constructor(rootStore: RootStore) {
    makeAutoObservable(this);
    this.selectedContacts = [];
    this.agreementWatch = {};
    this.selectedLocations = [];
    this.rootStore = rootStore;
  }

  setEditId = (id: number | undefined) => {
    this.editId = id;
  };

  setSelectedLocations = (locations: (Location & { canEdit?: boolean })[]) => {
    this.selectedLocations = locations;
  };

  createAgreement = async (agreement: CreateAgreement) => {
    const newAgreement = await agreementService.create(agreement);

    runInAction(() => {
      this.agreement = newAgreement;
    });

    return newAgreement;
  };

  resetAgreement = () => {
    this.agreement = undefined;
    this.agreementWatch = {};
  };

  updateAgreement = async (id: string, agreement: UpdateAgreement) => {
    const updated = await agreementService.update(id, agreement);
    runInAction(() => {
      this.agreement = updated;
    });
  };

  completeAgreement = async (id: string) => {
    if (
      this.agreement?.programType &&
      this.agreement?.name &&
      this.agreement?.locations?.length &&
      this.agreement?.contacts?.length
    ) {
      const completed = await agreementService.complete(id);

      runInAction(() => {
        this.agreement = completed;
      });
      return completed.creationCompleted;
    }
    return false;
  };

  getById = async (id: string) => {
    const agreement = await agreementService.getById(id);

    runInAction(() => {
      this.agreement = agreement;
    });

    return agreement;
  };

  createAndConnectContacts = async (organizationId: string, contacts: CreateContact[]) => {
    const newContacts = await agreementService.createContacts(organizationId, contacts);
    await this.connectContactsToAgreement(
      organizationId,
      newContacts.map((contact) => contact.id!),
      this.agreement!.id!,
    );

    runInAction(() => {
      if (this.rootStore.organizationStore.selectedOrganization?.contacts) {
        this.rootStore.organizationStore.selectedOrganization.contacts = [
          ...this.rootStore.organizationStore.selectedOrganization.contacts,
          ...newContacts,
        ];
      }
    });

    return newContacts[0];
  };

  connectContactsToAgreement = async (organizationId: string, contactIds: string[], agreementId: string) => {
    const agreement = await agreementService.connectContactsToAgreement(organizationId, contactIds, agreementId);

    runInAction(() => {
      this.agreement = agreement;
    });
  };

  disconnectContactsFromAgreement = async (organizationId: string, contactIds: string[], agreementId: string) => {
    await agreementService.disconnectContactsFromAgreement(organizationId, contactIds, agreementId);

    runInAction(() => {
      if (this.agreement?.contacts) {
        this.agreement.contacts = this.agreement.contacts.filter((contact) => !contactIds.includes(contact.id!));
        this.agreement = { ...this.agreement };
      }
    });
  };

  // eslint-disable-next-line class-methods-use-this
  getContactById = async (contactId: string) => {
    const contact = await organizationService.getContactById(contactId);
    return contact;
  };

  updateContact = async (id: string, contact: Partial<CreateContact>) => {
    const updatedContact = await organizationService.updateContact(id, contact);

    runInAction(() => {
      if (this.rootStore.organizationStore.selectedOrganization?.contacts) {
        const index = this.rootStore.organizationStore.selectedOrganization.contacts.findIndex((c) => c.id === id);

        this.rootStore.organizationStore.selectedOrganization.contacts[index] = updatedContact;
        this.rootStore.organizationStore.selectedOrganization.contacts = [
          ...this.rootStore.organizationStore.selectedOrganization.contacts,
        ];
      }

      if (this.agreement?.contacts) {
        const index = this.agreement.contacts.findIndex((c) => c.id === id);

        this.agreement.contacts[index] = updatedContact;
        this.agreement.contacts = [...this.agreement.contacts];
        this.agreement = { ...this.agreement };
      }
    });

    return updatedContact;
  };

  setEditContactId = (id: number | undefined) => {
    this.editContactId = id;
  };

  setSelectedContacts = (contacts: (Contact & { canEdit?: boolean })[]) => {
    this.selectedContacts = contacts;
  };

  watchAgreement = <T>(field: string, value: T) => {
    this.agreementWatch![field] = value;
  };

  retrieveAgreement = <T>(field: string): T => {
    return this.agreementWatch![field]! as T;
  };
}
