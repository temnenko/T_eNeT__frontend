import { observable, makeAutoObservable } from 'mobx';

import { ClientFormStepperKeys, TabsState, TabsTextState } from '../types/client-forms';
import { Client } from '../types/client';

type IClientFormStepper = {
  tab: TabsState;
  tabText: TabsTextState;
};

export interface IClientFormSteppers {
  personal: IClientFormStepper;
  demographics: IClientFormStepper;
  contact: IClientFormStepper;
  factors: IClientFormStepper;
  consent: IClientFormStepper;
  files: IClientFormStepper;
  review: IClientFormStepper;
}

export interface IClientFormStepperStore {
  steppers: IClientFormSteppers;
  currentlyActive: ClientFormStepperKeys;
}

const defaultSteppersValue: Record<ClientFormStepperKeys, IClientFormStepper> = {
  [ClientFormStepperKeys.PERSONAL]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [ClientFormStepperKeys.DEMOGRAPHICS]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [ClientFormStepperKeys.CONTACT]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [ClientFormStepperKeys.FACTORS]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [ClientFormStepperKeys.CONSENT]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [ClientFormStepperKeys.FILES]: {
    tab: TabsState.OPTIONAL,
    tabText: TabsTextState.DEFAULT,
  },
  [ClientFormStepperKeys.REVIEW]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
};

const initialSteppersValue: Record<ClientFormStepperKeys, IClientFormStepper> = {
  ...defaultSteppersValue,
  [ClientFormStepperKeys.PERSONAL]: {
    tab: TabsState.ACTIVE,
    tabText: TabsTextState.ACTIVE,
  },
};

class ClientFormStepperStore implements IClientFormStepperStore {
  @observable steppers: IClientFormSteppers = initialSteppersValue;

  @observable currentlyActive: ClientFormStepperKeys = ClientFormStepperKeys.PERSONAL;

  constructor() {
    makeAutoObservable(this);
    this.initializeSteps();
  }

  initializeSteps = () => {
    this.active(ClientFormStepperKeys.PERSONAL);
  };

  resetSteps = () => {
    this.steppers = initialSteppersValue;
    this.active(ClientFormStepperKeys.PERSONAL);
  };

  setCompletedSteps = (client: Client) => {
    this.active(ClientFormStepperKeys.PERSONAL);
    const {
      dateOfBirth,
      sinRecords,
      addresses,
      emailAddresses,
      phones,
      factors,
      demographic,
      foipConsentedAt,
      wcbAcknowledgedAt,
    } = client;

    if (dateOfBirth && sinRecords.length > 0) {
      this.done(ClientFormStepperKeys.PERSONAL);
    }

    if (addresses.length > 0 && emailAddresses.length > 0 && phones.length > 0) {
      this.done(ClientFormStepperKeys.CONTACT);
    }

    if (demographic) {
      this.done(ClientFormStepperKeys.DEMOGRAPHICS);
    }

    if (factors) {
      this.done(ClientFormStepperKeys.FACTORS);
    }

    if (foipConsentedAt && wcbAcknowledgedAt) {
      this.done(ClientFormStepperKeys.CONSENT);
    }
  };

  setActiveStep = (key: ClientFormStepperKeys) => {
    this.active(key);
  };

  reset = (key: ClientFormStepperKeys) => {
    if (this.steppers[key].tab === TabsState.DONE) {
      this.steppers[key].tabText = TabsTextState.DONE;

      return;
    }

    this.steppers[key] = defaultSteppersValue[key];
  };

  active = (key: ClientFormStepperKeys) => {
    this.reset(this.currentlyActive);
    this.currentlyActive = key;
    sessionStorage.setItem('activeStepperKey', key);

    if (this.steppers[key].tab === TabsState.DONE) {
      this.steppers[key].tabText = TabsTextState.ACTIVE;

      return;
    }

    this.steppers[key] = {
      tab: TabsState.ACTIVE,
      tabText: TabsTextState.ACTIVE,
    };
  };

  done = (key: ClientFormStepperKeys) => {
    this.steppers[key] = {
      tab: TabsState.DONE,
      tabText: TabsTextState.DONE,
    };
  };

  next = (): ClientFormStepperKeys | undefined => {
    const keys = Object.keys(this.steppers) as ClientFormStepperKeys[];
    const currentIndex = keys.indexOf(this.currentlyActive);
    const nextKey = keys[currentIndex + 1] as ClientFormStepperKeys;

    if (currentIndex === keys.length - 1) {
      return undefined;
    }

    this.done(this.currentlyActive);
    this.active(nextKey);

    return nextKey;
  };

  previous = (): ClientFormStepperKeys | undefined => {
    const keys = Object.keys(this.steppers) as ClientFormStepperKeys[];
    const currentIndex = keys.indexOf(this.currentlyActive);
    const previousKey = keys[currentIndex - 1] as ClientFormStepperKeys;

    if (currentIndex === 0) {
      return undefined;
    }

    this.reset(this.currentlyActive);
    this.active(previousKey);

    return previousKey;
  };
}

export default ClientFormStepperStore;
