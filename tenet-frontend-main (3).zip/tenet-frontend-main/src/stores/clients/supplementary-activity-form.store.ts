/* eslint-disable import/no-cycle */
import { runInAction, observable, makeAutoObservable } from 'mobx';
import {
  CreateSupplementaryActivity,
  SupplementaryActivity,
  UpdateSupplementaryActivity,
} from '../../types/service-plan';
import RootStore from '../root.store';
import { supplementaryActivityService } from '../../services/clients/supplementary-activity.service';

export interface ISupplementaryActivityFormStore {
  supplementaryActivity?: SupplementaryActivity;
  supplementaryActivities?: SupplementaryActivity[];
}

class SupplementaryActivityFormStore implements ISupplementaryActivityFormStore {
  rootStore: RootStore;

  @observable supplementaryActivity?: SupplementaryActivity | undefined;

  @observable supplementaryActivities?: SupplementaryActivity[] = [];

  constructor(rootStore: RootStore) {
    makeAutoObservable(this);
    this.rootStore = rootStore;
  }

  resetActivityStore = () => {
    this.supplementaryActivities = [];
    this.supplementaryActivity = undefined;
  };

  createActivity = async (args: CreateSupplementaryActivity) => {
    const activity = await supplementaryActivityService.create({
      clientId: this.rootStore.servicePlanStore.servicePlan!.clientId,
      servicePlanId: this.rootStore.servicePlanStore.servicePlan!.id,
      payload: args,
    });
    runInAction(() => {
      this.supplementaryActivity = activity;
    });

    await this.getActivities();

    return activity;
  };

  updateActivity = async (id: string, args: UpdateSupplementaryActivity) => {
    const activity = await supplementaryActivityService.update({
      id,
      clientId: this.rootStore.servicePlanStore.servicePlan!.clientId,
      servicePlanId: this.rootStore.servicePlanStore.servicePlan!.id,
      payload: args,
    });
    runInAction(() => {
      this.supplementaryActivity = activity;
    });

    await this.getActivities();

    return activity;
  };

  getActivities = async () => {
    const activities = await supplementaryActivityService.getByServicePlanId({
      clientId: this.rootStore.servicePlanStore.servicePlan!.clientId,
      servicePlanId: this.rootStore.servicePlanStore.servicePlan!.id,
    });

    runInAction(() => {
      this.supplementaryActivities = activities;
    });
  };
}

export default SupplementaryActivityFormStore;
