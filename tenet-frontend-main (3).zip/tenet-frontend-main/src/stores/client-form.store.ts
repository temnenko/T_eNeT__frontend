/* eslint-disable import/no-cycle */
import { observable, makeAutoObservable, runInAction } from 'mobx';
import {
  Client,
  ClientAddressRecord,
  CreateClientArgs,
  Demographic,
  EmailAddress,
  Phone,
  UpdateClientArgs,
} from '../types/client';
import { clientsService } from '../services/clients/clients.service';
import RootStore from './root.store';

class ClientFormStore {
  @observable client: Client | undefined;

  @observable clientWatch: Record<string, unknown> | undefined;

  rootStore: RootStore;

  constructor(rootStore: RootStore) {
    makeAutoObservable(this, { rootStore: false });
    this.rootStore = rootStore;
    this.clientWatch = {};
  }

  // Upon page refresh, this should load the client from the db.
  // We will be getting the id from the URL
  loadClient = async (clientId: string) => {
    const client = await clientsService.getById(clientId);
    runInAction(() => {
      this.client = client;
    });

    return client;
  };

  updateStore = (data: Client) => {
    runInAction(() => {
      this.client = data;
      if (this.rootStore.clientsStore && this.rootStore.clientsStore.selectedClient?.id === data.id) {
        this.rootStore.clientsStore.selectedClient = data;
      }
    });
  };

  watchClient = <T>(field: string, value: T) => {
    this.clientWatch![field] = value;
  };

  retrieveClient = <T>(field: string): T => {
    return this.clientWatch![field]! as T;
  };

  createClient = async (client: CreateClientArgs) => {
    const data = await clientsService.createClient(client);
    this.updateStore(data.client);
    return data.client;
  };

  updateClient = async (updateData: UpdateClientArgs, id?: string) => {
    const data = await clientsService.updateClient(id ?? this.client!.id, updateData);

    this.updateStore(data);
  };

  saveClientAddresses = async (addresses: ClientAddressRecord[]) => {
    const data = await clientsService.saveClientAddresses(this.client!.id, addresses ?? []);

    runInAction(() => {
      this.client!.addresses = data;
    });
  };

  saveClientContactDetails = async (emailAddresses: EmailAddress[], phones: Phone[]) => {
    const data = await clientsService.saveClientContactDetails(this.client!.id!, emailAddresses ?? [], phones ?? []);

    runInAction(() => {
      this.client!.emailAddresses = data.emailAddresses;
      this.client!.phones = data.phones;
    });
  };

  saveClientDemographics = async (demographic: Demographic) => {
    const data = await clientsService.saveClientDemographics(this.client!.id!, demographic);

    runInAction(() => {
      this.client!.demographic = data;
    });
  };

  clearClient = () => {
    this.client = undefined;
    this.clientWatch = {};
    this.rootStore.clientFilesStore.resetFiles();
  };
}

export default ClientFormStore;
