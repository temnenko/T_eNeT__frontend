import { computed, makeAutoObservable, observable, runInAction } from 'mobx';

import type RootStore from '../root.store';
import { UserIdNamePair } from '../../types/user';
import { Agreement } from '../../types/agreement';
import { agreementService, SortableAgreementField } from '../../services/organizations/agreement.service';
import { userService } from '../../services/user.service';
import { SelectionType } from '../../common/components/multiselect/use-multiselect.hook';

export class GoADashboardStore {
  rootStore: RootStore;

  @observable usersData: UserIdNamePair[] = [];

  @observable agreements: Agreement[] = [];

  @observable batchSize = 15;

  @observable skipCount = 0;

  @observable sortObject: Record<string, 'asc' | 'desc'> = {};

  currentListPosition: number = 1;

  hasNextBatch: boolean = false;

  totalCount: number = this.agreements?.length;

  searchString: string = '';

  constructor(rootStore: RootStore) {
    makeAutoObservable(this, { rootStore: false });
    this.rootStore = rootStore;
  }

  getUsersForDashboard = async (organizationId: string) => {
    const result = await userService.getUsersForDashboard(organizationId);

    runInAction(() => {
      this.usersData = result;
    });
  };

  getAgreements = async (selectedAssignees?: SelectionType, searchString?: string, resetPagination?: boolean) => {
    const assignees = selectedAssignees || this.rootStore.userConfigStore.selectedAssignees;
    if (resetPagination) {
      this.currentListPosition = 1;
      this.skipCount = 0;
    }

    const query = searchString ?? this.searchString;

    const result = await agreementService.getAgreementsForGoADashboard(this.getAgreementFilters(assignees, query));

    runInAction(() => {
      this.agreements = result.agreements;
      this.totalCount = result.metaData.totalCount;
      this.searchString = query;
    });
  };

  getAgreementFilters = (selectedAssignees: SelectionType, searchString: string) => {
    return {
      assigneeId: Object.values(selectedAssignees).map((assigneeSet) => {
        const [firstAssignee] = Array.from(assigneeSet);
        return firstAssignee?.id;
      }),
      skipCount: this.skipCount,
      batchSize: this.batchSize,
      sortBy: Object.keys(this.sortObject)[0] as SortableAgreementField,
      sortOrder: Object.values(this.sortObject)[0] as 'asc' | 'desc',
      nameOrNumberSearch: searchString,
    };
  };

  setCurrentListPosition = (position: number) => {
    if (this.currentListPosition !== position) {
      this.currentListPosition = position;

      const skip = (position - 1) * this.batchSize;

      this.skipCount = skip > 0 ? skip : 0;

      this.getAgreements(this.rootStore.userConfigStore.selectedAssignees, this.searchString);
    }
  };

  setListSize = (size: number) => {
    if (this.batchSize !== size) {
      this.batchSize = size;
      this.currentListPosition = 1;
      this.hasNextBatch = false;
      this.skipCount = 0;
      this.getAgreements(this.rootStore.userConfigStore.selectedAssignees, this.searchString);
    }
  };

  setSortObject = (sortObject: Record<string, 'asc' | 'desc'>) => {
    runInAction(() => {
      this.sortObject = sortObject;
    });
  };

  @computed get getListSize() {
    return this.batchSize;
  }
}
