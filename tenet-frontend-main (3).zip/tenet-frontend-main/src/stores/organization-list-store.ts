import { runInAction, observable, computed, makeAutoObservable } from 'mobx';

import { Organization, OrganizationKey } from '../types/organization';
import { organizationService } from '../services/organizations/organization.service';

export interface IOrganizationListStore {
  organizationsList: Organization[];
  hasNextBatch: boolean;
  totalCount: number;
  currentListPosition: number;
  skipCount: number;
  allOrganizations: Organization[];
  isFiltered: boolean;
}

class OrganizationListStore implements IOrganizationListStore {
  @observable organizationsList: Organization[] = [];

  constructor() {
    makeAutoObservable(this);
  }

  hasNextBatch: boolean = true;

  totalCount: number = this.organizationsList?.length;

  currentListPosition: number = 1;

  @observable private listSize = 15;

  @observable skipCount = 0;

  @observable nameSearch?: string = undefined;

  @observable allOrganizations: Organization[] = [];

  @observable isFiltered: boolean = false;

  getOrganizationsList = async () => {
    const batchSize = this.listSize;
    const { skipCount, nameSearch } = this;
    const { organizations, metaData } = await organizationService.getOrganizationsList(
      batchSize,
      skipCount,
      nameSearch,
    );

    runInAction(() => {
      this.organizationsList = organizations;
      this.hasNextBatch = metaData.hasNextBatch;
      this.totalCount = metaData.totalCount;
    });
  };

  @computed get hasOrganizations() {
    return this.organizationsList.length > 0;
  }

  setCurrentListPosition = (position: number) => {
    if (this.currentListPosition !== position) {
      this.currentListPosition = position;

      const skip = (position - 1) * this.listSize;

      this.skipCount = skip > 0 ? skip : 0;
    }
  };

  setNameSearch = (value: string | undefined) => {
    this.nameSearch = value;
  };

  setListSize = (size: number) => {
    if (this.listSize !== size) {
      this.listSize = size;
      this.currentListPosition = 1;
      this.hasNextBatch = true;
      this.skipCount = 0;
    }
  };

  @computed get getListSize() {
    return this.listSize;
  }

  sortData = (sortBy: OrganizationKey, sortDir: number) => {
    const orgList = [...this.organizationsList];
    orgList.sort((a: Organization, b: Organization) => {
      return (a[sortBy] > b[sortBy] ? 1 : -1) * sortDir;
    });
    runInAction(() => {
      this.organizationsList = orgList;
    });
  };
}

export default OrganizationListStore;
