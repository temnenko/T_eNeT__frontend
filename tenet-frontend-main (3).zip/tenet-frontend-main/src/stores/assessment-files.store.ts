import { makeAutoObservable, observable, runInAction } from 'mobx';
import { TenetFile, Upload } from '../types/files';
import { fileService } from '../services/clients/client-files.service';

class AssessmentFilesStore {
  @observable documents: TenetFile[] = [];

  @observable newUploads: Upload[] = [];

  constructor() {
    makeAutoObservable(this);
  }

  getAssementDocuments = async (assessmentId: string) => {
    const documents = await fileService.getFiles(assessmentId);
    runInAction(() => {
      this.documents = documents?.length
        ? documents
        : this.newUploads.map((file) => {
            return {
              id: file.id,
              adspId: '',
              recordId: '',
              fileName: file.file.name,
              addedByFullName: file.addedByFullName ?? '',
              typeName: file.fileType,
              size: file.file.size,
              urn: '',
              scanned: false,
              infected: false,
              securityClassification: '',
              adspCreatedAt: file.createdAt,
              createdAt: file.createdAt,
              updatedAt: new Date().toISOString(),
            };
          });
    });
  };

  uploadAssessmentDocuments = async (assessmentId: string) => {
    const newFiles = this.newUploads.filter(
      (newFile, index, self) => index === self.findIndex((f) => f.id === newFile.id),
    );

    if (newFiles.length === 0) {
      return;
    }

    const documents = await fileService.uploadFiles(assessmentId, newFiles);

    runInAction(() => {
      this.documents.push(...documents);
      this.newUploads = [];
    });
  };

  addToNewUploads = (upload: Upload) => {
    const existingUpload = this.newUploads.find((u) => u.id === upload.id);
    runInAction(() => {
      if (existingUpload) {
        existingUpload.fileType = upload.fileType;
      } else {
        this.newUploads.push(upload);
      }
    });
  };

  deleteDocument = async (id: string) => {
    runInAction(() => {
      this.newUploads = this.newUploads.filter((doc) => doc.id !== id);
    });
  };
}

export default AssessmentFilesStore;
