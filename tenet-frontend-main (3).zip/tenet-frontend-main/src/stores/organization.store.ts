/* eslint-disable no-console */
/* eslint-disable class-methods-use-this */
import { runInAction, observable, makeAutoObservable, computed } from 'mobx';

import { organizationService } from '../services/organizations/organization.service';
import { OrganizationStatus, Contract, LocationArgs, Location, Contact } from '../types/organization';
import { Upload } from '../types/files';
import { UserInvite } from '../types/user';
import { Agreement, AgreementSummary } from '../types/agreement';
import { agreementService } from '../services/organizations/agreement.service';

type IOrganization = {
  id: string;
  operatingName: string;
  legalName: string;
  emailAddress: string;
  website: string;
  createdAt: string;
  updatedAt: string;
  businessIdentifier: string;
  creationCompleted?: boolean;
  partnerNumber?: string;
  phoneNumber?: string;
  status: OrganizationStatus;
  firstUserName?: string;
  firstUserEmail?: string;
  corporateIdentityNumber?: string;
  corporateIdentityDocuments?: Upload[];
  lobbyistCheckedDate?: Date;
  lobbyistCheckProof?: Upload[];
  wcbVerifiedOn?: Date;
  wcbVerificationProof?: Upload[];
  liabilityPolicyExpiresOn?: Date;
  liabilityPolicyProof?: Upload[];
  privacyAssessmentCompletedOn?: Date;
  assessmentResult?: Upload[];
  locations?: Location[];
  contacts?: Contact[];
};

type IContracts = {
  id: string;
  organizationId: string;
  name: string;
  start: Date;
  end: Date;
};

type IUserInvite = Omit<UserInvite, 'givenName'> & {
  name?: string;
};

export interface IOrganizationStore {
  selectedOrganization?: IOrganization;
  agreements: Agreement[];
  contracts?: Contract[];
  userInvites: IUserInvite[];
}

class OrganizationStore implements IOrganizationStore {
  @observable selectedOrganization?: IOrganization = undefined;

  @observable agreements: Agreement[] = [];

  @observable completedAgreementsSummary: AgreementSummary[] = [];

  @observable hasNextAgreementsBatch = true;

  @observable totalAgreementsCount = 0;

  @observable currentAgreementsListPosition = 1;

  @observable private agreementsListSize = 15;

  @observable skipAgreementsCount = 0;

  @observable contracts?: IContracts[] = [];

  @observable userInvites: IUserInvite[] = [];

  @observable showExpiredAgreements: boolean = false;

  constructor() {
    makeAutoObservable(this);
  }

  resetSelectedOrganization = () => {
    this.selectedOrganization = undefined;
  };

  getOrganizationById = async (organizationId: string) => {
    const {
      id,
      operatingName,
      emailAddress,
      legalName,
      website,
      businessIdentifier,
      createdAt,
      updatedAt,
      creationCompleted,
      partnerNumber,
      phoneNumber,
      status,
      firstUserName,
      firstUserEmail,
      corporateIdentityNumber,
      corporateIdentityDocuments,
      lobbyistCheckedDate,
      lobbyistCheckProof,
      wcbVerifiedOn,
      wcbVerificationProof,
      liabilityPolicyExpiresOn,
      liabilityPolicyProof,
      privacyAssessmentCompletedOn,
      assessmentResult,
      locations,
      contacts,
    } = await organizationService.getOrganizationById(organizationId);

    runInAction(() => {
      this.selectedOrganization = {
        id,
        operatingName,
        emailAddress,
        legalName,
        website,
        businessIdentifier,
        createdAt,
        updatedAt,
        creationCompleted,
        partnerNumber,
        phoneNumber,
        status,
        firstUserName,
        firstUserEmail,
        corporateIdentityNumber,
        corporateIdentityDocuments,
        lobbyistCheckedDate,
        lobbyistCheckProof,
        wcbVerifiedOn,
        wcbVerificationProof,
        liabilityPolicyExpiresOn,
        liabilityPolicyProof,
        privacyAssessmentCompletedOn,
        assessmentResult,
        locations,
        contacts,
      };
    });
  };

  getOrganizationUserInvites = async (organizationId: string): Promise<void> => {
    const invites = await organizationService.getUserInvites(organizationId);

    runInAction(() => {
      this.userInvites = invites.map((item) => ({
        id: item.id,
        organizationId: item.organizationId,
        emailAddress: item.emailAddress,
        name: item.givenName,
        roleId: item.roleId,
      }));
    });
  };

  getOrganizationAgreements = async (organizationId: string): Promise<void> => {
    const { agreements, metaData } = await agreementService.getByOrganizationId({
      organizationId,
      batchSize: this.agreementsListSize,
      skipCount: this.skipAgreementsCount,
      showExpiredAgreements: this.showExpiredAgreements,
    });

    runInAction(() => {
      this.agreements = agreements;
      this.hasNextAgreementsBatch = metaData?.hasNextBatch;
      this.totalAgreementsCount = metaData?.totalCount;
    });
  };

  getOrganizationCompletedAgreements = async (organizationId: string): Promise<void> => {
    const completedAgreements = await agreementService.getAgreementNamesByOrganization(organizationId);

    runInAction(() => {
      this.completedAgreementsSummary = completedAgreements.agreements;
    });
  };

  setAgreements = (agreements: Agreement[]) => {
    this.agreements = agreements;
  };

  setCurrentAgreementsListPosition = (position: number) => {
    if (this.currentAgreementsListPosition !== position) {
      this.currentAgreementsListPosition = position;

      const skip = (position - 1) * this.agreementsListSize;

      this.skipAgreementsCount = skip > 0 ? skip : 0;
    }
  };

  setAgreementsListSize = (size: number) => {
    if (this.agreementsListSize !== size) {
      this.agreementsListSize = size;
      this.currentAgreementsListPosition = 1;
      this.hasNextAgreementsBatch = true;
      this.skipAgreementsCount = 0;
    }
  };

  @computed get getAgreementsListSize() {
    return this.agreementsListSize;
  }

  @computed get hasAgreements() {
    return this.agreements?.length > 0;
  }

  setOfficeLocation = async (organizationId: string, office: Omit<LocationArgs, 'economicRegion'>) => {
    const location = await organizationService.createLocation(organizationId, office);
    console.log(location);
    runInAction(() => {
      this.getOrganizationById(organizationId);
    });
  };

  updateOfficeLocation = async (
    locationId: string,
    office: Omit<LocationArgs, 'economicRegion'>,
    organizationId: string,
  ) => {
    await organizationService.updateLocation(locationId, office);
    runInAction(() => {
      this.getOrganizationById(organizationId);
    });
  };

  setShowExpiredAgreements = () => {
    runInAction(() => {
      this.showExpiredAgreements = !this.showExpiredAgreements;
    });
  };
}

export default OrganizationStore;
