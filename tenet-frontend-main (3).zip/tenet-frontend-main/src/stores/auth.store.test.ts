/* eslint-disable @typescript-eslint/no-unused-vars */
import AuthStore from './auth.store';
import { authService } from '../services/auth.service';
import { LoginResponse } from '../types/responses/login-response';
import { SetAuthInput } from '../types/user';

describe('AuthStore', () => {
  let authServiceLoginSpy: jest.SpyInstance;
  let authServiceLogoutSpy: jest.SpyInstance;

  beforeAll(() => {
    authServiceLoginSpy = jest.spyOn(authService, 'getLoginUrl').mockImplementation(async (_idpHint: string) => {});
    authServiceLogoutSpy = jest.spyOn(authService, 'logout').mockImplementation(async () => {});

    jest
      .spyOn(authService, 'exchangeCodeForToken')
      .mockImplementation(async (_code: string, _state: string) => ({}) as LoginResponse);
  });

  const store = new AuthStore();
  const mockSetAuthInput: SetAuthInput = {
    accessToken: 'access-token',
    refreshToken: 'refresh-token',
    expiresAt: 3600,
    expiresIn: 3450,
  };

  test('initializes correctly', () => {
    expect(store.accessToken).toEqual('');
    expect(store.refreshToken).toEqual('');
    expect(store.expiresAt).toEqual(0);
    expect(store.expiresIn).toEqual(0);
  });

  describe('login', () => {
    test('should delegate AuthService.login', async () => {
      await store.getLoginUrl('saml');

      expect(authServiceLoginSpy).toHaveBeenCalledTimes(1);
      expect(authServiceLoginSpy).toHaveBeenCalledWith('saml');
    });
  });

  describe('setAuth', () => {
    test('should set auth info', () => {
      store.setAuth(mockSetAuthInput);

      expect(store.accessToken).toEqual(mockSetAuthInput.accessToken);
      expect(store.refreshToken).toEqual(mockSetAuthInput.refreshToken);
      expect(store.expiresAt).toEqual(mockSetAuthInput.expiresAt);
      expect(store.expiresIn).toEqual(mockSetAuthInput.expiresIn);
    });
  });

  describe('unsetAuth', () => {
    test('should unset auth info', () => {
      store.setAuth(mockSetAuthInput);
      store.unsetAuth();

      expect(store.accessToken).toEqual('');
      expect(store.refreshToken).toEqual('');
      expect(store.expiresAt).toEqual(0);
      expect(store.expiresIn).toEqual(0);
    });
  });
});
