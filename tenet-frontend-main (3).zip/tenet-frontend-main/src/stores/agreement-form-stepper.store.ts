import { observable, makeAutoObservable } from 'mobx';
import { AgreementFormsStepperKeys } from '../types/agreement-forms';

export enum TabsTextState {
  DEFAULT = 'default-tab-text',
  ACTIVE = 'active-tab-text',
  DONE = 'done-tab-text',
}

export enum TabsState {
  DEFAULT = 'default-tab',
  ACTIVE = 'active-tab',
  OPTIONAL = 'optional-tab',
  DONE = 'done-tab',
}

type IAgreementFormsStepper = {
  tab: TabsState;
  tabText: TabsTextState;
};

export interface IAgreementFormsSteppers {
  programType: IAgreementFormsStepper;
  agreementDetails: IAgreementFormsStepper;
  deliveryLocations: IAgreementFormsStepper;
  contactGroup: IAgreementFormsStepper;
  documents: IAgreementFormsStepper;
  review: IAgreementFormsStepper;
}

export interface IAgreementFormStepperStore {
  steppers: IAgreementFormsSteppers;
  currentlyActive: AgreementFormsStepperKeys;
}

const defaultSteppersValue: Record<AgreementFormsStepperKeys, IAgreementFormsStepper> = {
  [AgreementFormsStepperKeys.PROGRAM_TYPE]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AgreementFormsStepperKeys.AGREEMENT_DETAILS]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AgreementFormsStepperKeys.DELIVERY_LOCATIONS]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AgreementFormsStepperKeys.CONTACT_GROUP]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AgreementFormsStepperKeys.DOCUMENTS]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
  [AgreementFormsStepperKeys.REVIEW]: {
    tab: TabsState.DEFAULT,
    tabText: TabsTextState.DEFAULT,
  },
};

const initialSteppersValue: Record<AgreementFormsStepperKeys, IAgreementFormsStepper> = {
  ...defaultSteppersValue,
  [AgreementFormsStepperKeys.PROGRAM_TYPE]: {
    tab: TabsState.ACTIVE,
    tabText: TabsTextState.ACTIVE,
  },
};

class AgreementFormStepperStore implements IAgreementFormStepperStore {
  @observable steppers: IAgreementFormsSteppers = initialSteppersValue;

  @observable currentlyActive: AgreementFormsStepperKeys = AgreementFormsStepperKeys.PROGRAM_TYPE;

  constructor() {
    makeAutoObservable(this);
    this.initializeSteps();
  }

  initializeSteps = () => {
    this.active(AgreementFormsStepperKeys.PROGRAM_TYPE);
  };

  setActiveStep = (key: AgreementFormsStepperKeys) => {
    this.active(key);
  };

  resetSteppers = () => {
    this.steppers = initialSteppersValue;
  };

  reset = (key: AgreementFormsStepperKeys) => {
    if (this.steppers[key].tab === TabsState.DONE) {
      this.steppers[key].tabText = TabsTextState.DONE;

      return;
    }

    this.steppers[key] = defaultSteppersValue[key];
  };

  active = (key: AgreementFormsStepperKeys) => {
    this.reset(this.currentlyActive);
    this.currentlyActive = key;
    sessionStorage.setItem('activeStepperKey', key);

    if (this.steppers[key].tab === TabsState.DONE) {
      this.steppers[key].tabText = TabsTextState.ACTIVE;

      return;
    }

    this.steppers[key] = {
      tab: TabsState.ACTIVE,
      tabText: TabsTextState.ACTIVE,
    };
  };

  done = (key: AgreementFormsStepperKeys) => {
    this.steppers[key] = {
      tab: TabsState.DONE,
      tabText: TabsTextState.DONE,
    };
  };

  next = (): AgreementFormsStepperKeys | undefined => {
    const keys = Object.keys(this.steppers) as AgreementFormsStepperKeys[];
    const currentIndex = keys.indexOf(this.currentlyActive);
    const nextKey = keys[currentIndex + 1] as AgreementFormsStepperKeys;

    if (currentIndex === keys.length - 1) {
      return undefined;
    }

    this.done(this.currentlyActive);
    this.active(nextKey);

    return nextKey;
  };

  previous = (): AgreementFormsStepperKeys | undefined => {
    const keys = Object.keys(this.steppers) as AgreementFormsStepperKeys[];
    const currentIndex = keys.indexOf(this.currentlyActive);
    const previousKey = keys[currentIndex - 1] as AgreementFormsStepperKeys;

    if (currentIndex === 0) {
      return undefined;
    }

    this.reset(this.currentlyActive);
    this.active(previousKey);

    return previousKey;
  };
}

export default AgreementFormStepperStore;
