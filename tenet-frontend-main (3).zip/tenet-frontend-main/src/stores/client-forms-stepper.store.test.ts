import { ClientFormStepperKeys } from '../types/client-forms';
import ClientFormStepperStore from './client-forms-stepper.store';

describe('ClientFormStepperStore', () => {
  let store: ClientFormStepperStore;

  beforeEach(() => {
    store = new ClientFormStepperStore();
  });

  describe('next method', () => {
    it('advances to the next step and updates statuses correctly', () => {
      expect(store.currentlyActive).toBe(ClientFormStepperKeys.PERSONAL);
      store.next();
      expect(store.currentlyActive).toBe(ClientFormStepperKeys.DEMOGRAPHICS);
      expect(store.steppers[ClientFormStepperKeys.PERSONAL].tab).toBe('done-tab');
      expect(store.steppers[ClientFormStepperKeys.DEMOGRAPHICS].tab).toBe('active-tab');
    });
  });

  describe('previous method', () => {
    it('goes back to the previous step and updates statuses correctly', () => {
      store.currentlyActive = ClientFormStepperKeys.DEMOGRAPHICS;
      store.previous();
      expect(store.currentlyActive).toBe(ClientFormStepperKeys.PERSONAL);
      expect(store.steppers[ClientFormStepperKeys.DEMOGRAPHICS].tab).toBe('default-tab');
      expect(store.steppers[ClientFormStepperKeys.PERSONAL].tab).toBe('active-tab');
    });

    it('returns undefined and does not change state when on the first step', () => {
      store.currentlyActive = ClientFormStepperKeys.PERSONAL;
      const result = store.previous();
      expect(result).toBeUndefined();
      expect(store.currentlyActive).toBe(ClientFormStepperKeys.PERSONAL);
    });
  });
});
