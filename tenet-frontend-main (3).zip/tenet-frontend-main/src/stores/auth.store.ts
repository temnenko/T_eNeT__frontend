import { action, computed, observable } from 'mobx';

import type { SetAuthInput } from '../types/user';
import { authService } from '../services/auth.service';
import { appEventService } from '../services/app-events.service';

class AuthStore {
  @observable accessToken = '';

  @observable refreshToken = '';

  @observable expiresIn = 0;

  @observable expiresAt = 0;

  constructor() {
    appEventService.getEmitter().on('tokensUpdated', (data: SetAuthInput) => {
      this.setAuth(data);
    });
  }

  // eslint-disable-next-line class-methods-use-this
  getLoginUrl = async (idpHint: string) => {
    this.unsetAuth();
    sessionStorage.removeItem('tenet-user');
    sessionStorage.removeItem('tenet-organization');

    await authService.logout();
    await authService.getLoginUrl(idpHint);
  };

  @action setAuth(input: SetAuthInput) {
    this.accessToken = input.accessToken;
    this.refreshToken = input.refreshToken;
    this.expiresAt = input.expiresAt;
    this.expiresIn = input.expiresIn;
  }

  @action unsetAuth() {
    this.accessToken = '';
    this.refreshToken = '';
    this.expiresAt = 0;
    this.expiresIn = 0;
  }

  getAuth() {
    return {
      accessToken: this.accessToken,
      refreshToken: this.refreshToken,
      expiresAt: this.expiresAt,
      expiresIn: this.expiresIn,
    };
  }

  @computed get isAuthenticated() {
    return !!this.accessToken;
  }

  @computed get headerUrl() {
    return this.accessToken ? '/dashboard' : '/';
  }
}

export default AuthStore;
