export default {
  preset: 'ts-jest',
  testEnvironment: 'jest-environment-jsdom',
  transform: {
    '^.+\\.tsx?$': [
      'ts-jest',
      {
        diagnostics: {
          ignoreCodes: [1343],
        },
        astTransformers: {
          before: [
            {
              path: 'node_modules/ts-jest-mock-import-meta',
              options: { metaObjectReplacement: { url: 'https://www.url.com' } },
            },
          ],
        },
      },
    ],
    // process `*.tsx` files with `ts-jest`
  },
  transformIgnorePatterns: [
    '/node_modules/(?!exceljs)', // Adjust this regex
  ],
  moduleNameMapper: {
    '\\.(gif|ttf|eot|svg|png)$': '<rootDir>/test/mocks/assets.js',
    '^uuid$': '<rootDir>/node_modules/uuid/dist',
  },
  testTimeout: 10000,
};
