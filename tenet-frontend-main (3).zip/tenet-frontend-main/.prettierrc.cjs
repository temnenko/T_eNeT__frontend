module.exports = {
  tabWidth: 2,
  semi: true,
  printWidth: 120,
  singleQuote: true,
};
