#!/bin/sh
# Substitute environment variables
envsubst < /usr/share/nginx/html/config.template.json > /tmp/config.json

exec nginx -g 'daemon off;'